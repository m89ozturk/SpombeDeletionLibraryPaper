imputeBetaRandomNumbersPerColumn_v2 <- function (data_set, start = 0.01, end = 0.05, shape1 = 2, shape2 = 2, 
                                                 impute_data_frame = TRUE, impute_prefix = "imputed.", seed = 1234) 
{
  original_data <- data_set
  if (impute_data_frame) {
    imputed_values_df <- data.frame()
  }
  set.seed(seed)
  imputing_data = data.frame()
  for (col_name in names(data_set)) {
    if (start <= 1) {
      min_index <- ifelse(as.integer(length(data_set[[col_name]]) * 
                                       start) < 1, 1, as.integer(length(data_set[[col_name]]) * 
                                                                   start))
      beta_min <- sort(data_set[[col_name]], na.last = TRUE)[min_index]
    } else {
      beta_min <- start
    }
    if (end <= 1) {
      max_index <- ifelse(as.integer(length(data_set[[col_name]]) * 
                                       end) < 1, 1, as.integer(length(data_set[[col_name]]) * 
                                                                 end))
      beta_max <- sort(data_set[[col_name]], na.last = TRUE)[max_index]
      beta_max <- ifelse(is.na(beta_max), max(data_set[[col_name]], na.rm = TRUE), beta_max)
    } else {
      beta_max <- end
    }
    count_NA_values <- sum(is.na(data_set[[col_name]]))
    seed_as_string <- ifelse(is.null(seed), "NULL", seed)
    imputing_data <- rbind(imputing_data, data.frame(column = col_name, 
                                                     start = start, end = end, shape1 = shape1, shape2 = shape2, 
                                                     NA_values = count_NA_values, beta_min = beta_min, 
                                                     beta_max = beta_max, seed = seed_as_string))
    random_numbers <- rbeta(count_NA_values, shape1, shape2) * 
      (beta_max - beta_min) + beta_min
    if (impute_data_frame) {
      imputed_values_df <- rbind(imputed_values_df, data.frame(value_type = c("original"), 
                                                               value = na.omit(data_set[[col_name]]), column = c(col_name), 
                                                               stringsAsFactors = FALSE))
      if (length(random_numbers) > 0) {
        imputed_values_df <- rbind(imputed_values_df, 
                                   data.frame(value_type = c("imputed"), value = random_numbers, 
                                              column = c(col_name)))
      }
    }
    data_set[col_name] <- replace(data_set[col_name], is.na(data_set[col_name]), 
                                  random_numbers)
  }
  colnames(data_set) <- paste0(impute_prefix, names(data_set))
  result <- list(imputed_values = data_set, imputing_data = imputing_data, 
                 original_data = original_data)
  if (impute_data_frame) {
    result$imputed_histogram <- imputed_values_df
  }
  return(result)
}


calculateAverages_v2 <- function (data_set, global_regex = "^(.*)_\\d+$", 
                sel_regex="^log2.LFQ.intensity.", imp_regex="imputed", cores=1)  
{
  require(parallel)
  #global_regex <- "^log2\\.LFQ\\.intensity\\..*" ## to grep log2.LFQ intensities column names
  sel_columns <- unique(gsub(global_regex, "\\1", grep(sel_regex, 
                                                    colnames(data_set), value = TRUE)))
  if (length(sel_columns) < 1) {
    stop(sprintf("There are no \"%s\"-columns in this data set!", sel_regex))
  }
  dflist <- mclapply(sel_columns, function(col_name){
    experiment <- gsub(sel_regex, "", col_name)  
    
    # numbers of sel columns
    raw_col_numbers <- grep(paste0("^", col_name), colnames(data_set))
    if (length(raw_col_numbers) < 1) {
      stop(sprintf("There is no raw column in the dataset \"%s\"", col_name))
    }
    
    #numbers of imputed columns
    if (imp_regex!="") { imp_regex= paste0(imp_regex, ".", col_name) }
    imp_col_numbers <- grep(imp_regex, colnames(data_set))
    if (length(imp_col_numbers) < 1) {
      stop(sprintf("There is no imputed column in the dataset \"%s\"", col_name))
    }
    
    # MEANS
    # Mean using measured values
    mean1_narm <- apply(data_set[raw_col_numbers], 1, mean, na.rm = TRUE)
    mean1_narm[is.nan(mean1_narm)] <- NA
        # na.rm is required to compute the mean of a prot group in less than 4 replicates
    
    # Mean using imputed values
    mean2_imp <- apply(data_set[imp_col_numbers], 1, mean)
        # here we have all values, no na.rm required
    
    # Mean using imputed values in non-detected proteins
    mean3_naimp <- mean1_narm
    mean3_naimp[is.na(mean3_naimp)] <- mean2_imp[is.na(mean3_naimp)]
        # for the prot groups that are present in less than 4 replicates
    
    # MEDIANS
    median1_narm <- apply(data_set[raw_col_numbers], 1, median, na.rm = TRUE)
    median1_narm[is.nan(median1_narm)] <- NA
    
    median2_imp <- apply(data_set[imp_col_numbers], 1, median)
    
    median3_naimp <- median1_narm
    median3_naimp[is.na(median3_naimp)] <- median2_imp[is.na(median3_naimp)]
    
    # COUNTS (of measured values per prot group)
    value_count <- apply(data_set[raw_col_numbers], 1, function(x) sum(!is.na(x)))
    
    # Construct the resulting data frame 
    resdf <- data.frame(mean1_narm, mean2_imp, mean3_naimp, median1_narm,
                        median2_imp, median3_naimp, value_count)
    colnames(resdf) <- paste0(colnames(resdf), "_", experiment)
    
    return(resdf)
    }, mc.cores = cores)
 do.call(cbind, dflist)   
}

## Get gene info from Biomart of a vector of (protein) ids
getGenes_biomart <- function(input_vector, sp_search="sapiens",  
                    grep_input= "ensembl_peptide_id"){
    require(biomaRt)
    biom <- listMarts()$biomart[grep("Genes", listMarts()$version)]
    mart <- useMart(biomart = biom)
    
    if(length(grep(sp_search, listDatasets(mart)$description)) >= 1){
      dset <- as.character(listDatasets(mart)$dataset[grep(sp_search, listDatasets(mart)$description)[1]])
      mart <- useMart(biomart = biom, dataset = dset)
    } else {
      return("No dataset found. Please check the search term for the species.")
    }
    
    geneid_name <- listAttributes(mart)$name[grep("Gene ID", listAttributes(mart)$description)[1]]
    genename_name <- listAttributes(mart)$name[grep("Gene Name", listAttributes(mart)$description)[1]]
    
    split_pept_l <- strsplit(input_vector, ";")
    names(split_pept_l) <- input_vector
    split_pept <- unlist(split_pept_l)
    names(split_pept) <- unlist(sapply(1:length(split_pept_l), function(x){
                                rep(names(split_pept_l)[x], length((split_pept_l)[[x]]))
                                }))
    
    if (grepl(".", split_pept[1])){
            split_pept <- sapply(strsplit(split_pept, "[.]"), "[", 1)
    }
    
    gene_data <- getBM(attributes = c(grep_input, geneid_name, genename_name), filters=grep_input, 
                    values = split_pept, mart = mart, uniqueRows = FALSE)
                    
    if (identical(names(split_pept), split_pept)){
        resBM <- merge(as.data.frame(split_pept), gene_data, by.x="split_pept", by.y=grep_input, all.x=TRUE) 
    }else{  
        resBM <- merge(data.frame(orig_ids=names(split_pept), in_ids=split_pept, 
                    stringsAsFactors=FALSE), gene_data, by.x="in_ids", by.y=grep_input, all.x=TRUE)
        #resBM <- ddply(resBM, .(orig_ids), paste, collapse=";")
        resBM <- as.data.frame(aggregate(.~orig_ids, data=resBM, paste, collapse=";"))
        resBM <- resBM[,-2]
        resBM <- matrix(apply(resBM, 2, rm_dup_col, spl_char=";"), ncol=3)
    }
    #rownames(gene_data) <- NULL
    colnames(resBM) <- c("Prot.IDs", "Gene.IDs", "Gene.Names")
    return(as.data.frame(resBM))
}


# Remove excess of ";" in annot columns
remv_spaces_col <- function(mycol, spl_char=";"){
        sapply(1:length(mycol), function(x){
                spl <- unlist(strsplit(mycol[x], spl_char))
                spl <- spl[spl != ""]
                spl <- paste(spl, collapse=spl_char)
                if(identical(spl, character(0))){ spl="" }
                return(spl)    
                })
}                
      
# Remove duplicates and spaces in columns
rm_dup_col <- function(mycol, spl_char=";"){
        sapply(1:length(mycol), function(x){
            chars <- unlist(strsplit(mycol[x], spl_char))
            chars <- chars[chars!= ""]       
            chars <- paste(unique(chars), collapse=spl_char)
            if(identical(chars, character(0))){ chars="" }
            return(chars)
            })
}


    
getEntrez_biomart_simple <- function(invector, sp_search="sapiens", 
                            attrib_in="ensembl_peptide_id", outquery="EntrezGene ID"){
    require(biomaRt)
    biom <- listMarts()$biomart[grep("Genes", listMarts()$version)]
    mart <- useMart(biomart = biom)
    
    if(length(grep(sp_search, listDatasets(mart)$description)) >= 1){
      dset <- as.character(listDatasets(mart)$dataset[grep(sp_search, listDatasets(mart)$description)[1]])
      mart <- useMart(biomart = biom, dataset = dset)
    } else {
      return("No dataset found. Please check the search term for the species.")
    }
    
    geneid_name <- listAttributes(mart)$name[grep(outquery, listAttributes(mart)$description)[1]]
 
    gene_data <- unlist(getBM(attributes = geneid_name, filters=attrib_in, 
                            values = invector, mart = mart))
                           
    names(gene_data) <- NULL
    return(gene_data)
}


# Get Entrez IDs from Gene Names of biomart
getEntrezFromGenes_biomart <- function(geneNamesList, sp_search="sapiens", geneFilter=c("name", "id"), sgd=c("no", "yes"), cores=1){
    require(biomaRt)
    biom <- listMarts()$biomart[grep("Genes", listMarts()$version)]
    mart <- useMart(biomart = biom)
    
    if(length(grep(sp_search, listDatasets(mart)$description)) >= 1){
      dset <- as.character(listDatasets(mart)$dataset[grep(sp_search, listDatasets(mart)$description)[1]])
      mart <- useMart(biomart = biom, dataset = dset)
    } else {
      return("No dataset found. Please check the search term for the species.")
    }
    if (sgd=="no") {
        # Define entrez id attribute name (output)
        gene_entrez_name <- listAttributes(mart)$name[grep("EntrezGene ID", listAttributes(mart)$description)[1]]
    }else{ 
        gene_entrez_name <- "sgd_gene" 
        }
    
    # Get the input filters to pass to BiomaRt
    if (geneFilter=="name") { geneFilter <- "external_gene_name" }
    if (geneFilter=="id") { geneFilter <- listAttributes(mart)$name[grep("Gene ID", 
                                    listAttributes(mart)$description)[1]] }
  
    # Call biomaRt
    gene_data <- mclapply(geneNamesList, function(namesVector){
                        single_ids_df <- getBM(attributes = c(geneFilter, gene_entrez_name), filters=geneFilter, 
                                            values = namesVector, mart = mart)
                        single_ids_df <- single_ids_df[!is.na(single_ids_df[,2]),]    
                        single_ids <- single_ids_df[,2]                  
                        names(single_ids) <- single_ids_df[,1]
                        return(single_ids)
                        }, mc.cores= cores)
    
    names(gene_data) <- names(geneNamesList)
    return(gene_data)
}


# Get the first occurrence of splited chars from 1 column
simplify_column <- function(column, mychar=";", index=1){
    sapply(column, function(mycol){
         unlist(strsplit(mycol, mychar))[index]
         })
    }

# Get all the occurrences of splited chars from 1 column
simplify_column_all <- function(column, mychar=";"){
    unlist(sapply(column, function(mycol){
         unlist(strsplit(mycol, mychar))
         }))
    }


rmdot_column <- function(column){
     sapply(column, function(cell){
         unlist(strsplit(cell, "[.]"))[1]
         })
}


# To get the numbers of filtered PGs by different criteria of value counts
count_filt <- function(pg_df, stat_table, myfilters, sel=c("any", "all", "sel"), 
                       selnames=""){
  if (sel=="sel" & selnames!="") {
    for(i in myfilters) {
      pg_df <- rbind(pg_df, c(paste("quantified", selnames, i, sep="_"), 
              nrow(stat_table[apply(stat_table[grep(paste0('value_count_', 
                                                           selnames), 
                    colnames(stat_table))] >= i, 1, all),])))
      }
  } else if (sel=="sel" & selnames=="") { 
    for(i in myfilters) {
      pg_df <- rbind(pg_df, c(paste("quantified", "all", i, sep="_"), 
              sum(apply(stat_table[,grep('value_count', colnames(stat_table))], 
                        1, function(x){ sum(x) >= i }))))
      }
  } else {                  
      for(i in myfilters) {
        pg_df <- rbind(pg_df, c(paste("quantified", sel, "condition", i, 
                                      sep="_"), 
                  nrow(stat_table[apply(stat_table[grep('value_count', 
                        colnames(stat_table))] >= i, 1, sel),])))
      }
  }    
  pg_df$count <- as.numeric(pg_df$count)
  return(pg_df)
}

# Function to filter PGs by a specific filter (returns the PG names as vector)
get_filt_names <- function(stat_table, myfilter, sel=c("any", "all", "sel"), 
                           selnames=""){
  if (sel=="sel" & selnames!="") {
    pg_filt_names <- rownames(stat_table
                      [apply(stat_table[grep(paste0('value_count_', selnames), 
                      colnames(stat_table))]  >= myfilter, 1, all),])
  } else if (sel=="sel" & selnames=="") { 
    pg_filt_names <- rownames(stat_table)[apply(stat_table[grep('value_count', 
                colnames(stat_table))], 1, function(x){ sum(x) >= myfilter })]
  } else {                  
    pg_filt_names <- rownames(stat_table
      [apply(stat_table[grep('value_count', colnames(stat_table))] >= myfilter,
             1, sel),])
  }    
  return(pg_filt_names)
}


# Value count plot where you can modify the columns to plot
createValueCountPlot_v2 <- function (data_set_int, data_set_stats, facet = TRUE, xvalue_regex = "^value_count_", yvalue_regex = "^log2.LFQ.intensity.") 
{
  data_set_stats <- data_set_stats[rownames(data_set_int),]
  data_set_int$Protein.IDs <- rownames(data_set_int)
  data_set_stats$Protein.IDs <- rownames(data_set_stats)
  
  value.x <- value.y <- NULL
  df <- melt(data_set_int[c("Protein.IDs", grep(yvalue_regex, colnames(data_set_int), value = TRUE))], 
             "Protein.IDs")
  df$variable <- sub(paste0(yvalue_regex, "([^_]+)_\\d"), "\\1",  df$variable)
  
  df2 <- melt(data_set_stats[c("Protein.IDs", grep(xvalue_regex, colnames(data_set_stats), value = TRUE))],
              "Protein.IDs")
  df2$variable <- sub(paste0(xvalue_regex, "([^_]+)"), "\\1", df2$variable)
  
  df3 <- subset(merge(df, df2, by = c("Protein.IDs", "variable")), value.y > 0) 
  # this stands for identified proteins (identififed in at least 1 replicate)
  
  # plot
  graph <- ggplot(df3, aes(factor(value.y), value.x, color = factor(value.y))) + 
    geom_point(position = position_jitter(width = 0.3), alpha = 0.2) + 
    geom_boxplot(alpha = 0.5, color = "black", outlier.shape = 3) + 
    scale_y_continuous(minor_breaks = seq(100), breaks = seq(0, 
                       100, 5)) + theme_imb() + xlab("value count") + 
                       ylab("log2(LFQ intensity)") + 
    ggtitle("Measured intensity grouped by value counts") + 
    guides(color = FALSE) 
  if (facet) {
    graph <- graph + facet_wrap(~variable)
  }
  return(graph)
}


# Create correlation plot of different intensity columns
createCorrelationPlot_v2 <- function (df, grepterm, col_names, norm='', limits = c(0, 1),
                                        margs=c(10,10)) {
  require(gplots)
  df <- df[,grep(grepterm, colnames(df))]
  colnames(df) <- col_names
  ratio_corr <- cor(scale(df), use = "complete.obs", method = "spearman")
  hmcol = colorRampPalette(brewer.pal(10, "RdBu"))(length(ratio_corr))
  pdf(file=file.path(out_dir, paste0(sprintf('correlation_plot_%s_', pg_basename), grepterm,
       '_', norm, '.pdf')), width=12, height=12)      
  heatmap.3(ratio_corr, col=hmcol, Rowv=NA, Colv="Rowv", margins=margs, 
          main=paste0("Correlation matrix ", grepterm), cellnote=round(ratio_corr,2), 
          notecol="black", notecex=0.7, trace="none", scale="none", symm=TRUE, 
          colsep=c(1:length(colnames(ratio_corr))), rowsep=c(1:length(rownames(ratio_corr))), 
          sepcolor="black", sepwidth=c(0.01,0.01),dendrogram="none", density.info="none",
          key=TRUE, keysize=0.8, lwid=c(1.5,6), lhei=c(0.8,6))
  
  dev.off()
  #return(correlation_matrix_plot2)
}


# Create correlation of PG identified
get_pg_corr <- function(x){
    data_set_stats <- data_set_stats[rownames(data_set_int),]
    data_set_int$Protein.IDs <- rownames(data_set_int)
    data_set_stats$Protein.IDs <- rownames(data_set_stats)
    
    value.x <- value.y <- NULL
    df <- melt(data_set_int[c("Protein.IDs", grep(yvalue_regex, colnames(data_set_int), value = TRUE))], 
               "Protein.IDs")
    df$variable <- sub(paste0(yvalue_regex, "([^_]+)_\\d"), "\\1",  df$variable)
    
    df2 <- melt(data_set_stats[c("Protein.IDs", grep(xvalue_regex, colnames(data_set_stats), value = TRUE))],
                "Protein.IDs")
    df2$variable <- sub(paste0(xvalue_regex, "([^_]+)"), "\\1", df2$variable)
    
    df3 <- subset(merge(df, df2, by = c("Protein.IDs", "variable")), value.y > 0) 
    
    
    sampleOverlap <- function(data,sampleID='Experiment',referenceID='Protein.IDs'){
      pgs <- by(data,data[,sampleID],function(x) unique(as.character(x[,referenceID])))
      pgsmatch <- lapply(pgs, function(x,y) { 
        lapply(y, function(y) length(intersect(x,y))/length(union(x,y))) } , pgs)
      m <- matrix(unlist(pgsmatch),nrow=length(pgs),ncol=length(pgs),byrow=TRUE)
      colnames(m) <- rownames(m) <- names(pgs)
      ans <- list(Peptides=pgs,M=m)
      return(ans)
    }
    pepovl <- sampleOverlap(pep.melt.narm, sampleID='variable',referenceID='Protein.IDs')
    
    heatmap.2(pepovlM*100, col=hmcol, Rowv=NA, Colv="Rowv", margins=c(15,10), 
              main="Sample to sample peptide identification overlap matrix", cellnote=round(pepovlM*100,1), 
              notecol="black", notecex=1.5, trace="none", keysize=1, scale="none", symm=TRUE, 
              colsep=c(1:length(colnames(pepovlM))), rowsep=c(1:length(rownames(pepovlM))), 
              sepcolor="black", sepwidth=c(0.01,0.01),dendrogram="none")
}




# To plot 2 components of the PCA
plotpca2d_ggplot <- function(pairvector, prcompsumm, prcomptable){
  pca_graph_prcomp <- ggplot(prcomptable, 
                      aes(x=prcomptable[,grep(paste0("PC", pairvector[1]), 
                      colnames(prcomptable))], y=prcomptable[,grep(paste0("PC",
                      pairvector[2]), colnames(prcomptable))], group=condition)) + 
    geom_point(aes(shape=condition, color=condition)) + theme_bw() + 
    xlab(paste0("PC", pairvector[1], " - ", 
          round(prcompsumm$importance[2,pairvector[1]] * 100, 0), "%")) +
    ylab(paste0("PC", pairvector[2], " - ", 
          round(prcompsumm$importance[2,pairvector[2]] * 100, 0), "%")) +
    scale_shape_manual(values=c(rep(c(15,16,17,18), each=8))) +
    scale_color_manual(values = rep(brewer.pal(9, 'Set1')[-6], 
          ceiling(length(unique(prcomptable$condition))/8))) +
    geom_text(aes(label=replicate), vjust=1.2) +
    ggtitle('Principal component analysis with all replicates')
  print(pca_graph_prcomp)
}



# Plot PCA of dataset
pca_subset <- function(regex="", dataset, compnum=3, name=""){
    # this allows to grep any regex of interest in the colnames of the dataset
    pca_columns <- grep(regex, colnames(dataset))
    # this calculates the pcs
    pg_prcomp <-prcomp(t(na.omit(dataset[,pca_columns])), scale. = TRUE)
    # gets the new coordinates of the number of PCs we decided to plot 
    pr_comp_table <- as.data.frame(pg_prcomp$x[,1:compnum])
    # format to fit the ggplot function
    pr_comp_table$replicate <- as.factor(sub('.*_(\\d+)','\\1', 
                                             rownames(pr_comp_table)))
    pr_comp_table$condition <- 
      as.factor(sub('.*intensity\\.(.*)_(\\d+)','\\1', rownames(pr_comp_table)))
    # creates a list with all the possible pairs for the number of PCs 
    # we want to plot
    pairs <- combn(compnum, 2, simplify=FALSE)
    # plot storing in a pdf file, 'name' is the optional label we would 
    # like to add to the filename
    pdf(file=file.path(out_dir, paste0('pca_', pg_basename, "_", name,
                                       '_prcomp.pdf')), width=8, height=8)
    # computes the plots in a loop, all the figures would be in different pages
    sapply(pairs, plotpca2d_ggplot, prcomptable=pr_comp_table, 
           prcompsumm=summary(pg_prcomp))
    dev.off()
    # it returns the whole prcomp object; summary() of the object will return the variance of each PC
    return(pg_prcomp)
    }


# Do t-test over an imputed set of 2 conditions 
get_ttest_pair <- function(exppair, dataset, intenslab='imputed.bpca', 
                    statlab='bpcaimp', selstat="mean3_naimp", myfilter=0){
    exppair <- as.character(exppair)               
    exp_a <- exppair[1]
    exp_b <- exppair[2]
    # select especific columns
    #sellab <- paste0(intenslab,"|", implab)
    intenscols <- grep(intenslab, colnames(dataset),value=TRUE)
    statcols <- grep(statlab, colnames(dataset),value=TRUE)    
    # get the cols from a and from b
    col_a <- grep(exp_a, intenscols, value=TRUE)
    col_b <- grep(exp_b, intenscols, value=TRUE)
    # get the cols to compute the difference
    col_dif_a <- grep(paste(selstat, exp_a, sep='_'), statcols, value=TRUE)
    col_dif_b <- grep(paste(selstat, exp_b, sep='_'), statcols, value=TRUE)
    # get the value_counts columns for exp_a and exp_b
    col_vc_a <- grep(paste0("value_count_", exp_a), statcols, value=TRUE) 
    col_vc_b <- grep(paste0("value_count_", exp_b), statcols, value=TRUE)
    # Select only the pgs that have at least a number of 'myfilter' in 1 of the 2 groups
    df <- dataset[apply(dataset[,c(col_vc_a, col_vc_b)] >= myfilter, 1, any),]
    # Loop for t-test in the subset df
    ttest_pg <- lapply(1:nrow(df), function(x) {
              pval <- t.test(df[x, col_a], df[x,col_b])$p.value
              mean_a <- t.test(df[x, col_a], df[x, col_b])$estimate[1]
              mean_b <- t.test(df[x, col_a], df[x, col_b])$estimate[2]
              differ <- mean_a -  mean_b
              dmean_set <- df[x,col_dif_a] - df[x,col_dif_b]
              data.frame(mean_a, mean_b, dmean_test=differ, 
                            dmean_set=dmean_set, pvalue=pval)
            })
    # Format result 
    ttest_pg <- do.call(rbind, ttest_pg)
    # Calculate adjusted pvalue
    ttest_pg$fdr <- p.adjust(ttest_pg$pvalue, method="BH")
    # Format 
    ttest_pg$pgnames <- rownames(df)
    rownames(ttest_pg) <- NULL
    colnames(ttest_pg) <- c(paste0('mean_', exp_a), paste0('mean_', exp_b),
        paste('dmean_test', exp_a, exp_b, sep='_'), paste('dmean_set', exp_a, exp_b, sep='_'),
        paste('pvalue', exp_a, exp_b, sep='_'), paste('fdr', exp_a, exp_b, sep='_'),
        "Prot.IDs")
    return(ttest_pg)
}


# Get t-test multi
get_ttest_multi <- function(pairtable, data_set, intens_lab='imputed.bpca', 
        stat_lab='bpcaimp', sel_stat="mean3_naimp", Filter=0, cores=1){
        require(parallel)
        exp_pairs <- lapply(1:nrow(pairtable), function(x){ pairtable[x,]})
        multilist <- mclapply(exp_pairs, get_ttest_pair, dataset=data_set, 
                        intenslab=intens_lab, statlab=stat_lab, selstat=sel_stat, 
                        mc.cores=cores, myfilter=Filter)
        # Change names before merge
        multilist <- lapply(seq(multilist), function(x){ 
            z <- multilist[[x]]
            inds_nopg <- grep("Prot.IDs", colnames(z), invert=TRUE)
            colnames(z)[inds_nopg] <- paste(colnames(z)[inds_nopg], x, sep=":")
            return(z)
        })            
        # Merge
        multitable <- Reduce(function(x,y){ merge(x,y, by="Prot.IDs", all=TRUE) }, multilist)
        # Change names after merge
        colnames(multitable)[-1] <- sapply(strsplit(colnames(multitable)[-1], 
                                                    ":"), "[", 1)
        rownames(multitable) <- multitable$Prot.IDs
        multitable$Prot.IDs <- NULL    
        return(multitable)
        }
        

# Get diff expressed pgs using Mann-Whitney test
get_dpg_mw_pair <- function(exppair, dataset, intenslab='imputed.bpca'){
        selcols <- grep(intenslab, colnames(dataset), value=TRUE)
        exp_a <- exppair[1]
        exp_b <- exppair[2]
        cols_a <- grep(exp_a, selcols, value=TRUE)
        cols_b <- grep(exp_b, selcols, value=TRUE)
        wtest <- lapply(1:nrow(dataset), function(x){
            intens_1 <- as.numeric(dataset[x,cols_a])
            intens_2 <- as.numeric(dataset[x,cols_b])
            mean_1 <- mean(intens_1, na.rm=TRUE)
            mean_2 <- mean(intens_2, na.rm=TRUE)
            Dmean <- mean_1 - mean_2
            pvalt <- wilcox.test(intens_1,intens_2, correct=TRUE)$p.value
            data.frame(mean_1, mean_2, Dmean, Pvalue=pvalt)
            })
        wtest <- do.call(rbind, wtest)
        wtest$fdr <- p.adjust(wtest$Pvalue, method="BH")
        rownames(wtest) <- rownames(dataset)
        colnames(wtest) <- c(paste0("mean_", exp_a), paste0("mean_", exp_b), 
                            paste(colnames(wtest)[3:5], exp_a, exp_b, sep='_'))
        return(wtest)
}        

# Get diff expressed pgs using Mann-Whitney test (mutiple comparisons)
get_dpg_mw_multi <- function(pairtable, data_set, intens_lab='imputed.bpca', cores=1){
        require(parallel)
        exp_pairs <- lapply(1:nrow(pairtable), function(x){ pairtable[x,]})
        multilist <- mclapply(exp_pairs, get_dpg_mw_pair, dataset=data_set, 
                        intenslab=intens_lab, mc.cores=cores)
        multitable <- do.call(cbind, multilist)
}
  
    
# Annotate stats using BiomaRt
get_annot_stats <- function(test_stats_df, species_tag="sapiens"){
    annot_table <- getGenes_biomart(input_vector=rownames(test_stats_df),
                             sp_search=species_tag)
    df <- merge(test_stats_df, annot_table, by.x="row.names", by.y="Prot.IDs", all.x=TRUE)  
    df$label <- df$Gene.Names
    colnames(df)[1] <- "Prot.IDs"
    subnames <- df[is.na(df$Gene.Names), "Prot.IDs"]
    subnames <- simplify_column(subnames)
    df[is.na(df$Gene.Names), "label"] <- paste0("(",subnames, ")")
    df$label <- simplify_column(df$label)
    rownames(df) <- df$Prot.IDs    
    return(df)
}    


# Volcanos   
plot_volcano_multi <- function(comparedf, dataset, diff_cutoff=0, pval_cutoff=1, pval_label= "fdr", 
        meanlbl="Dmean", datalbl="", plot_lbl=TRUE, plot_more=FALSE){
    require(calibrate)    
    pdf(file=file.path(out_dir, paste0('volcanos_', pg_basename, '_', 
        datalbl, '.pdf')), width=8, height=8)
        for(line in 1:nrow(comparedf)) {
            #dataset<- as.matrix(dataset)
            exp_a <- comparedf[line,1]
            exp_b <- comparedf[line,2] 
            mean_col <- paste(meanlbl, exp_a, exp_b, sep='_')
            pval_col <- paste(pval_label, exp_a, exp_b, sep='_')
            log_pval_col <- paste0("neg_log_", pval_col)
            df <- dataset[, c(mean_col, pval_col, "label")]
            df$log_col <- -log10(df[,pval_col])
            colnames(df)[ncol(df)] <- log_pval_col
            max_x <- max(abs(df[,mean_col]), na.rm = TRUE)
            max_y <- max(df[,log_pval_col], na.rm = TRUE)
            plot(df[,mean_col], df[,log_pval_col], pch=20, 
                main=paste("Volcano plot -", exp_b, "vs", exp_a), xlim= c(-max_x*1.05, max_x*1.05),
                ylim=c(-max_y*0.05 ,max_y*1.05), xlab="Mean difference in (log2) expression",
                ylab="-log10(p-value)")
            # Define subsets to plot    
            df_green <- subset(df, df[,pval_col] < pval_cutoff & (df[,mean_col] > diff_cutoff | 
                            df[,mean_col] < -diff_cutoff))
            df_red <- subset(df, df[, pval_col] < pval_cutoff)
            df_red <- df_red[setdiff(rownames(df_red), rownames(df_green)),]
            df_orange <- subset(df, df[, mean_col] > diff_cutoff | df[, mean_col] < -diff_cutoff)  
            df_orange <- df_orange[setdiff(rownames(df_orange), rownames(df_green)),]
            # Plot subsets
            points(df_red[,mean_col], df_red[,log_pval_col], pch=20, col="red")
            points(df_orange[,mean_col], df_orange[,log_pval_col],  pch=20, col="orange")
            points(df_green[,mean_col], df_green[,log_pval_col],  cex=1.5, pch=20, col="green")
            abline(h = -log10(pval_cutoff), v = c(-diff_cutoff,diff_cutoff), col = "blue", lty =2, lwd = 1)
            # Plot labels
            if (plot_lbl) {
                    par(xpd=TRUE)
                    textxy(df_green[,mean_col], df_green[,log_pval_col],
                            labs=df_green$label, cex=.5, offset=0.7)
                    par(xpd=FALSE)
                    }
             if (plot_more) {
                    par(xpd=TRUE)
                    textxy(df_red[,mean_col], df_red[,log_pval_col],
                            labs=df_red$label, cex=.4)   
                    textxy(df_orange[,mean_col], df_orange[,log_pval_col],
                            labs=df_orange$label, cex=.4)            
                    par(xpd=FALSE)
                    }       
        }
    dev.off()
}
    




# Get stats from signif prot for a comparison
get_sign_meantable <- function(condname, meanrestable, cutoff=1, dm_cutoff=0, dmeanlb="dmean_set",
                        pvallbl="fdr"){
        seldf <- meanrestable[, grep(condname, colnames(meanrestable))]
        pval_col <- colnames(seldf[grep(pvallbl, colnames(seldf))])
        dmean_col <- colnames(seldf[grep(dmeanlb, colnames(seldf))])
        resdf <- subset(seldf, seldf[,pval_col] <= cutoff & abs(seldf[,dmean_col]) >= dm_cutoff)
          #rownames(seldf)[seldf[,pval_col] <= cutoff & abs(seldf[,dmean_col]) >= dm_cutoff]
        #resdf <- seldf[sign_pg,]
        return(list(signNames=rownames(resdf), signTable=resdf))
        }



# Get stats from signif prot for multiple comparisons
get_sign_meantable_multi <- function(pair_table, restable, pval_cut=1, dm_cut=0, dmean_lbl="dmean_set",
                        pval_lbl="fdr", cores=1){
        require(parallel)
        exp_pairs <- lapply(1:nrow(pair_table), function(x){ pair_table[x,]})
        exps <- lapply(exp_pairs, paste, collapse="_")
        multi_list <- mclapply(exps, get_sign_meantable, meanrestable=restable, cutoff=pval_cut, 
                        dm_cutoff=dm_cut, dmeanlb=dmean_lbl, pvallbl=pval_lbl, mc.cores=cores)
        names(multi_list) <- sapply(exp_pairs, paste, collapse="_")               
        multi_table <- sapply(multi_list,"[",2)
        multi_vector <- sapply(multi_list,"[",1)
        return(list(multi_vector, multi_table))
}




# Annotate and store
get_annot_store <- function(sign_object, species_lbl="sapiens", input_val="ensembl_peptide_id",
                    pval_ord="pval", store_lbl="", cores=1){
        annot_list <- mclapply(sign_object[[1]], getGenes_biomart, sp_search=species_lbl, 
                    grep_input=input_val, mc.cores=cores)
        if (length(sign_object[[1]]) != length(annot_list)){
            stop("something weird is going on")
            }
        else{
            finalres_tablelist <- lapply(1:length(annot_list), function(x){
                    ftable <- merge(annot_list[[x]], sign_object[[2]][[x]], by.x="Prot.IDs", 
                        by.y="row.names")
                    pval_col <- grep(pval_ord, colnames(ftable), value=TRUE)
                    ftable <- ftable[order(ftable[,pval_col]),]
                    rownames(ftable) <- NULL
                    comp_name <- sub(".[^.]*$", "", names(sign_object[[2]][x]))
                    # unlist(strsplit(names(sign_object[[2]][x]), "[.]"))[1]
                    write.table(ftable, file=file.path(out_dir, 
                         paste("significant_proteinGroups", comp_name, store_lbl, 
                         "table.tsv", sep="_")), quote = FALSE, sep ="\t", row.names = FALSE)
                    return(ftable)
                    })
             names(finalres_tablelist) <- sub(".[^.]*$", "", names(sign_object[[2]]))
             return(finalres_tablelist)
        }
}


# Select down-regulated proteins
sel_down_annot <- function(annot_table_list, dmean_col="dmean_test", extra_lbl=""){
            res_list <- lapply(1:length(annot_table_list), function(x){
                mydf <- annot_table_list[[x]]
                dmean_col <- grep(dmean_col, colnames(mydf))
                res <- mydf[mydf[,dmean_col] < 0,]
                write.csv(res, file=file.path(out_dir, 
                         paste("significant_proteinGroups_downreg", extra_lbl,
                         names(annot_table_list)[x], "table.txt", sep="_")), quote = FALSE)
                return(res)
                })
            names(res_list) <- names(annot_table_list)   
            return(res_list) 
}


# Get sequences from Biomart by 2 variables values        
get_seqs_biom <- function(annot_table, sp_search="cerevisiae", value1="Gene.Names", value2="Gene.IDs", 
        filter1="external_gene_name", filter2="ensembl_gene_id", seqtype="cdna", 
        extra_cols= "Prot.IDs"){
    require(biomaRt)
    require(splitstackshape)
    options(stringsAsFactors=FALSE)
    biom <- listMarts()$biomart[grep("Genes", listMarts()$version)]
    mart <- useMart(biomart = biom)
    if(length(grep(sp_search, listDatasets(mart)$description)) >= 1){
      dset <- as.character(listDatasets(mart)$dataset[grep(sp_search, listDatasets(mart)$description)[1]])
      mart <- useMart(biomart = biom, dataset = dset)
    } else {
      return("No dataset found. Please check the search term for the species.")
    }
    val1_col <- grep(value1, colnames(annot_table), value=TRUE)
    val2_col <- grep(value2, colnames(annot_table), value=TRUE) 
    seqs_df <- annot_table[,c(extra_cols, val2_col, val1_col)]
    seqs_df[seqs_df[,val1_col] == "", val1_col] <- "_NA_"
    if(any(grepl(";", as.character(annot_table[,val1_col])))) {
        seqs_df <- as.data.frame(cSplit(seqs_df, val1_col, ";", "long"))
        seqs_df[,val1_col] <- as.character(seqs_df[,val1_col])
        }
    seqs_df[seqs_df[,val1_col] == "_NA_", val1_col] <- ""
    input_ids1 <- seqs_df[seqs_df[,val1_col]!="" ,val1_col]
    input_ids1 <- input_ids1[grep("'", input_ids1, invert=TRUE)]
    #if(any(grepl("'", input_ids1))) {
    #        wierdos <- grep("'", input_ids1, value=TRUE)
    #        wierdos <- sapply(strsplit(wierdos, "'"), "[", 1)
    #        input_ids1[grep("'", input_ids1)] <- wierdos
    #        }
    seqs1 <- getSequence(id=input_ids1, type=filter1, seqType=seqtype, mart = mart)
    seqs_df <- merge(seqs_df, seqs1, by.x=val1_col, by.y=filter1, all.x=TRUE)
    if (nrow(seqs1) != nrow(seqs_df)) {
        fail_names <- setdiff(as.character(seqs_df[,val1_col]), seqs1[, filter1])
        input_ids2 <- as.character(seqs_df[seqs_df[,val1_col] %in% fail_names,val2_col])
        if (any(grepl(";", input_ids2))) {
            seqs_df <- as.data.frame(cSplit(seqs_df, val2_col, ";", "long"))
            seqs_df[,val2_col] <- as.character(seqs_df[,val2_col])
            input_ids2 <- unlist(strsplit(input_ids2, ";"))
        }
        seqs2 <- getSequence(id=input_ids2, type=filter2, seqType=seqtype, mart = mart)
        seqs_df <- merge(seqs_df, seqs2, by.x=val2_col, by.y=filter2, all.x=TRUE)
        seqs_df[is.na(seqs_df[,paste0(seqtype, ".x")]), paste0(seqtype, ".x")] <-
               seqs_df[is.na(seqs_df[paste0(seqtype, ".x")]), paste0(seqtype, ".y")] 
        seqs_df[, paste0(seqtype, ".y")] <- NULL
        seq_col_ind <- match(paste0(seqtype, ".x"), colnames(seqs_df))
        colnames(seqs_df)[seq_col_ind] <- seqtype
        }
    return(seqs_df)
}


## Count specific triplets
count_triplet <- function(triplet, sequence){
        start_trp <- seq(1, nchar(sequence), by=3)
        all_triplets <- substring(sequence, start_trp, start_trp+2)
        Nt=length(grep(triplet, all_triplets))
        Tt=length(all_triplets)
        Pt=Nt/Tt
        resdf <- data.frame(query_trp= Nt, total_trp=Tt, prop_trp=Pt)
        colnames(resdf) <- paste(colnames(resdf), triplet, sep="_")
        return(resdf)
}     
  
        
### Get codon usage for annot table
get_codon_usage <- function(codons, annot_table, cdna_col="cdna", cores=1, cBind=TRUE){
        require(parallel)
        codUS_tot <- mclapply(codons, function(x){
            do.call(rbind, lapply(annot_table[,cdna_col], count_triplet, 
                    triplet=x))
            }, mc.cores=cores)
        codUS_tot <- do.call(cbind, codUS_tot)
        if (cBind) { res_df <- cbind(annot_table, codUS_tot) 
        } else { res_df <-codUS_tot }
        return(res_df)
}
    
# Distribution of codon proportions
plot_distr <- function(prop_table, grep_prop="prop", extra_lbl=""){
    pdf(file.path(out_dir, paste0("prop_dist_", extra_lbl, ".pdf")), height=6)
    sapply(grep("prop", colnames(prop_table)), function(x){
        trip <- unlist(strsplit(colnames(prop_table)[x], "_"))[3]
        plot(density(prop_table[,x]), main=paste0("Density of Prop of ", trip),
                xlim=c(0,0.25))
        #abline(v=0, col="gray", lty=2)
        #hist(prop_table[,x], breaks=20)
        })
    dev.off()
}

        

# Compute the stats for the significance of codon usage proportions
get_stats_codon_prop <- function(corr_table, tot_prop_table, sign_table_list, cores=1){
        require(parallel)
        ress <- mclapply(1:nrow(corr_table), function(x){
                mut <- corr_table$mutants[x]
                sign_table <- sign_table_list[[grep(mut, names(sign_table_list))]]
                no_sign_pgs <- setdiff(tot_prop_table$Prot.IDs, sign_table$Prot.IDs)
                no_sign_table <- tot_prop_table[tot_prop_table$Prot.IDs %in% no_sign_pgs,]
                cods <- unlist(strsplit(corr_table$codons[x], ";"))
                res <- lapply(cods, function(y){
                    sign_prop_table <- get_codon_usage(y, annot_table=sign_table, cBind=FALSE)
                    props_sign <- sign_prop_table[, grep(paste0("prop_trp_", y),
                                colnames(sign_prop_table))]
                    props_nosign <- no_sign_table[, grep(paste0("prop_trp_", y),
                                                    colnames(no_sign_table))]
                    # Mann-whitney test     
                    mwtest <- wilcox.test(props_sign, props_nosign, conf.int = TRUE)
                    pval <- mwtest$p.value
                    estim <- unname(mwtest$estimate)
                    dmean <- mean(props_sign, na.rm=TRUE) -  mean(props_nosign, na.rm=TRUE)
                    codUs_df <- data.frame(mutation=mut, codon=y, pvalue=pval, estimator=estim,
                               dmean=dmean)
                    return(list(sign_prop_table, codUs_df, props_sign, props_nosign))
                    })
                cod_df <- do.call(rbind, sapply(res, "[", 2))
                prop_df <- cbind(sign_table, do.call(cbind, sapply(res, "[", 1)))
                propsign_mut <- lapply(res, "[", c(3,4))
                names(propsign_mut) <- paste(mut, cods, sep="_")
                return(list(prop_df, cod_df, propsign_mut))
         }, mc.cores=cores)
         
         cod_df_final <- do.call(rbind, sapply(ress, "[", 2))
         prop_df_list <- sapply(ress, "[", 1)
         names(prop_df_list) <- names(sign_table_list)
         prop_value_list <- unlist(sapply(ress, "[", 3), recursive=FALSE)
         return(list(prop_df_list, cod_df_final, prop_value_list))
}

 
## Plot overlapped densities (sign + no_sign)     
plot_codUs_overl <- function(nosign_subset, sign_subset, cod, mut){        
                        x1 <- density(nosign_subset*100)
                        x2 <- density(sign_subset*100)
                        xmaxlim <- max(max(x1$x), max(x2$x))*1.05
                        ymaxlim <- max(max(x1$y), max(x2$y))*1.05
                        plot(x1, xlim=c(0, xmaxlim), ylim=c(0, ymaxlim), main="",
                                xlab="% of codon in prot. sequence")
                        lines(x2, col="green")
                        title(main=paste0("Density of ", cod, " usage in ", mut, " mutant"))
                        legend("topright", legend=c("Down-regulated", "Rest"), 
                                title=expression(bold("PROTEINS")),
                                col=c("green", "black"), fill=c("green", "black"), cex=0.7)
                        legend("bottomright", bty="n", legend= paste0("num_sign = ", length(sign_subset), 
                                "\nnum_nosign = ", length(nosign_subset), "\n\n\n\n"), cex=0.6)
}                          
        
## Plot overlapped densities (multi)
plot_codUs_overl_multi <- function(data_list, extra_lbl=""){
    pdf(file.path(out_dir, paste0(extra_lbl, "_codon_usage.pdf")))
    lapply(1:length(data_list), function(x){
        nosignsub <- data_list[[x]][[2]]       
        signsub <- data_list[[x]][[1]]
        codon <- unlist(strsplit(names(data_list)[x], "_"))[2]
        mutant <- unlist(strsplit(names(data_list)[x], "_"))[1]
        plot_codUs_overl(nosign_subset=nosignsub, sign_subset=signsub, cod=codon, mut=mutant)
    })
    dev.off()
} 

        
## Plot volcanos of the cod Usage
plot_volcano_codUs <- function(codUs_table, cutoff=1, diff_cutoff=0, extra_lbl=""){      
    pdf(file.path(out_dir, paste0(extra_lbl, "_codonUsage_volcano.pdf")))
    sign <- subset(codUs_table, pvalue < cutoff & estimator > diff_cutoff)
    nosign <- subset(codUs_table, pvalue > cutoff | estimator < diff_cutoff)
    plot(codUs_table$estimator, -log10(codUs_table$pvalue), ylab="-log10(p-value)",
            xlab="Difference in mean values", col="white")
    points(nosign$estimator, -log10(nosign$pvalue), col="black", pch=16)      
    points(sign$estimator, -log10(sign$pvalue), col="green", pch=16)
    text(sign$estimator, -log10(sign$pvalue), labels=paste(sign$mutation, sign$codon, sep="_"),
            pos=2, col="darkred", cex=0.8)
    title(main="Volcano plot of codon usage")
    abline(h=2, lty=2, col="grey60")
    abline(v=0, col="grey80")
    legend("bottomright", title=expression(bold("Legend")), legend="'mutation' - 'codon'",
             cex=0.6, bty="o")
    dev.off()
}
        
        

# Normalizing according different methods

get_imputation_bpca_bycond <- function(norm_matrix, conditions, cores=1, repCount=1,
                                       verbose=FALSE){
        require(pcaMethods)
        require(parallel)
        # Impute the missing values by experiment
        df_imp_list <-mclapply(conditions, function(x){
                df <- norm_matrix[,grep(x, colnames(norm_matrix))]
                df <- df[rowSums(!is.na(df)) >= repCount,]
                df_imp <- pcaMethods::pca(df, method="bpca", nPcs = 2, verbose=verbose)
                df_imp <- as.data.frame(completeObs(df_imp))
                df_imp$Prot.IDs <- rownames(df_imp)
                return(df_imp)
                }, mc.cores=cores)
        # Merge all the tables (have different length)
        df_imp_merge <- Reduce(function(x, y) merge(x,y,by="Prot.IDs", all=TRUE), df_imp_list)
        rownames(df_imp_merge) <- df_imp_merge$Prot.IDs; df_imp_merge$Prot.IDs <- NULL
        df_imp_merge[rownames(norm_matrix),]
}



# Function to select significant proteins by ANOVA-Tukey p-val & mean difference
sel.vars <- function(Y,A, absDiff_cut = 1, indPval_cut = 0.01, cpus=CPUS) {
    require("snowfall")
	sfInit(cpus=cpus,parallel=TRUE,type="SOCK")

	aov.res <- sfApply(Y,1,function(y,A) {
					fit <- aov(y ~ A)
					pval <- summary(fit)[[1]]["A","Pr(>F)"]     # p-value ANOVA
					s <- TukeyHSD(fit)$A
					    # p-value Tukey (padj) & diff in means per comparison (diff)
					return(c(pval,(abs(s[,"diff"]) > absDiff_cut & s[,"p adj"] < indPval_cut)))
				},A)
	sfStop()
        # This object has in the 1st row the p-values of every ANOVA 
        # and in the following rows each comparison per row with 0,1 (logical)
        # pointing the presence of a pval lower than threshold
	aov.pval <- p.adjust(aov.res[1,],method="BH")
	aov.cond <- aov.res[2:nrow(aov.res),]
	mode(aov.cond) <- "logical"
	aov.sum  <- apply(aov.cond,2,sum)   # number of significant comparisons per variable
	return(list(aov.pval=aov.pval,aov.cond=aov.cond, aov.sum=aov.sum))  #, aov.sum=aov.sum))
}

# Function to change the column names of proteinGroups file to match new sample names	
change_colnam_pg <- function(pgdf, phenodf){
  # phenodf has to have the sample names in column 'samples'  
  # and the replacement name in the column 'grnames'
  for (rowx in 1:nrow(phenodf)){
    #print(rowx)
    old_names <- grep(paste0(phenodf$samples[rowx], "_"), colnames(pgdf), value = TRUE)
    new_names <- gsub("_[^_]*$", "", old_names)
    new_names <- gsub(phenodf$samples[rowx], phenodf$grnames[rowx], new_names)
    ind <- grep(paste0(phenodf$samples[rowx], "_"), colnames(pgdf))
    colnames(pgdf)[ind] <- new_names
  } 
  return(pgdf)
}


# MULTIPLE PLOT FUNCTION (FROM R-COOKBOOK WEBPAGE)
#
# ggplot objects can be passed in ..., or to plotlist (as a list of ggplot objects)
# - cols:   Number of columns in layout
# - layout: A matrix specifying the layout. If present, 'cols' is ignored.
#
# If the layout is something like matrix(c(1,2,3,3), nrow=2, byrow=TRUE),
# then plot 1 will go in the upper left, 2 will go in the upper right, and
# 3 will go all the way across the bottom.
#
multiplot <- function(..., plotlist=NULL, file, cols=1, layout=NULL) {
  library(grid)
  
  # Make a list from the ... arguments and plotlist
  plots <- c(list(...), plotlist)
  
  numPlots = length(plots)
  
  # If layout is NULL, then use 'cols' to determine layout
  if (is.null(layout)) {
    # Make the panel
    # ncol: Number of columns of plots
    # nrow: Number of rows needed, calculated from # of cols
    layout <- matrix(seq(1, cols * ceiling(numPlots/cols)),
                     ncol = cols, nrow = ceiling(numPlots/cols))
  }
  
  if (numPlots==1) {
    print(plots[[1]])
    
  } else {
    # Set up the page
    grid.newpage()
    pushViewport(viewport(layout = grid.layout(nrow(layout), ncol(layout))))
    
    # Make each plot, in the correct location
    for (i in 1:numPlots) {
      # Get the i,j matrix positions of the regions that contain this subplot
      matchidx <- as.data.frame(which(layout == i, arr.ind = TRUE))
      
      print(plots[[i]], vp = viewport(layout.pos.row = matchidx$row,
                                      layout.pos.col = matchidx$col))
    }
  }
}























