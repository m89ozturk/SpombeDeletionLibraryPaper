options(stringsAsFactors =FALSE) #
# .libPaths(c(.libPaths(), "U:/Merve/Rpackages")) 

# setwd("U:/Merve/AllinAll_Mrv_IMB/Project/R_Projects/2017_TMT_SpDelLib/20190424_FinalDatasets")
setwd("E:/Merve/20190424_FinalDatasets")
source("myFunctions.R")
# source("U:/Merve/AllinAll_Mrv_IMB/R_course/Rtraining_Teresa/201611_teresa_LFQ/extra_fun_LFQ.R")
source("extra_fun_LFQ.R")

out_dir <- "ScreenProteome_AllNormalizations/"
# 1 # load the libraries #######################################################################################
library(dplyr)
library(tidyr)
library(plyr)
library(reshape2)
library(ggplot2)
library(RColorBrewer)
library(bapred)
library(sva)
library(limma)
library(data.table)
library(taRifx)
library(ggrepel)
###########################################################
# # 2 # normalization functions #############################
# # 2.1 # all the functions #################################
# Normalization_wtTech <- function(df_norm){
#   repInt_col <- grep("Sp", names(df_norm))
#   
#   plates <- unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\1",names(df_norm)[repInt_col]))
#   strains <- unique(gsub("^Sp[0-9]*([^0-9]*)[0-9]*.*", "\\1",names(df_norm)[repInt_col]))
#   
#   my_pg_med <- df_norm
#   for (mycol in 1:dim(my_pg_med)[2]) {
#     my_pg_med[,mycol] <- as.numeric(my_pg_med[,mycol])
#   }
#   
#   jnk_median_allProteins <- apply(my_pg_med, 1, median,na.rm = TRUE)
#   
#   my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))
#   
#   for (plate in plates) {
#     print(plate)
#     plate_col <- grep(plate, names(my_pg_med))
#     my_pg_med_subset <- my_pg_med[,plate_col]
#     experiments <- paste(unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\2",names(my_pg_med_subset))), "[-]", sep="")
#     
#     for(exp in experiments){
#       print(exp)
#       exp_col <- grep(exp, names(my_pg_med_subset))
#       my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
#       
#       norm_col <- grep("WT_Tech", names(my_pg_med_subset2))
#       my_pg_med_subset_wtNorm <- normalize2wtTech(my_pg_med_subset2, norm_col)
#       my_pg_med_subset_wtNorm$Proteins <- rownames(my_pg_med_subset_wtNorm)
#       my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset_wtNorm, by.x="Proteins", by.y="Proteins")
#     }
#   }  
#   
#   my_pg_med <- my_wt_normalized
#   
#   my_pg_med[,2:dim(my_pg_med)[2]] <- my_pg_med[,2:dim(my_pg_med)[2]] + jnk_median_allProteins
#   rownames(my_pg_med) <- my_pg_med$Proteins
#   my_pg_med <- my_pg_med[,-1]
#   return(my_pg_med)
# }
# Normalization_median <- function(df_norm){
#   repInt_col <- grep("Sp", names(df_norm))
#   
#   plates <- unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\1",names(df_norm)[repInt_col]))
#   strains <- unique(gsub("^Sp[0-9]*([^0-9]*)[0-9]*.*", "\\1",names(df_norm)[repInt_col]))
#   
#   my_pg_med <- df_norm
#   for (mycol in 1:dim(my_pg_med)[2]) {
#     my_pg_med[,mycol] <- as.numeric(my_pg_med[,mycol])
#   }
#   my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))
#   
#   for (plate in plates) {
#     print(plate)
#     plate_col <- grep(plate, names(my_pg_med))
#     my_pg_med_subset <- my_pg_med[,plate_col]
#     experiments <- paste(unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\2",names(my_pg_med_subset))), "[-]", sep="")
#     
#     for(exp in experiments){
#       print(exp)
#       exp_col <- grep(exp, names(my_pg_med_subset))
#       my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
#       
#       colMedian <- apply(my_pg_med_subset2, 2, median,na.rm = TRUE)
#       colMedian <- as.numeric(colMedian)
#       myRunMedian <- median(colMedian)
#       
#       for (mycol in 1:dim(my_pg_med_subset2)[2]) {
#         my_pg_med_subset2[,mycol] <- my_pg_med_subset2[,mycol] - colMedian[mycol] + myRunMedian
#       }
#       
#       my_pg_med_subset_wtNorm <- my_pg_med_subset2
#       my_pg_med_subset_wtNorm$Proteins <- rownames(my_pg_med_subset_wtNorm)
#       my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset_wtNorm, by.x="Proteins", by.y="Proteins")
#     }
#   }  
#   my_pg_med <- my_wt_normalized
#   rownames(my_pg_med) <- my_pg_med$Proteins
#   my_pg_med <- my_pg_med[,-1]
#   return(my_pg_med)
# }
# Normalization_medianProteinsRun <- function(df_norm){
#   repInt_col <- grep("Sp", names(df_norm))
#   
#   plates <- unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\1",names(df_norm)[repInt_col]))
#   strains <- unique(gsub("^Sp[0-9]*([^0-9]*)[0-9]*.*", "\\1",names(df_norm)[repInt_col]))
#   
#   my_pg_med <- df_norm
#   jnk_median_allProteins <- apply(my_pg_med, 1, median,na.rm = TRUE)
#   
#   my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))
#   
#   for (plate in plates) {
#     print(plate)
#     plate_col <- grep(plate, names(my_pg_med))
#     my_pg_med_subset <- my_pg_med[,plate_col]
#     experiments <- paste(unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\2",names(my_pg_med_subset))), "[-]", sep="")
#     for(exp in experiments){
#       print(exp)
#       exp_col <- grep(exp, names(my_pg_med_subset))
#       my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
#       
#       norm_col <- apply(my_pg_med_subset2, 1, median, na.rm=TRUE)
#       
#       my_pg_med_subset_wtNorm <- my_pg_med_subset2- norm_col
#       
#       my_pg_med_subset_wtNorm$Proteins <- rownames(my_pg_med_subset_wtNorm)
#       my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset_wtNorm, by.x="Proteins", by.y="Proteins")
#     }
#   }  
#   
#   my_pg_med <- my_wt_normalized
#   
#   my_pg_med[,2:dim(my_pg_med)[2]] <- my_pg_med[,2:dim(my_pg_med)[2]] + jnk_median_allProteins
#   rownames(my_pg_med) <- my_pg_med$Proteins
#   my_pg_med <- my_pg_med[,-1]
#   return(my_pg_med)
# }
# Normalization_limma <- function(df_norm){
#   batch = gsub("Sp([0-9][0-9]).*", "\\1", names(df_norm))
#   df_m <- as.matrix(df_norm)  
#   
#   limma_batch_df <- removeBatchEffect(df_m, batch)
#   limma_batch_df <- as.data.frame(limma_batch_df)
#   return(limma_batch_df)
# }
# Normalization_svaCombatParametric <- function(df_norm){
#   df_norm[is.na(df_norm)] <- 0
#   batch = gsub("Sp([0-9][0-9]).*", "\\1", names(df_norm))
#   df_m <- as.matrix(df_norm)  
#   combat_df = ComBat(dat=df_m, batch=batch, par.prior=TRUE, prior.plots=FALSE)
#   return(combat_df)
# }
# Normalization_svaCombatNONparametric <- function(df_norm){
#   df_norm[is.na(df_norm)] <- 0
#   batch = gsub("Sp([0-9][0-9]).*", "\\1", names(df_norm))
#   df_m <- as.matrix(df_norm)  
#   combat_df = ComBat(dat=df_m, batch=batch, par.prior=FALSE, prior.plots=FALSE)
#   return(combat_df)
# }
# Normalization_bapred_fabatch <- function(df_norm){
#   df_norm[is.na(df_norm)] <- 0
#   batch = gsub("Sp([0-9][0-9]).*", "\\1", names(df_norm))
#   df_m <- as.matrix(df_norm) 
#   bapred_batch <- as.factor(as.numeric(batch))
#   bapred_batch <- mapvalues(bapred_batch, from = levels(bapred_batch), to = 1:length(levels(bapred_batch)))
#   
#   jnk <- data.frame(colNames=colnames(df_m), Batch=bapred_batch)
#   jnk <- jnk[with(jnk, order(Batch)), ]
#   df_m <- df_m[,jnk$colNames]
#   df_m <- as.matrix(t(df_m))
#   
#   wttech <- grep("WT_Tech", rownames(df_m))
#   batch_y <- rep(1, length(bapred_batch))
#   batch_y[wttech] <- 2
#   batch_y <- as.factor(as.numeric(batch_y))
#   
#   
#   ba_df <- ba(x=df_m, y=batch_y, batch=as.factor(jnk$Batch), method = "fabatch")
#   
#   ba_df <- as.matrix(t(ba_df$xadj))
#   colnames(ba_df) <- rownames(df_m)
#   rownames(ba_df) <- colnames(df_m)
#   ba_df <- as.data.frame(ba_df)
#   return(ba_df)
#   }
# Normalization_bapred_combat <- function(df_norm){
#   df_norm[is.na(df_norm)] <- 0
#   batch = gsub("Sp([0-9][0-9]).*", "\\1", names(df_norm))
#   df_m <- as.matrix(df_norm) 
#   bapred_batch <- as.factor(as.numeric(batch))
#   bapred_batch <- mapvalues(bapred_batch, from = levels(bapred_batch), to = 1:length(levels(bapred_batch)))
#   
#   jnk <- data.frame(colNames=colnames(df_m), Batch=bapred_batch)
#   jnk <- jnk[with(jnk, order(Batch)), ]
#   df_m <- df_m[,jnk$colNames]
#   df_m <- as.matrix(t(df_m))
#   
#   wttech <- grep("WT_Tech", rownames(df_m))
#   batch_y <- rep(1, length(bapred_batch))
#   batch_y[wttech] <- 2
#   batch_y <- as.factor(as.numeric(batch_y))
#   
#   ba_df <- ba(x=df_m, batch=as.factor(jnk$Batch), method = "combat")
#   
#   ba_df <- as.matrix(t(ba_df$xadj))
#   colnames(ba_df) <- rownames(df_m)
#   rownames(ba_df) <- colnames(df_m)
#   ba_df <- as.data.frame(ba_df)
#   return(ba_df)
# }
# Normalization_bapred_sva <- function(df_norm){
#   df_norm[is.na(df_norm)] <- 0
#   batch = gsub("Sp([0-9][0-9]).*", "\\1", names(df_norm))
#   df_m <- as.matrix(df_norm) 
#   bapred_batch <- as.factor(as.numeric(batch))
#   bapred_batch <- mapvalues(bapred_batch, from = levels(bapred_batch), to = 1:length(levels(bapred_batch)))
#   
#   jnk <- data.frame(colNames=colnames(df_m), Batch=bapred_batch)
#   jnk <- jnk[with(jnk, order(Batch)), ]
#   df_m <- df_m[,jnk$colNames]
#   df_m <- as.matrix(t(df_m))
#   
#   wttech <- grep("WT_Tech", rownames(df_m))
#   batch_y <- rep(1, length(bapred_batch))
#   batch_y[wttech] <- 2
#   batch_y <- as.factor(as.numeric(batch_y))
#   
#   ba_df <- ba(x=df_m, y=batch_y, batch=as.factor(jnk$Batch), method = "sva", algorithm ="exact")
#   
#   ba_df <- as.matrix(t(ba_df$xadj))
#   colnames(ba_df) <- rownames(df_m)
#   rownames(ba_df) <- colnames(df_m)
#   ba_df <- as.data.frame(ba_df)
#   return(ba_df)
# }
# Normalization_bapred_meancenter <- function(df_norm){
#   df_norm[is.na(df_norm)] <- 0
#   batch = gsub("Sp([0-9][0-9]).*", "\\1", names(df_norm))
#   df_m <- as.matrix(df_norm) 
#   bapred_batch <- as.factor(as.numeric(batch))
#   bapred_batch <- mapvalues(bapred_batch, from = levels(bapred_batch), to = 1:length(levels(bapred_batch)))
#   
#   jnk <- data.frame(colNames=colnames(df_m), Batch=bapred_batch)
#   jnk <- jnk[with(jnk, order(Batch)), ]
#   df_m <- df_m[,jnk$colNames]
#   df_m <- as.matrix(t(df_m))
#   
#   wttech <- grep("WT_Tech", rownames(df_m))
#   batch_y <- rep(1, length(bapred_batch))
#   batch_y[wttech] <- 2
#   batch_y <- as.factor(as.numeric(batch_y))
#   
#   ba_df <- ba(x=df_m, batch=as.factor(jnk$Batch), method = "meancenter")
#   
#   ba_df <- as.matrix(t(ba_df$xadj))
#   colnames(ba_df) <- rownames(df_m)
#   rownames(ba_df) <- colnames(df_m)
#   ba_df <- as.data.frame(ba_df)
#   return(ba_df)
# }
# Normalization_bapred_standardize <- function(df_norm){
#   df_norm[is.na(df_norm)] <- 0
#   batch = gsub("Sp([0-9][0-9]).*", "\\1", names(df_norm))
#   df_m <- as.matrix(df_norm) 
#   bapred_batch <- as.factor(as.numeric(batch))
#   bapred_batch <- mapvalues(bapred_batch, from = levels(bapred_batch), to = 1:length(levels(bapred_batch)))
#   
#   jnk <- data.frame(colNames=colnames(df_m), Batch=bapred_batch)
#   jnk <- jnk[with(jnk, order(Batch)), ]
#   df_m <- df_m[,jnk$colNames]
#   df_m <- as.matrix(t(df_m))
#   
#   wttech <- grep("WT_Tech", rownames(df_m))
#   batch_y <- rep(1, length(bapred_batch))
#   batch_y[wttech] <- 2
#   batch_y <- as.factor(as.numeric(batch_y))
#   
#   ba_df <- ba(x=df_m, batch=as.factor(jnk$Batch), method = "standardize")
#   
#   ba_df <- as.matrix(t(ba_df$xadj))
#   colnames(ba_df) <- rownames(df_m)
#   rownames(ba_df) <- colnames(df_m)
#   ba_df <- as.data.frame(ba_df)
#   return(ba_df)
# }
# Normalization_bapred_ratioa <- function(df_norm){
#   df_norm[is.na(df_norm)] <- 0
#   batch = gsub("Sp([0-9][0-9]).*", "\\1", names(df_norm))
#   df_m <- as.matrix(df_norm) 
#   bapred_batch <- as.factor(as.numeric(batch))
#   bapred_batch <- mapvalues(bapred_batch, from = levels(bapred_batch), to = 1:length(levels(bapred_batch)))
#   
#   jnk <- data.frame(colNames=colnames(df_m), Batch=bapred_batch)
#   jnk <- jnk[with(jnk, order(Batch)), ]
#   df_m <- df_m[,jnk$colNames]
#   df_m <- as.matrix(t(df_m))
#   
#   wttech <- grep("WT_Tech", rownames(df_m))
#   batch_y <- rep(1, length(bapred_batch))
#   batch_y[wttech] <- 2
#   batch_y <- as.factor(as.numeric(batch_y))
#   
#   ba_df <- ba(x=df_m, batch=as.factor(jnk$Batch), method = "ratioa")
#   
#   ba_df <- as.matrix(t(ba_df$xadj))
#   colnames(ba_df) <- rownames(df_m)
#   rownames(ba_df) <- colnames(df_m)
#   ba_df <- as.data.frame(ba_df)
#   return(ba_df)
# }
# Normalization_bapred_ratiog <- function(df_norm){
#   df_norm[is.na(df_norm)] <- 0
#   batch = gsub("Sp([0-9][0-9]).*", "\\1", names(df_norm))
#   df_m <- as.matrix(df_norm) 
#   bapred_batch <- as.factor(as.numeric(batch))
#   bapred_batch <- mapvalues(bapred_batch, from = levels(bapred_batch), to = 1:length(levels(bapred_batch)))
#   
#   jnk <- data.frame(colNames=colnames(df_m), Batch=bapred_batch)
#   jnk <- jnk[with(jnk, order(Batch)), ]
#   df_m <- df_m[,jnk$colNames]
#   df_m <- as.matrix(t(df_m))
#   
#   wttech <- grep("WT_Tech", rownames(df_m))
#   batch_y <- rep(1, length(bapred_batch))
#   batch_y[wttech] <- 2
#   batch_y <- as.factor(as.numeric(batch_y))
#   
#   ba_df <- ba(x=df_m, batch=as.factor(jnk$Batch), method = "ratiog")
#   
#   ba_df <- as.matrix(t(ba_df$xadj))
#   colnames(ba_df) <- rownames(df_m)
#   rownames(ba_df) <- colnames(df_m)
#   ba_df <- as.data.frame(ba_df)
#   return(ba_df)
# }
# # 2.2 # first round with all of them ##################### 
# myfile <- list.files(path = "ScreenProteome/", pattern = "^3_1_.*rds")
# df_norm <- readRDS(file.path("ScreenProteome/", myfile))
# id <- "2_2"
# 
# jnk <- Normalization_wtTech(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_1_", Sys.Date(), "_wtTech.rds")))
# 
# jnk <- Normalization_median(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_2_", Sys.Date(), "_median.rds")))
# 
# jnk <- Normalization_medianProteinsRun(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_3_", Sys.Date(), "_medProt.rds")))
# 
# jnk <- Normalization_limma(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_4_", Sys.Date(), "_limma.rds")))
# 
# jnk <- Normalization_svaCombatParametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_5_", Sys.Date(), "_svaCombatParametric.rds")))
# 
# jnk <- Normalization_svaCombatNONparametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_6_", Sys.Date(), "_svaCombatNonParametric.rds")))
# 
# jnk <- Normalization_bapred_fabatch(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_7_", Sys.Date(), "_bapredFabatch.rds")))
# 
# jnk <- Normalization_bapred_combat(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_8_", Sys.Date(), "_bapredCombat.rds")))
# 
# jnk <- Normalization_bapred_sva(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_9_", Sys.Date(), "_bapredSva.rds")))
# 
# jnk <- Normalization_bapred_meancenter(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_10_", Sys.Date(), "_bapredMeanCenter.rds")))
# 
# jnk <- Normalization_bapred_standardize(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_11_", Sys.Date(), "_bapredStandardize.rds")))
# 
# jnk <- Normalization_bapred_ratioa(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_12_", Sys.Date(), "_bapredRatioA.rds")))
# 
# jnk <- Normalization_bapred_ratiog(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_13_", Sys.Date(), "_bapredRatioG.rds")))
# 
# # 2.3 # second round with all of them after wt_tech ##################### 
# df_norm <- readRDS("ScreenProteome_AllNormalizations/2_2_1_2019-07-12_wtTech.rds")
# id <- "2_3"
# 
# jnk <- Normalization_median(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_2_", Sys.Date(), "_median.rds")))
# 
# jnk <- Normalization_medianProteinsRun(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_3_", Sys.Date(), "_medProt.rds")))
# 
# jnk <- Normalization_limma(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_4_", Sys.Date(), "_limma.rds")))
# #
# jnk <- Normalization_svaCombatParametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_5_", Sys.Date(), "_svaCombatParametric.rds")))
# 
# jnk <- Normalization_svaCombatNONparametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_6_", Sys.Date(), "_svaCombatNonParametric.rds")))
# 
# jnk <- Normalization_bapred_fabatch(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_7_", Sys.Date(), "_bapredFabatch.rds")))
# 
# jnk <- Normalization_bapred_combat(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_8_", Sys.Date(), "_bapredCombat.rds")))
# 
# jnk <- Normalization_bapred_sva(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_9_", Sys.Date(), "_bapredSva.rds")))
# 
# jnk <- Normalization_bapred_meancenter(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_10_", Sys.Date(), "_bapredMeanCenter.rds")))
# 
# jnk <- Normalization_bapred_standardize(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_11_", Sys.Date(), "_bapredStandardize.rds")))
# 
# jnk <- Normalization_bapred_ratioa(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_12_", Sys.Date(), "_bapredRatioA.rds")))
# 
# jnk <- Normalization_bapred_ratiog(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_13_", Sys.Date(), "_bapredRatioG.rds")))
# 
# # 2.4 # third round with all of them after median ##################### 
# df_norm <- readRDS("ScreenProteome_AllNormalizations/2_2_2_2019-07-12_median.rds")
# id <- "2_4"
# 
# jnk <- Normalization_wtTech(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_1_", Sys.Date(), "_wtTech.rds")))
# 
# jnk <- Normalization_medianProteinsRun(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_3_", Sys.Date(), "_medProt.rds")))
# 
# jnk <- Normalization_limma(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_4_", Sys.Date(), "_limma.rds")))
# #
# jnk <- Normalization_svaCombatParametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_5_", Sys.Date(), "_svaCombatParametric.rds")))
# 
# jnk <- Normalization_svaCombatNONparametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_6_", Sys.Date(), "_svaCombatNonParametric.rds")))
# 
# jnk <- Normalization_bapred_fabatch(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_7_", Sys.Date(), "_bapredFabatch.rds")))
# 
# jnk <- Normalization_bapred_combat(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_8_", Sys.Date(), "_bapredCombat.rds")))
# 
# jnk <- Normalization_bapred_sva(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_9_", Sys.Date(), "_bapredSva.rds")))
# 
# jnk <- Normalization_bapred_meancenter(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_10_", Sys.Date(), "_bapredMeanCenter.rds")))
# 
# jnk <- Normalization_bapred_standardize(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_11_", Sys.Date(), "_bapredStandardize.rds")))
# 
# jnk <- Normalization_bapred_ratioa(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_12_", Sys.Date(), "_bapredRatioA.rds")))
# 
# jnk <- Normalization_bapred_ratiog(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_13_", Sys.Date(), "_bapredRatioG.rds")))
# 
# # 2.5 # 4th round with all of them after medianProteins ##################### 
# df_norm <- readRDS("ScreenProteome_AllNormalizations/2_2_3_2019-07-12_medProt.rds")
# id <- "2_5"
# 
# jnk <- Normalization_wtTech(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_1_", Sys.Date(), "_wtTech.rds")))
# 
# jnk <- Normalization_median(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_2_", Sys.Date(), "_median.rds")))
# 
# 
# jnk <- Normalization_limma(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_4_", Sys.Date(), "_limma.rds")))
# #
# jnk <- Normalization_svaCombatParametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_5_", Sys.Date(), "_svaCombatParametric.rds")))
# 
# jnk <- Normalization_svaCombatNONparametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_6_", Sys.Date(), "_svaCombatNonParametric.rds")))
# 
# jnk <- Normalization_bapred_fabatch(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_7_", Sys.Date(), "_bapredFabatch.rds")))
# 
# jnk <- Normalization_bapred_combat(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_8_", Sys.Date(), "_bapredCombat.rds")))
# 
# jnk <- Normalization_bapred_sva(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_9_", Sys.Date(), "_bapredSva.rds")))
# 
# jnk <- Normalization_bapred_meancenter(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_10_", Sys.Date(), "_bapredMeanCenter.rds")))
# 
# jnk <- Normalization_bapred_standardize(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_11_", Sys.Date(), "_bapredStandardize.rds")))
# 
# jnk <- Normalization_bapred_ratioa(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_12_", Sys.Date(), "_bapredRatioA.rds")))
# 
# jnk <- Normalization_bapred_ratiog(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_13_", Sys.Date(), "_bapredRatioG.rds")))
# 
# # 2.6 # 5th round with all of them after wt_tech & median ##################### 
# myfile <- list.files(path = "ScreenProteome_AllNormalizations/", pattern = "^2_3_2_.*rds")
# df_norm <- readRDS(file.path("ScreenProteome_AllNormalizations/", myfile))
# id <- "2_6"
# 
# jnk <- Normalization_medianProteinsRun(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_3_", Sys.Date(), "_medProt.rds")))
# 
# jnk <- Normalization_limma(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_4_", Sys.Date(), "_limma.rds")))
# 
# jnk <- Normalization_svaCombatParametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_5_", Sys.Date(), "_svaCombatParametric.rds")))
# 
# jnk <- Normalization_svaCombatNONparametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_6_", Sys.Date(), "_svaCombatNonParametric.rds")))
# 
# jnk <- Normalization_bapred_fabatch(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_7_", Sys.Date(), "_bapredFabatch.rds")))
# 
# jnk <- Normalization_bapred_combat(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_8_", Sys.Date(), "_bapredCombat.rds")))
# 
# jnk <- Normalization_bapred_sva(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_9_", Sys.Date(), "_bapredSva.rds")))
# 
# jnk <- Normalization_bapred_meancenter(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_10_", Sys.Date(), "_bapredMeanCenter.rds")))
# 
# jnk <- Normalization_bapred_standardize(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_11_", Sys.Date(), "_bapredStandardize.rds")))
# 
# jnk <- Normalization_bapred_ratioa(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_12_", Sys.Date(), "_bapredRatioA.rds")))
# 
# jnk <- Normalization_bapred_ratiog(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_13_", Sys.Date(), "_bapredRatioG.rds")))
# # 2.7 # 6th round with all of them after wt_tech & median & median proteins run ################## 
# myfile <- list.files(path = "ScreenProteome_AllNormalizations/", pattern = "^2_6_3_.*rds")
# df_norm <- readRDS(file.path("ScreenProteome_AllNormalizations/", myfile))
# id <- "2_7"
# 
# jnk <- Normalization_limma(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_4_", Sys.Date(), "_limma.rds")))
# 
# jnk <- Normalization_svaCombatParametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_5_", Sys.Date(), "_svaCombatParametric.rds")))
# 
# jnk <- Normalization_svaCombatNONparametric(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_6_", Sys.Date(), "_svaCombatNonParametric.rds")))
# 
# jnk <- Normalization_bapred_fabatch(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_7_", Sys.Date(), "_bapredFabatch.rds")))
# 
# jnk <- Normalization_bapred_combat(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_8_", Sys.Date(), "_bapredCombat.rds")))
# 
# jnk <- Normalization_bapred_sva(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_9_", Sys.Date(), "_bapredSva.rds")))
# 
# jnk <- Normalization_bapred_meancenter(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_10_", Sys.Date(), "_bapredMeanCenter.rds")))
# 
# jnk <- Normalization_bapred_standardize(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_11_", Sys.Date(), "_bapredStandardize.rds")))
# 
# jnk <- Normalization_bapred_ratioa(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_12_", Sys.Date(), "_bapredRatioA.rds")))
# 
# jnk <- Normalization_bapred_ratiog(df_norm)
# saveRDS(jnk, file.path(out_dir, paste0(id, "_13_", Sys.Date(), "_bapredRatioG.rds")))

###############################################################################################
rm(jnk)
rm(df_norm)
# 4 # dataframe with all the information ######################################
mydf <- as.data.frame(list.files(out_dir, pattern = ".rds"))
names(mydf) <- "filename"

mydf$id <- gsub("(^[2-3].*)\\_2019\\-.*", "\\1", mydf$filename)
mydf$lastMethod <- gsub("^[2-3]\\_.*\\_([a-zA-Z]*)\\.rds$", "\\1", mydf$filename)
mydf$lastMethod[mydf$id == "3_1"] <- "NotNormalized"

mydf$Median_Cor2OriginalData_Pearson <- NA
mydf$Median_Cor2OriginalData_Spearman <- NA

mydf$Median_Other_Cor_Pearson <- NA
mydf$Median_Same_Plate_Cor_Pearson <- NA
mydf$MedianSame_Run_Cor_Pearson <- NA


# temp functions ####
cor2originalData <- function(originalDF, normalizedDF){
  df_measured <- df
  df_measured[df_measured==0] <- NA
  
  df_normalized <- as.data.frame(df_norm)
  commonCols <- intersect(names(df_normalized), names(df_measured))
  
  df_normalized <- df_normalized[,names(df_normalized) %in% commonCols]
  df_measured <- df_measured[,names(df_measured) %in% commonCols]
  
  df_normalized <- setcolorder(df_normalized, names(df_measured))
  
  
  df_cor <- data.frame(Strain=colnames(df_measured), Measured_vs_Normalized_Pearson=NA, 
                       Measured_vs_Normalized_Spearman=NA)
  for (i in 1:dim(df_cor)[1]) {
    jnk <- cor(df_measured[,i], df_normalized[,i], use="pairwise.complete.obs", method="pearson")
    df_cor$Measured_vs_Normalized_Pearson[i] <- jnk
    
    jnk <- cor(df_measured[,i], df_normalized[,i], use="pairwise.complete.obs", method="spearman")
    df_cor$Measured_vs_Normalized_Spearman[i] <- jnk
  }
  df_cor_melt <- melt(df_cor, id.vars = "Strain")
  df_cor_melt <- df_cor_melt %>%
    group_by(variable) %>%
    dplyr::mutate(Median_value=median(value)) %>%
    as.data.frame()
  df_cor_melt <- unique(df_cor_melt[,c(2,4)])
  df_cor_melt <- remove.factors(df_cor_melt)
  df_cor_melt$variable <- gsub("Measured_vs_Normalized_", "", df_cor_melt$variable)
  return(df_cor_melt)
}
myQCnormalization <- function(df){
  df <- as.data.frame(df)

  df_cor <- as.data.frame(cor(df, use="pairwise.complete.obs", method="pearson")) 
  df_cor$Strain1 <- rownames(df_cor)
  df_cor_melt <- melt(df_cor, id="Strain1")
  names(df_cor_melt)[2:3] <- c("Strain2", "Pearson_R")
  
  df_cor_melt$S1Plate <- gsub("Sp([0-9][0-9]).*", "\\1", df_cor_melt$Strain1)
  df_cor_melt$S2Plate <- gsub("Sp([0-9][0-9]).*", "\\1", df_cor_melt$Strain2)
  
  df_cor_melt$S1RUN <- gsub("Sp[0-9][0-9].*([0-9][0-9])\\-.*", "\\1", df_cor_melt$Strain1)
  df_cor_melt$S2RUN <- gsub("Sp[0-9][0-9].*([0-9][0-9])\\-.*", "\\1", df_cor_melt$Strain2)
  df_cor_melt$S1RUN <- paste(df_cor_melt$S1Plate, df_cor_melt$S1RUN, sep="_")
  df_cor_melt$S2RUN <- paste(df_cor_melt$S2Plate, df_cor_melt$S2RUN, sep="_")
  
  df_cor_melt <- subset(df_cor_melt, Strain1 != Strain2)
  df_cor_melt$Pearson_R <- as.numeric(df_cor_melt$Pearson_R)
  
  
  df_cor_melt$Category <- NA
  df_cor_melt$Category[df_cor_melt$S1Plate == df_cor_melt$S2Plate] <- "SamePlate"
  df_cor_melt$Category[df_cor_melt$S1RUN == df_cor_melt$S2RUN] <- "SameRun"
  df_cor_melt$Category[is.na(df_cor_melt$Category)] <- "Other"
  
  df_cor_melt <- df_cor_melt %>%
    group_by(Category) %>%
    dplyr::mutate(median_Pearson=median(Pearson_R)) %>%
    as.data.frame()
 
  df_cor_melt <- unique(df_cor_melt[,c(8,9)])
  return(df_cor_melt)
}
# loop over the files ####################
myfile <- list.files(path = "ScreenProteome/", pattern = "^3_1_.*rds")
df <- readRDS(file.path("ScreenProteome/", myfile))

for (i in 1:dim(mydf)[1]) {
  print(i)
  df_norm <- readRDS(file.path(out_dir, mydf$filename[i]))
  jnk <- cor2originalData(df, df_norm)
  mydf$Median_Cor2OriginalData_Pearson[i] <- jnk$Median_value[jnk$variable == "Pearson"]
  mydf$Median_Cor2OriginalData_Spearman[i] <- jnk$Median_value[jnk$variable == "Spearman"]
  rm(jnk)
  jnk <- myQCnormalization(df_norm)
  mydf$Median_Other_Cor_Pearson[i] <- jnk$median_Pearson[jnk$Category == "Other"]
  mydf$Median_Same_Plate_Cor_Pearson[i] <- jnk$median_Pearson[jnk$Category == "SamePlate"]
  mydf$MedianSame_Run_Cor_Pearson[i] <- jnk$median_Pearson[jnk$Category == "SameRun"]
  rm(jnk)
  rm(df_norm)
  saveRDS(mydf, file.path(out_dir, paste0("4_", Sys.Date(), "_mySupp_df_Normalizations.rds")))
}
saveRDS(mydf, file.path(out_dir, paste0("4_", Sys.Date(), "_mySupp_df_Normalizations.rds")))
rm(df)
#################################################################
# 5 #  make the fit and plot ####################################
mydf$BiasCoeff_original <- NA
mydf$BiasCoeff_ordered <- NA
mydf$IQR <- NA
mydf$MedianCorPairwise <- NA

for(i in 4:12){
  mydf[,i] <- as.numeric(mydf[,i])
}

for (i in 1:dim(mydf)[1]) {
  print(i)
  jnk <- as.data.frame(t(mydf[i,6:8]))
  names(jnk)[1] <- "y"
  jnk$x <- 1:3
  
  jnk2 <- lm(jnk$y ~ jnk$x)
  mydf$BiasCoeff_original[i] <-  jnk2$coefficients[[2]]
  
  jnk <- as.data.frame(jnk[with(jnk, order(y)), ])
  jnk$x <- 1:3
  names(jnk)[1] <- "y"
  
  jnk2 <- lm(jnk$y ~ jnk$x)
  mydf$BiasCoeff_ordered[i] <-  jnk2$coefficients[[2]]
  
  mydf$IQR[i] <- max(jnk$y) - min(jnk$y)
  mydf$MedianCorPairwise[i] <- median(jnk$y)
  
  rm(jnk)
  rm(jnk2)
}
saveRDS(mydf, file.path(out_dir, paste0("5_", Sys.Date(), "_mySupp_df_Normalizations.rds")))


mydf$Color <- "ALL"
mydf$Color[mydf$filename=="2_4_3_2019-07-12_medProt.rds"] <- "OurChoice"



p1 <- ggplot(mydf, aes(BiasCoeff_original, Median_Cor2OriginalData_Pearson)) +
  geom_point(data=subset(mydf, Color=="ALL"), aes(color=lastMethod), size=4, alpha=0.6) +
  geom_point(data=subset(mydf, Color!="ALL"), color="#cb181d", size=6) +
  theme_bw() +
  xlab("Bias coefficient") +
  ylab("median(Pearson's R to original data)") +
  ylim(-1,1)+
  xlim(-0.1, 0.61)

p2 <- ggplot(mydf, aes(BiasCoeff_ordered, Median_Cor2OriginalData_Pearson)) +
  geom_point(data=subset(mydf, Color=="ALL"), aes(color=lastMethod), size=4, alpha=0.6) +
  geom_point(data=subset(mydf, Color!="ALL"), color="#cb181d", size=6) +
  theme_bw() +
  xlab("Bias coefficient ordered") +
  ylab("median(Pearson's R to original data)") +
  ylim(-1,1)+
  xlim(-0.1, 0.61)



p3 <- ggplot(mydf, aes(IQR, MedianCorPairwise)) +
  geom_point(data=subset(mydf, Color=="ALL"), aes(color=lastMethod), size=4, alpha=0.6) +
  geom_point(data=subset(mydf, Color!="ALL"), color="#cb181d", size=6) +
  theme_bw() +
  xlab("difference median correlation") +
  ylab("median correlation") +
  ylim(-1,1) +
  xlim(-0.1, 1.2)

pdf(file.path(out_dir, paste0("5_1_", Sys.Date(), "_NormalizationComparisonPlots.pdf")),height = 4, width = 6)
print(p1)
print(p2)
print(p3)
dev.off()







