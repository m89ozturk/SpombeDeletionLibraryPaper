options(stringsAsFactors =FALSE) #
# .libPaths(c(.libPaths(), "U:/Merve/Rpackages")) 
# setwd("U:/Merve/AllinAll_Mrv_IMB/Project/R_Projects/2017_TMT_SpDelLib/20190424_FinalDatasets")
setwd("E:/Merve/20190424_FinalDatasets")
source("myFunctions.R")
# source("U:/Merve/AllinAll_Mrv_IMB/R_course/Rtraining_Teresa/201611_teresa_LFQ/extra_fun_LFQ.R")
source("extra_fun_LFQ.R")
out_dir <- "ScreenProteome/"
# data_dir <- "Y:/Publications/SpombeSystems/MaxQuantOutputs/"
data_dir <- "F:/Merve_Spombe_DelLibrary_TMT_all/Screen_all/"
# 1 # load the libraries #######################################################################################
library(dplyr)
library(plotly)
library(tidyr)
library(knitr)
library(plyr)
library(reshape2)
library(ggplot2)
library(RColorBrewer)
library(parallel)
library(pcaMethods)
library(fBasics)
library(stats)
library(pvclust)
library(ggrepel)
library(cluster)
library(factoextra)
library(psych)
library(gridExtra)
library("ape")
library(ggpubr)
library(ggfortify)
library(broom)
library(data.table)
library(WGCNA)
library(e1071)
library(ggsignif)
library(corrplot)
library(GGally)
library(network)
library(sna)
library(igraph)
library(ggnetwork)
library(VennDiagram)
library(quantmod)
library(threejs)
library(crosstalk)
library(htmltools)
library(GOfuncR)
library(corrplot)
library(PerformanceAnalytics)
library(matrixTests)
library(pheatmap)
library("taRifx")
library(mvoutlier)
#############################################################################################
if(done){
if(newdf){
# 2 # protein groups file and initial QC #############################################################
# 2.0 # read and filter pG ###########################################################################
pG <- read.delim(file.path(data_dir,"Screen_combined_1U_noMBR/txt/proteinGroups.txt"))
pG <- my_pG_filter(pG,1,1)
saveRDS(pG, file.path(out_dir,paste0("2_0_",Sys.Date(),"_proteinGroups_filtered.rds")))

repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG))
pG_rep <- pG[,c(1,repCol)]

pG_rep[pG_rep==0] <- NA
pG_rep[,2:dim(pG_rep)[2]] <- log2(pG_rep[,2:dim(pG_rep)[2]])
# 2.1 # counts of identified proteins per sample ####################################################
jnk <- as.data.frame(colSums(is.na(pG_rep)))
jnk2 <- as.data.frame(colSums(!is.na(pG_rep)))
jnk$sample <- rownames(jnk)
jnk2$sample <- rownames(jnk2)
jnk <- merge(jnk, jnk2, by.x="sample", by.y="sample")
names(jnk) <- c("sample", "NotMeasured", "Measured")
write.table(jnk, file.path(out_dir,paste0("2_1_",Sys.Date(),"_counts.txt")), sep="\t", quote = F)
rm(jnk)
rm(jnk2)
# 2.2 # counts # old 3 from the analysis script ###################################################
pg_ident <- pG

repInt_col <- grep("^Reporter.intensity.corrected.[0-9].", names(pg_ident))
experiments <- unique(gsub("^Reporter.intensity.corrected.[0-9].(.*)$", "\\1",names(pg_ident)[repInt_col]))
strains <- unique(gsub("^Reporter.intensity.corrected.([0-9]).(.*)$", "\\1",names(pg_ident)[repInt_col]))
allsamples_name <- as.vector(sapply(experiments, paste0, '_', strains))

CT_TMT_noMBR <- data.frame(Position=character(), NumberOfProteins=numeric(), NumberOfProteinsIntensity=numeric(),
                           RepIntensityCount=character())
for (i in 1:length(experiments)) {
  print(i)
  pg_flt_x <- pg_ident[,grep(experiments[i], names(pg_ident))]
  colUnique <- names(pg_flt_x)[grep("^Unique.peptides", names(pg_flt_x))]
  colRazor <- names(pg_flt_x)[grep("^Razor", names(pg_flt_x))]
  
  enough_unique <- pg_flt_x[,colUnique] >= 1
  enough_razor_unique <- pg_flt_x[,colRazor] >= 1
  pg_ident_x <- subset(pg_flt_x, enough_razor_unique & enough_unique)
  
  colIntensity <- names(pg_ident_x)[grep("^Intensity.", names(pg_ident_x))]
  pg_ident_y <- subset(pg_ident_x, pg_ident_x[,colIntensity]>0)
  
  RepIntensity <- names(pg_ident_x)[grep("^Reporter.intensity.corrected.", names(pg_ident_x))]
  col4 <- NULL
  for(j in 1:length(RepIntensity)){
    pg_ident_z <- subset(pg_ident_x, pg_ident_x[,RepIntensity[j]]>0)
    col4 <- c(col4, dim(pg_ident_z)[1])
  }
  col4 <- paste0(col4, collapse = ";")
  
  CT_TMT_noMBR <- rbind(CT_TMT_noMBR, cbind(experiments[i], dim(pg_ident_x)[1], dim(pg_ident_y)[1], col4) )
}
names(CT_TMT_noMBR) <- c("Position", "NumberOfProteins", "NumberOfProteinsIntensity", "RepIntensityCount")

write.table(CT_TMT_noMBR, file.path(out_dir,paste0("2_2_",Sys.Date(),"_CountsTable.txt")), quote = F, row.names = F,
            sep="\t")
rm(CT_TMT_noMBR)
rm(pg_flt_x)
rm(pg_ident_x)
rm(pg_ident_y)
rm(pg_ident_z)
# 2.3 # reporter intensity decode ?? # old 4 from analysis script ###############################
plates <- unique(gsub("^Sp([0-9]*)C[0-9]*$", "\\1",experiments))
repIntCorr_col <- grep("Reporter.intensity.corrected.[0-9].", names(pg_ident))
repIntCorr_col_names <- names(pg_ident)[repIntCorr_col]

repInt_decode <- data.frame(colNames=repIntCorr_col_names, Plates=NA,
                            Position_X=NA, Position_Y=NA, MedianLog2Intensity=0,
                            MaxLog2Intensity=0, pGident=0)

repInt_decode$Plates <- gsub("Reporter.intensity.corrected.[0-9].Sp([0-9]*)C[0-9]*$", "\\1",
                             repInt_decode$colNames)

repInt_decode$Position_X <- gsub("Reporter.intensity.corrected.[0-9].Sp[0-9]*C([0-9]*)$", "\\1",
                                 repInt_decode$colNames)

repInt_decode$Position_Y <- gsub("Reporter.intensity.corrected.([0-9]).Sp[0-9]*C([0-9]*)$", "\\1",
                                 repInt_decode$colNames)

repInt_decode$Position_Y[repInt_decode$Position_Y==0] <- "A"
repInt_decode$Position_Y[repInt_decode$Position_Y==1] <- "B"
repInt_decode$Position_Y[repInt_decode$Position_Y==2] <- "WT_Tech"
repInt_decode$Position_Y[repInt_decode$Position_Y==3] <- "C"
repInt_decode$Position_Y[repInt_decode$Position_Y==4] <- "D"
repInt_decode$Position_Y[repInt_decode$Position_Y==5] <- "E"
repInt_decode$Position_Y[repInt_decode$Position_Y==6] <- "F"
repInt_decode$Position_Y[repInt_decode$Position_Y==7] <- "WT_Bio"
repInt_decode$Position_Y[repInt_decode$Position_Y==8] <- "G"
repInt_decode$Position_Y[repInt_decode$Position_Y==9] <- "H"

repInt_decode$ReLabel <- paste0("Sp", repInt_decode$Plates, repInt_decode$Position_Y,
                                repInt_decode$Position_X)

pg_ident_corrected <- pg_ident
pg_ident_corrected[repIntCorr_col][pg_ident_corrected[repIntCorr_col] ==0] <- NA

for(i in 1:dim(repInt_decode)[1]){
  print(i)
  repInt_decode$MedianLog2Intensity[i] <- median(log2(pg_ident_corrected[,repInt_decode$colNames[i]]), na.rm = T)
  repInt_decode$MaxLog2Intensity[i] <- max(log2(pg_ident_corrected[,repInt_decode$colNames[i]]), na.rm = T)
  repInt_decode$pGident[i] <- sum(!is.na(pg_ident_corrected[,repInt_decode$colNames[i]]))
}
repInt_decode$Plates <- as.character(repInt_decode$Plates)

write.table(repInt_decode, file.path(out_dir,paste0("2_3_",Sys.Date(),"_ReporterIntensityDecode_values.txt")),
            quote = F, row.names = F, sep="\t")
rm(pg_ident_corrected)
# 2.4 # median-max intensity DOTplots are saved # old 5 from analysis script ###############################
pdf(file.path(out_dir, paste0("2_4_",Sys.Date(),"_DOTplots.pdf")), width = 10, height = 8)
for(i in 1:length(plates)){
  repInt_decode_s <- subset(repInt_decode, Plates==plates[i])
  medPlot <- ggplot(repInt_decode_s, aes(x=Position_X, y=Position_Y))+
    geom_point(aes(color=MedianLog2Intensity, size=MedianLog2Intensity)) +
    scale_colour_gradientn(colours = c("#084594","#df65b0","#de2d26"),
                           values=c(0, median(repInt_decode$MedianLog2Intensity)/max(repInt_decode$MedianLog2Intensity), 1)) +
    scale_size_continuous(limits = c(min(repInt_decode$MedianLog2Intensity), max(repInt_decode$MedianLog2Intensity)))+
    xlab(NULL) +
    ylab(NULL)+
    ggtitle(paste0("Median intensity dotplot ", plates[i]))+
    geom_text(aes(label=pGident),size = 4, fontface = "bold", 
              color="#636363", vjust = 0, nudge_y = -0.5) 
  print(medPlot)
}
dev.off()
rm(medPlot)
rm(repInt_decode_s)
# 2.5 # create the table for each raw file and what is in which label # old 6 from analysis script ###########
# 2.5.1 # repInt decode advanced #############################################################################
myfile <- list.files(path=out_dir, pattern="^2_3_.*")
repInt_decode <- read.delim(file.path(out_dir, myfile))
repInt_decode$RawFileSuffix <- gsub("Reporter.intensity.corrected.[0-9].", "", repInt_decode$colNames)
names(repInt_decode)[1] <- "IntensityColumnNames_used"
repInt_decode$TMT_Label <- NA

repInt_decode$TMT_Label[repInt_decode$Position_Y == "A"] <- "126(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "B"] <- "127N(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "C"] <- "128N(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "D"] <- "128C(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "E"] <- "129N(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "F"] <- "129C(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "G"] <- "130C(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "H"] <- "131(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "WT_Bio"] <- "130N(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "WT_Tech"] <- "127C(TM)"

expDesign <- read.delim(file.path(data_dir,"Screen_combined_1U_noMBR/experimentalDesignTemplate.txt"))
expDesign <- expDesign[,c(1,3)]

repInt_decode <- merge(repInt_decode, expDesign, by.x="RawFileSuffix", by.y="Experiment", all=FALSE)
rm(expDesign)

repInt_decode$Name <- paste(repInt_decode$Name, "raw", sep=".")
repInt_decode <- repInt_decode[,c(11,1,2,10,9,3,8,7,6)]

names(repInt_decode)[1] <- "RawFileName" 
names(repInt_decode)[5] <- "Position_MS_Plate" 
names(repInt_decode)[6] <- "MS_Plate_Number" 
names(repInt_decode)[7] <- "NumberOfProteins" 
repInt_decode <- repInt_decode[,-6]

repInt_decode$Analyzed_ReMeasured <- "ToBeAnalyzed"
repInt_decode$StrainType <- "Knock-out"
repInt_decode$StrainType[grep("WT_Tech", repInt_decode$Position_MS_Plate)] <- "Technical_WildType"
repInt_decode$StrainType[grep("WT_Bio", repInt_decode$Position_MS_Plate)] <- "Biological_WildType"

repInt_decode$Position_KO_Library <- repInt_decode$Position_MS_Plate
repInt_decode$Position_KO_Library[grep("WT", repInt_decode$Position_MS_Plate)] <- "WildType"

write.table(repInt_decode, file.path(out_dir,paste0("2_5_1_",Sys.Date(),"_ReporterIntensityDecode_toCheckPositions.txt")),
            quote = F, row.names = F, sep="\t")
# 2.5.2 # repInt decode advanced - add the positions for the strains and wt add ########################
DelLib <- read.delim("U:/Merve/AllinAll_Mrv_IMB/Project/R_Projects/2017_TMT_SpDelLib/SpDelLib_positions_original.txt")
DelLib$PlateNumber <- as.character(DelLib$PlateNumber)
DelLib$PlateNumber[DelLib$PlateNumber=="1"] <- "01"
DelLib$PlateNumber[DelLib$PlateNumber=="2"] <- "02"
DelLib$PlateNumber[DelLib$PlateNumber=="3"] <- "03"
DelLib$PlateNumber[DelLib$PlateNumber=="4"] <- "04"
DelLib$PlateNumber[DelLib$PlateNumber=="5"] <- "05"
DelLib$PlateNumber[DelLib$PlateNumber=="6"] <- "06"
DelLib$PlateNumber[DelLib$PlateNumber=="7"] <- "07"
DelLib$PlateNumber[DelLib$PlateNumber=="8"] <- "08"
DelLib$PlateNumber[DelLib$PlateNumber=="9"] <- "09"

DelLib$Row[DelLib$Row==1] <- "A"
DelLib$Row[DelLib$Row==2] <- "B"
DelLib$Row[DelLib$Row==3] <- "C"
DelLib$Row[DelLib$Row==4] <- "D"
DelLib$Row[DelLib$Row==5] <- "E"
DelLib$Row[DelLib$Row==6] <- "F"
DelLib$Row[DelLib$Row==7] <- "G"
DelLib$Row[DelLib$Row==8] <- "H"

DelLib$Column <- as.character(DelLib$Column)
DelLib$Column[DelLib$Column=="0"] <- "12"
DelLib$Column[DelLib$Column=="1"] <- "01"
DelLib$Column[DelLib$Column=="2"] <- "02"
DelLib$Column[DelLib$Column=="3"] <- "03"
DelLib$Column[DelLib$Column=="4"] <- "04"
DelLib$Column[DelLib$Column=="5"] <- "05"
DelLib$Column[DelLib$Column=="6"] <- "06"
DelLib$Column[DelLib$Column=="7"] <- "07"
DelLib$Column[DelLib$Column=="8"] <- "08"
DelLib$Column[DelLib$Column=="9"] <- "09"

DelLib$KoLibraryPosition <- paste("Sp", DelLib$PlateNumber, DelLib$Row, DelLib$Column, sep="")
DelLib <- DelLib[,c(17,1:6, 8:11)]

# make repIntDecode
repInt_decode2 <- read.delim(file.path(out_dir, "alreadyDone_dontChange/7_2_ReporterIntensityDecode_CheckedPositions.txt"))
repInt_decode2 <- repInt_decode2[,c(5,10,11)]
names(repInt_decode2)[2] <- "StrainType_old"
names(repInt_decode2)[3] <- "Position_KO_Library_old"
repInt_decode <- merge(repInt_decode, repInt_decode2, by.x="Position_MS_Plate", 
                       by.y="Position_MS_Plate", all=FALSE)

jnk <- repInt_decode[repInt_decode$StrainType != repInt_decode$StrainType_old,]
jnk <- repInt_decode[repInt_decode$Position_KO_Library != repInt_decode$Position_KO_Library_old,]
repInt_decode <- repInt_decode[,c(1:9, 12,13)]
names(repInt_decode) <- gsub("_old", "", names(repInt_decode))
repInt_decode2 <- read.delim(file.path(out_dir, "alreadyDone_dontChange/7_2_ReporterIntensityDecode_CheckedPositions.txt"))
repInt_decode <- repInt_decode[,c(2:5, 1,6:11 )]

# ones measured multiple times
jnk <- as.data.frame(table(repInt_decode$Position_KO_Library))
jnk <- subset(jnk, Freq > 1)
jnkRows <- grep("Sp", jnk$Var1)
jnk <- jnk[jnkRows,]
jnk <- levels(droplevels(jnk$Var1))


#decide which measurement to use for double measurements # only the highest number kept
for (i in 1:length(jnk)[1]) {
  print(i)
  myProtein <- jnk[i]
  ProteinRows <- grep(myProtein, repInt_decode$Position_KO_Library)
  print(repInt_decode[ProteinRows,])
  jnk2 <- which(repInt_decode$NumberOfProteins[ProteinRows] == max(repInt_decode$NumberOfProteins[ProteinRows]))
  jnk3 <- which(repInt_decode$NumberOfProteins[ProteinRows] != max(repInt_decode$NumberOfProteins[ProteinRows]))
  print(jnk3)
  repInt_decode$Analyzed_ReMeasured[ProteinRows[jnk3]] <- "Remeasured_WillNotBeAnalyzed"
  print("done")
}

# filter for low ID for bio or add wt (1350)
lowRows <- repInt_decode$NumberOfProteins < 1350
repInt_decode$Analyzed_ReMeasured[lowRows] == "ToBeAnalyzed"
repInt_decode$StrainType[repInt_decode$NumberOfProteins < 1350 &
                           repInt_decode$Analyzed_ReMeasured == "ToBeAnalyzed"]

repInt_decode$Analyzed_ReMeasured[repInt_decode$NumberOfProteins < 1350 &
                                    repInt_decode$Analyzed_ReMeasured == "ToBeAnalyzed"] <- "LowNumberOfProteins_Excluded"

repInt_decode$Analyzed_ReMeasured[repInt_decode$NumberOfProteins < 1350 &
                                    repInt_decode$Analyzed_ReMeasured == "Remeasured_WillNotBeAnalyzed"] <- "LowNumberOfProteins_Remeasured_WillNotBeAnalyzed"
# add how many proteins identified in the run and difference columns
jnk <- repInt_decode[,c(2,6)]
jnk <- aggregate(NumberOfProteins ~ RawFileSuffix, data = jnk, max)
names(jnk)[2] <- "NumberOfProtein_WholeRun"

repInt_decode <- merge(repInt_decode, jnk, by.x="RawFileSuffix", by.y="RawFileSuffix", all=FALSE)
repInt_decode$NumberOfProteinsLess_Sample <- repInt_decode$NumberOfProteins - repInt_decode$NumberOfProtein_WholeRun

# decide what to exclude from analysis
table(repInt_decode$StrainType[repInt_decode$NumberOfProteinsLess_Sample < -1 & repInt_decode$Analyzed_ReMeasured == "ToBeAnalyzed"])
# exclude the additional and biological wild type
repInt_decode$Analyzed_ReMeasured[repInt_decode$NumberOfProteinsLess_Sample < -1 & (repInt_decode$StrainType == "Additional_WildType" | repInt_decode$StrainType == "Biological_WildType")] <- "LowNumberOfProteins_Run_Excluded"
# knock-outs / proteinNumbers are high enough so keep them no more repetition
repInt_decode[repInt_decode$NumberOfProteinsLess_Sample < -1 & repInt_decode$StrainType == "Knock-out" & repInt_decode$Analyzed_ReMeasured == "ToBeAnalyzed",]
# technical wt with less id ---- try during normalization to decide limit to number of proteins identified in wt
# or maybe average of the run is enough
repInt_decode$Analyzed_ReMeasured[repInt_decode$NumberOfProteinsLess_Sample < 0 & repInt_decode$StrainType == "Technical_WildType"] <- "ToBeAnalyzed_try_limitMeasured"


# merge the repInt_decode with DelLib 
repInt_decode_merged <- merge(repInt_decode, DelLib, by.x="Position_KO_Library", by.y="KoLibraryPosition", all.x=TRUE)

repInt_decode_merged <- repInt_decode_merged[,c(3,2,4,5,6,10,11,1,14:22,8,9,12,7,13,23)]
repInt_decode_merged <- repInt_decode_merged[,c(1:5,18:22,6:17,23)]
write.table(repInt_decode_merged, file.path(out_dir,paste0("2_5_2_", Sys.Date(), "_ReporterIntensityDecode_merged_SupTable1.txt")),
            quote = F, row.names = F, sep="\t")
rm(DelLib)
rm(jnk)
rm(repInt_decode)
rm(repInt_decode2)
rm(repInt_decode_merged)
# jnk <- read.delim("ScreenProteome/alreadyDone_dontChange/7_3_ReporterIntensityDecode_merged_SupTable1.txt")
# jnk2 <- as.data.frame(table(repInt_decode_merged[,c(11,13)]))
# jnk3 <- as.data.frame(table(jnk[,c(11,13)]))
# jnk2 <- jnk2[jnk2$Freq>0,]
# jnk3 <- jnk3[jnk3$Freq>0,]
# 2.5.2.2 # change the Supplementary table from "ScreenProteome/alreadyDone_dontChange/7_3_ReporterIntensityDecode_merged_SupTable1.txt" #####
rm(jnk)
rm(jnk2)
rm(jnk3)
rm(repInt_decode_merged)
myfile <- list.files(path = out_dir, pattern="^2_5_2.*txt")
S1new <- read.delim(file.path(out_dir, myfile))
S1old <- read.delim("ScreenProteome/alreadyDone_dontChange/7_3_ReporterIntensityDecode_merged_SupTable1.txt")

S1new <- S1new[with(S1new, order(IntensityColumnNames_used)), ]
S1old <- S1old[with(S1old, order(IntensityColumnNames_used)), ]

S1old[S1new$StrainType != S1old$StrainType,]

S1new[S1new$StrainType != S1old$StrainType, 12:22] <- S1old[S1new$StrainType != S1old$StrainType, 12:22]
S1new[208, 11:22] <- S1old[208, 11:22]


jnk <- S1old[S1new$Analyzed_ReMeasured != S1old$Analyzed_ReMeasured,]
jnk2 <- S1new[S1new$Analyzed_ReMeasured != S1old$Analyzed_ReMeasured,]
jnk3 <- subset(S1new, StrainType=="Biological_WildType" & NumberOfProteinsLess_Sample<0)
jnk4 <- subset(S1old, StrainType=="Biological_WildType" & NumberOfProteinsLess_Sample<0)

jnk5 <- subset(S1new, Analyzed_ReMeasured=="ToBeAnalyzed")
jnk5 <- subset(jnk5, StrainType!="Additional_WildType" & StrainType!="Technical_WildType")

write.table(S1new, file.path(out_dir,paste0("2_5_2_2_", Sys.Date(), "_SupplementaryTable1_ScreenDecode.txt")),
            quote = F, row.names = F, sep="\t")

rm(jnk)
rm(jnk2)
rm(jnk3)
rm(jnk4)
rm(jnk5)
rm(S1new)
rm(S1old)
#################################################################################################################################
# 2.5.3 # filter the pg_ident for columns to analyze ################################################################
myfile <- list.files(path=out_dir, pattern = "^2_0_.*")
pG <- readRDS(file.path(out_dir, myfile))
repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG))
pG_rep <- pG[,c(1,repCol)]

pG_rep[pG_rep==0] <- NA
pG_rep[,2:dim(pG_rep)[2]] <- log2(pG_rep[,2:dim(pG_rep)[2]])

df_pg2 <- pG_rep
rm(pG)
rm(pG_rep)

df_pg2_ID <- as.data.frame(cbind(df_pg2$Protein.IDs, df_pg2$Protein.IDs))
df_pg2_ID <- splitColumnBySep(df_pg2_ID, "V2")
df_pg2_ID$geneID <- gsub("(SP.*\\..*)\\.1\\:pep.*","\\1",df_pg2_ID$V2)
df_pg2_ID$geneID_length <- nchar(df_pg2_ID$geneID)

df_pg2_ID <- df_pg2_ID[,c(1,3)]
df_pg2_ID2 <- df_pg2_ID %>%
  group_by(V1) %>%
  dplyr::summarise(text=paste(geneID,collapse=';')) %>%
  as.data.frame()
rm(df_pg2_ID)
df_pg2_2 <- merge(df_pg2, df_pg2_ID2, by.x="Protein.IDs", by.y="V1")
df_pg2 <- df_pg2_2
rm(df_pg2_2)
rm(df_pg2_ID2)

# change intensity names to ms plate position names
rownames(df_pg2) <- df_pg2$text
df_pg2 <- df_pg2[,-c(1,dim(df_pg2)[2])]
df_pg2 <- as.data.frame(t(df_pg2))
df_pg2$Strain <- rownames(df_pg2)

myfile <- list.files(path=out_dir, pattern = "^2_5_2_2_.*Supplementary.*")
repInt_decode_merged <- read.delim(file.path(out_dir, myfile))

repInt_filtered <- subset(repInt_decode_merged, Analyzed_ReMeasured == "ToBeAnalyzed_try_limitMeasured" | Analyzed_ReMeasured == "ToBeAnalyzed")
rm(repInt_decode_merged)
df_pg2 <- df_pg2[rownames(df_pg2) %in% repInt_filtered$IntensityColumnNames_used,]
repInt_tomerge <- repInt_filtered[c(3,5)]

df_pg2 <- merge(df_pg2, repInt_tomerge, by.x="Strain", by.y="IntensityColumnNames_used", all=FALSE)
rownames(df_pg2) <- df_pg2$Position_MS_Plate
jnk <- grep("Strain|IntensityColumnNames_used|Position_MS_Plate", names(df_pg2))
df_pg2 <- df_pg2[,-jnk]
df_pg2 <- as.data.frame(t(df_pg2))
# remove the rows with no values
df_pg2 <- df_pg2[rowSums(is.na(df_pg2)) != dim(df_pg2)[2],]

saveRDS(df_pg2, file.path(out_dir, paste0("2_5_3_", Sys.Date(), "_pg_ident_IntensityColsToBeAnalysed_MSplatePositions.rds")))
rm(df_pg2)
rm(repInt_filtered)
rm(repInt_tomerge)
# 2.5.4 # include ko strain name in the ms position name ################################################################
myfile <- list.files(path=out_dir, pattern = "^2_5_3_.*")
df_pg2 <- readRDS(file.path(out_dir, myfile))

df_pg2 <- as.data.frame(t(df_pg2))
df_pg2$Strain <- rownames(df_pg2)

myfile <- list.files(path=out_dir, pattern = "^2_5_2_2_.*Supplementary.*")
repInt_decode_merged <- read.delim(file.path(out_dir, myfile))

repInt_filtered <- subset(repInt_decode_merged, Analyzed_ReMeasured == "ToBeAnalyzed_try_limitMeasured" | Analyzed_ReMeasured == "ToBeAnalyzed")
rm(repInt_decode_merged)
repInt_tomerge <- repInt_filtered[c(5,12,16)]

repInt_tomerge$Systemic.ID[repInt_tomerge$StrainType == "Additional_WildType"] <- "ADD"
repInt_tomerge$Systemic.ID[repInt_tomerge$StrainType == "Biological_WildType"] <- "BIO"
repInt_tomerge$Systemic.ID[repInt_tomerge$StrainType == "Technical_WildType"] <- "TECH"
repInt_tomerge <- repInt_tomerge[c(1,3)]
repInt_tomerge$NewID <- paste(repInt_tomerge$Position_MS_Plate, repInt_tomerge$Systemic.ID, sep="-")
repInt_tomerge <- repInt_tomerge[c(1,3)]

df_pg2 <- merge(df_pg2, repInt_tomerge, by.x="Strain", by.y="Position_MS_Plate", all=FALSE)
rownames(df_pg2) <- df_pg2$NewID
jnk <- grep("Strain|NewID|Position_MS_Plate", names(df_pg2))
df_pg2 <- df_pg2[,-jnk]
df_pg2 <- as.data.frame(t(df_pg2))

saveRDS(df_pg2, file.path(out_dir, paste0("2_5_4_", Sys.Date(), "_pg_ident_IntensityColsToBeAnalysed_MSplatePositions_SystemicID.rds")))
rm(df_pg2)
rm(repInt_filtered)
rm(repInt_tomerge)
# 3 # Normalization # old 7 from the analysis script ####################################################################
# 3.0 # remove wt_add ###################################################################################################
myfile <- list.files(path=out_dir, pattern = "^2_5_4_.*")
df <- readRDS(file.path(out_dir, myfile))

wt_add <- grep("ADD", names(df))
df <- df[, -c(wt_add)]
saveRDS(df, file.path(out_dir, paste0("3_0_", Sys.Date(), "_wt_add_removed.rds")))
rm(df)

# 3.1 # remove the proteins not identified in wt tech for that run ######################################################
myfile <- list.files(path=out_dir, pattern = "^3_0_.*")
df <- readRDS(file.path(out_dir, myfile))
df_norm <- as.data.frame(df)

repInt_col <- grep("Sp", names(df_norm))

plates <- unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\1",names(df_norm)[repInt_col]))
strains <- unique(gsub("^Sp[0-9]*([^0-9]*)[0-9]*.*", "\\1",names(df_norm)[repInt_col]))

my_pg_med <- df_norm
rm(df)
rm(df_norm)
my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))

for (plate in plates) {
  print(plate)
  plate_col <- grep(plate, names(my_pg_med))
  my_pg_med_subset <- my_pg_med[,plate_col]
  
  experiments <- paste(unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\2",names(my_pg_med_subset))), "[-]", sep="")
  for(exp in experiments){
    print(exp)
    exp_col <- grep(exp, names(my_pg_med_subset))
    
    my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
    
    norm_col <- grep("WT_Tech", names(my_pg_med_subset2))
    my_pg_med_subset2[is.na(my_pg_med_subset2[,norm_col]),] <- NA
    
    my_pg_med_subset2$Proteins <- rownames(my_pg_med_subset2)
    my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset2, by.x="Proteins", by.y="Proteins")
    
  }
}  
rownames(my_wt_normalized) <- my_wt_normalized$Proteins
my_wt_normalized <- my_wt_normalized[,-1]

saveRDS(my_wt_normalized, file.path(out_dir, paste0("3_1_", Sys.Date(), "_Filtered4Proteins_WTtech.rds")))

rm(my_pg_med)
rm(my_pg_med_subset)
rm(my_pg_med_subset2)
rm(my_wt_normalized)
# 3.2 # wtTech_MEDIAN_MEDIANrunNormalized ##############################################################
# 3.2.1 # wtTech #######################################################################################
myfile <- list.files(path=out_dir, pattern = "^3_1_.*")
df_norm <- readRDS(file.path(out_dir, myfile))
repInt_col <- grep("Sp", names(df_norm))

plates <- unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\1",names(df_norm)[repInt_col]))
strains <- unique(gsub("^Sp[0-9]*([^0-9]*)[0-9]*.*", "\\1",names(df_norm)[repInt_col]))

my_pg_med <- df_norm
for (mycol in 1:dim(my_pg_med)[2]) {
  my_pg_med[,mycol] <- as.numeric(my_pg_med[,mycol])
}

jnk_median_allProteins <- apply(my_pg_med, 1, median,na.rm = TRUE)

my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))

for (plate in plates) {
  print(plate)
  plate_col <- grep(plate, names(my_pg_med))
  my_pg_med_subset <- my_pg_med[,plate_col]
  experiments <- paste(unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\2",names(my_pg_med_subset))), "[-]", sep="")
  
  for(exp in experiments){
    print(exp)
    exp_col <- grep(exp, names(my_pg_med_subset))
    my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
    
    norm_col <- grep("WT_Tech", names(my_pg_med_subset2))
    my_pg_med_subset_wtNorm <- normalize2wtTech(my_pg_med_subset2, norm_col)
    my_pg_med_subset_wtNorm$Proteins <- rownames(my_pg_med_subset_wtNorm)
    my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset_wtNorm, by.x="Proteins", by.y="Proteins")
  }
}  

my_pg_med <- my_wt_normalized

my_pg_med[,2:dim(my_pg_med)[2]] <- my_pg_med[,2:dim(my_pg_med)[2]] + jnk_median_allProteins
rownames(my_pg_med) <- my_pg_med$Proteins
my_pg_med <- my_pg_med[,-1]

saveRDS(my_pg_med, file.path(out_dir, paste0("3_2_1_", Sys.Date(), "_wtTechNORMALIZED.rds")))

rm(df_norm)
rm(my_pg_med_subset)
rm(my_pg_med_subset_wtNorm)
rm(my_pg_med)
rm(my_pg_med_subset2)  
rm(my_wt_normalized)  

# 3.2.2 # MEDIANrun ######################################################################################
myfile <- list.files(path=out_dir, pattern = "3_2_1_")
df_norm <- readRDS(file.path(out_dir, myfile))

repInt_col <- grep("Sp", names(df_norm))

plates <- unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\1",names(df_norm)[repInt_col]))
strains <- unique(gsub("^Sp[0-9]*([^0-9]*)[0-9]*.*", "\\1",names(df_norm)[repInt_col]))

my_pg_med <- df_norm
rm(df_norm)
for (mycol in 1:dim(my_pg_med)[2]) {
  my_pg_med[,mycol] <- as.numeric(my_pg_med[,mycol])
}
my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))

for (plate in plates) {
  print(plate)
  plate_col <- grep(plate, names(my_pg_med))
  my_pg_med_subset <- my_pg_med[,plate_col]
  experiments <- paste(unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\2",names(my_pg_med_subset))), "[-]", sep="")
  
  for(exp in experiments){
    print(exp)
    exp_col <- grep(exp, names(my_pg_med_subset))
    my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
    
    colMedian <- apply(my_pg_med_subset2, 2, median,na.rm = TRUE)
    colMedian <- as.numeric(colMedian)
    myRunMedian <- median(colMedian)
    
    for (mycol in 1:dim(my_pg_med_subset2)[2]) {
      my_pg_med_subset2[,mycol] <- my_pg_med_subset2[,mycol] - colMedian[mycol] + myRunMedian
    }
    
    my_pg_med_subset_wtNorm <- my_pg_med_subset2
    my_pg_med_subset_wtNorm$Proteins <- rownames(my_pg_med_subset_wtNorm)
    my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset_wtNorm, by.x="Proteins", by.y="Proteins")
  }
}  
my_pg_med <- my_wt_normalized
rownames(my_pg_med) <- my_pg_med$Proteins
my_pg_med <- my_pg_med[,-1]

saveRDS(my_pg_med, file.path(out_dir, paste0("3_2_2_", Sys.Date(), "_MEDIANrun.rds")))

rm(my_pg_med_subset)
rm(my_pg_med_subset_wtNorm)
rm(my_pg_med)
rm(my_pg_med_subset2)  
rm(my_wt_normalized)  
rm(colMedian)
# 3.2.3 # MEDIAN of proteins from the run #############################################################
myfile <- list.files(path=out_dir, pattern = "3_2_2_")
df_norm <- readRDS(file.path(out_dir, myfile))

repInt_col <- grep("Sp", names(df_norm))

plates <- unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\1",names(df_norm)[repInt_col]))
strains <- unique(gsub("^Sp[0-9]*([^0-9]*)[0-9]*.*", "\\1",names(df_norm)[repInt_col]))

my_pg_med <- df_norm
jnk_median_allProteins <- apply(my_pg_med, 1, median,na.rm = TRUE)

my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))

for (plate in plates) {
  print(plate)
  plate_col <- grep(plate, names(my_pg_med))
  my_pg_med_subset <- my_pg_med[,plate_col]
  experiments <- paste(unique(gsub("(Sp[0-9]*)[^0-9]*([0-9]*).*", "\\2",names(my_pg_med_subset))), "[-]", sep="")
  for(exp in experiments){
    print(exp)
    exp_col <- grep(exp, names(my_pg_med_subset))
    my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
    
    norm_col <- apply(my_pg_med_subset2, 1, median, na.rm=TRUE)
    
    my_pg_med_subset_wtNorm <- my_pg_med_subset2- norm_col
    
    my_pg_med_subset_wtNorm$Proteins <- rownames(my_pg_med_subset_wtNorm)
    my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset_wtNorm, by.x="Proteins", by.y="Proteins")
  }
}  

my_pg_med <- my_wt_normalized

my_pg_med[,2:dim(my_pg_med)[2]] <- my_pg_med[,2:dim(my_pg_med)[2]] + jnk_median_allProteins
rownames(my_pg_med) <- my_pg_med$Proteins
my_pg_med <- my_pg_med[,-1]

saveRDS(my_pg_med, file.path(out_dir, paste0("3_2_3_", Sys.Date(), "_MEDIANproteinsRUN.rds")))

rm(df_norm)
rm(my_pg_med)
rm(my_pg_med_subset)
rm(my_pg_med_subset2)
rm(my_pg_med_subset_wtNorm)
rm(my_wt_normalized)
# # 3.3 # compare the median all and median proteins to median run and median proteins #################
# med_old <- readRDS("ScreenProteome/obsolete/3_2_2_2019-05-08_MEDIAN.rds")
# medprot_old <- readRDS("ScreenProteome/obsolete/3_2_3_2019-05-08_MEDIANproteinsRUN.rds")
# 
# med_new <- readRDS("ScreenProteome/3_2_2_2019-05-17_MEDIANrun.rds")
# medprot_new <- readRDS("ScreenProteome/3_2_3_2019-05-17_MEDIANproteinsRUN.rds")
# 
# 
# length(setdiff(names(med_old), names(med_new)))
# sum(names(med_old)==names(med_new))
# sum(names(med_old)==names(medprot_new))
# sum(rownames(med_old)==rownames(med_new))
# sum(rownames(med_old)==rownames(medprot_new))
# sum(rownames(medprot_old)==rownames(medprot_new))
# length(setdiff(names(medprot_old), names(medprot_new)))
# sum(names(medprot_old)==names(medprot_new))
# 
# my_pG <- data.frame(MyComparisonStrain=colnames(med_new), Pearson_NA=0, Pearson_0=0,
#                     Old_pG=0, New_pG=0, Overlap=0)
# 
# my_pG_prot <- data.frame(MyComparisonStrain=colnames(med_new), Pearson_NA=0, Pearson_0=0,
#                     Old_pG=0, New_pG=0, Overlap=0)
# 
# med_old_0 <- med_old
# med_old_0[is.na(med_old_0)] <- 0
# medprot_old_0 <- medprot_old
# medprot_old_0[is.na(medprot_old_0)] <- 0
# 
# med_new_0 <- med_new
# med_new_0[is.na(med_new_0)] <- 0
# medprot_new_0 <- medprot_new
# medprot_new_0[is.na(medprot_new_0)] <- 0
# 
# for (i in 1:dim(med_new)[2]) {
#   print(i)
#   my_pG$Pearson_NA[i] <- cor(med_new[,i], med_old[,i], use = "pairwise.complete.obs", method = "pearson")[1]
#   my_pG$Pearson_0[i] <- cor(med_new_0[,i], med_old_0[,i], use = "complete.obs", method = "pearson")[1]
#   my_pG$Old_pG[i] <- sum(!is.na(med_old[,i]))
#   my_pG$New_pG[i] <- sum(!is.na(med_new[,i]))
#   my_pG$Overlap[i] <- length(intersect(rownames(med_new)[!is.na(med_new[,i])], rownames(med_old)[!is.na(med_old[,i])]))
#   
#   my_pG_prot$Pearson_NA[i] <- cor(medprot_new[,i], medprot_old[,i], use = "pairwise.complete.obs", method = "pearson")[1]
#   my_pG_prot$Pearson_0[i] <- cor(medprot_new_0[,i], medprot_old_0[,i], use = "complete.obs", method = "pearson")[1]
#   my_pG_prot$Old_pG[i] <- sum(!is.na(medprot_old[,i]))
#   my_pG_prot$New_pG[i] <- sum(!is.na(medprot_new[,i]))
#   my_pG_prot$Overlap[i] <- length(intersect(rownames(medprot_new)[!is.na(medprot_new[,i])], rownames(medprot_old)[!is.na(medprot_old[,i])]))
# }
# saveRDS(my_pG, file.path(out_dir, paste0("3_3_", Sys.Date(), "_medianCompare.rds")))
# saveRDS(my_pG_prot, file.path(out_dir, paste0("3_3_", Sys.Date(), "_medianProteinCompare.rds")))
# # they are quite similar but still try with median run normalized for the following steps #################
# rm(med_new)
# rm(med_new_0)
# rm(med_old)
# rm(med_old_0)
# rm(medprot_new)
# rm(medprot_new_0)
# rm(medprot_old)
# rm(medprot_old_0)
# rm(my_pG)
# rm(my_pG_prot)
# # 3.4 # check if wt tech was removed before ??? #################
# e1 <- readRDS("ScreenProteome/obsolete_e_files/e_1_MEDIAN.rds")
# e2 <- readRDS("ScreenProteome/obsolete_e_files/e_2_MEDIANstrainsRUN.rds")
# e31 <- readRDS("ScreenProteome/obsolete_e_files/e_3_1_MEDIANproteinsRUN.rds")
# e32 <- readRDS("ScreenProteome/obsolete_e_files/e_3_2_MEDIANproteinsRUN.rds")
# rm(e1)
# rm(e2)
# rm(e31)
# rm(e32)
# # same dimensions 4239 strains so wt tech was kept ##############
# #######################################################################################################
}
if(QC) {
  # # on the side # compare old and new df ##################################
  # df_new <- readRDS("ScreenProteome/3_2_3_2019-05-08_MEDIANproteinsRUN.rds")
  # df_old <- readRDS("C:/Users/moeztuer/Desktop/_analysis/20181022_reAnalysis/e_3_2_MEDIANproteinsRUN.rds")
  # 
  # names(df_new) <- gsub("(.*)\\-.*", "\\1", names(df_new))
  # 
  # length(setdiff(names(df_old), names(df_new)))
  # sum(names(df_new)==names(df_old))
  # 
  # df_new <- df_new[,match(colnames(df_old), colnames(df_new))]
  # sum(names(df_new)==names(df_old))
  # 
  # length(setdiff(rownames(df_old), rownames(df_new)))
  # length(setdiff(rownames(df_new), rownames(df_old)))
  # 
  # jnk <- intersect(rownames(df_new), rownames(df_old))
  # 
  # df_new <- df_new[rownames(df_new) %in% jnk,]
  # df_old <- df_old[rownames(df_old) %in% jnk,]
  # 
  # df_new <- df_new[match(rownames(df_old), rownames(df_new)),]
  # sum(names(df_new)==names(df_old))
  # sum(rownames(df_new)==rownames(df_old))
  # 
  # my_df <- data.frame(MyComparisonStrain=colnames(df_new), Pearson_NA=0, Pearson_0=0,
  #                     Old_pG=0, New_pG=0, Overlap=0)
  # 
  # df_new_0 <- df_new
  # df_old_0 <- df_old
  # df_new_0[is.na(df_new_0)] <- 0
  # df_old_0[is.na(df_old)] <- 0
  # 
  # for (i in 1:dim(df_new)[2]) {
  #   print(i)
  #   my_df$Pearson_NA[i] <- cor(df_new[,i], df_old[,i], use = "pairwise.complete.obs", method = "pearson")[1]
  #   my_df$Pearson_0[i] <- cor(df_new_0[,i], df_old_0[,i], use = "complete.obs", method = "pearson")[1]
  #   my_df$Old_pG[i] <- sum(!is.na(df_old[,i]))
  #   my_df$New_pG[i] <- sum(!is.na(df_new[,i]))
  #   my_df$Overlap[i] <- length(intersect(rownames(df_new)[!is.na(df_new[,i])], rownames(df_old)[!is.na(df_old[,i])]))
  # }
  # saveRDS(my_df, "20190515_old-new_comparison.rds")
  # # on the side # compare old and new protein groups ##################################
  # pG_old <- read.delim("X:/_MS_DATA_OUT/Merve/20180818_combined_someRepeated/txt/proteinGroups.txt")
  # pG_new <- read.delim("Y:/Publications/SpombeSystems/MaxQuantOutputs/Screen_combined_1U_noMBR/txt/proteinGroups.txt")
  # 
  # pG_old <- my_pG_filter(pG_old,1,1)
  # repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG_old))
  # pG_old <- pG_old[,c(1,repCol)]
  # pG_old[pG_old==0] <- NA
  # pG_old[,2:dim(pG_old)[2]] <- log2(pG_old[,2:dim(pG_old)[2]])
  # 
  # pG_new <- my_pG_filter(pG_new,1,1)
  # repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG_new))
  # pG_new <- pG_new[,c(1,repCol)]
  # pG_new[pG_new==0] <- NA
  # pG_new[,2:dim(pG_new)[2]] <- log2(pG_new[,2:dim(pG_new)[2]])
  # 
  # rownames(pG_old) <- pG_old$Protein.IDs
  # rownames(pG_new) <- pG_new$Protein.IDs
  # 
  # pG_old <- pG_old[,-1]
  # pG_new <- pG_new[,-1]
  # 
  # df_pg2_ID <- as.data.frame(cbind(rownames(pG_new), rownames(pG_new)))
  # df_pg2_ID <- splitColumnBySep(df_pg2_ID, "V2")
  # df_pg2_ID$geneID <- gsub("(SP.*\\..*)\\.1\\:pep.*","\\1",df_pg2_ID$V2)
  # df_pg2_ID$geneID_length <- nchar(df_pg2_ID$geneID)
  # 
  # df_pg2_ID <- df_pg2_ID[,c(1,3)]
  # df_pg2_ID2 <- df_pg2_ID %>%
  #   group_by(V1) %>%
  #   dplyr::summarise(text=paste(geneID,collapse=';')) %>%
  #   as.data.frame()
  # rm(df_pg2_ID)
  # 
  # pG_new$Strain <- rownames(pG_new)
  # 
  # pG_new <- merge(pG_new, df_pg2_ID2, by.x="Strain", by.y="V1")
  # rm(df_pg2_ID2)
  # 
  # # change intensity names to ms plate position names
  # rownames(pG_new) <- pG_new$text
  # pG_new <- pG_new[,-c(1,dim(pG_new)[2])]
  # 
  # length(setdiff(names(pG_old), names(pG_new)))
  # sum(names(pG_new)==names(pG_old))
  # 
  # pG_new <- pG_new[,match(colnames(pG_old), colnames(pG_new))]
  # sum(names(pG_new)==names(pG_old))
  # 
  # length(setdiff(rownames(pG_old), rownames(pG_new)))
  # length(setdiff(rownames(pG_new), rownames(pG_old)))
  # 
  # jnk <- intersect(rownames(pG_new), rownames(pG_old))
  # 
  # pG_new <- pG_new[rownames(pG_new) %in% jnk,]
  # pG_old <- pG_old[rownames(pG_old) %in% jnk,]
  # 
  # pG_new <- pG_new[match(rownames(pG_old), rownames(pG_new)),]
  # sum(names(pG_new)==names(pG_old))
  # sum(rownames(pG_new)==rownames(pG_old))
  # 
  # my_pG <- data.frame(MyComparisonStrain=colnames(pG_new), Pearson_NA=0, Pearson_0=0,
  #                     Old_pG=0, New_pG=0, Overlap=0)
  # 
  # pG_new_0 <- pG_new
  # pG_old_0 <- pG_old
  # pG_new_0[is.na(pG_new_0)] <- 0
  # pG_old_0[is.na(pG_old)] <- 0
  # 
  # for (i in 1:dim(pG_new)[2]) {
  #   print(i)
  #   my_pG$Pearson_NA[i] <- cor(pG_new[,i], pG_old[,i], use = "pairwise.complete.obs", method = "pearson")[1]
  #   my_pG$Pearson_0[i] <- cor(pG_new_0[,i], pG_old_0[,i], use = "complete.obs", method = "pearson")[1]
  #   my_pG$Old_pG[i] <- sum(!is.na(pG_old[,i]))
  #   my_pG$New_pG[i] <- sum(!is.na(pG_new[,i]))
  #   my_pG$Overlap[i] <- length(intersect(rownames(pG_new)[!is.na(pG_new[,i])], rownames(pG_old)[!is.na(pG_old[,i])]))
  # }
  # saveRDS(my_pG, "20190516_old-new_comparison.rds")
  # 
  # 
  ####################################################################################
  # 4 # Quality control and additional filtering for wt bio ###############################################################
  # 4.0 # initial QC not normalized ####
  myfile <- list.files(path = out_dir, pattern = "^3_1_")
  df <- readRDS(file.path(out_dir, myfile))
  
  myP <- myQCnormalization(df, "RawData")

  pdf(file.path(out_dir, paste0("4_0_1_", Sys.Date(), "_QC_ALL_RawData_3_1.pdf")),height = 15, width = 13)
  print(myP)
  dev.off()
  
  df2 <- df[rowSums(!is.na(df))==dim(df)[2],]
  myP <- myQCnormalization(df2, "RawData")
  pdf(file.path(out_dir, paste0("4_0_2_", Sys.Date(), "_QC_513_RawData_3_1.pdf")),height = 15, width = 13)
  print(myP)
  dev.off()
  rm(df2)
  rm(myP)
  myfile <- list.files(path = out_dir, pattern = "^3_2_1_")
  df <- readRDS(file.path(out_dir, myfile))
  myP <- myQCnormalization(df, "WTtech")
  pdf(file.path(out_dir, paste0("4_0_3_", Sys.Date(), "_QC_ALL_WTtech_3_2_1.pdf")),height = 15, width = 13)
  print(myP)
  dev.off()
  
  df2 <- df[rowSums(!is.na(df))==dim(df)[2],]
  myP <- myQCnormalization(df2, "WTtech")
  pdf(file.path(out_dir, paste0("4_0_4_", Sys.Date(), "_QC_513_WTtech_3_2_1.pdf")),height = 15, width = 13)
  print(myP)
  dev.off()
  rm(df2)
  rm(myP)
  # 4.1 # initial QC ####
  myfile <- list.files(path = out_dir, pattern = "3_2_3_")
  df <- readRDS(file.path(out_dir, myfile))
  myP <- myQCnormalization(df, "MEDIANproteinsRUN")
  pdf(file.path(out_dir, paste0("4_1_1_", Sys.Date(), "_QC_ALL_MEDIANproteinsRUN_3_2_3.pdf")),height = 15, width = 13)
  print(myP)
  dev.off()
  
  df2 <- df[rowSums(!is.na(df))==dim(df)[2],]
  myP <- myQCnormalization(df2, "MEDIANproteinsRUN")
  pdf(file.path(out_dir, paste0("4_1_2_", Sys.Date(), "_QC_513_MEDIANproteinsRUN_3_2_3.pdf")),height = 15, width = 13)
  print(myP)
  dev.off()
  rm(df2)
  rm(myP)
  # 4.2.4 # remove wt_tech and DONT filter wt_bio ##################################################################
  myfile <- list.files(path = out_dir, pattern = "3_2_3_")
  df <- readRDS(file.path(out_dir, myfile))
  jnk <- grep("WT_Tech", names(df))
  df <- df[,-jnk]
  saveRDS(df, file.path(out_dir, paste0("4_2_4_1_", Sys.Date(), "_dfNormalized_noWTtech.rds")))
  
  rm(df)
  ########################################################################################################################
}
if(QCafterFiltering){
  # 5 # filtering additionally for pG in terms of power in wt_bio #######################################################
  # 5.1 # effect of normalization and cor2original data ################################################################
  myfile <- list.files(path = out_dir, pattern = "^3_1")
  df_original <- readRDS(file.path(out_dir, myfile))
  
  myfile <- list.files(path = out_dir, pattern = "^4_2_4_1")
  df <- readRDS(file.path(out_dir, myfile))
  
  p1 <- effectOfNormalization(df_original, df)
  p2 <- cor2originalData(df_original, df)
  
  # power
  wtBioCol <- grep("WT_Bio", names(df))
  df_wtBio <- df[ ,wtBioCol]
  
  wt_count <- rowSums(!is.na(df_wtBio))
  wt_SD <- apply(df_wtBio, 1, sd, na.rm=TRUE)
  wt_mean <- apply(df_wtBio, 1, mean, na.rm=TRUE)
  powerTable <- data.frame(Genes=rownames(df_wtBio),
                           n=wt_count, mu0= wt_mean,
                           sigma = wt_SD,
                           alpha=0.001, FC=1)
  
  powerTable$Power <- NA
  
  for (i in 1:dim(powerTable)[1]) {
    n <- powerTable$n[i]
    z <- qnorm(1 - powerTable$alpha[i])
    mu0 <- powerTable$mu0[i]
    sigma <- powerTable$sigma[i]
    
    powerTable$Power[i] <- pnorm(mu0 + z * sigma/sqrt(n), mean = mu0+powerTable$FC[i], 
                                 sd=sigma/sqrt(n), lower.tail = F)
  }
  # QC plots
  pdf(file.path(out_dir, paste0("5_1_", Sys.Date(), "_QCplots_Power.pdf")))
  print(p1)
  print(p2)
  rm(p1)
  rm(p2)
  hist(powerTable$Power, breaks = 100)
  hist(powerTable$Power, breaks = 100, ylim = c(0,20))
  
  plot(powerTable$n, powerTable$Power)
  plot(powerTable$n, powerTable$Power, xlim=c(0,50))
  jnk <- as.data.frame(table(powerTable$n, powerTable$Power))
  
  powerTable2 <- powerTable[!is.na(powerTable$Power),]
  
  p <- ggplot(powerTable2, aes(x=n, y=Power, group=n))+
    geom_boxplot()
  print(p)
  p <- ggplot(powerTable2, aes(x=n, y=Power, group=n))+
    geom_boxplot() +
    xlim(0,100)
  print(p)
  p <- ggplot(powerTable2, aes(x=n, y=Power, group=n))+
    geom_boxplot() +
    xlim(0,30)
  print(p)
  dev.off()
  rm(df_original)
  rm(p)
  rm(powerTable2)
  rm(jnk)
  # filter 4 power
  df_wtBio_filtered <- df_wtBio[powerTable$Power>=0.999 & wt_count >= 25, ]
  rows2keep <- rownames(df) %in% rownames(df_wtBio_filtered)
  df <- df[rows2keep,]
  saveRDS(df, file.path(out_dir, paste0("5_1_", Sys.Date(), "_df_normalized_noWTtech_PowerFiltered25.rds")))
  
  rm(df)
  rm(df_wtBio)
  rm(df_wtBio_filtered)
  rm(powerTable)
  # 5.2 # QC after power filtering ################################################################
  myfile <- list.files(path = out_dir, pattern = "^5_1_.*.rds")
  df <- readRDS(file.path(out_dir, myfile))

  myP <- myQCnormalization(df, "FILTERED4Power")
  pdf(file.path(out_dir, paste0("5_2_1_", Sys.Date(), "_QC_ALL_FILTERED4Power_5_1.pdf")),height = 11, width = 13)
  print(myP)
  dev.off()
  
  df2 <- df[rowSums(!is.na(df))==dim(df)[2],]
  myP <- myQCnormalization(df, "FILTERED4Power")
  pdf(file.path(out_dir, paste0("5_2_2_", Sys.Date(), "_QC_513_FILTERED4Power_5_1.pdf")),height = 11, width = 13)
  print(myP)
  dev.off()
  
  rm(df)
  rm(df2)
  rm(myP)
  # 5.3 # check pg count in wt_bio ### to be con't#############################################################
  myfile <- list.files(path = out_dir, pattern = "^5_1_.*.rds")
  df <- readRDS(file.path(out_dir, myfile))
  my_df <- data.frame(pG=rownames(df))
  
  wt_col <- grep("WT_Bio", names(df))
  my_df$wt_count <- rowSums(!is.na(df[, wt_col]))
  my_df$wt_sd <- apply(df[, wt_col],1, sd, na.rm=TRUE)
  my_df$wt_mean <- apply(df[, wt_col],1,mean, na.rm=TRUE)
  
  my_df$ko_count <- rowSums(!is.na(df[, -wt_col]))
  my_df$ko_sd <- apply(df[, -wt_col],1, sd, na.rm=TRUE)
  my_df$ko_mean <- apply(df[, -wt_col],1,mean, na.rm=TRUE)
  
  jk <- cor(my_df[,2:7])
  library(ppcor)
  jk2 <- pcor(my_df[,2:7])
  
  ggplot(my_df, aes(x=wt_count, y=ko_count))+
    geom_point(aes(color=wt_mean))
  ggplot(my_df, aes(x=wt_count, y=ko_count))+
    geom_point(aes(color=ko_mean))
  
  ggplot(my_df, aes(x=wt_count, y=wt_mean))+
    geom_point(aes(color=wt_sd, size=wt_sd))+
    scale_color_gradient2(low="black", mid = "blue", high = "red", midpoint = 0.7)
  
  ggplot(my_df, aes(x=wt_mean, y=1/wt_sd))+
    geom_point(aes(color=wt_count))
  
  ggplot(my_df, aes(x=ko_sd, y=wt_sd))+
    geom_point(aes(color=ko_count))+
    scale_color_gradient2(low="black", mid = "blue", high = "red", midpoint = 17)
  
  ggplot(my_df, aes(x=wt_sd, y=ko_sd))+
    geom_point(aes(color=wt_mean))
  
  ########################################################################################################################
}
if(ZscoreCalculate_ecdf){
  # 6 # calculate Z-score, pvalue, pvalue-FDR, FC ... ####################################################################
  # 6.1 # Zscore #########################################################################################################
  myfile <- list.files(path = out_dir, pattern = "^5_1_.*.rds")
  df_normalized <- readRDS(file.path(out_dir, myfile))
  
  numberOfStrains <- dim(df_normalized)[2]
  allCols <- 1:numberOfStrains
  wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
  koCols <- setdiff(allCols, wtCols) 
  
  # assume normal distribution because when all data points on;y 1 is not significant
  # for just wild-type measurements it is 875 after p value correction not normal out of 2562 = 34%
  # df_normalized_rowNormality <- apply(df_normalized[,wtCols], 1, my.shapiro.test)
  # hist(-log10(df_normalized_rowNormality), 100)
  # df_normalized_rowNormality_corrected <- p.adjust(df_normalized_rowNormality, method = "fdr")
  # hist(-log10(df_normalized_rowNormality_corrected), 100)
  # hist(-log10(df_normalized_rowNormality_corrected), 100, xlim=c(0,50))
  # 
  # sum(df_normalized_rowNormality > 0.05)
  # sum(df_normalized_rowNormality_corrected > 0.05)
  # max(df_normalized_rowNormality_corrected)
  # df_normalized_rowCount <- rowSums(!is.na(df_normalized[,wtCols]))
  
  wt_Mean <- rowMeans(df_normalized[, wtCols], na.rm = T)
  wt_SD <- apply(df_normalized[, wtCols],1,sd, na.rm=TRUE)
  
  df_normalized_Zscore <- df_normalized - wt_Mean
  df_normalized_Zscore <- df_normalized_Zscore / wt_SD
  
  saveRDS(df_normalized_Zscore, file.path(out_dir, paste0("6_1_", Sys.Date(), "_dfNormalized_Zscore.rds")))
  rm(df_normalized)
  rm(df_normalized_Zscore)
  # 6.2 # p-value ##################################################################################################
  myfile <- list.files(path = out_dir, pattern = "^6_1_.*.rds")
  df_Zscore <- readRDS(file.path(out_dir, myfile))
  
  df_Zscore_pvalue <- 2*pnorm(-abs(as.matrix(df_Zscore)))
  df_Zscore_pvalue <- as.data.frame(df_Zscore_pvalue)
  
  
  pdf(file.path(out_dir, paste0("6_2_1_", Sys.Date(), "_Zscore_pvale_distribution.pdf")),height = 11, width = 13)
  hist(as.numeric(as.matrix(df_Zscore)), xlim = c(-5,5), breaks=1000, xlab="Zscore", main="Zscore distribution")
  hist(as.numeric(-log10(as.matrix(df_Zscore_pvalue))), xlim=c(0,4),breaks=1000, xlab="-log10(pvalue)", main="pvalue distribution")
  hist(as.numeric(as.matrix(df_Zscore_pvalue)), xlim=c(0,1),breaks=1000, xlab="pvalue", main="pvalue distribution")
  dev.off()

  saveRDS(df_Zscore_pvalue, file.path(out_dir, paste0("6_2_2_", Sys.Date(), "_dfNormalized_pvalue.rds")))
  rm(df_Zscore)
  rm(df_Zscore_pvalue)
  # 6.3 # p-value corrected ###########################################################################################
  myfile <- list.files(path = out_dir, pattern = "^6_2_.*.rds")
  df_Zscore_pvalue <- readRDS(file.path(out_dir, myfile))
  
  df_Zscore_pvalue$pG <- rownames(df_Zscore_pvalue)
  df_Zscore_pvalue_melt <- melt(df_Zscore_pvalue, id="pG")
  names(df_Zscore_pvalue_melt) <- c("Protein", "Gene", "pValue")
  
  df_Zscore_pvalue_melt$p_FDR <- p.adjust(df_Zscore_pvalue_melt$pValue, method = "fdr", n = length(df_Zscore_pvalue_melt$pValue))
  
  # cor(df_Zscore_pvalue_melt$p_FDR, df_Zscore_pvalue_melt$p_FDR2, use = 'pairwise.complete.obs')
  
  df_Zscore_pvalue_melt2 <- df_Zscore_pvalue_melt[,c(1,2,4)]
  df_Zscore_pvalue_melt2 <- dcast(df_Zscore_pvalue_melt2, Protein ~ Gene, value.var = "p_FDR")
  rownames(df_Zscore_pvalue_melt2) <- df_Zscore_pvalue_melt2$Protein
  df_Zscore_pvalue_melt2 <- df_Zscore_pvalue_melt2[,-1]
  
  saveRDS(df_Zscore_pvalue, file.path(out_dir, paste0("6_3_", Sys.Date(), "_dfNormalized_pvalue_FDRcorrected.rds")))
  rm(df_Zscore_pvalue)
  rm(df_Zscore_pvalue_melt)
  rm(df_Zscore_pvalue_melt2)
  # 6.4 # Fold Change ########################################################################################
  myfile <- list.files(path = out_dir, pattern = "^5_1_.*.rds")
  df_normalized <- readRDS(file.path(out_dir, myfile))
  
  wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
  wt_Mean <- rowMeans(df_normalized[, wtCols], na.rm = T)
  df_normalized_FC <- df_normalized - wt_Mean
  saveRDS(df_normalized_FC, file.path(out_dir, paste0("6_4_", Sys.Date(), "_dfNormalized_FC.rds")))
  rm(df_normalized_FC)
  rm(df_normalized)
  # 6.5 # put the tables together #####################################################################################
  jnk <- as.data.frame(list.files(path=out_dir, pattern = "6_[1-4].*.rds", recursive=FALSE))
  names(jnk) <- "jnk"
  jnk$code <- c("Zscore", "p_value", "pvalue_FDR","FC")
  
  myfile <- list.files(path = out_dir, pattern = "^5_1_.*.rds")
  df <- readRDS(file.path(out_dir, myfile))
  
  df$Proteins <- rownames(df)
  df_melt <- melt(df, id="Proteins")
  rm(df)
  df_melt$identifier <- paste(df_melt$Proteins, df_melt$variable, sep="_")
  df_melt <- df_melt[,c(4,1,2,3)]
  names(df_melt)[3:4] <- c("Strain", "NormalizedValue")
  
  for (i in 1:dim(jnk)[1]) {
    print(i)
    df_jnk <- readRDS(file.path(out_dir, jnk$jnk[i]))
    df_jnk$Proteins <- rownames(df_jnk)
    df_melt_jnk <- melt(df_jnk, id="Proteins")
    df_melt_jnk$identifier <- paste(df_melt_jnk$Proteins, df_melt_jnk$variable, sep="_")
    df_melt_jnk <- df_melt_jnk[,c(4,3)]
    names(df_melt_jnk)[2] <- jnk$code[i]
    df_melt <- merge(df_melt, df_melt_jnk, by.x="identifier", by.y="identifier", all.x=TRUE)
    print(dim(df_melt))
  }
  
  df_melt <- df_melt[,-1]
  saveRDS(df_melt, file.path(out_dir, paste0("6_5_", Sys.Date(), "_meltAllInfo.rds")))
  
  rm(df_jnk)
  rm(df_melt)
  rm(df_melt_jnk)
  rm(jnk)
  # 6.6 # heatmaps #####################################
  myfile <- list.files(path = out_dir, pattern = "^6_5_.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  
  df_melt$StrainType <- "Knockout"
  df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wildtype"
  
  # 6.6.1 # normalized value ###########################
  df_heatmap <- df_melt[,1:3]
  df_heatmap <- dcast(df_heatmap, Proteins ~ Strain, value.var = "NormalizedValue")
  rownames(df_heatmap) <- df_heatmap$Proteins
  df_heatmap <- df_heatmap[,-1]
  df_heatmap$Mean <- rowMeans(df_heatmap, na.rm=TRUE)
  df_heatmap <- df_heatmap[with(df_heatmap, order(Mean, decreasing = TRUE)), ]
  df_heatmap <- df_heatmap[,-c(grep("^Mean$", names(df_heatmap)))]
  df_heatmap[is.na(df_heatmap)] <- 0  
  
  for (i in 1:dim(df_heatmap)[2]) {
    df_heatmap[,i] <- as.numeric(df_heatmap[,i])
  }
  df_heatmap <- as.data.frame(t(df_heatmap))
  
  df_heatmap$GeneName <- rownames(df_heatmap)
  df_heatmap$StrainType <- "Knockout"
  df_heatmap$StrainType[grep("WT", df_heatmap$GeneName)] <- "Wildtype"
  df_heatmap <- df_heatmap[with(df_heatmap, order(StrainType)), ]
  
  df_heatmap_annotate <- df_heatmap[,c(2460,2461)]
  rownames(df_heatmap) <- df_heatmap$GeneName
  df_heatmap <- df_heatmap[,-c(2460,2461)]
  
  mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
  rownames(mymat) <- rownames(df_heatmap)
  colnames(mymat) <- colnames(df_heatmap)
  
  mydf <- df_heatmap_annotate
  rownames(mydf) <- mydf$GeneName
  mydf <- as.data.frame(mydf[,2])
  names(mydf) <- "Strain_type"
  rownames(mydf) <- df_heatmap_annotate$GeneName
  
  mymat <- as.matrix(t(mymat))

  ann_colors = list(Strain_type = c(Knockout = "#e31a1c", Wildtype = "#1f78b4"))
  
  pheatmap(mymat, cluster_cols = F, cluster_rows = F, show_colnames=F, show_rownames=F, 
           annotation_col = mydf, border_color = NA, 
           color = colorRampPalette(brewer.pal(n = 9, name = "BuGn"))(100),
           annotation_colors = ann_colors,
           annotation_legend = FALSE,
           file=file.path(out_dir, paste0("6_6_1_", Sys.Date(), "_NormalizedValue.pdf")),
           height = 1, width = 1)
  pheatmap(mymat, cluster_cols = F, cluster_rows = F, show_colnames=F, show_rownames=F, 
           annotation_col = mydf, border_color = NA, 
           color = colorRampPalette(brewer.pal(n = 9, name = "BuGn"))(100),
           annotation_colors = ann_colors,
           annotation_legend = FALSE,
           file=file.path(out_dir, paste0("6_6_1_", Sys.Date(), "_NormalizedValue.png")),
           height = 4, width = 4)
  
  pheatmap(mymat, cluster_cols = F, cluster_rows = F, show_colnames=F, show_rownames=F, 
           annotation_col = mydf, border_color = NA, 
           color = colorRampPalette(brewer.pal(n = 9, name = "BuGn"))(100),
           annotation_colors = ann_colors,
           annotation_legend = FALSE,
           file=file.path(out_dir, paste0("6_6_1_", Sys.Date(), "_NormalizedValue.tiff")),
           height = 1, width = 1)
  pheatmap(mymat, cluster_cols = F, cluster_rows = F, show_colnames=F, show_rownames=F, 
           annotation_col = mydf, border_color = NA, 
           color = colorRampPalette(brewer.pal(n = 9, name = "BuGn"))(100),
           annotation_colors = ann_colors,
           annotation_legend = FALSE,
           file=file.path(out_dir, paste0("6_6_1_", Sys.Date(), "_NormalizedValue.jpeg")),
           height = 1, width = 1)
  # 6.6.2 # Z_score ###########################
  df_heatmap <- df_melt[,c(1,2,4)]
  df_heatmap <- dcast(df_heatmap, Proteins ~ Strain, value.var = "Zscore")
  rownames(df_heatmap) <- df_heatmap$Proteins
  df_heatmap <- df_heatmap[,-1]
  df_heatmap[is.na(df_heatmap)] <- -100  
  
  for (i in 1:dim(df_heatmap)[2]) {
    df_heatmap[,i] <- as.numeric(df_heatmap[,i])
  }
  df_heatmap <- as.data.frame(t(df_heatmap))
  
  df_heatmap$GeneName <- rownames(df_heatmap)
  df_heatmap$StrainType <- "Knockout"
  df_heatmap$StrainType[grep("WT", df_heatmap$GeneName)] <- "Wildtype"
  df_heatmap <- df_heatmap[with(df_heatmap, order(StrainType)), ]
  
  df_heatmap_annotate <- df_heatmap[,c(2460,2461)]
  rownames(df_heatmap) <- df_heatmap$GeneName
  df_heatmap <- df_heatmap[,-c(2460,2461)]
  
  mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
  rownames(mymat) <- rownames(df_heatmap)
  colnames(mymat) <- colnames(df_heatmap)
  
  mydf <- df_heatmap_annotate
  rownames(mydf) <- mydf$GeneName
  mydf <- as.data.frame(mydf[,2])
  names(mydf) <- "Strain_type"
  rownames(mydf) <- df_heatmap_annotate$GeneName
  
  mymat <- as.matrix(t(mymat))
  
  ann_colors = list(Strain_type = c(Knockout = "#e31a1c", Wildtype = "#1f78b4"))
  
  my.breaks <- c(-100, seq(min(df_melt$Zscore, na.rm=TRUE),  max(df_melt$Zscore, na.rm=TRUE), by=1)) 
  my.colors <- c("black", colorRampPalette(colors = c("blue", "white"))(length(my.breaks)/2), colorRampPalette(colors = c("white", "red"))(length(my.breaks)/2))

  
  pheatmap(mymat, cluster_cols = F, cluster_rows = T, show_colnames=F, show_rownames=F, 
           annotation_col = mydf, 
           color = my.colors,
           breaks = my.breaks,           main = "Z-score", annotation_colors = ann_colors,
           annotation_legend = FALSE,
           file=file.path(out_dir, paste0("6_6_2_", Sys.Date(), "_Zscore.png")))
  
  
  mymat2 <- mymat[rowSums(mymat != -100) == dim(mymat)[2],]
  
  pheatmap(mymat2, cluster_cols = F, cluster_rows = T, show_colnames=F, show_rownames=F, 
           annotation_col = mydf, 
           color = my.colors,
           breaks = my.breaks,           main = "Z-score, 513 proteins", annotation_colors = ann_colors,
           annotation_legend = FALSE,
           file=file.path(out_dir, paste0("6_6_3_", Sys.Date(), "_Zscore_513.png")))
  
  # #### changing the range
  # my.breaks <- c(-100, seq(-15,  15, by=1)) 
  # my.colors <- c("black", colorRampPalette(colors = c("blue", "white"))(length(my.breaks)/2), colorRampPalette(colors = c("white", "red"))(length(my.breaks)/2))
  # 
  # 
  # pheatmap(mymat, cluster_cols = F, cluster_rows = T, show_colnames=F, show_rownames=F, 
  #          annotation_col = mydf, 
  #          color = my.colors,
  #          breaks = my.breaks,           main = "Z-score", annotation_colors = ann_colors,
  #          annotation_legend = FALSE,
  #          file=file.path(out_dir, paste0("6_6_4_", Sys.Date(), "_Zscore.png")))
  # 
  # pheatmap(mymat2, cluster_cols = F, cluster_rows = T, show_colnames=F, show_rownames=F, 
  #          annotation_col = mydf, 
  #          color = my.colors,
  #          breaks = my.breaks,           main = "Z-score, 513 proteins", annotation_colors = ann_colors,
  #          annotation_legend = FALSE,
  #          file=file.path(out_dir, paste0("6_6_5_", Sys.Date(), "_Zscore_513.png")))
  # # 6.7 # filter for the protein groups with higher variability ##########
  # myfile <- list.files(path = out_dir, pattern = "^6_5_.*.rds")
  # df_melt <- readRDS(file.path(out_dir, myfile))
  # 
  # df_melt$StrainType <- "Knockout"
  # df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wild-type"
  # 
  # df_melt <- df_melt %>%
  #   group_by(Proteins, StrainType) %>%
  #   dplyr::mutate(Protein_count=sum(!is.na(NormalizedValue))) %>%
  #   group_by(Proteins, StrainType) %>%
  #   dplyr::mutate(Protein_mean=mean(NormalizedValue, na.rm=TRUE)) %>%
  #   group_by(Proteins, StrainType) %>%
  #   dplyr::mutate(Protein_sd=sd(NormalizedValue, na.rm=TRUE)) %>%
  #   group_by(Proteins, StrainType) %>%
  #   dplyr::mutate(Protein_regulated=sum(pvalue_FDR <=0.05 & abs(FC) >=1, na.rm=TRUE)) %>%
  #   as.data.frame()
  # 
  # jnk <- unique(df_melt[,c(1,8:12)])
  # 
  # jnk2 <- jnk[,c(1,2,6)]
  # jnk2 <- dcast(jnk2, Proteins ~ StrainType, value.var="Protein_regulated")
  # jnk2$MoreinWT <- (jnk2$Knockout / jnk2$`Wild-type`) < (3308/461)
  # jnk2 <- jnk2[,c(1,4)]
  # jnk <- merge(jnk, jnk2, by=1, all=FALSE)
  # 
  # ggplot(jnk, aes(StrainType, Protein_sd)) +
  #   geom_violin(aes(color=MoreinWT))
  # 
  # ggplot(jnk, aes(Proteins, Protein_sd)) +
  #   geom_point(aes(color=StrainType))
  # # it might be better to try iterating for each protein over p value and fc to find better cut off ###
  # 
  # # 6.8 # iterate ##########
  # myfile <- list.files(path = out_dir, pattern = "^6_5_.*.rds")
  # df_melt <- readRDS(file.path(out_dir, myfile))
  # 
  # df_melt$StrainType <- "Knockout"
  # df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wild-type"
  # 
  # pval <- seq(0,0.05, 0.0001)
  # jnk <- as.data.frame(unique(df_melt[,c(1,8)]))
  # jnk$myID <- paste(jnk$Proteins, jnk$StrainType, sep="-")
  # 
  # jnk2 <- as.data.frame(unique(jnk$Proteins))
  # names(jnk2) <- "myProteins"
  # 
  # df_melt$myID <- paste(df_melt$Proteins, df_melt$StrainType, sep="-")
  # df_melt$pvalue_FDR <- as.numeric(df_melt$pvalue_FDR)
  # for (i in 402:length(pval)) {
  #   print(i)
  #   df_melt <- df_melt %>%
  #     group_by(Proteins, StrainType) %>%
  #     dplyr::mutate(Protein_regulated=sum(pvalue_FDR <= pval[i], na.rm=TRUE)) %>%
  #     as.data.frame()
  #   jnk_jnk <- unique(df_melt[,c(9,10)])
  #   names(jnk_jnk)[2] <- paste0("Regulated_", i)
  #   jnk <- merge(jnk, jnk_jnk, by.x="myID", by.y="myID", all=FALSE)
  # 
  #   jnk_jnk <- unique(df_melt[,c(1,8,10)])
  #   jnk_jnk <- dcast(jnk_jnk, Proteins ~ StrainType, value.var="Protein_regulated")
  #   jnk_jnk$Ratio <- round((jnk_jnk$Knockout / (0.00001 + jnk_jnk$`Wild-type`)),2)
  #   jnk_jnk <- jnk_jnk[,c(1,4)]
  #   names(jnk_jnk)[2] <- paste0("Ratio_", i)
  #   jnk2 <- merge(jnk2, jnk_jnk, by.x="myProteins", by.y="Proteins", all=FALSE)
  # }
  # 
  # saveRDS(jnk, file.path(out_dir, paste0("6_8_1_", Sys.Date(), "_Regulated_pval.rds")))
  # saveRDS(jnk2, file.path(out_dir, paste0("6_8_1_", Sys.Date(), "_Ratio_pval.rds")))
  # rm(jnk)
  # rm(jnk_jnk)
  # rm(jnk2)
  # rm(df_melt)
  # # 6.9 # select p-value for each protein or general ##########
  # # 6.9.1 # based on ratio ####################################
  # myfile <- list.files(path = out_dir, pattern = "^6_8_1_.*Ratio")
  # jnk_ratio <- readRDS(file.path(out_dir, myfile))
  # jnk_ratio <- melt(jnk_ratio, id="myProteins")
  # 
  # jnk_ratio <- jnk_ratio %>%
  #   group_by(variable) %>%
  #   dplyr::mutate(value_average=mean(value)) %>%
  #   as.data.frame()
  # jnk <- as.data.frame(unique(jnk_ratio[,c(2,4)]))
  # # it is weird use the values ####################################
  # # 6.9.2 # based on counts ####################################
  # myfile <- list.files(path = out_dir, pattern = "^6_5_.*.rds")
  # df_melt <- readRDS(file.path(out_dir, myfile))
  # df_melt$StrainType <- "Knockout"
  # df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wild-type"
  # 
  # df_melt <- df_melt %>%
  #   group_by(Proteins, StrainType) %>%
  #   dplyr::mutate(CountMeasured=sum(!is.na(NormalizedValue))) %>%
  #   as.data.frame()
  # df_melt$myID <- paste(df_melt$Proteins, df_melt$StrainType, sep="-")
  # 
  # df_melt <- df_melt %>%
  #   group_by(Proteins, StrainType) %>%
  #   dplyr::mutate(sd=sd(NormalizedValue, na.rm=T)) %>%
  #   as.data.frame()
  # 
  # jnk <- unique(df_melt[,c(1,8,9,11)])
  # 
  # 
  # ######
  # 
  # 
  # myfile <- list.files(path = out_dir, pattern = "^6_8_1_.*Regulated")
  # jnk_count <- readRDS(file.path(out_dir, myfile))
  # jnk_count_melt <- melt(jnk_count, id=c("Proteins", "StrainType", "myID"))
  # 
  # df_melt_merge <- unique(df_melt[,9:10])
  # 
  # jnk_count_merged <- merge(jnk_count, df_melt_merge, by.x="myID", by.y="myID")
  # jnk_count_merged_percentage <- jnk_count_merged
  # for (i in 4:504) {
  #   jnk_count_merged_percentage[,i] <- round(100*(jnk_count_merged_percentage[,i]/jnk_count_merged_percentage[,505]),2)
  # }
  # jnk <- unique(jnk_count_merged_percentage$Proteins)
  # for (i in 1:length(jnk) {
  #   jnk2 <- as.data.frame(t(jnk_count_merged_percentage[grep(jnk[i], jnk_count_merged_percentage$Proteins),]))
  #   jnk2$difference <- as.numeric(jnk2$`1007`) - as.numeric(jnk2$`1008`)
  # 
  # 
  #   }
  # 
  # jnk_count_merged_percentage <- melt(jnk_count_merged_percentage, id=c("Proteins", "StrainType", "myID", "CountMeasured"))
  # 
  # jnk_count_merged_percentage <- jnk_count_merged_percentage %>%
  #   group_by(StrainType, variable) %>%
  #   dplyr::mutate(mean_value=mean(value)) %>%
  #   group_by(StrainType, variable) %>%
  #   dplyr::mutate(median_value=median(value)) %>%
  #   as.data.frame()
  # 
  # jnk <- unique(jnk_count_merged_percentage[,c(2,5,8)])
  # jnk <- dcast(jnk, variable ~ StrainType, value.var="median_value")
  # jnk$difference <- jnk$Knockout - jnk$`Wild-type`
  # rm(jnk)
  # 
  # 
  # 
  # 
  # 6.10 # ecdf per protein based on wt bio #############################################
  myfile <- list.files(path = out_dir, pattern = "^6_5_.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  
  df_melt$StrainType <- "Knockout"
  df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wildtype"
  
  df_melt$ID <- paste(df_melt$Proteins, df_melt$Strain, sep="_")
  
  mypg <- unique(df_melt$Proteins)
  myjnk <- data.frame(ID=character(), myecdf=numeric())
  for (i in 1:length(mypg)) {
    print(i)
    pg <- mypg[i]
    df_melt_jnk <- subset(df_melt, Proteins == pg)
    x <- ecdf(df_melt_jnk$NormalizedValue[df_melt_jnk$StrainType=="Wildtype"])
    
    df_melt_jnk$myecdf <- x(df_melt_jnk$NormalizedValue)
    myjnk <- as.data.frame(rbind(myjnk, df_melt_jnk[,c(9,10)]))
    
  }
  df_melt2 <- merge(df_melt, myjnk, by.x="ID", by.y="ID", all=FALSE)
  saveRDS(df_melt2, file.path(out_dir, paste0("6_10_", Sys.Date(), "_meltAllInfo.rds")))
  
  df_melt2$myecdf_changing <- NA
  df_melt2$myecdf_changing[!is.na(df_melt2$myecdf)] <- "Not"
  df_melt2$myecdf_changing[df_melt2$myecdf >= 0.995] <- "UP"
  df_melt2$myecdf_changing[df_melt2$myecdf <= 0.005] <- "DOWN"
  saveRDS(df_melt2, file.path(out_dir, paste0("6_10_", Sys.Date(), "_meltAllInfo.rds")))
  
  jnk <- as.data.frame(table(df_melt2[,c(9,11)]))
  rm(df_melt_jnk)
  rm(df_melt)
  rm(myjnk)
  rm(jnk)
  rm(df_melt2)
  # 6.11 # quick check #############################################
  myfile <- list.files(path = out_dir, pattern = "^6_10_.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  df_count <- as.data.frame(table(df_melt[,c(3,11)]))
  df_count <- dcast(df_count, Strain ~ myecdf_changing, value.var="Freq")
  df_count$Changing <- df_count$DOWN + df_count$UP
  
  df_count$StrainType <- "Knockout"
  df_count$StrainType[grep("WT", df_count$Strain)] <- "Wildtype"
  df_count <- df_count[,c(1,6,5)]
  names(df_count)[3] <- "Changing_ecdf"
  
  jnk <- df_melt %>%
    group_by(Strain) %>%
    dplyr::mutate(Changing_pFDR=sum(pvalue_FDR<=0.01, na.rm=TRUE)) %>%
    as.data.frame()
  jnk <- as.data.frame(unique(jnk[,c(3,12)]))
  
  df_count <- merge(df_count, jnk, by.x="Strain", by.y="Strain", all=FALSE)
  df_melt$myFDR_changing <- df_melt$pvalue_FDR <= 0.01
  saveRDS(df_melt, file.path(out_dir, paste0("6_11_", Sys.Date(), "_meltAllInfo.rds")))
  saveRDS(df_count, file.path(out_dir, paste0("6_11_", Sys.Date(), "_counts.rds")))
  
  
  ggplot(df_count, aes(StrainType, Changing)) +
    geom_boxplot()
  
  
  # 6.12 # some plots ###############################################
  myfile <- list.files(path = out_dir, pattern = "^6_11_.*melt.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  
  jnk <- df_melt[,c(2,4)]
  jnk <- jnk %>%
    group_by(Proteins) %>%
    dplyr::mutate(pgcount = sum(!is.na(NormalizedValue))) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,3)])
  
  p1 <- ggplot(jnk, aes(pgcount)) +
    geom_histogram(bins=300, color="black") +
    theme_bw() +
    xlab("Number of times measured") +
    ylab("Number of proteins")
  
  jnk <- df_melt[,c(2,12)]
  jnk <- jnk %>%
    group_by(Proteins) %>%
    dplyr::mutate(pgcount = sum(myFDR_changing, na.rm = T)) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,3)])
  
  p2 <- ggplot(jnk, aes(pgcount)) +
    geom_histogram(bins=300, color="black") +
    theme_bw() +
    xlab("Number of times regulated") +
    ylab("Number of proteins")
  
 
  
  jnk <- df_melt[,c(3,4)]
  jnk <- jnk %>%
    group_by(Strain) %>%
    dplyr::mutate(pgcount = sum(!is.na(NormalizedValue))) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,3)])
  
  p3 <- ggplot(jnk, aes(pgcount)) +
    geom_histogram(bins=100, color="black") +
    theme_bw() +
    xlab("Number of proteins identified") +
    ylab("Number of strains")+
    xlim(0, 2000)
  
  jnk <- df_melt[,c(3,12)]
  jnk <- jnk %>%
    group_by(Strain) %>%
    dplyr::mutate(pgcount = sum(myFDR_changing, na.rm = T)) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,3)])
  
  p4 <- ggplot(jnk, aes(pgcount)) +
    geom_histogram(bins=100, color="black") +
    theme_bw() +
    xlab("Number of proteins regulated") +
    ylab("Number of strains")
  
  
  jnk <- df_melt[,c(3,4,12)]
  jnk <- jnk %>%
    group_by(Strain) %>%
    dplyr::mutate(pgcount = sum(!is.na(NormalizedValue)),
                  pgreg = sum(myFDR_changing, na.rm = T)) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,4,5)])
  jnk$pgregPerc <- round((100*jnk$pgreg/jnk$pgcount),2)
  
  p5 <- ggplot(jnk, aes(pgregPerc)) +
    geom_histogram(bins=100, color="black") +
    theme_bw() +
    xlab("Percentage of proteins measured, regulated") +
    ylab("Number of strains")
  
  
  x <- round(cor(jnk$pgcount, jnk$pgreg)[1],3)
  p6 <- ggplot(jnk, aes(pgcount, pgreg)) +
    geom_point() +
    theme_bw() +
    xlab("Number of proteins measured") +
    ylab("Number of proteins regulated")+
    xlim(1300,2000)+
    annotate("text", x=1360, y=300, label=paste("Pearson R: ", x))
  
  x <- round(cor(jnk$pgcount, jnk$pgregPerc)[1],3)
  p7 <- ggplot(jnk, aes(pgcount, pgregPerc)) +
    geom_point() +
    theme_bw() +
    xlab("Number of proteins measured") +
    ylab("Percentage of proteins regulated")+
    xlim(1300,2000)+
    annotate("text", x=1360, y=21, label=paste("Pearson R: ", x))
  
  
  x <- round(cor(jnk$pgreg, jnk$pgregPerc)[1],4)
  
  p8 <- ggplot(jnk, aes(pgreg, pgregPerc)) +
    geom_point() +
    theme_bw() +
    xlab("Number of proteins regulated") +
    ylab("Percentage of proteins regulated") +
    annotate("text", x=50, y=18, label=paste("Pearson R: ", x))
  
  pdf(file.path(out_dir, paste0("6_12_1_", Sys.Date(), "_NumbersPlots.pdf")))
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  print(p5)
  print(p6)
  print(p7)
  print(p8)
  dev.off()
  ###############################################################
}
if(ZscoreCalculate_ecdf_noPower){
  ########### second round with all the values #############################
  # 6 # calculate Z-score, pvalue, pvalue-FDR, FC ... ####################################################################
  # 6.1 # Zscore #########################################################################################################
  myfile <- list.files(path = out_dir, pattern = "^4_2_4_1.*.rds")
  df_normalized <- readRDS(file.path(out_dir, myfile))
  
  numberOfStrains <- dim(df_normalized)[2]
  allCols <- 1:numberOfStrains
  wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
  koCols <- setdiff(allCols, wtCols) 
  
  # assume normal distribution because when all data points on;y 1 is not significant
  # for just wild-type measurements it is 875 after p value correction not normal out of 2562 = 34%
  # df_normalized_rowNormality <- apply(df_normalized[,wtCols], 1, my.shapiro.test)
  # hist(-log10(df_normalized_rowNormality), 100)
  # df_normalized_rowNormality_corrected <- p.adjust(df_normalized_rowNormality, method = "fdr")
  # hist(-log10(df_normalized_rowNormality_corrected), 100)
  # hist(-log10(df_normalized_rowNormality_corrected), 100, xlim=c(0,50))
  # 
  # sum(df_normalized_rowNormality > 0.05)
  # sum(df_normalized_rowNormality_corrected > 0.05)
  # max(df_normalized_rowNormality_corrected)
  # df_normalized_rowCount <- rowSums(!is.na(df_normalized[,wtCols]))
  
  wt_Mean <- rowMeans(df_normalized[, wtCols], na.rm = T)
  wt_SD <- apply(df_normalized[, wtCols],1,sd, na.rm=TRUE)
  
  df_normalized_Zscore <- df_normalized - wt_Mean
  df_normalized_Zscore <- df_normalized_Zscore / wt_SD
  
  saveRDS(df_normalized_Zscore, file.path(out_dir, paste0("6_1_1_", Sys.Date(), "_dfNormalized_Zscore.rds")))
  rm(df_normalized)
  rm(df_normalized_Zscore)
  # 6.2 # p-value ##################################################################################################
  myfile <- list.files(path = out_dir, pattern = "^6_1_1_.*.rds")
  df_Zscore <- readRDS(file.path(out_dir, myfile))
  
  df_Zscore_pvalue <- 2*pnorm(-abs(as.matrix(df_Zscore)))
  df_Zscore_pvalue <- as.data.frame(df_Zscore_pvalue)
  
  
  pdf(file.path(out_dir, paste0("6_2_1__", Sys.Date(), "_Zscore_pvale_distribution.pdf")),height = 11, width = 13)
  hist(as.numeric(as.matrix(df_Zscore)), xlim = c(-5,5), breaks=1000, xlab="Zscore", main="Zscore distribution")
  hist(as.numeric(-log10(as.matrix(df_Zscore_pvalue))), xlim=c(0,4),breaks=1000, xlab="-log10(pvalue)", main="pvalue distribution")
  hist(as.numeric(as.matrix(df_Zscore_pvalue)), xlim=c(0,1),breaks=1000, xlab="pvalue", main="pvalue distribution")
  dev.off()
  
  saveRDS(df_Zscore_pvalue, file.path(out_dir, paste0("6_2_1_2_", Sys.Date(), "_dfNormalized_pvalue.rds")))
  rm(df_Zscore)
  rm(df_Zscore_pvalue)
  # 6.3 # p-value corrected ###########################################################################################
  myfile <- list.files(path = out_dir, pattern = "^6_2_1_2_.*.rds")
  df_Zscore_pvalue <- readRDS(file.path(out_dir, myfile))
  
  df_Zscore_pvalue$pG <- rownames(df_Zscore_pvalue)
  df_Zscore_pvalue_melt <- melt(df_Zscore_pvalue, id="pG")
  names(df_Zscore_pvalue_melt) <- c("Protein", "Gene", "pValue")
  
  df_Zscore_pvalue_melt$p_FDR <- p.adjust(df_Zscore_pvalue_melt$pValue, method = "fdr", n = length(df_Zscore_pvalue_melt$pValue))
  
  # cor(df_Zscore_pvalue_melt$p_FDR, df_Zscore_pvalue_melt$p_FDR2, use = 'pairwise.complete.obs')
  
  df_Zscore_pvalue_melt2 <- df_Zscore_pvalue_melt[,c(1,2,4)]
  df_Zscore_pvalue_melt2 <- dcast(df_Zscore_pvalue_melt2, Protein ~ Gene, value.var = "p_FDR")
  rownames(df_Zscore_pvalue_melt2) <- df_Zscore_pvalue_melt2$Protein
  df_Zscore_pvalue_melt2 <- df_Zscore_pvalue_melt2[,-1]
  
  saveRDS(df_Zscore_pvalue, file.path(out_dir, paste0("6_3_1_", Sys.Date(), "_dfNormalized_pvalue_FDRcorrected.rds")))
  rm(df_Zscore_pvalue)
  rm(df_Zscore_pvalue_melt)
  rm(df_Zscore_pvalue_melt2)
  # 6.4 # Fold Change ########################################################################################
  myfile <- list.files(path = out_dir, pattern = "^4_2_4_1.*.rds")
  df_normalized <- readRDS(file.path(out_dir, myfile))
  
  wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
  wt_Mean <- rowMeans(df_normalized[, wtCols], na.rm = T)
  df_normalized_FC <- df_normalized - wt_Mean
  saveRDS(df_normalized_FC, file.path(out_dir, paste0("6_4_1_", Sys.Date(), "_dfNormalized_FC.rds")))
  rm(df_normalized_FC)
  rm(df_normalized)
  # 6.5 # put the tables together #####################################################################################
  jnk <- as.data.frame(list.files(path=out_dir, pattern = "6_[1-4]_1.*.rds", recursive=FALSE))
  names(jnk) <- "jnk"
  jnk$code <- c("Zscore", "p_value", "pvalue_FDR","FC")
  
  myfile <- list.files(path = out_dir, pattern = "^4_2_4_1.*.rds")
  df <- readRDS(file.path(out_dir, myfile))
  
  df$Proteins <- rownames(df)
  df_melt <- melt(df, id="Proteins")
  rm(df)
  df_melt$identifier <- paste(df_melt$Proteins, df_melt$variable, sep="_")
  df_melt <- df_melt[,c(4,1,2,3)]
  names(df_melt)[3:4] <- c("Strain", "NormalizedValue")
  
  for (i in 1:dim(jnk)[1]) {
    print(i)
    df_jnk <- readRDS(file.path(out_dir, jnk$jnk[i]))
    df_jnk$Proteins <- rownames(df_jnk)
    df_melt_jnk <- melt(df_jnk, id="Proteins")
    df_melt_jnk$identifier <- paste(df_melt_jnk$Proteins, df_melt_jnk$variable, sep="_")
    df_melt_jnk <- df_melt_jnk[,c(4,3)]
    names(df_melt_jnk)[2] <- jnk$code[i]
    df_melt <- merge(df_melt, df_melt_jnk, by.x="identifier", by.y="identifier", all.x=TRUE)
    print(dim(df_melt))
  }
  
  df_melt <- df_melt[,-1]
  saveRDS(df_melt, file.path(out_dir, paste0("6_5_1_", Sys.Date(), "_meltAllInfo.rds")))
  
  rm(df_jnk)
  rm(df_melt)
  rm(df_melt_jnk)
  rm(jnk)
  # 6.6 # heatmaps #####################################
  myfile <- list.files(path = out_dir, pattern = "^6_5_1_.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  
  df_melt$StrainType <- "Knockout"
  df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wildtype"
  
  # 6.6.1 # normalized value ###########################
  df_heatmap <- df_melt[,1:3]
  df_heatmap <- dcast(df_heatmap, Proteins ~ Strain, value.var = "NormalizedValue")
  rownames(df_heatmap) <- df_heatmap$Proteins
  df_heatmap <- df_heatmap[,-1]
  df_heatmap$Mean <- rowMeans(df_heatmap, na.rm=TRUE)
  df_heatmap <- df_heatmap[with(df_heatmap, order(Mean, decreasing = TRUE)), ]
  df_heatmap <- df_heatmap[,-c(grep("^Mean$", names(df_heatmap)))]
  df_heatmap[is.na(df_heatmap)] <- 0  
  
  for (i in 1:dim(df_heatmap)[2]) {
    df_heatmap[,i] <- as.numeric(df_heatmap[,i])
  }
  df_heatmap <- as.data.frame(t(df_heatmap))
  
  df_heatmap$GeneName <- rownames(df_heatmap)
  df_heatmap$StrainType <- "Knockout"
  df_heatmap$StrainType[grep("WT", df_heatmap$GeneName)] <- "Wildtype"
  df_heatmap <- df_heatmap[with(df_heatmap, order(StrainType)), ]
  
  df_heatmap_annotate <- df_heatmap[,c(2923,2924)]
  rownames(df_heatmap) <- df_heatmap$GeneName
  df_heatmap <- df_heatmap[,-c(2923,2924)]
  
  mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
  rownames(mymat) <- rownames(df_heatmap)
  colnames(mymat) <- colnames(df_heatmap)
  
  mydf <- df_heatmap_annotate
  rownames(mydf) <- mydf$GeneName
  mydf <- as.data.frame(mydf[,2])
  names(mydf) <- "Strain_type"
  rownames(mydf) <- df_heatmap_annotate$GeneName
  
  mymat <- as.matrix(t(mymat))
  
  ann_colors = list(Strain_type = c(Knockout = "#e31a1c", Wildtype = "#1f78b4"))
  
  # pheatmap(mymat, cluster_cols = F, cluster_rows = F, show_colnames=F, show_rownames=F, 
  #          annotation_col = mydf, border_color = NA, 
  #          color = colorRampPalette(brewer.pal(n = 9, name = "BuGn"))(100),
  #          annotation_colors = ann_colors,
  #          annotation_legend = FALSE,
  #          file=file.path(out_dir, paste0("6_6_1_", Sys.Date(), "_NormalizedValue.pdf")),
  #          height = 1, width = 1)
  pheatmap(mymat, cluster_cols = F, cluster_rows = F, show_colnames=F, show_rownames=F, 
           annotation_col = mydf, border_color = NA, 
           color = colorRampPalette(brewer.pal(n = 9, name = "BuGn"))(100),
           annotation_colors = ann_colors,
           annotation_legend = FALSE,
           file=file.path(out_dir, paste0("6_6_1_1_", Sys.Date(), "_NormalizedValue.png")),
           height = 4, width = 4)
  
  # pheatmap(mymat, cluster_cols = F, cluster_rows = F, show_colnames=F, show_rownames=F, 
  #          annotation_col = mydf, border_color = NA, 
  #          color = colorRampPalette(brewer.pal(n = 9, name = "BuGn"))(100),
  #          annotation_colors = ann_colors,
  #          annotation_legend = FALSE,
  #          file=file.path(out_dir, paste0("6_6_1_", Sys.Date(), "_NormalizedValue.tiff")),
  #          height = 1, width = 1)
  # pheatmap(mymat, cluster_cols = F, cluster_rows = F, show_colnames=F, show_rownames=F, 
  #          annotation_col = mydf, border_color = NA, 
  #          color = colorRampPalette(brewer.pal(n = 9, name = "BuGn"))(100),
  #          annotation_colors = ann_colors,
  #          annotation_legend = FALSE,
  #          file=file.path(out_dir, paste0("6_6_1_", Sys.Date(), "_NormalizedValue.jpeg")),
  #          height = 1, width = 1)
  # 6.10 # ecdf per protein based on wt bio #############################################
  myfile <- list.files(path = out_dir, pattern = "^6_5_1_.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  
  df_melt$StrainType <- "Knockout"
  df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wildtype"
  
  df_melt$ID <- paste(df_melt$Proteins, df_melt$Strain, sep="_")
  
  mypg <- unique(df_melt$Proteins)
  myjnk <- data.frame(ID=character(), myecdf=numeric())
  for (i in 1287:length(mypg)) {
    print(i)
    pg <- mypg[i]
    df_melt_jnk <- subset(df_melt, Proteins == pg)
    x <- ecdf(df_melt_jnk$NormalizedValue[df_melt_jnk$StrainType=="Wildtype"])
    
    df_melt_jnk$myecdf <- x(df_melt_jnk$NormalizedValue)
    myjnk <- as.data.frame(rbind(myjnk, df_melt_jnk[,c(9,10)]))
    
  }
  df_melt2 <- merge(df_melt, myjnk, by.x="ID", by.y="ID", all=FALSE)
  
  saveRDS(df_melt2, file.path(out_dir, paste0("6_10_1_", Sys.Date(), "_meltAllInfo.rds")))
  
  df_melt2$myecdf_changing <- NA
  df_melt2$myecdf_changing[!is.na(df_melt2$myecdf)] <- "Not"
  df_melt2$myecdf_changing[df_melt2$myecdf >= 0.995] <- "UP"
  df_melt2$myecdf_changing[df_melt2$myecdf <= 0.005] <- "DOWN"
  saveRDS(df_melt2, file.path(out_dir, paste0("6_10_1_", Sys.Date(), "_meltAllInfo.rds")))
  
  jnk <- as.data.frame(table(df_melt2[,c(9,11)]))
  rm(df_melt_jnk)
  rm(df_melt)
  rm(myjnk)
  rm(jnk)
  rm(df_melt2)
  # 6.11 # quick check #############################################
  myfile <- list.files(path = out_dir, pattern = "^6_10_1_.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  df_count <- as.data.frame(table(df_melt[,c(3,11)]))
  df_count <- dcast(df_count, Strain ~ myecdf_changing, value.var="Freq")
  df_count$Changing <- df_count$DOWN + df_count$UP
  
  df_count$StrainType <- "Knockout"
  df_count$StrainType[grep("WT", df_count$Strain)] <- "Wildtype"
  df_count <- df_count[,c(1,6,5)]
  names(df_count)[3] <- "Changing_ecdf"
  
  jnk <- df_melt %>%
    group_by(Strain) %>%
    dplyr::mutate(Changing_pFDR=sum(pvalue_FDR<=0.01, na.rm=TRUE)) %>%
    as.data.frame()
  jnk <- as.data.frame(unique(jnk[,c(3,12)]))
  
  df_count <- merge(df_count, jnk, by.x="Strain", by.y="Strain", all=FALSE)
  df_melt$myFDR_changing <- df_melt$pvalue_FDR <= 0.01
  saveRDS(df_melt, file.path(out_dir, paste0("6_11_1_", Sys.Date(), "_meltAllInfo.rds")))
  saveRDS(df_count, file.path(out_dir, paste0("6_11_1_", Sys.Date(), "_counts.rds")))
  
  myfile <- list.files(path = out_dir, pattern = "^6_11_1_.*counts.*.rds")
  df_count <- readRDS(file.path(out_dir, myfile))
  
  pdf(file.path(out_dir, paste0("6_11_1_2_", Sys.Date(), "_p_vs_ecdf.pdf")))

  p <- ggplot(df_count, aes(StrainType, Changing_pFDR)) +
    geom_boxplot()
  print(p)
  p <- ggplot(df_count, aes(StrainType, Changing_ecdf)) +
    geom_boxplot()
  print(p)
  
  p <- ggplot(df_count, aes(Changing_pFDR, Changing_ecdf)) +
    geom_point()+
    geom_abline(slope=1, intercept = 0)+
    annotate("text", x=50, y=400, label=round(cor(df_count$Changing_ecdf,
                                                 df_count$Changing_pFDR),2))
  print(p)
  dev.off()
  rm(df_count)
  rm(p)
  # 6.12 # some plots ###############################################
  myfile <- list.files(path = out_dir, pattern = "^6_11_1_.*melt.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  
  df_melt$myecdf_changing_category <- df_melt$myecdf_changing
  df_melt$myecdf_changing[df_melt$myecdf_changing=="Not"] <- FALSE
  df_melt$myecdf_changing[df_melt$myecdf_changing=="UP"] <- TRUE
  df_melt$myecdf_changing[df_melt$myecdf_changing=="DOWN"] <- TRUE

  df_melt$myFDR_changing_category <- df_melt$myFDR_changing
  df_melt$myFDR_changing_category[df_melt$myFDR_changing == FALSE] <- "Not"
  df_melt$myFDR_changing_category[df_melt$myFDR_changing == TRUE & df_melt$FC>0] <- "UP"
  df_melt$myFDR_changing_category[df_melt$myFDR_changing == TRUE & df_melt$FC<0] <- "DOWN"
  
  saveRDS(df_melt, file.path(out_dir, paste0("6_12_1_", Sys.Date(), "_meltAllInfo.rds")))
  
  # 6.12.1 # check how the overlaps are for different methods ###############
  table(df_melt[,c(11,13)])
  table(df_melt[,c(12,14)])
  jnk2 <- as.data.frame(table(df_melt[,c(13,14)]))
  
  jnk <- chisq.test(df_melt$myecdf_changing_category, 
                    df_melt$myFDR_changing_category, correct=FALSE)
  
  pdf(file.path(out_dir, paste0("6_12_1_", Sys.Date(), "_ecdf_p_plots.pdf")))
  
  p<-ggplot(df_melt, aes(x=myecdf_changing_category, fill=myecdf_changing_category)) +
    geom_bar() +
    facet_grid(myFDR_changing_category ~ .) +
    xlab(NULL) +
    ggtitle("Pearson's Chi-squared test p-value < 2.2e-16") +
    theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
          axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold"),
          strip.text = element_text(size = 14, face="bold")) +
    scale_fill_discrete(guide = 'none') +
    scale_y_log10()
  print(p)

  library(corrplot)
  corrplot(jnk$residuals, is.cor = FALSE, title="Chi-squared test residuals")
  dev.off()
  
  # 6.12.2 # number plots ########################################
  jnk <- df_melt[,c(2,4)]
  jnk <- jnk %>%
    group_by(Proteins) %>%
    dplyr::mutate(pgcount = sum(!is.na(NormalizedValue))) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,3)])
  
  p1 <- ggplot(jnk, aes(pgcount)) +
    geom_histogram(bins=3769, color="black", size=1.3) +
    theme_classic() +
    xlab("Number of times measured") +
    ylab("Number of proteins") +
    annotate(geom = "text", x=3769, y=540, label="513", size=5, color="#a50f15", fontface =2) +
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold")) +
    scale_y_continuous(breaks=seq(0,500,100)) +
    scale_x_continuous(breaks=c(0,1000,2000,3000,3769))
  
  jnk <- df_melt[,c(3,4)]
  jnk <- jnk %>%
    group_by(Strain) %>%
    dplyr::mutate(pgcount = sum(!is.na(NormalizedValue))) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,3)])
  jnk$pgcount <- as.numeric(jnk$pgcount)
  p2 <- ggplot(jnk, aes(pgcount)) +
    geom_histogram(bins=90, color="#252525", fill="#f0f0f0") +
    theme_classic() +
    xlab("Number of proteins identified") +
    ylab("Number of strains")+
    xlim(0, 2050) +
    geom_hline(yintercept=0, colour="white", size=0.2) +
    geom_rug(sides="b")+
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  
  
  jnk <- df_melt[,c(2,12)]
  jnk <- jnk %>%
    group_by(Proteins) %>%
    dplyr::mutate(pgcount = sum(myFDR_changing, na.rm = T)) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,3)])
  
  p3 <- ggplot(jnk, aes(pgcount)) +
    geom_histogram(bins=100, color="#252525", fill="#f0f0f0") +
    theme_classic() +
    xlab("Number of times regulated") +
    ylab("Number of proteins")+
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))+
    xlim(0,1000) 
    
  jnk <- df_melt[,c(3,12)]
  jnk <- jnk %>%
    group_by(Strain) %>%
    dplyr::mutate(pgcount = sum(myFDR_changing, na.rm = T)) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,3)])
  
  p4 <- ggplot(jnk, aes(pgcount)) +
    geom_histogram(bins=100, color="#252525", fill="#f0f0f0") +
    theme_classic() +
    xlab("Number of proteins regulated") +
    ylab("Number of strains")+
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))

  jnk <- df_melt[,c(2,11)]
  jnk <- jnk %>%
    group_by(Proteins) %>%
    dplyr::mutate(pgcount = sum(myecdf_changing==TRUE, na.rm = T)) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,3)])
  
  p3_1 <- ggplot(jnk, aes(pgcount)) +
    geom_histogram(bins=100, color="#252525", fill="#f0f0f0") +
    theme_classic() +
    xlab("Number of times regulated, ecdf") +
    ylab("Number of proteins")+
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  
  jnk <- df_melt[,c(3,11)]
  jnk <- jnk %>%
    group_by(Strain) %>%
    dplyr::mutate(pgcount = sum(myecdf_changing==TRUE, na.rm = T)) %>%
    as.data.frame()
  jnk <- unique(jnk[,c(1,3)])
  
  p4_1 <- ggplot(jnk, aes(pgcount)) +
    geom_histogram(bins=100, color="#252525", fill="#f0f0f0") +
    theme_classic() +
    xlab("Number of proteins regulated, ecdf") +
    ylab("Number of strains")+
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  
  jnk <- df_melt[,c(3,4,11,12)]
  jnk <- jnk %>%
    group_by(Strain) %>%
    dplyr::mutate(pgcount = sum(!is.na(NormalizedValue)),
                  pgreg_p = sum(myFDR_changing, na.rm = T),
                  pgreg_ecdf = sum(myecdf_changing==TRUE, na.rm = T)) %>%
    as.data.frame()
  
  jnk <- unique(jnk[,c(1,5,6,7)])
  
  x1 <- round(cor(jnk$pgcount, jnk$pgreg_p)[1],3)
  x2 <- round(cor(jnk$pgcount, jnk$pgreg_ecdf)[1],3)
  
  p6 <- ggplot(jnk, aes(pgcount, pgreg_p)) +
    geom_point() +
    theme_classic() +
    xlab("Number of proteins measured") +
    ylab("Number of proteins regulated")+
    xlim(1300,2000)+
    annotate("label", x=1450, y=350, label=paste("Pearson R: ", x1)) +
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  
  p6_1 <- ggplot(jnk, aes(pgcount, pgreg_ecdf)) +
    geom_point() +
    theme_classic() +
    xlab("Number of proteins measured") +
    ylab("Number of proteins regulated, ecdf")+
    xlim(1300,2000)+
    annotate("label", x=1450, y=450, label=paste("Pearson R: ", x2)) +
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  
  pdf(file.path(out_dir, paste0("6_12_2_", Sys.Date(), "_NumbersPlots.pdf")), height = 4, width = 4)
  print(p1)
  print(p2)
  print(p3)
  print(p3_1)
  print(p4)
  print(p4_1)
  print(p6)
  print(p6_1)
  dev.off()
  ########################################################
}
if(growth=="G"){
  # G # growth information of the strains to include in the analysis #######################
  # G.0 # decide which files to use for the growth information per plate ###################
  data_dir <- "U:/Merve/AllinAll_Mrv_IMB/Project/SpKOlibrary/Sp_DelLib_TMT/OD600/"
  
  jnk <- as.data.frame(list.files(path = data_dir))
  names(jnk) <- "filename"
  jnk$Plate <- gsub("[0-9]*\\_Plate(.*)\\_OD600\\_(.*)\\.xls", "\\1", jnk$filename)
  jnk$Culture <- gsub("[0-9]*\\_Plate(.*)\\_OD600\\_(.*)\\.xls", "\\2", jnk$filename)
  jnk <- jnk[grep("Plate", jnk$filename),]
  jnk$TimeCreated <- NA
  
  for (i in 1:dim(jnk)[1]) {
    jnk$TimeCreated[i] <- as.character(file.info(file.path(data_dir, jnk$filename[i]))$ctime)
  }
  jnk$Plate[jnk$Plate==9] <- "09"
  
  # jnk_ic <- jnk[grep("ic", jnk$Culture),]
  jnk_fc <- jnk[grep("fc", jnk$Culture),]
  jnk_fc <- jnk_fc[jnk_fc$Plate <= 36,]
  
  jnk2 <- as.data.frame(table(jnk_fc$Plate))
  jnk3 <- jnk2[jnk2$Freq!=1,]
  
  jnk2 <- jnk2[jnk2$Freq==1,]
  
  jnk_fc_keep <- jnk_fc[jnk_fc$Plate %in% jnk2$Var1,]
  jnk_fc_decide <- jnk_fc[jnk_fc$Plate %in% jnk3$Var1,]
  rownames(jnk_fc_decide) <- NULL
  
  jnk_fc_keep <- rbind(jnk_fc_keep,jnk_fc_decide[c(5,6,9,10,16,15,14),])

  jnk_fc_keep <- jnk_fc_keep[with(jnk_fc_keep, order(Plate)), ]
  rm(jnk_fc)
  rm(jnk_fc_decide)
  rm(jnk2)
  rm(jnk3)
  
  jnk_ic <- jnk[grep("ic", jnk$Culture),]
  jnk_ic <- jnk_ic[jnk_ic$Plate <= 36,]
  
  jnk2 <- as.data.frame(table(jnk_ic$Plate))
  jnk3 <- jnk2[jnk2$Freq!=1,]
  
  jnk2 <- jnk2[jnk2$Freq==1,]
  
  jnk_ic_keep <- jnk_ic[jnk_ic$Plate %in% jnk2$Var1,]
  jnk_ic_decide <- jnk_ic[jnk_ic$Plate %in% jnk3$Var1,]
  rownames(jnk_ic_decide) <- NULL
  
  jnk_ic_keep <- rbind(jnk_ic_keep,jnk_ic_decide[c(5,6,9,10,16,15,14),])
  
  jnk_ic_keep <- jnk_ic_keep[with(jnk_ic_keep, order(Plate)), ]
  rm(jnk_ic)
  rm(jnk_ic_decide)
  rm(jnk)
  rm(jnk2)
  rm(jnk3)
  
  saveRDS(jnk_ic_keep, file.path(out_dir, paste0("G_0_1_", Sys.Date(), "_InitialCulture_Files.rds")))
  saveRDS(jnk_fc_keep, file.path(out_dir, paste0("G_0_2_", Sys.Date(), "_FinalCulture_Files.rds")))
  rm(jnk_ic_keep)
  rm(jnk_fc_keep)
  # G.1 # read the files, restructure and combine ###################
  data_dir <- "U:/Merve/AllinAll_Mrv_IMB/Project/SpKOlibrary/Sp_DelLib_TMT/OD600/"
  
  myfile <- list.files(path = out_dir, pattern = "^G_0_1_.*.rds")
  ic_files <- readRDS(file.path(out_dir, myfile))
  
  myfile <- list.files(path = out_dir, pattern = "^G_0_2_.*.rds")
  fc_files <- readRDS(file.path(out_dir, myfile))
  
  mynames <- c("abs", "01", "02","03","04","05","06","07","08","09","10","11","12")
  
  myfile <- list.files(path = out_dir, pattern = "^2_5_2_2_")
  mydecode <- read.delim(file.path(out_dir, myfile))
  mydecode <- mydecode[grep("ToBeAnalyzed",mydecode$Analyzed_ReMeasured),]
  mydecode <- mydecode[grep("Knock-out",mydecode$StrainType),]
  
  my_ic_Z <- data.frame(DelLibPosition=character(), Abs_ic=numeric(), Zscore_ic=numeric())
  
  for (i in 1:dim(ic_files)[1]) {
    print(i)
    myfile <- list.files(path = data_dir, pattern = ic_files$filename[i])
    jnk <- as.data.frame(readxl::read_xls(file.path(data_dir, myfile), skip = 14, n_max = 8, sheet = 1))
    names(jnk) <- mynames
    jnk <- melt(jnk, "abs")
    jnk$DelLibPosition <- paste0("Sp", ic_files$Plate[i], jnk$abs, jnk$variable)
    jnk <- jnk[,c(4,3)]
    names(jnk)[2] <- "Abs_ic"
    jnk <- jnk[jnk$DelLibPosition %in% mydecode$Position_KO_Library,]
    
    jnk_Mean <- mean(jnk$Abs_ic, na.rm = T)
    jnk_SD <- sd(jnk$Abs_ic, na.rm = T)
    
    jnk$Zscore_ic <- (jnk$Abs_ic - jnk_Mean) / jnk_SD
    
    my_ic_Z <- as.data.frame(rbind(my_ic_Z, jnk))
    saveRDS(my_ic_Z, file.path(out_dir, paste0("G_1_1_", Sys.Date(), "_InitialCulture_Zscore.rds")))
    }
  
  my_fc_Z <- data.frame(DelLibPosition=character(), Abs_fc=numeric(), Zscore_fc=numeric())
  
  for (i in 1:dim(fc_files)[1]) {
    print(i)
    myfile <- list.files(path = data_dir, pattern = fc_files$filename[i])
    jnk <- as.data.frame(readxl::read_xls(file.path(data_dir, myfile), skip = 14, n_max = 8, sheet = 1))
    names(jnk) <- mynames
    jnk <- melt(jnk, "abs")
    jnk$DelLibPosition <- paste0("Sp", fc_files$Plate[i], jnk$abs, jnk$variable)
    jnk <- jnk[,c(4,3)]
    names(jnk)[2] <- "Abs_fc"
    jnk <- jnk[jnk$DelLibPosition %in% mydecode$Position_KO_Library,]
    
    jnk_Mean <- mean(jnk$Abs_fc, na.rm = T)
    jnk_SD <- sd(jnk$Abs_fc, na.rm = T)
    
    jnk$Zscore_fc <- (jnk$Abs_fc - jnk_Mean) / jnk_SD
    
    my_fc_Z <- as.data.frame(rbind(my_fc_Z, jnk))
    saveRDS(my_fc_Z, file.path(out_dir, paste0("G_1_2_", Sys.Date(), "_FinalCulture_Zscore.rds")))
  }
  
  my_Z <- merge(my_fc_Z, my_ic_Z, by=1)
  # ggplot(my_Z, aes(Abs_fc, Abs_ic))+
  #   geom_point()
  p1 <- ggplot(my_Z, aes(Zscore_ic, Zscore_fc))+
    geom_point() +
    geom_vline(xintercept = c(-1,1), linetype="dashed") + 
    geom_hline(yintercept = c(-1,1), linetype="dashed") +
    xlab("Zscore(initial culture)") +
    ylab("Zscore(final culture)") +
    xlim(-9,9) +
    ylim(-6,6)
  
  
  mydecode <- merge(mydecode, my_Z, by.x="Position_KO_Library", by.y="DelLibPosition", all=FALSE)
  mydecode$growth[mydecode$growth == ""] <- "NA"
  saveRDS(mydecode, file.path(out_dir, paste0("G_1_3_", Sys.Date(), "_Decode_Zscore_Growth.rds")))
  
  mydecode <- mydecode %>%
    group_by(growth) %>%
    dplyr::mutate(Size=n()) %>%
    as.data.frame()
  saveRDS(mydecode, file.path(out_dir, paste0("G_1_3_", Sys.Date(), "_Decode_Zscore_Growth.rds")))
  
  p2 <- ggplot(mydecode, aes(growth, Zscore_ic))+
    geom_boxplot(aes(fill=growth)) +
    geom_text(data = as.data.frame(unique(mydecode[,c(23,28)])),aes(x=growth, y=8, label=Size)) +
    guides(fill=FALSE) +
    ylab("Zscore(initial culture)") +
    xlab("Library growth rate") +
    ylim(-9,9)
  
  p3 <- ggplot(mydecode, aes(growth, Zscore_fc))+
    geom_boxplot(aes(fill=growth)) +
    geom_text(data = as.data.frame(unique(mydecode[,c(23,28)])),aes(x=growth, y=6, label=Size)) +
    guides(fill=FALSE) +
    ylab("Zscore(final culture)") +
    xlab("Library growth rate") +
    ylim(-6,6)
  
  p4 <- ggplot(mydecode, aes(Zscore_ic, Zscore_fc))+
    geom_point(aes(color=growth), alpha=0.6) +
    geom_vline(xintercept = c(-1,1), linetype="dashed") + 
    geom_hline(yintercept = c(-1,1), linetype="dashed") +
    xlab("Zscore(initial culture)") +
    ylab("Zscore(final culture)") +
    xlim(-9,9) +
    ylim(-6,6) +
    theme_bw()
  p5 <- ggplot(mydecode, aes(Zscore_ic, Zscore_fc))+
    geom_point(data=subset(mydecode, growth=="NA"), color="grey", alpha=0.6) +
    geom_point(data=subset(mydecode, growth=="1"), color="darkgreen") +
    geom_point(data=subset(mydecode, growth=="1L"), color="darkgreen", alpha=0.5) +
    geom_point(data=subset(mydecode, growth=="2"), color="orange") +
    geom_point(data=subset(mydecode, growth=="2L"), color="orange", alpha=0.5) +
    geom_point(data=subset(mydecode, growth=="3"), color="red") +
    geom_vline(xintercept = c(-1,1), linetype="dashed") + 
    geom_hline(yintercept = c(-1,1), linetype="dashed") +
    xlab("Zscore(initial culture)") +
    ylab("Zscore(final culture)") +
    xlim(-9,9) +
    ylim(-6,6) +
    theme_bw()
  
  pdf(file.path(out_dir, paste0("G_1_4_", Sys.Date(), "_Growth_comparison_plots.pdf")))
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  print(p5)
  dev.off()
  rm(fc_files)
  rm(ic_files)
  rm(jnk)
  rm(my_ic_Z)
  rm(my_fc_Z)
  rm(my_Z)
  rm(mydecode)
  rm(p1)
  rm(p2)
  rm(p3)
  rm(p4)
  rm(p5)
  # G.2 # compare the growth rate to the number of proteins changing ###################
  myfile <- list.files(path = out_dir, pattern = "^G_1_3_.*.rds")
  decode_growth <- readRDS(file.path(out_dir, myfile))
  
  myfile <- list.files(path = out_dir, pattern = "^6_11_1.*counts.rds")
  df_counts <- readRDS(file.path(out_dir, myfile))
  df_counts <- remove.factors(df_counts)
  df_counts$StrainID <- gsub("Sp.*\\-(SP.*)", "\\1", df_counts$Strain)
  df_counts <- df_counts[,c(5,3,4)]
  
  decode_growth <- merge(decode_growth, df_counts, by.x="Systemic.ID", by.y="StrainID", all=FALSE)
  rm(df_counts)
  saveRDS(decode_growth, file.path(out_dir, paste0("G_2_1_", Sys.Date(), "_Decode_Zscore_Growth_Change.rds")))
  
  # G.2.2
  myfile <- list.files(path = out_dir, pattern = "^G_2_1_.*.rds")
  decode_growth <- readRDS(file.path(out_dir, myfile[2]))
  
  decode_growth <- decode_growth[with(decode_growth, order(-Changing_pFDR)), ]
  decode_growth$Changing_pFDR_t250 <- decode_growth$Changing_pFDR >= 44
  
  decode_growth <- decode_growth[with(decode_growth, order(-Changing_ecdf)), ]
  decode_growth$Changing_ecdf_t250 <- decode_growth$Changing_ecdf >= 50
  
  jnk <- decode_growth[,c(1,23, 24, 25, 26, 27, 29, 30, 31, 32)]
  
  p1 <- ggplot(jnk, aes(Changing_pFDR_t250, Zscore_fc))+
    geom_boxplot(aes(color=Changing_pFDR_t250), size=1.2) +
    stat_compare_means(label.x = 1.25, label.y = 5, size=8)+
    theme_classic()+
    xlab("Top 250 strains with highest remodeling, p") +
    ylab("Final culture, Zscore(OD600)") +
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold")) +
    scale_color_manual(values=c("#1a1a1a", "#b2182b")) +
    guides(color=FALSE)
  
  ggsave(file.path(out_dir,"G_2_2_flts_Zscore_250.pdf"), p1, height = 6, width = 6)
  
  
  p2 <- ggplot(jnk, aes(Changing_pFDR_t250, Zscore_ic))+
    geom_boxplot() +
    stat_compare_means(label.x = 1.25, label.y = 2)+
    theme_bw()+
    xlab("Top 250 strains with highest remodeling, p") +
    ylab("Initial culture, Zscore(OD600)")
  
  p3 <- ggplot(jnk, aes(Changing_ecdf_t250, Zscore_fc))+
    geom_boxplot() +
    stat_compare_means(label.x = 1.25, label.y = 5)+
    theme_bw()+
    xlab("Top 250 strains with highest remodeling, ecdf") +
    ylab("Final culture, Zscore(OD600)")
  
  p4 <- ggplot(jnk, aes(Changing_ecdf_t250, Zscore_ic))+
    geom_boxplot() +
    stat_compare_means(label.x = 1.25, label.y = 2)+
    theme_bw()+
    xlab("Top 250 strains with highest remodeling, ecdf") +
    ylab("Initial culture, Zscore(OD600)")
  
  pdf(file.path(out_dir, paste0("G_2_2_", Sys.Date(), "_Growth_comparison_plots.pdf")))
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  dev.off()
  
  if(jnk){
  # df_melt <- df_melt %>%
  #   group_by(Proteins) %>%
  #   dplyr::mutate(Protein_count=sum(!is.na(NormalizedValue))) %>%
  #   as.data.frame()
  # 
  # df_melt <- df_melt %>%
  #   group_by(Strain) %>%
  #   dplyr::mutate(Strain_pGcount=sum(!is.na(NormalizedValue))) %>%
  #   as.data.frame()
  # 
  # jnk <- unique(df_melt[,c(1,8)])
  # jnk <- jnk[jnk$Protein_count >= quantile(jnk$Protein_count, 0.5)[[1]],]
  # 
  # df_melt_1844 <- df_melt[df_melt$Proteins %in% jnk$Proteins,]
  # 
  # df_melt_1844$Changing <- "NotRegulated"
  # df_melt_1844$Changing[df_melt_1844$pvalue_FDR <= 0.05 & abs(df_melt_1844$FC) >= 1] <- "Significant"
  # p1 <- ggplot(df_melt_1844, aes(Changing, FC)) +
  #   geom_violin() +
  #   ylab("Fold change")
  # 
  # # df_melt_1844$Changing[df_melt_1844$pvalue_FDR <= 0.05 & abs(df_melt_1844$FC) >= 1] <- "SignificantFC"
  # df_melt_1844$StrainType <- "Knockout"
  # df_melt_1844$StrainType[grep("WT", df_melt_1844$Strain)] <- "Wild-type"
  # 
  # jnk <- as.data.frame(table(df_melt_1844[,c(2,10)]))
  # jnk$StrainType <- "Knockout"
  # jnk$StrainType[grep("WT", jnk$Strain)] <- "Wild-type"
  # 
  # ggplot(jnk, aes(StrainType, Freq)) +
  #   geom_boxplot() +
  #   facet_wrap(~Changing, scales="free")
  # jnk <- jnk[,1:3]
  # jnk <- dcast(jnk, Strain ~ Changing, value.var = "Freq")
  # jnk <- jnk[-grep("WT", jnk$Strain),]
  # jnk <- as.data.frame(jnk)
  # 
  # jnk$kostrain <- gsub("Sp.*\\-(SP.*)","\\1",jnk$Strain)
  # 
  # decode_growth <- merge(decode_growth, jnk, by.x="Systemic.ID", by.y="kostrain", all=FALSE)
  # ggplot(decode_growth, aes(growth, Significant))+
  #   geom_boxplot()
  # 
  # cor(decode_growth$Significant, -decode_growth$Zscore_ic)
  # ggplot(decode_growth, aes(-Zscore_ic, Significant))+
  #   geom_point()
  # 
  # cor(decode_growth$Significant, -decode_growth$Zscore_fc)
  # ggplot(decode_growth, aes(-Zscore_fc, Significant))+
  #   geom_point()
  # 
  # decode_growth$TopQ <- decode_growth$Significant >= quantile(decode_growth$Significant, 0.95)[[1]]
  # ggplot(decode_growth, aes(TopQ, Zscore_ic))+
  #   geom_violin()
  }
  ###################################################################### 
  
}
if(kodetection){
  # KO # knockout detection plots that falk was asking ##########################
  # KO.1 # use the df_melt for KO detection table ####
  myfile <- list.files(path = out_dir, pattern = "^6_5_.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  
  df_melt$StrainType <- "Knockout"
  df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wildtype"
  
  df_melt$StrainType[df_melt$StrainType == "Knockout"] <- gsub("Sp.*\\-(SP.*)", "\\1", df_melt$Strain[df_melt$StrainType == "Knockout"])
  proteinsID <- unique(df_melt[,c(1,1)])
  proteinsID <- splitColumnBySep(proteinsID, "Proteins.1")
  proteinsID <- proteinsID[-grep("REV|CON", proteinsID$Proteins.1),]
  
  koNotdetected <- length(setdiff(unique(df_melt$StrainType), proteinsID$Proteins.1)) -1
  koDetected <- length(intersect(proteinsID$Proteins, unique(df_melt$StrainType)))
  koDetectedGroup <- length(setdiff(intersect(proteinsID$Proteins.1, unique(df_melt$StrainType)),
                                    intersect(proteinsID$Proteins, unique(df_melt$StrainType))))
  
  # length(intersect(proteinsID$Proteins, unique(df_melt$StrainType)))
  # length(intersect(proteinsID$Proteins.1, unique(df_melt$StrainType)))
  # setdiff(intersect(proteinsID$Proteins.1, unique(df_melt$StrainType)),
  #         intersect(proteinsID$Proteins, unique(df_melt$StrainType)))
  df_melt <- as.data.frame(df_melt)
  df_normalized <- as.data.frame(df_melt[,c(1:3,8)])
  df_normalized2 <- df_normalized[,c(1:3)]
  df_normalized2 <- dcast(df_normalized2, Proteins ~ Strain, value.var="NormalizedValue")
  rownames(df_normalized2) <- df_normalized2$Proteins
  df_normalized2 <- df_normalized2[,-1]
  
  df_normalized$StrainType[grep("Wildtype", df_normalized$StrainType)] <- as.character(df_normalized$Strain[grep("Wildtype", df_normalized$StrainType)])
  df_normalized <- df_normalized[,c(1,3,4)]
  
  df_normalized <- dcast(df_normalized, Proteins ~ StrainType, value.var="NormalizedValue")
  rownames(df_normalized) <- df_normalized$Proteins
  df_normalized <- df_normalized[,-1]
  
  myfile <- list.files(path = out_dir, pattern = "^G_1_3_.*.rds")
  koLibrary_jnk <- readRDS(file.path(out_dir, myfile))
  
  allStrains <- 1:dim(df_normalized)[2]
  wt_bio <- grep("WT_Bio", names(df_normalized))
  koCols <- setdiff(allStrains, wt_bio)
  
  koStrains <- names(df_normalized)[koCols]
  
  KOdetectionTable <- data.frame(Systemic.ID=koStrains, MeasuredAll_number=0, Measured_run=FALSE, 
                                 Measured_strain = FALSE, 
                                 Abundace_mean_all=0, Abundace_min_all=0, Abundace_max_all=0,
                                 Abundace_mean_run=0, Abundace_min_run=0, Abundace_max_run=0, 
                                 Abundance_ko=0, 
                                 Percentile_all=NA, Percentile_run=NA, 
                                 Percentile_wt=NA, Percentile_ko=NA)
  for (i in 1:dim(KOdetectionTable)[1]) {
    print(i)
    strain <- KOdetectionTable$Systemic.ID[i]
    rowStrain <- grep(strain, rownames(df_normalized))
    
    if (length(rowStrain) == 1) {
      all_vector <- as.vector(df_normalized[rowStrain,])
      all_vector<- all_vector[!is.na(all_vector)]
      
      wt_vector <- as.vector(df_normalized[rowStrain,wt_bio])
      wt_vector<- wt_vector[!is.na(wt_vector)]
      
      ko_vector <- as.vector(df_normalized[rowStrain,koCols])
      ko_vector<- ko_vector[!is.na(ko_vector)]
      
      KOdetectionTable$MeasuredAll_number[i] <- sum(!is.na(df_normalized2[rowStrain,]))
      
      MSrun <- koLibrary_jnk$Position_MS_Plate[grep(strain, koLibrary_jnk$Systemic.ID)]
      
      df_normalized2_subset <- df_normalized2[,grep(substr(MSrun, 1, 4), names(df_normalized2))]
      df_normalized2_subset <- df_normalized2_subset[,grep(paste0(substr(MSrun, 6, 74), "-"), names(df_normalized2_subset))]
      df_normalized2_subset <- df_normalized2_subset[rowSums(is.na(df_normalized2_subset)) != dim(df_normalized2_subset)[2],]
      
      if (length(grep(strain, rownames(df_normalized2_subset)))!=0) {
        KOdetectionTable$Measured_run[i] <- TRUE
      }
      measured_run_row <- grep(strain, rownames(df_normalized2_subset))
      if (length(measured_run_row)!=0) {
        run_vector <- as.vector(df_normalized2_subset[measured_run_row,])
        run_vector<- run_vector[!is.na(run_vector)]
        
        KOdetectionTable$Measured_run[i] <- TRUE
        KOdetectionTable$Abundace_mean_run[i] <- mean(t(df_normalized2_subset[measured_run_row,]), na.rm=TRUE)
        KOdetectionTable$Abundace_min_run[i] <- min(t(df_normalized2_subset[measured_run_row,]), na.rm=TRUE)
        KOdetectionTable$Abundace_max_run[i] <- max(t(df_normalized2_subset[measured_run_row,]), na.rm=TRUE)
        
        
        
        if (!is.na(df_normalized2_subset[measured_run_row, grep(MSrun, names(df_normalized2_subset))])) {
          ko_value_measured <- df_normalized[rowStrain,grep(strain, names(df_normalized))]
          KOdetectionTable$Measured_strain[i] <- TRUE
          KOdetectionTable$Abundance_ko[i] <- df_normalized2_subset[measured_run_row, grep(MSrun, names(df_normalized2_subset))]
          
          KOdetectionTable$Percentile_all[i] <- 100*ecdf_fun(all_vector, ko_value_measured)
          KOdetectionTable$Percentile_run[i] <- 100*ecdf_fun(run_vector, ko_value_measured)
          KOdetectionTable$Percentile_wt [i] <- 100*ecdf_fun(wt_vector, ko_value_measured)
          KOdetectionTable$Percentile_ko[i] <- 100*ecdf_fun(ko_vector, ko_value_measured)
          
        }
      }
      KOdetectionTable$Abundace_mean_all[i] <- mean(t(df_normalized2[rowStrain,]), na.rm=TRUE)
      KOdetectionTable$Abundace_min_all[i] <- min(t(df_normalized2[rowStrain,]), na.rm=TRUE)
      KOdetectionTable$Abundace_max_all[i] <- max(t(df_normalized2[rowStrain,]), na.rm=TRUE)
    }
  }
  
  saveRDS(KOdetectionTable, file.path(out_dir, paste0("KO_1_", Sys.Date(), "_KOdetectionTable.rds")))
  rm(df_normalized)
  rm(df_normalized2)
  rm(df_normalized2_subset)
  rm(KOdetectionTable)
  rm(koLibrary_jnk)
  rm(allStrains)
  rm(wt_bio)
  rm(koStrains)
  rm(strain)
  rm(rowStrain)
  rm(MSrun)
  rm(measured_run_row)
  # KO.2 # exploratory plots for ko detection ####
  myfile <- list.files(path = out_dir, pattern = "^KO_1_.*.rds")
  KOdetectionTable_normalized <- readRDS(file.path(out_dir, myfile))

  # General Library assesment ###
  viability <- read.delim("FYPOviability.tsv",
                          header=FALSE)
  names(viability) <- c("Strain", "Viability")
  
  koLibrary <- as.data.frame(KOdetectionTable_normalized$Systemic.ID)
  koLibrary$mut <- "koLibrary"
  names(koLibrary)[1] <- "Systemics.ID"
  viability <- merge(viability, koLibrary, by = 1, all=TRUE)
  
  allStrainsNumber <- dim(viability)[1]
  viableStrainsNumber <- sum(viability$Viability=="viable", na.rm=TRUE)
  inviableStrainsNumber <- sum(viability$Viability=="inviable", na.rm=TRUE)
  conditionStrainsNumber <- sum(viability$Viability=="condition-dependent", na.rm=TRUE)
  
  n25 <- dim(subset(viability, Viability=="viable" & mut == "koLibrary"))[1]
  n35 <- dim(subset(viability, Viability=="condition-dependent" & mut == "koLibrary"))[1]
  n45 <- dim(subset(viability, Viability=="inviable" & mut == "koLibrary"))[1]
  write.table(viability, file.path(out_dir, "KO_2_1_viability.txt"), quote = F, sep="\t")
  # Venn Diagram for strains viability ####
  library(VennDiagram)
  library(eulerr)
  Qvenn <-  draw.quad.venn(viableStrainsNumber, conditionStrainsNumber, inviableStrainsNumber, dim(koLibrary)[1],
                           0, 0, n25, 0, n35, n45, 0, 0, 0, 0, 0, lwd=rep(0,4), cex = rep(2, 15),
                           cat.cex= rep(1.5, 4), alpha = rep(0.3, 4), lty=rep(0,4),
                           category = c("Viable", "ConditionDependent", "Inviable", "koLibrary"),
                           fill=c("#74c476", "#fed98e", "#bd0026", "#ffff99"))
  fit <- euler(c(Viable = 335, ConditionDependent=41, Inviable = 1236, koLibrary=3, 
                 "koLibrary&Inviable" = 7, "koLibrary&ConditionDependent" = 63, 
                 "koLibrary&Viable" = 3235))
  
  eulerr_ <- plot(fit, fill = c("#74c476", "#fed98e", "#bd0026", "#ffff99"), 
                  fills = 0.4,counts = TRUE, fill_opacity=0.2, quantities = TRUE)
  
  measured <- KOdetectionTable_normalized[,1:4]
  viability <- merge(viability, measured, by = 1, all=TRUE)
  
  pdf(file.path(out_dir, "KO_2_2_VennDiagrams.pdf"), width=14)
  grid.draw(Qvenn)
  print(eulerr_)
  dev.off()
  
  rm(eulerr_)
  rm(fit)
  rm(Qvenn)
  
  # KO detection Table ####
  KOdetectionTable_normalized <- KOdetectionTable_normalized[with(KOdetectionTable_normalized, order(-Abundace_mean_all)), ]
  KOdetectionTable_normalized$Rank <- 1:dim(KOdetectionTable_normalized)[1]
  
  jnk <- data.frame(Total=dim(KOdetectionTable_normalized)[1],
                    notMeasuredAtAll = sum(KOdetectionTable_normalized$MeasuredAll_number==0),
                    MeasuredAtAll = sum(KOdetectionTable_normalized$MeasuredAll_number>0),
                    Measured_run = table(KOdetectionTable_normalized$Measured_run)[2][[1]],
                    Measured_strain=table(KOdetectionTable_normalized$Measured_strain)[2][[1]])
  jnk$NotMeasured_run <- jnk$MeasuredAtAll - jnk$Measured_run
  jnk <- jnk[,-3]
  jnk$NotMeasured_strain <- jnk$Measured_run - jnk$Measured_strain
  jnk <- jnk[,c(2,5,6,4)]
  
  jnk <- melt(jnk)
  jnk$Type <- "Genes_Knockout_Library"
  jnk <- jnk[jnk$value != 0,]
  
  d <- ggplot(jnk,aes(x=Type, y=value, fill=factor(variable)))+
    geom_bar(stat="identity", position = "stack")+
    geom_text(aes(label=value),size = 5, fontface = "bold", position = position_stack(vjust = 0.5))+
    ggtitle("Distribution of ko-genes by identification status")+
    theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
          axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))+
    guides(fill=guide_legend(title=NULL))+
    ylab("Number of proteins") +
    xlab(NULL)
  
  p <- ggplot(data=subset(KOdetectionTable_normalized, Measured_run==TRUE), 
              aes(x=Rank, y=Abundace_min_all))+
    geom_point(color="black") +
    geom_point(aes(x=Rank,y=Abundace_min_run), color="blue")+
    geom_point(aes(x=Rank,y=Abundance_ko), color="red")+
    ggtitle("Black=minAll, Blue=minRun, Red=koStrain") +
    theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
          axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  
  s <- ggplot(data=subset(KOdetectionTable_normalized, Measured_run==TRUE), 
              aes(x=Rank, y=Abundace_min_all))+
    geom_smooth(color="black") +
    geom_smooth(aes(x=Rank,y=Abundace_min_run), color="blue")+
    geom_smooth(aes(x=Rank,y=Abundance_ko), color="red")+
    ggtitle("Black=minAll, Blue=minRun, Red=koStrain")+
    theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
          axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  # histograms #######
  df_his <- subset(KOdetectionTable_normalized, Measured_run==TRUE & Measured_strain==TRUE)
  x <- ecdf(df_his$Percentile_all)
  df_his$Percentile_all_ecdf <- x(df_his$Percentile_all)
  
  his_a <- ggplot(df_his, aes(Percentile_all))+
    geom_histogram(color="black", bins = 100)+
    geom_point(aes(Percentile_all, 300*Percentile_all_ecdf), color="#f46d43", size=0.9) +
    scale_y_continuous(sec.axis = sec_axis(~./300, name = "Cumulative fraction", breaks = c(0,0.8,1))) +
    theme_bw() +
    xlab("Expression percentile of ko gene in ko strain, all measurements")+
    ylab("Number of knockout genes") +
    geom_hline(yintercept = 240, linetype="dashed", color="#006837")+
    geom_vline(xintercept = df_his$Percentile_all[grep(max((0.8-min(abs(df_his$Percentile_all_ecdf-0.8))),
                                                           (min(abs(df_his$Percentile_all_ecdf-0.8))+0.8)), df_his$Percentile_all_ecdf)], linetype="dashed", color="#006837")
  
  df_his <- subset(KOdetectionTable_normalized, Measured_run==TRUE & Measured_strain==TRUE)
  x <- ecdf(df_his$Percentile_wt)
  df_his$Percentile_wt_ecdf <- x(df_his$Percentile_wt)
  
  his_wt <- ggplot(df_his, aes(Percentile_wt))+
    geom_histogram(color="black", bins = 100)+
    geom_point(aes(Percentile_wt, 300*Percentile_wt_ecdf), color="#f46d43", size=0.9) +
    scale_y_continuous(sec.axis = sec_axis(~./300, name = "Cumulative fraction", breaks = c(0,0.8,1))) +
    theme_bw() +
    xlab("Expression percentile of ko gene in ko strain, wild type")+
    ylab("Number of knockout genes") +
    geom_hline(yintercept = 240, linetype="dashed", color="#006837")+
    geom_vline(xintercept = df_his$Percentile_wt[grep(max((0.8-min(abs(df_his$Percentile_wt_ecdf-0.8))),
                                                           (min(abs(df_his$Percentile_wt_ecdf-0.8))+0.8)), df_his$Percentile_wt_ecdf)], linetype="dashed", color="#006837")
  
  
  myfile <- list.files(path = out_dir, pattern = "^G_2_1_.*.rds")
  decode_growth <- readRDS(file.path(out_dir, myfile))
  decode_growth <- decode_growth[,c(1,23:30)]
  
  df_his <- subset(KOdetectionTable_normalized, Measured_run==TRUE & Measured_strain==TRUE)
  x <- ecdf(df_his$Percentile_wt)
  df_his$Percentile_wt_ecdf <- x(df_his$Percentile_wt)
  x <- ecdf(df_his$Percentile_all)
  df_his$Percentile_all_ecdf <- x(df_his$Percentile_all)
  
  decode_growth <- merge(decode_growth, df_his, by=1, all=FALSE)
  decode_growth <- decode_growth[,c(1,8,9,20, 22,25,26)]
  
  decode_growth$categories <- floor(decode_growth$Percentile_all/10)
  decode_growth$categories <- (decode_growth$categories/10)
  decode_growth$categories[decode_growth$categories==1] <- 0.9
  decode_growth$categories <- decode_growth$categories + 0.1
  jnk <- as.data.frame(table(decode_growth$categories))
  
  px1 <- ggplot(decode_growth, aes(as.factor(categories), Changing_ecdf))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from all") +
    ylab("Number of proteins changing, ecdf")+
    theme_bw()
  px2 <- ggplot(decode_growth, aes(as.factor(categories), Changing_pFDR))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from all") +
    ylab("Number of proteins changing, p")+
    theme_bw()
  
  
  decode_growth$categories <- floor(decode_growth$Percentile_wt/10)
  decode_growth$categories <- (decode_growth$categories/10)
  decode_growth$categories[decode_growth$categories==1] <- 0.9
  decode_growth$categories <- decode_growth$categories + 0.1
  jnk <- as.data.frame(table(decode_growth$categories))
  
  px3 <- ggplot(decode_growth, aes(as.factor(categories), Changing_ecdf))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from wt") +
    ylab("Number of proteins changing, ecdf")+
    theme_bw()
  px4 <- ggplot(decode_growth, aes(as.factor(categories), Changing_pFDR))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from wt") +
    ylab("Number of proteins changing, p")+
    theme_bw()
  
  
  decode_growth$categories <- floor(decode_growth$Percentile_all_ecdf*10)
  decode_growth$categories <- (decode_growth$categories/10)
  decode_growth$categories[decode_growth$categories==1] <- 0.9
  decode_growth$categories <- decode_growth$categories + 0.1
  jnk <- as.data.frame(table(decode_growth$categories))
  
  px5 <- ggplot(decode_growth, aes(as.factor(categories), Changing_ecdf))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from all, ecdf") +
    ylab("Number of proteins changing, ecdf")+
    theme_bw()
  px6 <- ggplot(decode_growth, aes(as.factor(categories), Changing_pFDR))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from all, ecdf") +
    ylab("Number of proteins changing, p")+
    theme_bw()
  
  decode_growth$categories <- floor(decode_growth$Percentile_wt_ecdf*10)
  decode_growth$categories <- (decode_growth$categories/10)
  decode_growth$categories[decode_growth$categories==1] <- 0.9
  decode_growth$categories <- decode_growth$categories + 0.1
  jnk <- as.data.frame(table(decode_growth$categories))
  
  px7 <- ggplot(decode_growth, aes(as.factor(categories), Changing_ecdf))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from wt, ecdf") +
    ylab("Number of proteins changing, ecdf")+
    theme_bw()
  px8 <- ggplot(decode_growth, aes(as.factor(categories), Changing_pFDR))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from wt, ecdf") +
    ylab("Number of proteins changing, p")+
    theme_bw()
  # perc <- ggplot(data=subset(KOdetectionTable_normalized, Measured_run==TRUE & Measured_strain==TRUE), 
  #                aes(x=Rank, y=Percentile_all))+
  #   geom_point(aes(color=MeasuredAll_number)) +
  #   theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
  #         axis.text=element_text(size=12),
  #         axis.title=element_text(size=14,face="bold"))
  # 
  # perc_2 <- ggplot(data=subset(KOdetectionTable_normalized, Measured_run==TRUE & Measured_strain==TRUE), 
  #                  aes(x=Percentile_wt, y=Percentile_all))+
  #   geom_point(aes(color=MeasuredAll_number)) +
  #   theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
  #         axis.text=element_text(size=12),
  #         axis.title=element_text(size=14,face="bold"))
  
  pdf(file.path(out_dir, "KO_2_3_KOdetectionDecisions.pdf"))
  print(d)
  print(p)
  print(s)
  print(his_a)
  print(his_wt)
  print(px1)
  print(px2)
  print(px3)
  print(px4)
  print(px5)
  print(px6)
  print(px7)
  print(px8)
  dev.off()
  # with the normalized file without any filtering ###############################
  # KO.3 # use the df_melt for KO detection table ####
  myfile <- list.files(path = out_dir, pattern = "^4_2_4_1.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  df_melt$pG <- rownames(df_melt)
  df_melt <- melt(df_melt, id="pG")
  names(df_melt) <- c("Proteins", "Strain", "NormalizedValue")
  
  df_melt$StrainType <- "Knockout"
  df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wildtype"
  
  df_melt$StrainType[df_melt$StrainType == "Knockout"] <- gsub("Sp.*\\-(SP.*)", "\\1", df_melt$Strain[df_melt$StrainType == "Knockout"])
  proteinsID <- unique(df_melt[,c(1,1)])
  proteinsID <- splitColumnBySep(proteinsID, "Proteins.1")
  proteinsID <- proteinsID[-grep("REV|CON", proteinsID$Proteins.1),]
  
  koNotdetected <- length(setdiff(unique(df_melt$StrainType), proteinsID$Proteins.1)) -1
  koDetected <- length(intersect(proteinsID$Proteins, unique(df_melt$StrainType)))
  koDetectedGroup <- length(setdiff(intersect(proteinsID$Proteins.1, unique(df_melt$StrainType)),
                                    intersect(proteinsID$Proteins, unique(df_melt$StrainType))))
  
  # length(intersect(proteinsID$Proteins, unique(df_melt$StrainType)))
  # length(intersect(proteinsID$Proteins.1, unique(df_melt$StrainType)))
  # setdiff(intersect(proteinsID$Proteins.1, unique(df_melt$StrainType)),
  #         intersect(proteinsID$Proteins, unique(df_melt$StrainType)))
  df_melt <- as.data.frame(df_melt)
  
  df_normalized <- as.data.frame(df_melt[,c(1:4)])
  df_normalized2 <- df_normalized[,c(1:3)]
  df_normalized2 <- dcast(df_normalized2, Proteins ~ Strain, value.var="NormalizedValue")
  rownames(df_normalized2) <- df_normalized2$Proteins
  df_normalized2 <- df_normalized2[,-1]
  
  df_normalized$StrainType[grep("Wildtype", df_normalized$StrainType)] <- as.character(df_normalized$Strain[grep("Wildtype", df_normalized$StrainType)])
  df_normalized <- df_normalized[,c(1,3,4)]
  
  df_normalized <- dcast(df_normalized, Proteins ~ StrainType, value.var="NormalizedValue")
  rownames(df_normalized) <- df_normalized$Proteins
  df_normalized <- df_normalized[,-1]
  
  myfile <- list.files(path = out_dir, pattern = "^G_1_3_.*.rds")
  koLibrary_jnk <- readRDS(file.path(out_dir, myfile))
  
  allStrains <- 1:dim(df_normalized)[2]
  wt_bio <- grep("WT_Bio", names(df_normalized))
  koCols <- setdiff(allStrains, wt_bio)
  
  koStrains <- names(df_normalized)[koCols]
  
  KOdetectionTable <- data.frame(Systemic.ID=koStrains, MeasuredAll_number=0, Measured_run=FALSE, 
                                 Measured_strain = FALSE, 
                                 Abundace_mean_all=0, Abundace_min_all=0, Abundace_max_all=0,
                                 Abundace_mean_run=0, Abundace_min_run=0, Abundace_max_run=0, 
                                 Abundance_ko=0, 
                                 Percentile_all=NA, Percentile_run=NA, 
                                 Percentile_wt=NA, Percentile_ko=NA)
  for (i in 1:dim(KOdetectionTable)[1]) {
    print(i)
    strain <- KOdetectionTable$Systemic.ID[i]
    rowStrain <- grep(strain, rownames(df_normalized))
    
    if (length(rowStrain) == 1) {
      all_vector <- as.vector(df_normalized[rowStrain,])
      all_vector<- all_vector[!is.na(all_vector)]
      
      wt_vector <- as.vector(df_normalized[rowStrain,wt_bio])
      wt_vector<- wt_vector[!is.na(wt_vector)]
      
      ko_vector <- as.vector(df_normalized[rowStrain,koCols])
      ko_vector<- ko_vector[!is.na(ko_vector)]
      
      KOdetectionTable$MeasuredAll_number[i] <- sum(!is.na(df_normalized2[rowStrain,]))
      
      MSrun <- koLibrary_jnk$Position_MS_Plate[grep(strain, koLibrary_jnk$Systemic.ID)]
      
      df_normalized2_subset <- df_normalized2[,grep(substr(MSrun, 1, 4), names(df_normalized2))]
      df_normalized2_subset <- df_normalized2_subset[,grep(paste0(substr(MSrun, 6, 74), "-"), names(df_normalized2_subset))]
      df_normalized2_subset <- df_normalized2_subset[rowSums(is.na(df_normalized2_subset)) != dim(df_normalized2_subset)[2],]
      
      if (length(grep(strain, rownames(df_normalized2_subset)))!=0) {
        KOdetectionTable$Measured_run[i] <- TRUE
      }
      measured_run_row <- grep(strain, rownames(df_normalized2_subset))
      if (length(measured_run_row)!=0) {
        run_vector <- as.vector(df_normalized2_subset[measured_run_row,])
        run_vector<- run_vector[!is.na(run_vector)]
        
        KOdetectionTable$Measured_run[i] <- TRUE
        KOdetectionTable$Abundace_mean_run[i] <- mean(t(df_normalized2_subset[measured_run_row,]), na.rm=TRUE)
        KOdetectionTable$Abundace_min_run[i] <- min(t(df_normalized2_subset[measured_run_row,]), na.rm=TRUE)
        KOdetectionTable$Abundace_max_run[i] <- max(t(df_normalized2_subset[measured_run_row,]), na.rm=TRUE)
        
        
        
        if (!is.na(df_normalized2_subset[measured_run_row, grep(MSrun, names(df_normalized2_subset))])) {
          ko_value_measured <- df_normalized[rowStrain,grep(strain, names(df_normalized))]
          KOdetectionTable$Measured_strain[i] <- TRUE
          KOdetectionTable$Abundance_ko[i] <- df_normalized2_subset[measured_run_row, grep(MSrun, names(df_normalized2_subset))]
          
          KOdetectionTable$Percentile_all[i] <- 100*ecdf_fun(all_vector, ko_value_measured)
          KOdetectionTable$Percentile_run[i] <- 100*ecdf_fun(run_vector, ko_value_measured)
          KOdetectionTable$Percentile_wt [i] <- 100*ecdf_fun(wt_vector, ko_value_measured)
          KOdetectionTable$Percentile_ko[i] <- 100*ecdf_fun(ko_vector, ko_value_measured)
          
        }
      }
      KOdetectionTable$Abundace_mean_all[i] <- mean(t(df_normalized2[rowStrain,]), na.rm=TRUE)
      KOdetectionTable$Abundace_min_all[i] <- min(t(df_normalized2[rowStrain,]), na.rm=TRUE)
      KOdetectionTable$Abundace_max_all[i] <- max(t(df_normalized2[rowStrain,]), na.rm=TRUE)
    }
  }
  
  saveRDS(KOdetectionTable, file.path(out_dir, paste0("KO_3_", Sys.Date(), "_KOdetectionTable_norm.rds")))
  rm(df_normalized)
  rm(df_normalized2)
  rm(df_normalized2_subset)
  rm(KOdetectionTable)
  rm(koLibrary_jnk)
  rm(allStrains)
  rm(wt_bio)
  rm(koStrains)
  rm(strain)
  rm(rowStrain)
  rm(MSrun)
  rm(measured_run_row)
  # KO.4 # exploratory plots for ko detection ####
  myfile <- list.files(path = out_dir, pattern = "^KO_3_.*.rds")
  KOdetectionTable_normalized <- readRDS(file.path(out_dir, myfile))
  
  # General Library assesment ###
  viability <- read.delim("FYPOviability.tsv",
                          header=FALSE)
  names(viability) <- c("Strain", "Viability")
  
  koLibrary <- as.data.frame(KOdetectionTable_normalized$Systemic.ID)
  koLibrary$mut <- "koLibrary"
  names(koLibrary)[1] <- "Systemics.ID"
  viability <- merge(viability, koLibrary, by = 1, all=TRUE)
  
  allStrainsNumber <- dim(viability)[1]
  viableStrainsNumber <- sum(viability$Viability=="viable", na.rm=TRUE)
  inviableStrainsNumber <- sum(viability$Viability=="inviable", na.rm=TRUE)
  conditionStrainsNumber <- sum(viability$Viability=="condition-dependent", na.rm=TRUE)
  
  n25 <- dim(subset(viability, Viability=="viable" & mut == "koLibrary"))[1]
  n35 <- dim(subset(viability, Viability=="condition-dependent" & mut == "koLibrary"))[1]
  n45 <- dim(subset(viability, Viability=="inviable" & mut == "koLibrary"))[1]
  write.table(viability, file.path(out_dir, "KO_4_1_viability.txt"), quote = F, sep="\t")
  # Venn Diagram for strains viability ####
  library(VennDiagram)
  library(eulerr)
  Qvenn <-  draw.quad.venn(viableStrainsNumber, conditionStrainsNumber, inviableStrainsNumber, dim(koLibrary)[1],
                           0, 0, n25, 0, n35, n45, 0, 0, 0, 0, 0, lwd=rep(0,4), cex = rep(2, 15),
                           cat.cex= rep(1.5, 4), alpha = rep(0.3, 4), lty=rep(0,4),
                           category = c("Viable", "ConditionDependent", "Inviable", "koLibrary"),
                           fill=c("#74c476", "#fed98e", "#bd0026", "#ffff99"))
  fit <- euler(c(Viable = 335, ConditionDependent=41, Inviable = 1236, koLibrary=3, 
                 "koLibrary&Inviable" = 7, "koLibrary&ConditionDependent" = 63, 
                 "koLibrary&Viable" = 3235))
  
  eulerr_ <- plot(fit, fill = c("#74c476", "#fed98e", "#bd0026", "#ffff99"), 
                  fills = 0.4,counts = TRUE, fill_opacity=0.2, quantities = TRUE)
  
  measured <- KOdetectionTable_normalized[,1:4]
  viability <- merge(viability, measured, by = 1, all=TRUE)
  
  pdf(file.path(out_dir, "KO_4_2_VennDiagrams.pdf"), width=14)
  grid.draw(Qvenn)
  print(eulerr_)
  dev.off()
  
  rm(eulerr_)
  rm(fit)
  rm(Qvenn)
  
  # KO detection Table ####
  KOdetectionTable_normalized <- KOdetectionTable_normalized[with(KOdetectionTable_normalized, order(-Abundace_mean_all)), ]
  KOdetectionTable_normalized$Rank <- 1:dim(KOdetectionTable_normalized)[1]
  
  jnk <- data.frame(Total=dim(KOdetectionTable_normalized)[1],
                    notMeasuredAtAll = sum(KOdetectionTable_normalized$MeasuredAll_number==0),
                    MeasuredAtAll = sum(KOdetectionTable_normalized$MeasuredAll_number>0),
                    Measured_run = table(KOdetectionTable_normalized$Measured_run)[2][[1]],
                    Measured_strain=table(KOdetectionTable_normalized$Measured_strain)[2][[1]])
  jnk$NotMeasured_run <- jnk$MeasuredAtAll - jnk$Measured_run
  jnk <- jnk[,-3]
  jnk$NotMeasured_strain <- jnk$Measured_run - jnk$Measured_strain
  jnk <- jnk[,c(2,5,6,4)]
  
  jnk <- melt(jnk)
  jnk$Type <- "Genes_Knockout_Library"
  jnk <- jnk[jnk$value != 0,]
  
  d <- ggplot(jnk,aes(x=Type, y=value, fill=factor(variable)))+
    geom_bar(stat="identity", position = "stack")+
    geom_text(aes(label=value),size = 5, fontface = "bold", position = position_stack(vjust = 0.5))+
    ggtitle("Distribution of ko-genes by identification status")+
    theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
          axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))+
    guides(fill=guide_legend(title=NULL))+
    ylab("Number of proteins") +
    xlab(NULL)
  
  p <- ggplot(data=subset(KOdetectionTable_normalized, Measured_run==TRUE), 
              aes(x=Rank, y=Abundace_min_all))+
    geom_point(color="black") +
    geom_point(aes(x=Rank,y=Abundace_min_run), color="blue")+
    geom_point(aes(x=Rank,y=Abundance_ko), color="red")+
    ggtitle("Black=minAll, Blue=minRun, Red=koStrain") +
    theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
          axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  
  s <- ggplot(data=subset(KOdetectionTable_normalized, Measured_run==TRUE), 
              aes(x=Rank, y=Abundace_min_all))+
    geom_smooth(color="black") +
    geom_smooth(aes(x=Rank,y=Abundace_min_run), color="blue")+
    geom_smooth(aes(x=Rank,y=Abundance_ko), color="red")+
    ggtitle("Black=minAll, Blue=minRun, Red=koStrain")+
    theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
          axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  # histograms #######
  df_his <- subset(KOdetectionTable_normalized, Measured_run==TRUE & Measured_strain==TRUE)
  x <- ecdf(df_his$Percentile_all)
  df_his$Percentile_all_ecdf <- x(df_his$Percentile_all)
  
  his_a <- ggplot(df_his, aes(Percentile_all))+
    geom_histogram(color="black", bins = 100)+
    geom_point(aes(Percentile_all, 300*Percentile_all_ecdf), color="#f46d43", size=0.9) +
    scale_y_continuous(sec.axis = sec_axis(~./300, name = "Cumulative fraction", breaks = c(0,0.8,1))) +
    theme_bw() +
    xlab("Expression percentile of ko gene in ko strain, all measurements")+
    ylab("Number of knockout genes") +
    geom_hline(yintercept = 240, linetype="dashed", color="#006837")+
    geom_vline(xintercept = df_his$Percentile_all[grep(paste((0.8-min(abs(df_his$Percentile_all_ecdf-0.8))),
                                                             (min(abs(df_his$Percentile_all_ecdf-0.8))+0.8),sep="|"), 
                                                       df_his$Percentile_all_ecdf)], linetype="dashed", color="#006837")
  
  df_his <- subset(KOdetectionTable_normalized, Measured_run==TRUE & Measured_strain==TRUE)
  x <- ecdf(df_his$Percentile_wt)
  df_his$Percentile_wt_ecdf <- x(df_his$Percentile_wt)
  
  his_wt <- ggplot(df_his, aes(Percentile_wt))+
    geom_histogram(color="black", bins = 100)+
    geom_point(aes(Percentile_wt, 300*Percentile_wt_ecdf), color="#f46d43", size=0.9) +
    scale_y_continuous(sec.axis = sec_axis(~./300, name = "Cumulative fraction", breaks = c(0,0.8,1))) +
    theme_bw() +
    xlab("Expression percentile of ko gene in ko strain, wild type")+
    ylab("Number of knockout genes") +
    geom_hline(yintercept = 240, linetype="dashed", color="#006837")+
    geom_vline(xintercept = df_his$Percentile_wt[grep(paste((0.8-min(abs(df_his$Percentile_wt_ecdf-0.8))),
                                                       (min(abs(df_his$Percentile_wt_ecdf-0.8))+0.8),sep="|"), 
                                                 df_his$Percentile_wt_ecdf)], linetype="dashed", color="#006837")
  
  
  myfile <- list.files(path = out_dir, pattern = "^G_2_1_.*.rds")
  decode_growth <- readRDS(file.path(out_dir, myfile))
  decode_growth <- decode_growth[,c(1,23:30)]
  
  df_his <- subset(KOdetectionTable_normalized, Measured_run==TRUE & Measured_strain==TRUE)
  x <- ecdf(df_his$Percentile_wt)
  df_his$Percentile_wt_ecdf <- x(df_his$Percentile_wt)
  x <- ecdf(df_his$Percentile_all)
  df_his$Percentile_all_ecdf <- x(df_his$Percentile_all)
  
  decode_growth <- merge(decode_growth, df_his, by=1, all=FALSE)
  decode_growth <- decode_growth[,c(1,8,9,20, 22,25,26)]
  
  decode_growth$categories <- floor(decode_growth$Percentile_all/10)
  decode_growth$categories <- (decode_growth$categories/10)
  decode_growth$categories[decode_growth$categories==1] <- 0.9
  decode_growth$categories <- decode_growth$categories + 0.1
  jnk <- as.data.frame(table(decode_growth$categories))
  
  px1 <- ggplot(decode_growth, aes(as.factor(categories), Changing_ecdf))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from all") +
    ylab("Number of proteins changing, ecdf")+
    theme_bw()
  px2 <- ggplot(decode_growth, aes(as.factor(categories), Changing_pFDR))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from all") +
    ylab("Number of proteins changing, p")+
    theme_bw()
  
  
  decode_growth$categories <- floor(decode_growth$Percentile_wt/10)
  decode_growth$categories <- (decode_growth$categories/10)
  decode_growth$categories[decode_growth$categories==1] <- 0.9
  decode_growth$categories <- decode_growth$categories + 0.1
  jnk <- as.data.frame(table(decode_growth$categories))
  
  px3 <- ggplot(decode_growth, aes(as.factor(categories), Changing_ecdf))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from wt") +
    ylab("Number of proteins changing, ecdf")+
    theme_bw()
  px4 <- ggplot(decode_growth, aes(as.factor(categories), Changing_pFDR))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from wt") +
    ylab("Number of proteins changing, p")+
    theme_bw()
  
  
  decode_growth$categories <- floor(decode_growth$Percentile_all_ecdf*10)
  decode_growth$categories <- (decode_growth$categories/10)
  decode_growth$categories[decode_growth$categories==1] <- 0.9
  decode_growth$categories <- decode_growth$categories + 0.1
  jnk <- as.data.frame(table(decode_growth$categories))
  
  px5 <- ggplot(decode_growth, aes(as.factor(categories), Changing_ecdf))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from all, ecdf") +
    ylab("Number of proteins changing, ecdf")+
    theme_bw()
  px6 <- ggplot(decode_growth, aes(as.factor(categories), Changing_pFDR))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from all, ecdf") +
    ylab("Number of proteins changing, p")+
    theme_bw()
  
  decode_growth$categories <- floor(decode_growth$Percentile_wt_ecdf*10)
  decode_growth$categories <- (decode_growth$categories/10)
  decode_growth$categories[decode_growth$categories==1] <- 0.9
  decode_growth$categories <- decode_growth$categories + 0.1
  jnk <- as.data.frame(table(decode_growth$categories))
  
  px7 <- ggplot(decode_growth, aes(as.factor(categories), Changing_ecdf))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from wt, ecdf") +
    ylab("Number of proteins changing, ecdf")+
    theme_bw()
  px8 <- ggplot(decode_growth, aes(as.factor(categories), Changing_pFDR))+
    geom_boxplot()+
    geom_text(data=jnk, aes(x=Var1, label=Freq), y=480)+
    ylim(0, 500)+
    xlab("groups of percentiles from wt, ecdf") +
    ylab("Number of proteins changing, p")+
    theme_bw()
  # perc <- ggplot(data=subset(KOdetectionTable_normalized, Measured_run==TRUE & Measured_strain==TRUE), 
  #                aes(x=Rank, y=Percentile_all))+
  #   geom_point(aes(color=MeasuredAll_number)) +
  #   theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
  #         axis.text=element_text(size=12),
  #         axis.title=element_text(size=14,face="bold"))
  # 
  # perc_2 <- ggplot(data=subset(KOdetectionTable_normalized, Measured_run==TRUE & Measured_strain==TRUE), 
  #                  aes(x=Percentile_wt, y=Percentile_all))+
  #   geom_point(aes(color=MeasuredAll_number)) +
  #   theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
  #         axis.text=element_text(size=12),
  #         axis.title=element_text(size=14,face="bold"))
  
  pdf(file.path(out_dir, "KO_4_3_KOdetectionDecisions.pdf"))
  print(d)
  print(p)
  print(s)
  print(his_a)
  print(his_wt)
  print(px1)
  print(px2)
  print(px3)
  print(px4)
  print(px5)
  print(px6)
  print(px7)
  print(px8)
  dev.off()
  ############################
  
  
  ##########
  
  if(later){  
    if(checkFiltered_DF){
      # 12 # Global analysis #####################################################
      subDir2 <- paste0(subDir, "/20181022_12_FilteredDF")
      dir.create(file.path(getwd(), subDir2), showWarnings = FALSE)
      
      # 12.1 # k/o strains DIFFERENT background vs wild type #####################
      df_normalized <- as.data.frame(readRDS(file.path(subDir,"11_a_DF_NORMALIZED_final.rds")))
      df_normalized[df_normalized==0] <- NA
      
      proteinsIdentified <- dim(df_normalized)[1]
      numberOfStrains <- dim(df_normalized)[2]
      col_WTbio <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
      df_normalized <- df_normalized[,1:numberOfStrains]
      
      koLibrary <- read.delim("old/7_3_ReporterIntensityDecode_merged_SupTable1.txt")
      koLibrary <- subset(koLibrary, Analyzed_ReMeasured == "ToBeAnalyzed")
      koLibrary_jnk <- koLibrary[,c(5,19)]
      
      df_normalized_VP <- as.data.frame(t(df_normalized))
      df_normalized_VP$Strains <- rownames(df_normalized_VP)
      df_normalized_VP <- merge(df_normalized_VP, koLibrary_jnk, by.x = "Strains", by.y = "Position_MS_Plate", all.x = TRUE)
      df_normalized_VP$Wild.type[is.na(df_normalized_VP$Wild.type)] <- "wt"
      df_normalized_VP$Identifier <- paste(df_normalized_VP$Strains, df_normalized_VP$Wild.type, sep=";")
      rownames(df_normalized_VP) <- df_normalized_VP$Identifier
      df_normalized_VP <- df_normalized_VP[,-c(1,(dim(df_normalized_VP)[2]-1), dim(df_normalized_VP)[2])]
      df_normalized_VP <- as.data.frame(t(df_normalized_VP))
      rm(koLibrary_jnk)
      
      allCols <- 1:numberOfStrains
      wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized_VP))
      koCols <- setdiff(allCols, wtCols) 
      koCols_ED666 <- grep("ED666", colnames(df_normalized_VP))
      koCols_ED668 <- grep("ED668", colnames(df_normalized_VP))
      
      # calculate the means of the groups and the fold change #
      df_normalized_VP$Mean_wt <- apply(df_normalized_VP[,wtCols], 1, mean, na.rm=T)
      df_normalized_VP$Mean_ko <- apply(df_normalized_VP[,koCols], 1, mean, na.rm=T)
      df_normalized_VP$Mean_ko666 <- apply(df_normalized_VP[,koCols_ED666], 1, mean, na.rm=T)
      df_normalized_VP$Mean_ko668 <- apply(df_normalized_VP[,koCols_ED668], 1, mean, na.rm=T)
      
      df_normalized_VP$FoldChange_KOwt <- df_normalized_VP$Mean_ko - df_normalized_VP$Mean_wt
      df_normalized_VP$FoldChange_KO666wt <- df_normalized_VP$Mean_ko666 - df_normalized_VP$Mean_wt
      df_normalized_VP$FoldChange_KO668wt <- df_normalized_VP$Mean_ko668 - df_normalized_VP$Mean_wt
      df_normalized_VP$FoldChange_KO666KO668 <- df_normalized_VP$Mean_ko666 - df_normalized_VP$Mean_ko668
      
      
      # calculate the p values #
      df_normalized_VP$pValue_KOwt <- NA
      df_normalized_VP$pValue_KO666wt <- NA
      df_normalized_VP$pValue_KO668wt <- NA
      df_normalized_VP$pValue_KO666KO668 <- NA
      
      my.t.test.p.value <- function(x,y) {
        obj<-try(t.test(x,y), silent=TRUE)
        if (is(obj, "try-error")) return(NA) else return(obj$p.value)
      }
      
      for (i in 1:dim(df_normalized_VP)[1]) {
        print(i)
        df_normalized_VP$pValue_KOwt[i] <- my.t.test.p.value(df_normalized_VP[i,koCols], df_normalized_VP[i,wtCols])
        df_normalized_VP$pValue_KO666wt[i] <- my.t.test.p.value(df_normalized_VP[i,koCols_ED666], df_normalized_VP[i,wtCols])
        df_normalized_VP$pValue_KO668wt[i] <- my.t.test.p.value(df_normalized_VP[i,koCols_ED668], df_normalized_VP[i,wtCols])
        df_normalized_VP$pValue_KO666KO668[i] <- my.t.test.p.value(df_normalized_VP[i,koCols_ED666], df_normalized_VP[i,koCols_ED668])
      }
      
      # correct the p values #
      df_normalized_VP$pValue_KOwt_B <- p.adjust(df_normalized_VP$pValue_KOwt, method = "bonferroni",
                                                 n = length(df_normalized_VP$pValue_KOwt))
      df_normalized_VP$pValue_KO666wt_B <- p.adjust(df_normalized_VP$pValue_KO666wt, method = "bonferroni",
                                                    n = length(df_normalized_VP$pValue_KO666wt))
      df_normalized_VP$pValue_KO668wt_B <- p.adjust(df_normalized_VP$pValue_KO668wt, method = "bonferroni",
                                                    n = length(df_normalized_VP$pValue_KO668wt))
      df_normalized_VP$pValue_KO666KO668_B <- p.adjust(df_normalized_VP$pValue_KO666KO668, method = "bonferroni",
                                                       n = length(df_normalized_VP$pValue_KO666KO668))
      
      df_normalized_VP$pValue_KOwt_BH <- p.adjust(df_normalized_VP$pValue_KOwt, method = "BH",
                                                  n = length(df_normalized_VP$pValue_KOwt))
      df_normalized_VP$pValue_KO666wt_BH <- p.adjust(df_normalized_VP$pValue_KO666wt, method = "BH",
                                                     n = length(df_normalized_VP$pValue_KO666wt))
      df_normalized_VP$pValue_KO668wt_BH <- p.adjust(df_normalized_VP$pValue_KO668wt, method = "BH",
                                                     n = length(df_normalized_VP$pValue_KO668wt))
      df_normalized_VP$pValue_KO666KO668_BH <- p.adjust(df_normalized_VP$pValue_KO666KO668, method = "BH",
                                                        n = length(df_normalized_VP$pValue_KO666KO668))
      
      # volcano plot with corrected p values and fold changes #
      df_normalized_VP$GeneNames <- rownames(df_normalized_VP)
      
      pdf(file.path(subDir2, "12_1_volcanoPlot_wtKO_differentWT666_668.pdf"))
      
      # ko-wt #
      cor_jnk <- cor(x=df_normalized_VP$Mean_wt, y=df_normalized_VP$Mean_ko, use = "pairwise.complete.obs")
      ggplot(df_normalized_VP, aes(x=Mean_wt, y=Mean_ko))+
        geom_point(alpha=0.4)+
        geom_abline(slope=1, color="red") +
        ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))
      
      ggplot(df_normalized_VP, aes(FoldChange_KOwt))+
        geom_density(size=1, fill="grey")+
        ggtitle("FoldChange_KOwt") +
        xlab("mean(KO) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KOwt))+
        geom_point()+
        ggtitle("FoldChange_KOwt") +
        xlab("mean(KO) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KOwt <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt <= 0.01 & FoldChange_KOwt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP, 
                                       pValue_KOwt <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt <= 0.01 & FoldChange_KOwt <= -1), 
                         aes(label=GeneNames)) +
        ggtitle("all KO's vs. wt") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt_B)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KOwt_B <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt_B <= 0.01 & FoldChange_KOwt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KOwt_B <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt_B <= 0.01 & FoldChange_KOwt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("all KO's vs. wt (bonferroni corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt_BH)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KOwt_BH <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt_BH <= 0.01 & FoldChange_KOwt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KOwt_BH <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt_BH <= 0.01 & FoldChange_KOwt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("all KO's vs. wt (Benjamini-Hochberg corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO) - mean(wt)")
      
      
      
      # ko666-wt #
      cor_jnk <- cor(x=df_normalized_VP$Mean_wt, y=df_normalized_VP$Mean_ko666, use = "pairwise.complete.obs")
      ggplot(df_normalized_VP, aes(x=Mean_wt, y=Mean_ko666))+
        geom_point(alpha=0.4)+
        geom_abline(slope=1, color="red") +
        ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))
      
      ggplot(df_normalized_VP, aes(FoldChange_KO666wt))+
        geom_density(size=1, fill="grey")+
        ggtitle("FoldChange_KO666wt") +
        xlab("mean(KO666) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KO666wt))+
        geom_point()+
        ggtitle("FoldChange_KO666wt") +
        xlab("mean(KO666) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666wt, y=-log10(pValue_KO666wt)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666wt <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt <= 0.01 & FoldChange_KO666wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP, 
                                       pValue_KO666wt <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt <= 0.01 & FoldChange_KO666wt <= -1), 
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. wt") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666wt, y=-log10(pValue_KO666wt_B)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666wt_B <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt_B <= 0.01 & FoldChange_KO666wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO666wt_B <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt_B <= 0.01 & FoldChange_KO666wt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. wt (bonferroni corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666wt, y=-log10(pValue_KO666wt_BH)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666wt_BH <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt_BH <= 0.01 & FoldChange_KO666wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO666wt_BH <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt_BH <= 0.01 & FoldChange_KO666wt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. wt (Benjamini-Hochberg corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(wt)")
      
      # ko668-wt #
      cor_jnk <- cor(x=df_normalized_VP$Mean_wt, y=df_normalized_VP$Mean_ko668, use = "pairwise.complete.obs")
      ggplot(df_normalized_VP, aes(x=Mean_wt, y=Mean_ko668))+
        geom_point(alpha=0.4)+
        geom_abline(slope=1, color="red") +
        ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))
      
      ggplot(df_normalized_VP, aes(FoldChange_KO668wt))+
        geom_density(size=1, fill="grey")+
        ggtitle("FoldChange_KO668wt") +
        xlab("mean(KO668) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KO668wt))+
        geom_point()+
        ggtitle("FoldChange_KO668wt") +
        xlab("mean(KO668) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO668wt, y=-log10(pValue_KO668wt)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO668wt <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt <= 0.01 & FoldChange_KO668wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP, 
                                       pValue_KO668wt <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt <= 0.01 & FoldChange_KO668wt <= -1), 
                         aes(label=GeneNames)) +
        ggtitle("KO668 vs. wt") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO668) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO668wt, y=-log10(pValue_KO668wt_B)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO668wt_B <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt_B <= 0.01 & FoldChange_KO668wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO668wt_B <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt_B <= 0.01 & FoldChange_KO668wt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO668 vs. wt (bonferroni corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO668) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO668wt, y=-log10(pValue_KO668wt_BH)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO668wt_BH <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt_BH <= 0.01 & FoldChange_KO668wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO668wt_BH <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt_BH <= 0.01 & FoldChange_KO668wt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO668 vs. wt (Benjamini-Hochberg corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO668) - mean(wt)")
      
      # ko666-ko668 #
      cor_jnk <- cor(x=df_normalized_VP$Mean_ko666, y=df_normalized_VP$Mean_ko668, use = "pairwise.complete.obs")
      ggplot(df_normalized_VP, aes(x=Mean_ko666, y=Mean_ko668))+
        geom_point(alpha=0.4)+
        geom_abline(slope=1, color="red") +
        ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))
      
      ggplot(df_normalized_VP, aes(FoldChange_KO666KO668))+
        geom_density(size=1, fill="grey")+
        ggtitle("FoldChange_KO666KO668") +
        xlab("mean(KO666) - mean(KO668)")
      
      ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KO666KO668))+
        geom_point()+
        ggtitle("FoldChange_KO666KO668") +
        xlab("mean(KO666) - mean(KO668)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666KO668, y=-log10(pValue_KO666KO668)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666KO668 <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668 <= 0.01 & FoldChange_KO666KO668 <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP, 
                                       pValue_KO666KO668 <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668 <= 0.01 & FoldChange_KO666KO668 <= -1), 
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. KO668") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(KO668)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666KO668, y=-log10(pValue_KO666KO668_B)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666KO668_B <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668_B <= 0.01 & FoldChange_KO666KO668 <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO666KO668_B <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668_B <= 0.01 & FoldChange_KO666KO668 <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. KO668 (bonferroni corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(KO668)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666KO668, y=-log10(pValue_KO666KO668_BH)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666KO668_BH <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668_BH <= 0.01 & FoldChange_KO666KO668 <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO666KO668_BH <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668_BH <= 0.01 & FoldChange_KO666KO668 <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. KO668 (Benjamini-Hochberg corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(KO668)")
      
      dev.off()
      ###################################################################
      # 12.2 # at the gene level ########################################
      # 12.2.1 # descriptive variables ###########################
      allCols <- 1:numberOfStrains
      wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
      koCols <- setdiff(allCols, wtCols)
      
      df_normalized$Kurtosis_ko <- apply(df_normalized[,koCols], 1, kurtosis, na.rm=T)
      df_normalized$Kurtosis_wt <- apply(df_normalized[,col_WTbio], 1, kurtosis, na.rm=T)
      df_normalized$Skewness_ko <- apply(df_normalized[,koCols], 1, skewness, na.rm=T)
      df_normalized$Skewness_wt <- apply(df_normalized[,col_WTbio], 1, skewness, na.rm=T)
      df_normalized$Min_ko <- apply(df_normalized[,koCols], 1, min, na.rm=T)
      df_normalized$Min_wt <- apply(df_normalized[,col_WTbio], 1, min, na.rm=T)
      df_normalized$Mean_ko <- apply(df_normalized[,koCols], 1, mean, na.rm=T)
      df_normalized$Mean_wt <- apply(df_normalized[,col_WTbio], 1, mean, na.rm=T)
      df_normalized$Max_ko <- apply(df_normalized[,koCols], 1, max, na.rm=T)
      df_normalized$Max_wt <- apply(df_normalized[,col_WTbio], 1, max, na.rm=T)
      df_normalized$Sd_ko <- apply(df_normalized[,koCols], 1, sd, na.rm=T)
      df_normalized$Sd_wt <- apply(df_normalized[,col_WTbio], 1, sd, na.rm=T)
      df_normalized$Var_ko <- apply(df_normalized[,koCols], 1, var, na.rm=T)
      df_normalized$Var_wt <- apply(df_normalized[,col_WTbio], 1, var, na.rm=T)
      
      df_normalized$MeaNwt3sd_up <- df_normalized$Mean_wt + (3*df_normalized$Sd_wt)
      df_normalized$MeaNwt3sd_down <- df_normalized$Mean_wt - (3*df_normalized$Sd_wt)
      df_normalized$wt99_up <- apply(df_normalized[,col_WTbio], 1, function(x) quantile(x, 0.99, na.rm=T))
      df_normalized$wt99_down <- apply(df_normalized[,col_WTbio], 1, function(x) quantile(x, 0.01, na.rm=T))
      
      
      variables2plot <- names(df_normalized)[(numberOfStrains+1):dim(df_normalized)[2]]
      variables2plot <- unique(gsub("(.*)\\_.*", "\\1",variables2plot))
      
      pdf(file.path(subDir2, "12_2_1_DescriptiveVariablePlots.pdf"))
      for(vari in variables2plot){
        cols2plot <- grep(vari, names(df_normalized))
        df_jnk <- df_normalized[,cols2plot]
        
        p<-ggplot(df_jnk, aes(x=df_jnk[,1], y=df_jnk[,2])) +
          geom_point() +
          geom_smooth(color="blue") +
          geom_abline(slope=1, intercept = 0, color="darkred", size=1)+
          xlab(colnames(df_jnk)[1]) +
          ylab(colnames(df_jnk)[2]) +
          ggtitle(paste0("cor= ", round(cor(df_jnk[,1],df_jnk[,2], use="pairwise.complete.obs", method="pearson"),2)))+
          theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
                axis.text=element_text(size=14),
                axis.title=element_text(size=14,face="bold"),
                strip.text = element_text(size = 14, face="bold")) +
          scale_fill_discrete(guide = 'none')
        print(p)
        
        
        df_jnk$Protein.IDs <- rownames(df_jnk)
        names(df_jnk) <- gsub(paste0(vari, "_"), "", names(df_jnk))
        df_jnk_melt <- melt(df_jnk, id="Protein.IDs")
        
        p<-ggplot(df_jnk_melt, aes(x=value, fill=variable)) +
          geom_density() +
          facet_grid(variable ~ .) +
          xlab(vari) +
          theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
                axis.text=element_text(size=14),
                axis.title=element_text(size=14,face="bold"),
                strip.text = element_text(size = 14, face="bold")) +
          scale_fill_discrete(guide = 'none')
        
        print(p)
      }
      dev.off()
      rm(df_jnk)
      rm(df_jnk_melt)
      rm(vari)
      rm(variables2plot)
      # 12.2.2 # each protein with the limits #############################
      cols2keep <- grep("wt", names(df_normalized))[c(3,5,8,9,10,11)]
      
      df_normalized2 <- df_normalized[, c(1:numberOfStrains, cols2keep)]
      allCols <- 1:numberOfStrains
      wtCols <- col_WTbio 
      koCols <- setdiff(allCols, wtCols)
      
      pdf(file.path(subDir2, "12_2_2_EachProteinWithLimits.pdf"))
      for(i in 1:dim(df_normalized2)[1]){
        df_jnk <- df_normalized2[i,]
        
        protein2plot <- rownames(df_jnk)
        
        df_jnk$Protein.IDs <- rownames(df_jnk)
        df_jnk_melt <- as.data.frame(melt(df_jnk, id="Protein.IDs"), drop=TRUE)
        
        df_jnk_melt$category <- NA
        df_jnk_melt$category[wtCols] <- "wt"
        df_jnk_melt$category[koCols] <- "ko"
        
        jnk <- df_jnk_melt[is.na(df_jnk_melt$category),2:3]
        df_jnk_melt <- df_jnk_melt[!is.na(df_jnk_melt$category),]
        
        p<-ggplot(df_jnk_melt, aes(x=value, fill=category)) +
          geom_density() +
          facet_grid(category ~ .) +
          xlab("Distribution of ratios") +
          ggtitle(protein2plot) +
          theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
                axis.text=element_text(size=14),
                axis.title=element_text(size=14,face="bold"),
                strip.text = element_text(size = 14, face="bold"),
                panel.border = element_blank()) +
          scale_fill_discrete(guide = 'none') +
          geom_vline(data=jnk, aes(xintercept = value, colour=variable), size=0.2)+
          scale_color_manual(values=c("#fd8d3c", "#762a83", "#fd8d3c", "#41ab5d", "#41ab5d", "#2166ac", "#2166ac",
                                      "#cb181d", "#cb181d"))
        
        print(p)
      }
      dev.off()
      rm(df_jnk)
      rm(df_jnk_melt)
      rm(p)
      rm(df_normalized2)
      rm(jnk)
      #################################################################
      # 12.2.3 # make box plots based on number of proteins changing in wt or ###################
      # k/o strains based on the criteria to be picked ##
      # based on min-max wt #
      colMin <- grep("Min_wt", names(df_normalized))
      colMax <- grep("Max_wt", names(df_normalized))
      df_upDown_minMax <- calculateDFupDown(df_normalized, colMin, colMax, numberOfStrains)
      
      # based on mean wt +/* 3sd #
      colMin <- grep("MeaNwt3sd_down", names(df_normalized))
      colMax <- grep("MeaNwt3sd_up", names(df_normalized))
      df_upDown_sd3 <- calculateDFupDown(df_normalized, colMin, colMax, numberOfStrains)
      
      # based on wt 99% limits #
      colMin <- grep("wt99_down", names(df_normalized))
      colMax <- grep("wt99_up", names(df_normalized))
      df_upDown_wt99 <- calculateDFupDown(df_normalized, colMin, colMax, numberOfStrains)
      
      rm(colMin)
      rm(colMax)
      # create a data frame to put the data together ##
      minMax_up <- calculateUpDownNumberOfGenes(df_upDown_minMax, 1)
      names(minMax_up)[1] <- "minMax_up"
      minMax_down <- calculateUpDownNumberOfGenes(df_upDown_minMax, -1)
      names(minMax_down)[1] <- "minMax_down"
      minMax <- merge(minMax_up, minMax_down, by=2)
      minMax$minMax_changing <- minMax$minMax_up + minMax$minMax_down
      rm(df_upDown_minMax)
      
      minMax_up <- calculateUpDownNumberOfGenes(df_upDown_sd3, 1)
      names(minMax_up)[1] <- "sd3_up"
      minMax_down <- calculateUpDownNumberOfGenes(df_upDown_sd3, -1)
      names(minMax_down)[1] <- "sd3_down"
      sd3 <- merge(minMax_up, minMax_down, by=2)
      sd3$sd3_changing <- sd3$sd3_up + sd3$sd3_down
      rm(df_upDown_sd3)
      
      minMax_up <- calculateUpDownNumberOfGenes(df_upDown_wt99, 1)
      names(minMax_up)[1] <- "wt99_up"
      minMax_down <- calculateUpDownNumberOfGenes(df_upDown_wt99, -1)
      names(minMax_down)[1] <- "wt99_down"
      wt99 <- merge(minMax_up, minMax_down, by=2)
      wt99$wt99_changing <- wt99$wt99_up + wt99$wt99_down
      rm(df_upDown_wt99)
      
      rm(minMax_down)
      rm(minMax_up)
      
      # putting tables together  for making the boxplots #
      Changingtable <- merge(minMax, sd3, by=1, all=FALSE)
      Changingtable <- merge(Changingtable, wt99, by=1, all=FALSE)
      
      Changingtable$StrainType <- NA
      allROWs <- 1:numberOfStrains
      wtROWs <- grep("Sp[0-9]*WT\\_Bio[0-9]*", Changingtable$Strain)
      koROWs <- setdiff(allROWs, wtROWs)
      
      Changingtable$StrainType[koROWs] <- "ko"
      Changingtable$StrainType[wtROWs] <- "wt"
      rm(minMax)
      rm(sd3)
      rm(wt99)
      
      
      #making a boxplot #
      Changingtable_melt <- as.data.frame(melt(Changingtable, id=c("Strain", "StrainType")))
      Changingtable_melt$Correspondance <- paste(Changingtable_melt$variable, Changingtable_melt$StrainType, sep = "_")
      Changingtable_melt$faceting <- gsub(".*\\_", "",Changingtable_melt$variable)
      Changingtable_melt$Criteria <- gsub("\\_.*", "",Changingtable_melt$variable)
      
      anno_df = compare_means(value ~ Correspondance, group.by = "faceting", data = Changingtable_melt)
      anno_df <- anno_df[c(1,10,15,16,25,30,31,40,45),]
      pdf(file.path(subDir2, "12_2_3_BoxPlotsWithDifferentCriteria.pdf"))
      p<-ggplot(Changingtable_melt, aes(x=Correspondance, y=value)) +
        geom_boxplot(aes(color=Criteria, fill=StrainType)) +
        facet_grid(. ~ faceting, scales="free") +
        ggtitle("Number of proteins regulated all wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank(),
              axis.title.x=element_blank(),
              axis.text.x=element_blank(),
              axis.ticks.x=element_blank())+
        scale_fill_manual(values=c("#000000", "#999999")) +
        ggsignif::geom_signif(data=anno_df,aes(xmin=group1, xmax=group2, 
                                               annotations=p.signif, y_position=1300), manual=TRUE)
      
      print(p)
      dev.off()
      koLibrary <- read.delim("old/7_3_ReporterIntensityDecode_merged_SupTable1.txt")
      koLibrary <- subset(koLibrary, Analyzed_ReMeasured == "ToBeAnalyzed")
      # 12.3.4 # save changing table #####################################################
      Changingtable2 <- merge(koLibrary, Changingtable, by.y="Strain", by.x = "Position_MS_Plate", all.y = T)
      write.table(Changingtable2, file.path(subDir2, "12_3_4_ChangingTable_differentCriteria_upDown.txt"),
                  quote = F, row.names = F, sep="\t")
      
      rm(Changingtable)
      rm(Changingtable_melt)
      rm(p)
      rm(anno_df)
      # 12.3.5 # variation #############################################
      df_normalized <- df_normalized[,1:numberOfStrains]
      
      Mean_wt <- as.data.frame(apply(df_normalized[,col_WTbio], 1, mean, na.rm=T))
      df_normalized_variance <- getDFvsColVariation(df_normalized, Mean_wt) 
      
      pdf(file.path(subDir2, "12_3_5_Plots4Variance_SD.pdf"))
      varStrains <- as.data.frame(colMeans(df_normalized_variance, na.rm=T))
      
      names(varStrains) <- "MeanVariance"
      varStrains$MeanVariance <- as.numeric(varStrains$MeanVariance)
      varStrains$MeanStandardDeviation <- sqrt(varStrains$MeanVariance)
      varStrains$Strain <- rownames(varStrains)
      
      varStrains$StrainType <- NA
      
      allROWs <- 1:numberOfStrains
      wtROWs <- grep("Sp[0-9]*WT\\_Bio[0-9]*", varStrains$Strain)
      koROWs <- setdiff(allROWs, wtROWs)
      
      varStrains$StrainType[koROWs] <- "ko"
      varStrains$StrainType[wtROWs] <- "wt"
      
      p<-ggplot(varStrains, aes(x=StrainType, y=MeanVariance)) +
        geom_boxplot(aes(fill=StrainType)) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        #  stat_compare_means(paired = F, size=8, label.x = 0.7, label.y = 1) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(x=StrainType, y=MeanVariance)) +
        geom_violin(aes(fill=StrainType)) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(MeanVariance)) +
        geom_density(aes(fill=StrainType, color=StrainType), alpha=0.5) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      
      p<-ggplot(varStrains, aes(x=StrainType, y=MeanStandardDeviation)) +
        geom_boxplot(aes(fill=StrainType)) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        #  stat_compare_means(paired = F, size=8, label.x = 0.7, label.y = 1) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(x=StrainType, y=MeanStandardDeviation)) +
        geom_violin(aes(fill=StrainType)) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(MeanStandardDeviation)) +
        geom_density(aes(fill=StrainType, color=StrainType), alpha=0.5) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      ####
      varStrains <- as.data.frame(colSums(df_normalized_variance, na.rm=T))
      
      names(varStrains) <- "SUMVariance"
      varStrains$SUMVariance <- as.numeric(varStrains$SUMVariance)
      varStrains$SUMStandardDeviation <- sqrt(varStrains$SUMVariance)
      varStrains$Strain <- rownames(varStrains)
      
      varStrains$StrainType <- NA
      
      allROWs <- 1:numberOfStrains
      wtROWs <- grep("Sp[0-9]*WT\\_Bio[0-9]*", varStrains$Strain)
      koROWs <- setdiff(allROWs, wtROWs)
      
      varStrains$StrainType[koROWs] <- "ko"
      varStrains$StrainType[wtROWs] <- "wt"
      
      p<-ggplot(varStrains, aes(x=StrainType, y=SUMVariance)) +
        geom_boxplot(aes(fill=StrainType)) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        #  stat_compare_means(paired = F, size=8, label.x = 0.7, label.y = 1) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(x=StrainType, y=SUMVariance)) +
        geom_violin(aes(fill=StrainType)) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(SUMVariance)) +
        geom_density(aes(fill=StrainType, color=StrainType), alpha=0.5) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      
      p<-ggplot(varStrains, aes(x=StrainType, y=SUMStandardDeviation)) +
        geom_boxplot(aes(fill=StrainType)) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        #  stat_compare_means(paired = F, size=8, label.x = 0.7, label.y = 1) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(x=StrainType, y=SUMStandardDeviation)) +
        geom_violin(aes(fill=StrainType)) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(SUMStandardDeviation)) +
        geom_density(aes(fill=StrainType, color=StrainType), alpha=0.5) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      dev.off()
      rm(df_normalized_variance)
      rm(p)
      rm(Mean_wt)
      
      varStrains <- merge(koLibrary, varStrains, by.y="Strain", by.x = "Position_MS_Plate", all.y = T)
      write.table(varStrains, file.path(subDir2, "12_3_5_MeanVariationOfStrains.txt"), 
                  sep = "\t", quote = FALSE)
      ####################################################################################
      # 12.3.6 # table for stains with variation and number of genes changing ############
      varStrains <- varStrains[,c(1,23,24)]
      Changingtable2 <- read.delim(file.path(subDir2, "12_3_4_ChangingTable_differentCriteria_upDown.txt"))
      Changingtable3 <- merge(Changingtable2, varStrains, by.x = "Position_MS_Plate", 
                              by.y = "Position_MS_Plate", all = T)
      rm(Changingtable2)
      rm(koLibrary)
      rm(varStrains)
      write.table(Changingtable3, file.path(subDir2, "12_3_6_ChangingTable_Variation.txt"), 
                  sep = "\t", quote = FALSE)
      ####################################################################################
      # 12.3.7 # correlation of k/o strains to wt strains as a measure of being different ####
      # correlation distribution between wt meaurements
      allCols <- 1:dim(df_normalized)[2]
      wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
      koCols <- setdiff(allCols, wtCols)
      
      df_normalized_wt <- df_normalized[wtCols]
      
      df_normalized_wt_cor <- as.data.frame(cor(df_normalized_wt, use="pairwise.complete.obs", method="pearson")) 
      df_normalized_wt_cor$WT <- rownames(df_normalized_wt_cor)
      df_normalized_wt_cor_m <- melt(df_normalized_wt_cor, id="WT") 
      
      colnames(df_normalized_wt_cor_m) <- c("WT1", "WT2", "PearsonPaired")
      mean_wt_cor <- mean(df_normalized_wt_cor_m$PearsonPaired)
      sd_wt_cor <- sd(df_normalized_wt_cor_m$PearsonPaired)
      
      # correlation distribution between wt meaurements and ko strains
      df_normalized_cor <- as.data.frame(cor(df_normalized, use="pairwise.complete.obs", method="pearson"))
      df_normalized_cor$Strain1 <- rownames(df_normalized_cor)
      wtRows <- grep("WT_Bio", df_normalized_cor$Strain1)
      df_normalized_cor_wtRows <- df_normalized_cor[wtRows,]
      
      df_normalized_cor_wtRows <- df_normalized_cor_wtRows[,-dim(df_normalized_cor_wtRows)[2]]
      allCols <- 1:dim(df_normalized_cor_wtRows)[2]
      wtCols <- grep("WT_Bio", names(df_normalized_cor_wtRows))
      koCols <- setdiff(allCols, wtCols)
      
      df_cor_VP <- data.frame(Strains=c("WTs", names(df_normalized_cor_wtRows)[koCols]))
      df_cor_VP$MeanCor <- NA
      df_cor_VP$FCCor <- NA
      df_cor_VP$PvalCor <- NA
      
      wtMeanCor <- mean(as.numeric(as.matrix(df_normalized_cor_wtRows[,wtCols])))
      df_cor_VP$MeanCor[1] <- wtMeanCor
      for (i in 2:dim(df_cor_VP)[1]) {
        print(i)
        gene <- df_cor_VP$Strains[i]
        colGene <- grep(gene, names(df_normalized_cor_wtRows))
        
        df_cor_VP$MeanCor[i] <- mean(df_normalized_cor_wtRows[,colGene])
        df_cor_VP$PvalCor[i] <- my.t.test.p.value(as.numeric(as.matrix(df_normalized_cor_wtRows[,wtCols])),
                                                  as.numeric(df_normalized_cor_wtRows[,colGene]))
      }
      df_cor_VP$PvalCor[1] <- 1
      
      df_cor_VP$FCCor <- df_cor_VP$MeanCor - wtMeanCor
      
      wt_cors <- df_normalized_cor_wtRows[,wtCols]
      wt_cors <- melt(wt_cors)
      
      
      
      p1 <- ggplot(wt_cors, aes(value))+
        geom_histogram(bins=100) +
        geom_vline(xintercept = mean(wt_cors$value), color="red")+
        ggtitle("Distribution of corerlation btw. WTs")
      
      
      p2 <- ggplot(df_cor_VP, aes(x=MeanCor, y=-log10(PvalCor)))+
        geom_point()+
        geom_point(data = subset(df_cor_VP, Strains=="WTs"), color="red") +
        xlab("Mean(correlation)") +
        ggtitle("VP4: correlation of ko strains to all wt")
      
      p3 <- ggplot(df_cor_VP, aes(x=FCCor, y=-log10(PvalCor)))+
        geom_point()+
        geom_point(data = subset(df_cor_VP, Strains=="WTs"), color="red") +
        xlab("FC(correlation)") +
        ggtitle("VP4: correlation of ko strains to all wt")
      
      pdf(file.path(subDir2, "12_3_7_Correlation2Wt.pdf"))
      print(p1)
      print(p2)
      print(p3)
      dev.off()
      
      write.table(df_cor_VP, file.path(subDir2, "12_3_7_koStrainsCorrelation2Wt.txt"), 
                  sep = "\t", quote = FALSE)
      # 12.3.8 # corralate and compare up/down/sd/var ####################################
      Changingtable3 <- read.delim(file.path(subDir2, "12_3_6_ChangingTable_Variation.txt"))
      df_cor_VP <- read.delim(file.path(subDir2, "12_3_7_koStrainsCorrelation2Wt.txt"))
      df_cor_VP <- df_cor_VP[,-4]
      df_cor_VP$MeanCor <- 100*df_cor_VP$MeanCor
      df_cor_VP$FCCor <- 100*df_cor_VP$FCCor
      
      df_pcor <- merge(Changingtable3, df_cor_VP, by.x="Position_MS_Plate", by.y="Strains", all=FALSE)
      df_pcor <- df_pcor[, 23:35]
      df_pcor <- df_pcor[,-10]
      names(df_pcor)[12] <- "MeanCor2wt"
      DF_cor<- cor(df_pcor, use="pairwise.complete.obs", method="pearson")
      
      pdf(file.path(subDir2, "12_3_8_Correlation_RegulatedGenes_VarianceSD_correlation2wt.pdf"))
      corrplot(DF_cor, type = "upper", order = "hclust", 
               tl.col = "black", tl.srt = 45, title="cor")
      dev.off()
      rm(DF_cor)
      rm(df_pcor)
      #################################################################################################
    }
    #######################################################################################################
    if(checkNORMALIZED_DF){
      # 12 # Global analysis #####################################################
      subDir2 <- paste0(subDir, "/20181022_12_NOTFilteredDF")
      dir.create(file.path(getwd(), subDir2), showWarnings = FALSE)
      # 12.1 # k/o strains DIFFERENT background vs wild type #####################
      df_normalized <- as.data.frame(readRDS(file.path(subDir, "8_2_FILTERED4Power_25.rds")))
      df_normalized[df_normalized==0] <- NA
      
      proteinsIdentified <- dim(df_normalized)[1]
      numberOfStrains <- dim(df_normalized)[2]
      col_WTbio <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
      df_normalized <- df_normalized[,1:numberOfStrains]
      
      koLibrary <- read.delim("old/7_3_ReporterIntensityDecode_merged_SupTable1.txt")
      koLibrary <- subset(koLibrary, Analyzed_ReMeasured == "ToBeAnalyzed")
      koLibrary_jnk <- koLibrary[,c(5,19)]
      
      df_normalized_VP <- as.data.frame(t(df_normalized))
      df_normalized_VP$Strains <- rownames(df_normalized_VP)
      df_normalized_VP <- merge(df_normalized_VP, koLibrary_jnk, by.x = "Strains", by.y = "Position_MS_Plate", all.x = TRUE)
      df_normalized_VP$Wild.type[is.na(df_normalized_VP$Wild.type)] <- "wt"
      df_normalized_VP$Identifier <- paste(df_normalized_VP$Strains, df_normalized_VP$Wild.type, sep=";")
      rownames(df_normalized_VP) <- df_normalized_VP$Identifier
      df_normalized_VP <- df_normalized_VP[,-c(1,(dim(df_normalized_VP)[2]-1), dim(df_normalized_VP)[2])]
      df_normalized_VP <- as.data.frame(t(df_normalized_VP))
      rm(koLibrary_jnk)
      
      allCols <- 1:numberOfStrains
      wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized_VP))
      koCols <- setdiff(allCols, wtCols) 
      koCols_ED666 <- grep("ED666", colnames(df_normalized_VP))
      koCols_ED668 <- grep("ED668", colnames(df_normalized_VP))
      
      # calculate the means of the groups and the fold change #
      df_normalized_VP$Mean_wt <- apply(df_normalized_VP[,wtCols], 1, mean, na.rm=T)
      df_normalized_VP$Mean_ko <- apply(df_normalized_VP[,koCols], 1, mean, na.rm=T)
      df_normalized_VP$Mean_ko666 <- apply(df_normalized_VP[,koCols_ED666], 1, mean, na.rm=T)
      df_normalized_VP$Mean_ko668 <- apply(df_normalized_VP[,koCols_ED668], 1, mean, na.rm=T)
      
      df_normalized_VP$FoldChange_KOwt <- df_normalized_VP$Mean_ko - df_normalized_VP$Mean_wt
      df_normalized_VP$FoldChange_KO666wt <- df_normalized_VP$Mean_ko666 - df_normalized_VP$Mean_wt
      df_normalized_VP$FoldChange_KO668wt <- df_normalized_VP$Mean_ko668 - df_normalized_VP$Mean_wt
      df_normalized_VP$FoldChange_KO666KO668 <- df_normalized_VP$Mean_ko666 - df_normalized_VP$Mean_ko668
      
      
      # calculate the p values #
      df_normalized_VP$pValue_KOwt <- NA
      df_normalized_VP$pValue_KO666wt <- NA
      df_normalized_VP$pValue_KO668wt <- NA
      df_normalized_VP$pValue_KO666KO668 <- NA
      
      my.t.test.p.value <- function(x,y) {
        obj<-try(t.test(x,y), silent=TRUE)
        if (is(obj, "try-error")) return(NA) else return(obj$p.value)
      }
      
      for (i in 1:dim(df_normalized_VP)[1]) {
        print(i)
        df_normalized_VP$pValue_KOwt[i] <- my.t.test.p.value(df_normalized_VP[i,koCols], df_normalized_VP[i,wtCols])
        df_normalized_VP$pValue_KO666wt[i] <- my.t.test.p.value(df_normalized_VP[i,koCols_ED666], df_normalized_VP[i,wtCols])
        df_normalized_VP$pValue_KO668wt[i] <- my.t.test.p.value(df_normalized_VP[i,koCols_ED668], df_normalized_VP[i,wtCols])
        df_normalized_VP$pValue_KO666KO668[i] <- my.t.test.p.value(df_normalized_VP[i,koCols_ED666], df_normalized_VP[i,koCols_ED668])
      }
      
      # correct the p values #
      df_normalized_VP$pValue_KOwt_B <- p.adjust(df_normalized_VP$pValue_KOwt, method = "bonferroni",
                                                 n = length(df_normalized_VP$pValue_KOwt))
      df_normalized_VP$pValue_KO666wt_B <- p.adjust(df_normalized_VP$pValue_KO666wt, method = "bonferroni",
                                                    n = length(df_normalized_VP$pValue_KO666wt))
      df_normalized_VP$pValue_KO668wt_B <- p.adjust(df_normalized_VP$pValue_KO668wt, method = "bonferroni",
                                                    n = length(df_normalized_VP$pValue_KO668wt))
      df_normalized_VP$pValue_KO666KO668_B <- p.adjust(df_normalized_VP$pValue_KO666KO668, method = "bonferroni",
                                                       n = length(df_normalized_VP$pValue_KO666KO668))
      
      df_normalized_VP$pValue_KOwt_BH <- p.adjust(df_normalized_VP$pValue_KOwt, method = "BH",
                                                  n = length(df_normalized_VP$pValue_KOwt))
      df_normalized_VP$pValue_KO666wt_BH <- p.adjust(df_normalized_VP$pValue_KO666wt, method = "BH",
                                                     n = length(df_normalized_VP$pValue_KO666wt))
      df_normalized_VP$pValue_KO668wt_BH <- p.adjust(df_normalized_VP$pValue_KO668wt, method = "BH",
                                                     n = length(df_normalized_VP$pValue_KO668wt))
      df_normalized_VP$pValue_KO666KO668_BH <- p.adjust(df_normalized_VP$pValue_KO666KO668, method = "BH",
                                                        n = length(df_normalized_VP$pValue_KO666KO668))
      
      # volcano plot with corrected p values and fold changes #
      df_normalized_VP$GeneNames <- rownames(df_normalized_VP)
      
      pdf(file.path(subDir2, "12_1_volcanoPlot_wtKO_differentWT666_668.pdf"))
      
      # ko-wt #
      cor_jnk <- cor(x=df_normalized_VP$Mean_wt, y=df_normalized_VP$Mean_ko, use = "pairwise.complete.obs")
      ggplot(df_normalized_VP, aes(x=Mean_wt, y=Mean_ko))+
        geom_point(alpha=0.4)+
        geom_abline(slope=1, color="red") +
        ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))
      
      ggplot(df_normalized_VP, aes(FoldChange_KOwt))+
        geom_density(size=1, fill="grey")+
        ggtitle("FoldChange_KOwt") +
        xlab("mean(KO) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KOwt))+
        geom_point()+
        ggtitle("FoldChange_KOwt") +
        xlab("mean(KO) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KOwt <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt <= 0.01 & FoldChange_KOwt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP, 
                                       pValue_KOwt <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt <= 0.01 & FoldChange_KOwt <= -1), 
                         aes(label=GeneNames)) +
        ggtitle("all KO's vs. wt") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt_B)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KOwt_B <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt_B <= 0.01 & FoldChange_KOwt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KOwt_B <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt_B <= 0.01 & FoldChange_KOwt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("all KO's vs. wt (bonferroni corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt_BH)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KOwt_BH <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt_BH <= 0.01 & FoldChange_KOwt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KOwt_BH <= 0.01 & FoldChange_KOwt >= 1 | pValue_KOwt_BH <= 0.01 & FoldChange_KOwt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("all KO's vs. wt (Benjamini-Hochberg corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO) - mean(wt)")
      
      
      
      # ko666-wt #
      cor_jnk <- cor(x=df_normalized_VP$Mean_wt, y=df_normalized_VP$Mean_ko666, use = "pairwise.complete.obs")
      ggplot(df_normalized_VP, aes(x=Mean_wt, y=Mean_ko666))+
        geom_point(alpha=0.4)+
        geom_abline(slope=1, color="red") +
        ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))
      
      ggplot(df_normalized_VP, aes(FoldChange_KO666wt))+
        geom_density(size=1, fill="grey")+
        ggtitle("FoldChange_KO666wt") +
        xlab("mean(KO666) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KO666wt))+
        geom_point()+
        ggtitle("FoldChange_KO666wt") +
        xlab("mean(KO666) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666wt, y=-log10(pValue_KO666wt)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666wt <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt <= 0.01 & FoldChange_KO666wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP, 
                                       pValue_KO666wt <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt <= 0.01 & FoldChange_KO666wt <= -1), 
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. wt") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666wt, y=-log10(pValue_KO666wt_B)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666wt_B <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt_B <= 0.01 & FoldChange_KO666wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO666wt_B <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt_B <= 0.01 & FoldChange_KO666wt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. wt (bonferroni corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666wt, y=-log10(pValue_KO666wt_BH)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666wt_BH <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt_BH <= 0.01 & FoldChange_KO666wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO666wt_BH <= 0.01 & FoldChange_KO666wt >= 1 | pValue_KO666wt_BH <= 0.01 & FoldChange_KO666wt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. wt (Benjamini-Hochberg corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(wt)")
      
      # ko668-wt #
      cor_jnk <- cor(x=df_normalized_VP$Mean_wt, y=df_normalized_VP$Mean_ko668, use = "pairwise.complete.obs")
      ggplot(df_normalized_VP, aes(x=Mean_wt, y=Mean_ko668))+
        geom_point(alpha=0.4)+
        geom_abline(slope=1, color="red") +
        ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))
      
      ggplot(df_normalized_VP, aes(FoldChange_KO668wt))+
        geom_density(size=1, fill="grey")+
        ggtitle("FoldChange_KO668wt") +
        xlab("mean(KO668) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KO668wt))+
        geom_point()+
        ggtitle("FoldChange_KO668wt") +
        xlab("mean(KO668) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO668wt, y=-log10(pValue_KO668wt)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO668wt <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt <= 0.01 & FoldChange_KO668wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP, 
                                       pValue_KO668wt <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt <= 0.01 & FoldChange_KO668wt <= -1), 
                         aes(label=GeneNames)) +
        ggtitle("KO668 vs. wt") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO668) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO668wt, y=-log10(pValue_KO668wt_B)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO668wt_B <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt_B <= 0.01 & FoldChange_KO668wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO668wt_B <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt_B <= 0.01 & FoldChange_KO668wt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO668 vs. wt (bonferroni corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO668) - mean(wt)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO668wt, y=-log10(pValue_KO668wt_BH)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO668wt_BH <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt_BH <= 0.01 & FoldChange_KO668wt <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO668wt_BH <= 0.01 & FoldChange_KO668wt >= 1 | pValue_KO668wt_BH <= 0.01 & FoldChange_KO668wt <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO668 vs. wt (Benjamini-Hochberg corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO668) - mean(wt)")
      
      # ko666-ko668 #
      cor_jnk <- cor(x=df_normalized_VP$Mean_ko666, y=df_normalized_VP$Mean_ko668, use = "pairwise.complete.obs")
      ggplot(df_normalized_VP, aes(x=Mean_ko666, y=Mean_ko668))+
        geom_point(alpha=0.4)+
        geom_abline(slope=1, color="red") +
        ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))
      
      ggplot(df_normalized_VP, aes(FoldChange_KO666KO668))+
        geom_density(size=1, fill="grey")+
        ggtitle("FoldChange_KO666KO668") +
        xlab("mean(KO666) - mean(KO668)")
      
      ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KO666KO668))+
        geom_point()+
        ggtitle("FoldChange_KO666KO668") +
        xlab("mean(KO666) - mean(KO668)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666KO668, y=-log10(pValue_KO666KO668)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666KO668 <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668 <= 0.01 & FoldChange_KO666KO668 <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP, 
                                       pValue_KO666KO668 <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668 <= 0.01 & FoldChange_KO666KO668 <= -1), 
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. KO668") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(KO668)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666KO668, y=-log10(pValue_KO666KO668_B)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666KO668_B <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668_B <= 0.01 & FoldChange_KO666KO668 <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO666KO668_B <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668_B <= 0.01 & FoldChange_KO666KO668 <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. KO668 (bonferroni corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(KO668)")
      
      ggplot(df_normalized_VP, aes(x=FoldChange_KO666KO668, y=-log10(pValue_KO666KO668_BH)))+
        geom_point()+
        geom_point(data = subset(df_normalized_VP, 
                                 pValue_KO666KO668_BH <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668_BH <= 0.01 & FoldChange_KO666KO668 <= -1), 
                   color="red") +
        geom_label_repel(data = subset(df_normalized_VP,
                                       pValue_KO666KO668_BH <= 0.01 & FoldChange_KO666KO668 >= 1 | pValue_KO666KO668_BH <= 0.01 & FoldChange_KO666KO668 <= -1),
                         aes(label=GeneNames)) +
        ggtitle("KO666 vs. KO668 (Benjamini-Hochberg corrected)") +
        geom_vline(xintercept = 1, color="red", alpha=0.3) +
        geom_vline(xintercept = -1, color="red", alpha=0.3) +
        geom_hline(yintercept = 2, color="red", alpha=0.3) +
        xlab("mean(KO666) - mean(KO668)")
      
      dev.off()
      ###################################################################
      # 12.2 # at the gene level ########################################
      # 12.2.1 # descriptive variables ###########################
      allCols <- 1:numberOfStrains
      wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
      koCols <- setdiff(allCols, wtCols)
      
      df_normalized$Kurtosis_ko <- apply(df_normalized[,koCols], 1, kurtosis, na.rm=T)
      df_normalized$Kurtosis_wt <- apply(df_normalized[,col_WTbio], 1, kurtosis, na.rm=T)
      df_normalized$Skewness_ko <- apply(df_normalized[,koCols], 1, skewness, na.rm=T)
      df_normalized$Skewness_wt <- apply(df_normalized[,col_WTbio], 1, skewness, na.rm=T)
      df_normalized$Min_ko <- apply(df_normalized[,koCols], 1, min, na.rm=T)
      df_normalized$Min_wt <- apply(df_normalized[,col_WTbio], 1, min, na.rm=T)
      df_normalized$Mean_ko <- apply(df_normalized[,koCols], 1, mean, na.rm=T)
      df_normalized$Mean_wt <- apply(df_normalized[,col_WTbio], 1, mean, na.rm=T)
      df_normalized$Max_ko <- apply(df_normalized[,koCols], 1, max, na.rm=T)
      df_normalized$Max_wt <- apply(df_normalized[,col_WTbio], 1, max, na.rm=T)
      df_normalized$Sd_ko <- apply(df_normalized[,koCols], 1, sd, na.rm=T)
      df_normalized$Sd_wt <- apply(df_normalized[,col_WTbio], 1, sd, na.rm=T)
      df_normalized$Var_ko <- apply(df_normalized[,koCols], 1, var, na.rm=T)
      df_normalized$Var_wt <- apply(df_normalized[,col_WTbio], 1, var, na.rm=T)
      
      df_normalized$MeaNwt3sd_up <- df_normalized$Mean_wt + (3*df_normalized$Sd_wt)
      df_normalized$MeaNwt3sd_down <- df_normalized$Mean_wt - (3*df_normalized$Sd_wt)
      df_normalized$wt99_up <- apply(df_normalized[,col_WTbio], 1, function(x) quantile(x, 0.99, na.rm=T))
      df_normalized$wt99_down <- apply(df_normalized[,col_WTbio], 1, function(x) quantile(x, 0.01, na.rm=T))
      
      
      variables2plot <- names(df_normalized)[(numberOfStrains+1):dim(df_normalized)[2]]
      variables2plot <- unique(gsub("(.*)\\_.*", "\\1",variables2plot))
      
      pdf(file.path(subDir2, "12_2_1_DescriptiveVariablePlots.pdf"))
      for(vari in variables2plot){
        cols2plot <- grep(vari, names(df_normalized))
        df_jnk <- df_normalized[,cols2plot]
        
        p<-ggplot(df_jnk, aes(x=df_jnk[,1], y=df_jnk[,2])) +
          geom_point() +
          geom_smooth(color="blue") +
          geom_abline(slope=1, intercept = 0, color="darkred", size=1)+
          xlab(colnames(df_jnk)[1]) +
          ylab(colnames(df_jnk)[2]) +
          ggtitle(paste0("cor= ", round(cor(df_jnk[,1],df_jnk[,2], use="pairwise.complete.obs", method="pearson"),2)))+
          theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
                axis.text=element_text(size=14),
                axis.title=element_text(size=14,face="bold"),
                strip.text = element_text(size = 14, face="bold")) +
          scale_fill_discrete(guide = 'none')
        print(p)
        
        
        df_jnk$Protein.IDs <- rownames(df_jnk)
        names(df_jnk) <- gsub(paste0(vari, "_"), "", names(df_jnk))
        df_jnk_melt <- melt(df_jnk, id="Protein.IDs")
        
        p<-ggplot(df_jnk_melt, aes(x=value, fill=variable)) +
          geom_density() +
          facet_grid(variable ~ .) +
          xlab(vari) +
          theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
                axis.text=element_text(size=14),
                axis.title=element_text(size=14,face="bold"),
                strip.text = element_text(size = 14, face="bold")) +
          scale_fill_discrete(guide = 'none')
        
        print(p)
      }
      dev.off()
      rm(df_jnk)
      rm(df_jnk_melt)
      rm(vari)
      rm(variables2plot)
      # 12.2.2 # each protein with the limits #############################
      cols2keep <- grep("wt", names(df_normalized))[c(3,5,8,9,10,11)]
      
      df_normalized2 <- df_normalized[, c(1:numberOfStrains, cols2keep)]
      allCols <- 1:numberOfStrains
      wtCols <- col_WTbio 
      koCols <- setdiff(allCols, wtCols)
      
      pdf(file.path(subDir2, "12_2_2_EachProteinWithLimits.pdf"))
      for(i in 1:dim(df_normalized2)[1]){
        df_jnk <- df_normalized2[i,]
        
        protein2plot <- rownames(df_jnk)
        
        df_jnk$Protein.IDs <- rownames(df_jnk)
        df_jnk_melt <- as.data.frame(melt(df_jnk, id="Protein.IDs"), drop=TRUE)
        
        df_jnk_melt$category <- NA
        df_jnk_melt$category[wtCols] <- "wt"
        df_jnk_melt$category[koCols] <- "ko"
        
        jnk <- df_jnk_melt[is.na(df_jnk_melt$category),2:3]
        df_jnk_melt <- df_jnk_melt[!is.na(df_jnk_melt$category),]
        
        p<-ggplot(df_jnk_melt, aes(x=value, fill=category)) +
          geom_density() +
          facet_grid(category ~ .) +
          xlab("Distribution of ratios") +
          ggtitle(protein2plot) +
          theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
                axis.text=element_text(size=14),
                axis.title=element_text(size=14,face="bold"),
                strip.text = element_text(size = 14, face="bold"),
                panel.border = element_blank()) +
          scale_fill_discrete(guide = 'none') +
          geom_vline(data=jnk, aes(xintercept = value, colour=variable), size=0.2)+
          scale_color_manual(values=c("#fd8d3c", "#762a83", "#fd8d3c", "#41ab5d", "#41ab5d", "#2166ac", "#2166ac",
                                      "#cb181d", "#cb181d"))
        
        print(p)
      }
      dev.off()
      rm(df_jnk)
      rm(df_jnk_melt)
      rm(p)
      rm(df_normalized2)
      rm(jnk)
      #################################################################
      # 12.2.3 # make box plots based on number of proteins changing in wt or ###################
      # k/o strains based on the criteria to be picked ##
      # based on min-max wt #
      colMin <- grep("Min_wt", names(df_normalized))
      colMax <- grep("Max_wt", names(df_normalized))
      df_upDown_minMax <- calculateDFupDown(df_normalized, colMin, colMax, numberOfStrains)
      
      # based on mean wt +/* 3sd #
      colMin <- grep("MeaNwt3sd_down", names(df_normalized))
      colMax <- grep("MeaNwt3sd_up", names(df_normalized))
      df_upDown_sd3 <- calculateDFupDown(df_normalized, colMin, colMax, numberOfStrains)
      
      # based on wt 99% limits #
      colMin <- grep("wt99_down", names(df_normalized))
      colMax <- grep("wt99_up", names(df_normalized))
      df_upDown_wt99 <- calculateDFupDown(df_normalized, colMin, colMax, numberOfStrains)
      
      rm(colMin)
      rm(colMax)
      # create a data frame to put the data together ##
      minMax_up <- calculateUpDownNumberOfGenes(df_upDown_minMax, 1)
      names(minMax_up)[1] <- "minMax_up"
      minMax_down <- calculateUpDownNumberOfGenes(df_upDown_minMax, -1)
      names(minMax_down)[1] <- "minMax_down"
      minMax <- merge(minMax_up, minMax_down, by=2)
      minMax$minMax_changing <- minMax$minMax_up + minMax$minMax_down
      rm(df_upDown_minMax)
      
      minMax_up <- calculateUpDownNumberOfGenes(df_upDown_sd3, 1)
      names(minMax_up)[1] <- "sd3_up"
      minMax_down <- calculateUpDownNumberOfGenes(df_upDown_sd3, -1)
      names(minMax_down)[1] <- "sd3_down"
      sd3 <- merge(minMax_up, minMax_down, by=2)
      sd3$sd3_changing <- sd3$sd3_up + sd3$sd3_down
      rm(df_upDown_sd3)
      
      minMax_up <- calculateUpDownNumberOfGenes(df_upDown_wt99, 1)
      names(minMax_up)[1] <- "wt99_up"
      minMax_down <- calculateUpDownNumberOfGenes(df_upDown_wt99, -1)
      names(minMax_down)[1] <- "wt99_down"
      wt99 <- merge(minMax_up, minMax_down, by=2)
      wt99$wt99_changing <- wt99$wt99_up + wt99$wt99_down
      rm(df_upDown_wt99)
      
      rm(minMax_down)
      rm(minMax_up)
      
      # putting tables together  for making the boxplots #
      Changingtable <- merge(minMax, sd3, by=1, all=FALSE)
      Changingtable <- merge(Changingtable, wt99, by=1, all=FALSE)
      
      Changingtable$StrainType <- NA
      allROWs <- 1:numberOfStrains
      wtROWs <- grep("Sp[0-9]*WT\\_Bio[0-9]*", Changingtable$Strain)
      koROWs <- setdiff(allROWs, wtROWs)
      
      Changingtable$StrainType[koROWs] <- "ko"
      Changingtable$StrainType[wtROWs] <- "wt"
      rm(minMax)
      rm(sd3)
      rm(wt99)
      
      
      #making a boxplot #
      Changingtable_melt <- as.data.frame(melt(Changingtable, id=c("Strain", "StrainType")))
      Changingtable_melt$Correspondance <- paste(Changingtable_melt$variable, Changingtable_melt$StrainType, sep = "_")
      Changingtable_melt$faceting <- gsub(".*\\_", "",Changingtable_melt$variable)
      Changingtable_melt$Criteria <- gsub("\\_.*", "",Changingtable_melt$variable)
      
      anno_df = compare_means(value ~ Correspondance, group.by = "faceting", data = Changingtable_melt)
      anno_df <- anno_df[c(1,10,15,16,25,30,31,40,45),]
      pdf(file.path(subDir2, "12_2_3_BoxPlotsWithDifferentCriteria.pdf"))
      p<-ggplot(Changingtable_melt, aes(x=Correspondance, y=value)) +
        geom_boxplot(aes(color=Criteria, fill=StrainType)) +
        facet_grid(. ~ faceting, scales="free") +
        ggtitle("Number of proteins regulated all wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank(),
              axis.title.x=element_blank(),
              axis.text.x=element_blank(),
              axis.ticks.x=element_blank())+
        scale_fill_manual(values=c("#000000", "#999999")) +
        ggsignif::geom_signif(data=anno_df,aes(xmin=group1, xmax=group2, 
                                               annotations=p.signif, y_position=1300), manual=TRUE)
      
      print(p)
      dev.off()
      koLibrary <- read.delim("old/7_3_ReporterIntensityDecode_merged_SupTable1.txt")
      koLibrary <- subset(koLibrary, Analyzed_ReMeasured == "ToBeAnalyzed")
      # 12.3.4 # save changing table #####################################################
      Changingtable2 <- merge(koLibrary, Changingtable, by.y="Strain", by.x = "Position_MS_Plate", all.y = T)
      write.table(Changingtable2, file.path(subDir2, "12_3_4_ChangingTable_differentCriteria_upDown.txt"),
                  quote = F, row.names = F, sep="\t")
      
      rm(Changingtable)
      rm(Changingtable_melt)
      rm(p)
      rm(anno_df)
      # 12.3.5 # variation #############################################
      df_normalized <- df_normalized[,1:numberOfStrains]
      
      Mean_wt <- as.data.frame(apply(df_normalized[,col_WTbio], 1, mean, na.rm=T))
      df_normalized_variance <- getDFvsColVariation(df_normalized, Mean_wt) 
      
      pdf(file.path(subDir2, "12_3_5_Plots4Variance_SD.pdf"))
      varStrains <- as.data.frame(colMeans(df_normalized_variance, na.rm=T))
      
      names(varStrains) <- "MeanVariance"
      varStrains$MeanVariance <- as.numeric(varStrains$MeanVariance)
      varStrains$MeanStandardDeviation <- sqrt(varStrains$MeanVariance)
      varStrains$Strain <- rownames(varStrains)
      
      varStrains$StrainType <- NA
      
      allROWs <- 1:numberOfStrains
      wtROWs <- grep("Sp[0-9]*WT\\_Bio[0-9]*", varStrains$Strain)
      koROWs <- setdiff(allROWs, wtROWs)
      
      varStrains$StrainType[koROWs] <- "ko"
      varStrains$StrainType[wtROWs] <- "wt"
      
      p<-ggplot(varStrains, aes(x=StrainType, y=MeanVariance)) +
        geom_boxplot(aes(fill=StrainType)) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        #  stat_compare_means(paired = F, size=8, label.x = 0.7, label.y = 1) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(x=StrainType, y=MeanVariance)) +
        geom_violin(aes(fill=StrainType)) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(MeanVariance)) +
        geom_density(aes(fill=StrainType, color=StrainType), alpha=0.5) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      
      p<-ggplot(varStrains, aes(x=StrainType, y=MeanStandardDeviation)) +
        geom_boxplot(aes(fill=StrainType)) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        #  stat_compare_means(paired = F, size=8, label.x = 0.7, label.y = 1) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(x=StrainType, y=MeanStandardDeviation)) +
        geom_violin(aes(fill=StrainType)) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(MeanStandardDeviation)) +
        geom_density(aes(fill=StrainType, color=StrainType), alpha=0.5) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      ####
      varStrains <- as.data.frame(colSums(df_normalized_variance, na.rm=T))
      
      names(varStrains) <- "SUMVariance"
      varStrains$SUMVariance <- as.numeric(varStrains$SUMVariance)
      varStrains$SUMStandardDeviation <- sqrt(varStrains$SUMVariance)
      varStrains$Strain <- rownames(varStrains)
      
      varStrains$StrainType <- NA
      
      allROWs <- 1:numberOfStrains
      wtROWs <- grep("Sp[0-9]*WT\\_Bio[0-9]*", varStrains$Strain)
      koROWs <- setdiff(allROWs, wtROWs)
      
      varStrains$StrainType[koROWs] <- "ko"
      varStrains$StrainType[wtROWs] <- "wt"
      
      p<-ggplot(varStrains, aes(x=StrainType, y=SUMVariance)) +
        geom_boxplot(aes(fill=StrainType)) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        #  stat_compare_means(paired = F, size=8, label.x = 0.7, label.y = 1) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(x=StrainType, y=SUMVariance)) +
        geom_violin(aes(fill=StrainType)) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(SUMVariance)) +
        geom_density(aes(fill=StrainType, color=StrainType), alpha=0.5) +
        ggtitle("Average variation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      
      p<-ggplot(varStrains, aes(x=StrainType, y=SUMStandardDeviation)) +
        geom_boxplot(aes(fill=StrainType)) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        #  stat_compare_means(paired = F, size=8, label.x = 0.7, label.y = 1) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(x=StrainType, y=SUMStandardDeviation)) +
        geom_violin(aes(fill=StrainType)) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      p<-ggplot(varStrains, aes(SUMStandardDeviation)) +
        geom_density(aes(fill=StrainType, color=StrainType), alpha=0.5) +
        ggtitle("Average standard deviation for each strain wt vs. all k/o") +
        theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
              axis.text=element_text(size=14),
              axis.title=element_text(size=14,face="bold"),
              strip.text = element_text(size = 14, face="bold"),
              panel.border = element_blank()) +
        guides(fill=FALSE)
      print(p)
      dev.off()
      rm(df_normalized_variance)
      rm(p)
      rm(Mean_wt)
      
      varStrains <- merge(koLibrary, varStrains, by.y="Strain", by.x = "Position_MS_Plate", all.y = T)
      write.table(varStrains, file.path(subDir2, "12_3_5_MeanVariationOfStrains.txt"), 
                  sep = "\t", quote = FALSE)
      ####################################################################################
      # 12.3.6 # table for stains with variation and number of genes changing ############
      varStrains <- varStrains[,c(1,23,24)]
      Changingtable2 <- read.delim(file.path(subDir2, "12_3_4_ChangingTable_differentCriteria_upDown.txt"))
      Changingtable3 <- merge(Changingtable2, varStrains, by.x = "Position_MS_Plate", 
                              by.y = "Position_MS_Plate", all = T)
      rm(Changingtable2)
      rm(koLibrary)
      rm(varStrains)
      write.table(Changingtable3, file.path(subDir2, "12_3_6_ChangingTable_Variation.txt"), 
                  sep = "\t", quote = FALSE)
      ####################################################################################
      # 12.3.7 # correlation of k/o strains to wt strains as a measure of being different ####
      # correlation distribution between wt meaurements
      allCols <- 1:dim(df_normalized)[2]
      wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
      koCols <- setdiff(allCols, wtCols)
      
      df_normalized_wt <- df_normalized[wtCols]
      
      df_normalized_wt_cor <- as.data.frame(cor(df_normalized_wt, use="pairwise.complete.obs", method="pearson")) 
      df_normalized_wt_cor$WT <- rownames(df_normalized_wt_cor)
      df_normalized_wt_cor_m <- melt(df_normalized_wt_cor, id="WT") 
      
      colnames(df_normalized_wt_cor_m) <- c("WT1", "WT2", "PearsonPaired")
      mean_wt_cor <- mean(df_normalized_wt_cor_m$PearsonPaired)
      sd_wt_cor <- sd(df_normalized_wt_cor_m$PearsonPaired)
      
      # correlation distribution between wt meaurements and ko strains
      df_normalized_cor <- as.data.frame(cor(df_normalized, use="pairwise.complete.obs", method="pearson"))
      df_normalized_cor$Strain1 <- rownames(df_normalized_cor)
      wtRows <- grep("WT_Bio", df_normalized_cor$Strain1)
      df_normalized_cor_wtRows <- df_normalized_cor[wtRows,]
      
      df_normalized_cor_wtRows <- df_normalized_cor_wtRows[,-dim(df_normalized_cor_wtRows)[2]]
      allCols <- 1:dim(df_normalized_cor_wtRows)[2]
      wtCols <- grep("WT_Bio", names(df_normalized_cor_wtRows))
      koCols <- setdiff(allCols, wtCols)
      
      df_cor_VP <- data.frame(Strains=c("WTs", names(df_normalized_cor_wtRows)[koCols]))
      df_cor_VP$MeanCor <- NA
      df_cor_VP$FCCor <- NA
      df_cor_VP$PvalCor <- NA
      
      wtMeanCor <- mean(as.numeric(as.matrix(df_normalized_cor_wtRows[,wtCols])))
      df_cor_VP$MeanCor[1] <- wtMeanCor
      for (i in 2:dim(df_cor_VP)[1]) {
        print(i)
        gene <- df_cor_VP$Strains[i]
        colGene <- grep(gene, names(df_normalized_cor_wtRows))
        
        df_cor_VP$MeanCor[i] <- mean(df_normalized_cor_wtRows[,colGene])
        df_cor_VP$PvalCor[i] <- my.t.test.p.value(as.numeric(as.matrix(df_normalized_cor_wtRows[,wtCols])),
                                                  as.numeric(df_normalized_cor_wtRows[,colGene]))
      }
      df_cor_VP$PvalCor[1] <- 1
      
      df_cor_VP$FCCor <- df_cor_VP$MeanCor - wtMeanCor
      
      wt_cors <- df_normalized_cor_wtRows[,wtCols]
      wt_cors <- melt(wt_cors)
      
      
      
      p1 <- ggplot(wt_cors, aes(value))+
        geom_histogram(bins=100) +
        geom_vline(xintercept = mean(wt_cors$value), color="red")+
        ggtitle("Distribution of corerlation btw. WTs")
      
      
      p2 <- ggplot(df_cor_VP, aes(x=MeanCor, y=-log10(PvalCor)))+
        geom_point()+
        geom_point(data = subset(df_cor_VP, Strains=="WTs"), color="red") +
        xlab("Mean(correlation)") +
        ggtitle("VP4: correlation of ko strains to all wt")
      
      p3 <- ggplot(df_cor_VP, aes(x=FCCor, y=-log10(PvalCor)))+
        geom_point()+
        geom_point(data = subset(df_cor_VP, Strains=="WTs"), color="red") +
        xlab("FC(correlation)") +
        ggtitle("VP4: correlation of ko strains to all wt")
      
      pdf(file.path(subDir2, "12_3_7_Correlation2Wt.pdf"))
      print(p1)
      print(p2)
      print(p3)
      dev.off()
      
      write.table(df_cor_VP, file.path(subDir2, "12_3_7_koStrainsCorrelation2Wt.txt"), 
                  sep = "\t", quote = FALSE)
      # 12.3.8 # corralate and compare up/down/sd/var ####################################
      Changingtable3 <- read.delim(file.path(subDir2, "12_3_6_ChangingTable_Variation.txt"))
      df_cor_VP <- read.delim(file.path(subDir2, "12_3_7_koStrainsCorrelation2Wt.txt"))
      df_cor_VP <- df_cor_VP[,-4]
      df_cor_VP$MeanCor <- 100*df_cor_VP$MeanCor
      df_cor_VP$FCCor <- 100*df_cor_VP$FCCor
      
      df_pcor <- merge(Changingtable3, df_cor_VP, by.x="Position_MS_Plate", by.y="Strains", all=FALSE)
      df_pcor <- df_pcor[, 23:35]
      df_pcor <- df_pcor[,-10]
      names(df_pcor)[12] <- "MeanCor2wt"
      DF_cor<- cor(df_pcor, use="pairwise.complete.obs", method="pearson")
      
      pdf(file.path(subDir2, "12_3_8_Correlation_RegulatedGenes_VarianceSD_correlation2wt.pdf"))
      corrplot(DF_cor, type = "upper", order = "hclust", 
               tl.col = "black", tl.srt = 45, title="cor")
      dev.off()
      rm(DF_cor)
      rm(df_pcor)
      #################################################################################################
    }
    ##########################################################################################################
    
    # side check FDR filtered mean and variation #############################################################
    df_not <- readRDS("8_2_FILTERED4Power_25.rds")
    df_filtered <- readRDS("11_a_DF_NORMALIZED_final.rds")
    df_not <- df_not[!rownames(df_not) %in% rownames(df_filtered),]
    jnk <- rowSds(df_not[,grep("WT_Bio", names(df_not))], na.rm=TRUE)
    jnk2 <- rowSds(df_not[,-grep("WT_Bio", names(df_not))], na.rm=TRUE)
    
    jnk3 <- rowSds(df_filtered[,grep("WT_Bio", names(df_filtered))], na.rm=TRUE)
    jnk4 <- rowSds(df_filtered[,-grep("WT_Bio", names(df_filtered))], na.rm=TRUE)
    
    jnk3 <- rowSds(df_not, na.rm=TRUE)
    jnk4 <- rowSds(df_filtered, na.rm=TRUE)
    
    
  }
}}
if(strainCorCluster){
  out_dir2 <- "ScreenProteome/7_20190718_strainClusterCor/"
  # 7 # idea is to use all possible measures to assess similarities of expression profiles of strains #####################
  # use Zscores as measures for clustering correlation etc. 
  # and all the proteins measured without power filtering
  myfile <- list.files(path = out_dir, pattern = "^6_11_1.*melt.*rds")
  df_screen <- readRDS(file.path(out_dir, myfile))
  # make a dataframe from the Zscore
  mydf <- df_screen[,c(2,3,5)]
  mydf <- dcast(mydf, Proteins ~ Strain, value.var="Zscore")
  rownames(mydf) <- mydf$Proteins
  mydf <- mydf[,-1]
  mydf <- mydf[rowSums(!is.na(mydf))!=0,]
  rm(df_screen)
  saveRDS(mydf, file.path(out_dir2, paste0("7_0_", Sys.Date(), "_mydf_Zscore.rds")))
  rm(mydf)
  # 7.1 # correlations P|S|K ###############################################################################################
  myfile <- list.files(path = out_dir2, pattern = "^7_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  
  corAndPvalue_method <- function(df, cor_method){
    StrainCor <- corAndPvalue(df, y = NULL, 
                               use = "pairwise.complete.obs", 
                               alternative = c("two.sided", "less", "greater"), 
                               method=cor_method)
    
    my_df <- as.data.frame(StrainCor[[1]])
    my_df$Strain <- rownames(my_df)
    my_df_melt <- melt(data = my_df, id="Strain")
    names(my_df_melt) <- c("Strain1", "Strain2", names(StrainCor)[1])
    my_df_melt$identifier <- paste(my_df_melt$Strain1, my_df_melt$Strain2, sep="&")
    rm(my_df)
    rownames(my_df_melt) <- my_df_melt$identifier
    my_df_melt <- my_df_melt[,-4]
    jnk <- c(2,5)
    for (i in jnk) {
      print(i)
      my_df_jnk <- as.data.frame(StrainCor[[i]])
      my_df_jnk$Strain <- rownames(my_df_jnk)
      my_df_jnk_melt <- melt(data = my_df_jnk, id="Strain")
      rm(my_df_jnk)
      names(my_df_jnk_melt) <- c("Strain1", "Strain2", names(StrainCor)[i])
      my_df_jnk_melt$identifier <- paste(my_df_jnk_melt$Strain1, my_df_jnk_melt$Strain2, sep="&")
      rownames(my_df_jnk_melt) <- my_df_jnk_melt$identifier
      my_df_jnk_melt <- my_df_jnk_melt[match(rownames(my_df_melt), rownames(my_df_jnk_melt)), ]
      my_df_jnk_melt <- as.data.frame(my_df_jnk_melt[,3])
      names(my_df_jnk_melt)[1] <- names(StrainCor)[i]
      my_df_melt <- cbind(my_df_melt, my_df_jnk_melt)
    }
    saveRDS(my_df_melt, file.path(out_dir2, paste0("7_1_",cor_method,"_", Sys.Date(), "_corAndPvalue.rds")))
  }
  
  corAndPvalue_method(mydf, "pearson")
  corAndPvalue_method(mydf, "spearman")
  corAndPvalue_method(mydf, "kendall")
  # 7.2 # partial correlations P ###############################################################################################
  myfile <- list.files(path = out_dir2, pattern = "^7_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  
  StrainCor <- partial.r(mydf, use = "pairwise.complete.obs", method="pearson")
  
  my_df <- as.data.frame(StrainCor)
  my_df$Strain <- rownames(my_df)
  my_df_melt <- melt(data = my_df, id="Strain")
  names(my_df_melt) <- c("Strain1", "Strain2", "partialR")
  my_df_melt$identifier <- paste(my_df_melt$Strain1, my_df_melt$Strain2, sep="&")
  rm(my_df)
  rownames(my_df_melt) <- my_df_melt$identifier
  my_df_melt <- my_df_melt[,-4]
  saveRDS(my_df_melt, file.path(out_dir2, paste0("7_2_pearson_", Sys.Date(), "_partialR.rds")))
  # 7.3 # clustering with som ###############################################################################################
  library(kohonen)
  
  myfile <- list.files(path = out_dir2, pattern = "^7_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  mydf <- as.matrix(t(mydf))
  
  for (i in 1:20) {
    print(i)
    df_som <- supersom(mydf, grid = somgrid(i, i, "hexagonal"), rlen = 1000, normalizeDataLayers = FALSE, maxNA.fraction = 2889)
    saveRDS(df_som, file.path(out_dir2, paste0("7_3_", Sys.Date(), "_", i*i,"_clusters_som.rds")))
  }
  # 7.7 # overlap of the strains they are regulated together ########################################################
  # 7.7.1 # put the correlation of the pairs together first
  myfiles <- list.files(out_dir2, pattern = "^7_1.*")
  
  df_jnk <- readRDS(file.path(out_dir2, myfiles[1]))
  names(df_jnk) <- paste(names(df_jnk), "_kendall", sep="")
  df_jnk$identifier <- rownames(df_jnk)
  df_jnk <- df_jnk[,3:6]
  
  df_jnk2 <- readRDS(file.path(out_dir2, myfiles[2]))
  names(df_jnk2) <- paste(names(df_jnk2), "_pearson", sep="")
  df_jnk2$identifier <- rownames(df_jnk2)
  df_jnk2 <- df_jnk2[,3:6]
  
  df_jnk <- merge(df_jnk, df_jnk2, by.x="identifier", by.y="identifier", all=FALSE)
  
  df_jnk2 <- readRDS(file.path(out_dir2, myfiles[3]))
  names(df_jnk2)[3:5] <- paste(names(df_jnk2)[3:5], "_spearman", sep="")
  df_jnk2$identifier <- rownames(df_jnk2)
  
  df_jnk <- merge(df_jnk, df_jnk2, by.x="identifier", by.y="identifier", all=FALSE)
  rm(df_jnk2)
  saveRDS(df_jnk, file.path(out_dir2, paste0("7_7_1_", Sys.Date(), "_all_corAndPvalue.rds")))
  rm(df_jnk)
  rm(myfiles)
  # 7.7.2 # integrate the coregulation information
  myfile <- list.files(path = out_dir, pattern = "^6_12_1.*melt.*rds")
  df_screen <- readRDS(file.path(out_dir, myfile))
  df_screen <- df_screen[!is.na(df_screen$NormalizedValue),]
  # myfile <- list.files(path = out_dir2, pattern = "^7_7_1.*rds")
  # df_cor <- readRDS(file.path(out_dir2, myfile))
  # df_cor <- df_cor[,c(8,9,7,5,6,10,11,2,3)]
  # names(df_cor)[3] <- "nObservations"
  # saveRDS(df_cor, file.path(out_dir2, paste0("7_7_1_", Sys.Date(), "_all_corAndPvalue.rds")))
  
  myfile <- list.files(path = out_dir2, pattern = "^7_7_1.*rds")
  df_cor <- readRDS(file.path(out_dir2, myfile))
  
  df_cor$Strain1_nMeasured <- NA
  df_cor$Strain2_nMeasured <- NA
  
  df_cor$Strain1_nRegulated_P <- NA
  df_cor$Strain2_nRegulated_P <- NA
  
  df_cor$Strain1_nRegulated_ecdf <- NA
  df_cor$Strain2_nRegulated_ecdf <- NA
  
  df_cor$common_nMeasured <- NA
  df_cor$common_nRegulated_P <- NA
  df_cor$common_nRegulated_ecdf <- NA
  
  df_cor$common_nRegulated_P_sameDir <- NA
  df_cor$common_nRegulated_ecdf_sameDir <- NA
  df_cor <- remove.factors(df_cor)
  
  for (i in 1:dim(df_cor)[1]) {
    print(i)
    p1 <- df_cor$Strain1[i]
    p2 <- df_cor$Strain2[i]
    df_screen_jnk1 <- subset(df_screen, Strain==p1)
    df_screen_jnk2 <- subset(df_screen, Strain==p2)
    
    df_cor$Strain1_nMeasured[i] <- dim(df_screen_jnk1)[1]
    df_cor$Strain2_nMeasured[i] <- dim(df_screen_jnk2)[1]
    
    df_cor$Strain1_nRegulated_P[i] <- sum(df_screen_jnk1$myFDR_changing == TRUE)
    df_cor$Strain2_nRegulated_P[i] <- sum(df_screen_jnk2$myFDR_changing == TRUE)
    
    df_cor$Strain1_nRegulated_ecdf[i] <- sum(df_screen_jnk1$myecdf_changing == TRUE)
    df_cor$Strain2_nRegulated_ecdf[i] <- sum(df_screen_jnk2$myecdf_changing == TRUE)
    
    df_cor$common_nMeasured[i] <- length(intersect(df_screen_jnk1$Proteins, 
                                                   df_screen_jnk2$Proteins))
    df_cor$common_nRegulated_P[i] <- length(intersect(df_screen_jnk1$Proteins[df_screen_jnk1$myFDR_changing == TRUE], 
                                                      df_screen_jnk2$Proteins[df_screen_jnk2$myFDR_changing == TRUE]))
    df_cor$common_nRegulated_ecdf[i] <- length(intersect(df_screen_jnk1$Proteins[df_screen_jnk1$myecdf_changing == TRUE], 
                                                         df_screen_jnk2$Proteins[df_screen_jnk2$myecdf_changing == TRUE]))
    
    df_screen_jnk1_1 <- subset(df_screen_jnk1, myFDR_changing==TRUE)
    df_screen_jnk2_1 <- subset(df_screen_jnk2, myFDR_changing==TRUE)
    df_screen_jnk1_1$identifier <- paste(df_screen_jnk1_1$Proteins, df_screen_jnk1_1$myFDR_changing_category)
    df_screen_jnk2_1$identifier <- paste(df_screen_jnk2_1$Proteins, df_screen_jnk2_1$myFDR_changing_category)
    df_cor$common_nRegulated_P_sameDir[i] <- length(intersect(df_screen_jnk1_1$identifier, 
                                                              df_screen_jnk2_1$identifier))
    
    df_screen_jnk1_1 <- subset(df_screen_jnk1, myecdf_changing==TRUE)
    df_screen_jnk2_1 <- subset(df_screen_jnk2, myecdf_changing==TRUE)
    df_screen_jnk1_1$identifier <- paste(df_screen_jnk1_1$Proteins, df_screen_jnk1_1$myecdf_changing_category)
    df_screen_jnk2_1$identifier <- paste(df_screen_jnk2_1$Proteins, df_screen_jnk2_1$myecdf_changing_category)
    df_cor$common_nRegulated_ecdf_sameDir[i] <- length(intersect(df_screen_jnk1_1$identifier, 
                                                                 df_screen_jnk2_1$identifier))
    
  }
  saveRDS(df_cor, file.path(out_dir2, paste0("7_7_2_", Sys.Date(), "_all_corAndPvalue_commonRegulation.rds")))
  
  # 7.8 # check the som clusters and grouping #######################################################################
  myfiles <- as.data.frame(list.files(out_dir2, pattern = "^7_3.*"))
  myfiles$nCluster <- NA
  names(myfiles)[1] <- "filename"
  myfiles$nCluster <- gsub("^7_3_2019-07-[0-9]*\\_([0-9]*)\\_clusters_som.rds$", "\\1", myfiles$filename)
  myfiles$nCluster <- as.numeric(myfiles$nCluster)
  # size of the groups
  myfile <- list.files(path = out_dir2, pattern = "^7_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  
  mydf <- as.data.frame(colnames(mydf))
  
  for (i in 1:dim(myfiles)[1]) {
    print(i)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[i]))
    jnk <- df_som$unit.classif
    mydf <- cbind(mydf, jnk)
    names(mydf)[dim(mydf)[2]] <- paste0("somCluster_", myfiles$nCluster[i])
  }
  rm(df_som)
  
  names(mydf)[1] <- "pG"
  mydf <- melt(mydf, id="pG")
  mydf$nCluster <- gsub("somCluster\\_([0-9]*)", "\\1", mydf$variable)
  
  mydf_sizes <- as.data.frame(table(mydf[,3:4]))
  mydf_sizes <- mydf_sizes[mydf_sizes$Freq != 0,]
  names(mydf_sizes)[1] <- "whichCluster"
  mydf_sizes <- remove.factors(mydf_sizes)
  
  for (i in 1:dim(mydf_sizes)[2]) {
    mydf_sizes[,i] <- as.numeric(mydf_sizes[,i])
  }
  
  p0 <- ggplot(mydf_sizes, aes(as.factor(nCluster), Freq)) +
    geom_boxplot() +
    theme_classic() +
    xlab("Number of som clusters") +
    ylab("Number of proteins in each cluster - log10") +
    theme(axis.text = element_text(size = 12),
          axis.title = element_text(size=14))
  
  p1 <- ggplot(mydf_sizes, aes(as.factor(nCluster), Freq)) +
    geom_boxplot() +
    scale_y_log10() +
    theme_classic() +
    xlab("Number of som clusters") +
    ylab("Number of proteins in each cluster - log10") +
    theme(axis.text = element_text(size = 12),
          axis.title = element_text(size=14))
  
  p2 <- ggplot(mydf_sizes, aes(as.factor(nCluster), Freq)) +
    geom_boxplot() +
    theme_classic() +
    xlab("Number of som clusters") +
    ylab("Number of proteins in each cluster - log10") +
    theme(axis.text = element_text(size = 12),
          axis.title = element_text(size=14)) +
    ylim(0,500)
  df_keep <- mydf
  names(df_keep) <- c("Strain", "somCluster", "whichCluster", "somClusterNumber")
  # distance within or between the groups
  myfile <- list.files(path = out_dir2, pattern = "^7_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  
  mydf <- as.data.frame(colnames(mydf))
  
  for (i in 1:dim(myfiles)[1]) {
    print(i)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[i]))
    df_som_jnk <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif, df_som$distances))
    names(df_som_jnk) <- c("pG", paste0("Cluster_",myfiles$nCluster[i]), paste0("Distance_",myfiles$nCluster[i]))
    mydf <- merge(mydf, df_som_jnk, by=1, all=FALSE)
  }
  rm(df_som)
  rm(df_som_jnk)
  names(mydf)[1] <- "Strain"
  col2keep <- grep("Distance", names(mydf))
  mydf <- mydf[,c(1,col2keep)]
  mydf <- melt(mydf, id="Strain")
  mydf$nCluster <- gsub("Distance\\_([0-9]*)", "\\1", mydf$variable)
  names(mydf)[3] <- "Distance"
  
  mydf$identifier <- paste(mydf$Strain, mydf$nCluster)
  df_keep$identifier <- paste(df_keep$Strain, df_keep$somClusterNumber)
  
  df_keep <- df_keep[,c(5,1,3)]
  mydf <- mydf[,c(5,4,3)]
  
  df_keep <- merge(df_keep, mydf, by.x="identifier", by.y="identifier", all=FALSE)
  rm(mydf)
  df_keep <- df_keep[,2:5]
  names(df_keep)[3] <- "SOM_nCluster"
  df_keep <- remove.factors(df_keep)
  
  saveRDS(df_keep, file.path(out_dir2, paste0("7_8_1_", Sys.Date(), "_Sizes_Distances_SOM.rds")))
  
  for (i in 2:dim(df_keep)[2]) {
    df_keep[,i] <- as.numeric(df_keep[,i])
  }
  
  df_keep <- df_keep %>%
    group_by(whichCluster, SOM_nCluster) %>%
    dplyr::mutate(AverageDistance = mean(as.numeric(Distance)),
                  Size = n()) %>%
    as.data.frame()
  
  df_keep <- df_keep %>%
    group_by(whichCluster, SOM_nCluster) %>%
    dplyr::mutate(Q3Distance = quantile(as.numeric(Distance),0.75)[[1]]) %>%
    as.data.frame()
  
  df_keep <- df_keep %>%
    group_by(whichCluster, SOM_nCluster) %>%
    dplyr::mutate(Q3Distance_keep = AverageDistance<Q3Distance) %>%
    as.data.frame()
  
  df_keep <- df_keep %>%
    group_by(SOM_nCluster, Q3Distance_keep) %>%
    dplyr::mutate(Q3Distance_keep_size = n()) %>%
    as.data.frame()
  
  
  df_keep <- df_keep %>%
    group_by(SOM_nCluster) %>%
    dplyr::mutate(AverageDistance_median = median(AverageDistance),
                  Size_median = median(Size)) %>%
    as.data.frame()
  
  
  p3 <- ggplot(df_keep, aes(as.factor(SOM_nCluster), Q3Distance_keep_size))+
    geom_point(aes(color=Q3Distance_keep), size=4) +
    theme_classic()
  
  
  
  p4 <- ggplot(df_keep, aes(AverageDistance))+
    geom_density() +
    scale_x_log10() +
    theme_classic() +
    facet_wrap(~SOM_nCluster, scales = "free")
  
  
  p5 <- ggplot(df_keep, aes(Size))+
    geom_density() +
    scale_x_log10() +
    theme_classic() +
    facet_wrap(~SOM_nCluster, scales = "free")
  
  p6 <- ggplot(data=as.data.frame(unique(df_keep[,c(3,10,11)])), aes(Size_median, AverageDistance_median)) +
    geom_point(aes(color=as.factor(SOM_nCluster))) + 
    scale_y_log10() +
    scale_x_log10() +
    guides(color=FALSE) +
    geom_label_repel(aes(label=SOM_nCluster))+
    theme_classic()
  
  p7 <- ggplot(data=as.data.frame(unique(df_keep[,c(3,10,11)])), aes(Size_median, AverageDistance_median)) +
    geom_point(aes(color=as.factor(SOM_nCluster))) + 
    guides(color=FALSE) +
    geom_label_repel(aes(label=SOM_nCluster)) +
    xlim(0,200) +
    ylim(0,2000) +
    theme_classic()
  
  saveRDS(df_keep, file.path(out_dir2, paste0("7_8_1_", Sys.Date(), "_Sizes_Distances_SOM.rds")))
  
  # add the correlation information as well
  myfile <- list.files(out_dir2, "^7_7_1")
  df_cor <- readRDS(file.path(out_dir2, myfile))
  
  myclusters <- unique(df_keep$SOM_nCluster)
  
  myclusters_df <- data.frame(SameCluster=character(), 
                              median_pearson= numeric(),
                              median_spearman=numeric(),
                              median_kendall=numeric(),
                              NCluster=numeric())
  
  for (i in 1:length(myclusters)) {
    print(i)
    df_jnk <- subset(df_keep, SOM_nCluster==myclusters[i])
    df_jnk <- df_jnk[,1:2]
    
    names(df_jnk)[2] <- "Strain1_cluster"
    df_cor_jnk <- merge(df_cor, df_jnk, by.x="Strain1", by.y="Strain", all=FALSE)
    names(df_jnk)[2] <- "Strain2_cluster"
    df_cor_jnk <- merge(df_cor_jnk, df_jnk, by.x="Strain2", by.y="Strain", all=FALSE)
    
    df_cor_jnk$SameCluster <- df_cor_jnk$Strain1_cluster == df_cor_jnk$Strain2_cluster
    
    df_cor_jnk <- df_cor_jnk %>%
      group_by(SameCluster) %>%
      dplyr::mutate(median_pearson=median(cor_pearson, na.rm = T),
                    median_spearman=median(cor_spearman, na.rm = T),
                    median_kendall=median(cor_kendall, na.rm = T)) %>%
      as.data.frame()
    
    df_cor_jnk <- as.data.frame(unique(df_cor_jnk[,12:15]))
    
    df_cor_jnk$NCluster <- myclusters[i]
    myclusters_df <- as.data.frame(rbind(myclusters_df, df_cor_jnk))
  }
  
  saveRDS(myclusters_df, file.path(out_dir2, paste0("7_8_2_", Sys.Date(), "_SOMcluster_correlations.rds")))
  myclusters_df <- melt(myclusters_df, id=c("SameCluster", "NCluster"))
  myclusters_df <- remove.factors(myclusters_df)
  myclusters_df$NCluster <- as.numeric(myclusters_df$NCluster)
  
  p8 <- ggplot(myclusters_df, aes(as.factor(NCluster), value))+
    geom_point(aes(color=SameCluster), size=4) +
    theme_classic()+
    facet_grid(variable~.)
  # save the plots
  pdf(file.path(out_dir2, paste0("7_8_3_", Sys.Date(), "_SOM_plots.pdf")), height = 8, width = 10)
  print(p0)
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  print(p5)
  print(p6)
  print(p7)
  print(p8)
  dev.off()
  rm(df_cor)
  rm(df_cor_jnk)
  rm(df_jnk)
  rm(df_keep)
  rm(jnk)
  rm(myclusters_df)
  rm(mydf_sizes)
  rm(myfiles)
  rm(p0)
  rm(p1)
  rm(p2)
  rm(p3)
  rm(p4)
  rm(p5)
  rm(p6)
  rm(p7)
  rm(p8)
  # decide for #of clusters with supersom !!! ##################################
  ## go over different cluster #################################################################
  # 7.9.X # work with different supersom clusters #######################################
  myfiles <- as.data.frame(list.files(out_dir2, "^7_3"))
  myfiles$prefix <- gsub("7_3_.*\\_(.*)\\_clusters_som.rds", "\\1", myfiles$`list.files(out_dir2, "^7_3")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)
  
  for (myfile in 2:dim(myfiles)[1]) {
    print(myfile)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[myfile]))
    
    df_class_distance <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif, df_som$distances))
    
    df_cluster_averages <- as.data.frame(df_som$codes[[1]])
    df_data <- as.data.frame(df_som$data[[1]])
    
    df_cluster_distances <- as.data.frame(matrix(NA, nrow=myfiles$prefix[myfile], ncol=myfiles$prefix[myfile]))
    
    rownames(df_cluster_distances) <- rownames(df_cluster_averages)
    colnames(df_cluster_distances) <- rownames(df_cluster_averages)
    
    for (i in 1:dim(df_cluster_distances)[1]) {
      print(i)
      df_cluster_averages_jnk <- df_cluster_averages
      jnk <- as.data.frame(matrix(as.numeric(rep(as.numeric(df_cluster_averages_jnk[i,]),myfiles$prefix[myfile])), 
                                  nrow = dim(df_cluster_averages_jnk)[1], 
                                  ncol = dim(df_cluster_averages_jnk)[2], byrow = TRUE))
      jnk <- remove.factors(jnk)
      df_cluster_averages_jnk <- df_cluster_averages_jnk - jnk
      df_cluster_averages_jnk <- df_cluster_averages_jnk^2
      df_cluster_averages_jnk <- rowSums(df_cluster_averages_jnk)
      df_cluster_distances[i,] <- df_cluster_averages_jnk
    }
    
    rm(df_cluster_averages_jnk)
    rm(jnk)
    rm(df_cluster_averages)
    df_cluster_distances[df_cluster_distances==0] <- NA
    df_cluster_distances$ClusterN <- 1:myfiles$prefix[myfile]
    df_cluster_distances <- melt(df_cluster_distances, id="ClusterN")
    names(df_cluster_distances)[2] <- "Distance2ClusterN"
    names(df_cluster_distances)[3] <- "Distance"
    df_cluster_distances$Distance2ClusterN <- gsub("V", "", df_cluster_distances$Distance2ClusterN)
    df_cluster_distances <- remove.factors(df_cluster_distances)
    df_cluster_distances$Distance2ClusterN <- as.numeric(df_cluster_distances$Distance2ClusterN)
    df_cluster_distances <- df_cluster_distances[!is.na(df_cluster_distances$Distance),]
    
    rm(df_data)
    rm(df_som)
    
    names(df_class_distance) <- c("pG", "ClusterN", "Distance")
    df_class_distance$Distance <- as.numeric(df_class_distance$Distance)
    df_class_distance <- df_class_distance %>%
      group_by(ClusterN) %>%
      dplyr::mutate(averageDistance = median(Distance),
                    SizeCluster=n()) %>%
      as.data.frame() %>%
      remove.factors() %>%
      as.data.frame()
    
    df_class_distance$ClusterN <- as.numeric(df_class_distance$ClusterN)
    
    meanDistance_cluster <- as.data.frame(unique(df_class_distance[,c(2,4,5)]))
    
    p0 <- ggplot(df_class_distance, aes(as.factor(ClusterN), Distance))+
      geom_boxplot() +
      scale_y_log10() +
      theme_classic() +
      xlab(paste0("Cluster Number supersom ", myfiles$prefix[myfile])) +
      ylab("within class distance")
    
    p1 <- ggplot(df_cluster_distances, aes(as.factor(ClusterN), Distance))+
      geom_boxplot() +
      scale_y_log10() +
      theme_classic() +
      xlab(paste0("Cluster Number supersom ", myfiles$prefix[myfile])) +
      ylab("distance to other clusters")+
      geom_point(data=meanDistance_cluster, aes(as.factor(ClusterN), averageDistance), color="red") +
      geom_text(data=meanDistance_cluster, aes(x=as.factor(ClusterN), y=0, label=SizeCluster))
    
    saveRDS(df_class_distance, file.path(out_dir2, paste0("7_9_X_", myfiles$prefix[myfile],"_1_", Sys.Date(), "_SOMcluster_proteins_distance.rds")))
    saveRDS(df_cluster_distances, file.path(out_dir2, paste0("7_9_X_", myfiles$prefix[myfile],"_2_", Sys.Date(), "_SOMcluster_btw_cluster_distances.rds")))
    
    pdf(file.path(out_dir2, paste0("7_9_X_", myfiles$prefix[myfile],"_3_", Sys.Date(), "_SOM_plots.pdf")), height = 8, width = 10)
    print(p0)
    print(p1)
    dev.off()
    rm(p0)
    rm(p1)
    
    
    df_class_distance$pG_GO <- gsub(".*\\-(.*)", "\\1", df_class_distance$pG)
    write.table(df_class_distance, 
                file.path(out_dir2, 
                          paste0("7_9_X_", myfiles$prefix[myfile],"_4_", Sys.Date(), 
                                 "_SOMcluster_proteins_distance.txt")),
                quote = F, row.names = F, col.names = T, sep="\t")
  }
  # 7.11.X # GeneOntology different supersom clusters ################################################
  myproteins <- read.delim(file.path(out_dir2, "bg_strains_3308.txt"), header = F)
  
  myproteins <- myproteins$V1
  '%ni%' <- Negate('%in%')
  # # GO-biomart # prepare # DONE
  # pombeBioMartGO <- read.delim("mart_export_Spombe_GO.txt")
  # pombeBioMartGO <- subset(pombeBioMartGO, GO.term.accession != "")
  # pombeBioMartGO_my <- subset(pombeBioMartGO, Gene.stable.ID %in% myproteins)
  # exp_code <- c("EXP", "IDA", "IPI", "IMP", "IGI", "IEP", "HTP", "HDA", "HMP", "HGI", "HEP")
  # pombeBioMartGO_my <- subset(pombeBioMartGO_my, GO.term.evidence.code %ni% c("ND", "NAS"))
  # pombeBioMartGO_exp <- subset(pombeBioMartGO_my, GO.term.evidence.code %in% exp_code)
  # saveRDS(pombeBioMartGO_my, file.path(out_dir2, paste0("7_11_1_", Sys.Date(), "_Spombe_BiomaRtGO_myStrains.rds")))
  # saveRDS(pombeBioMartGO_exp, file.path(out_dir2, paste0("7_11_2_", Sys.Date(), "_Spombe_BiomaRtGO_expOnly_myStrains.rds")))
  # rm(pombeBioMartGO)
  # # GO-pombase_go # prepare # DONE
  # GO <- read.delim("gene_association.pombase.gz", skip=42, header=FALSE)
  # GO_my <- subset(GO, V2 %in% myproteins)
  # rm(GO)
  # exp_code <- c("EXP", "IDA", "IPI", "IMP", "IGI", "IEP", "HTP", "HDA", "HMP", "HGI", "HEP")
  # GO_my <- subset(GO_my, V7 %ni% c("ND", "NAS"))
  # GO_exp <- subset(GO_my, V7 %in% exp_code)
  # GO_my <- GO_my[,c(2,5)]
  # names(GO_my) <- c("gene", "go_id")
  # GO_exp <- GO_exp[,c(2,5)]
  # names(GO_exp) <- c("gene", "go_id")
  # saveRDS(GO_my, file.path(out_dir2, paste0("7_11_3_", Sys.Date(), "_Spombe_pombaseGO_myStrains.rds")))
  # saveRDS(GO_exp, file.path(out_dir2, paste0("7_11_4_", Sys.Date(), "_Spombe_pombaseGO_expOnly_myStrains.rds")))
  # rm(GO_exp)
  # rm(GO_my)
  # my functions
  prepare4go <- function(indice, column){
    jnk <- as.data.frame(strsplit(df[indice, column], ";"))
    if(dim(jnk)[1]>0){
      jnk$is_candidate <- 1
      names(jnk)[1] <- "gene_ids"
      if(length(grep("REV|CON", jnk$gene_ids)) >0){
        jnk <- jnk[-c(grep("REV|CON", jnk$gene_ids)),]
      }
    }
    return(jnk)
  }
  myGO <- function(my_df, my_annot){
    if(dim(my_df)[1] > 0){
      res_hyper_anno = go_enrich(my_df, annotations=my_annot, n_randsets = 100)
      stats = res_hyper_anno[[1]]
      stats <- subset(stats, FWER_overrep<=0.05)} else {stats <- data.frame(ontology=character(), node_id=character())}
    return(stats)
  }
  
  resultMyGO <- function(mygo_df){
    if(dim(mygo_df)[1]>0){
      jnk <- paste0(dim(mygo_df)[1], paste0(mygo_df$node_name, collapse = ":"), collapse = ";")} else {jnk <- NA}
    return(jnk)
  }
  
  # loop over the clusters
  myfile <- list.files(out_dir2, "^7_11_1")
  pombeBioMartGO_my <- readRDS(file.path(out_dir2, myfile))
  
  myfiles <- as.data.frame(list.files(out_dir2, "^7_9_X_.*_1.*SOMcluster_proteins_distance"))
  myfiles$prefix <- gsub("7_9_X_(.*)\\_1.*", "\\1", myfiles$`list.files(out_dir2, "^7_9_X_.*_1.*SOMcluster_proteins_distance")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)  
  myfiles <- myfiles[with(myfiles, order(prefix)), ]
  
  
  for (myfile in 1:dim(myfiles)[1]) {
    print(myfile)
    df_class_distance <- readRDS(file.path(out_dir2, myfiles$filename[myfile]))
    df_class_distance$pG_GO <- gsub(".*\\-(.*)", "\\1", df_class_distance$pG)
    
    df <- df_class_distance[,c(6,2,4,5)]
    names(df)[1] <- "pG"
    rm(df_class_distance)
    
    df <- df %>%
      group_by(ClusterN) %>%
      dplyr::mutate(wtCount=sum(pG=="BIO"),pG=paste0(pG, collapse=";")) %>%
      as.data.frame()
    
    df$wtPercentage <- round((100*(df$wtCount)/df$SizeCluster),2)
    df <- as.data.frame(unique(df))
    df$GO <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_my))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    # now MF
    df$GO_MF <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    pombeBioMartGO_MF <- subset(pombeBioMartGO_my, GO.domain == "molecular_function")
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO_MF[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_MF))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    
    # now BP
    df$GO_BP <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    pombeBioMartGO_BP <- subset(pombeBioMartGO_my, GO.domain == "biological_process")
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO_BP[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_BP))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    
    GO_NA_p <- sum(!is.na(df$GO))
    saveRDS(df, file.path(out_dir2, paste0("7_11_X_5_", Sys.Date(), 
                                           "_Spombe_BiomartGO_4clusters_",myfiles$prefix[myfile],
                                           "_",GO_NA_p,".rds")))
    
  }
  ##########################################################3
  
  
  
  
  
  
  
  
  
  # 7.11.Y # GeneOntology different supersom clusters # pombase annotations################################################
  myproteins <- read.delim(file.path(out_dir2, "bg_strains_3308.txt"), header = F)
  out_dir3 <- "ScreenProteome/7_20190718_strainClusterCor/7_11_Y/"
  myproteins <- myproteins$V1
  '%ni%' <- Negate('%in%')
  # my functions
  prepare4go <- function(indice, column){
    jnk <- as.data.frame(strsplit(df[indice, column], ";"))
    if(dim(jnk)[1]>0){
      jnk$is_candidate <- 1
      names(jnk)[1] <- "gene_ids"
      if(length(grep("REV|CON", jnk$gene_ids)) >0){
        jnk <- jnk[-c(grep("REV|CON", jnk$gene_ids)),]
      }
    }
    return(jnk)
  }
  myGO <- function(my_df, my_annot){
    if(dim(my_df)[1] > 0){
      res_hyper_anno = go_enrich(my_df, annotations=my_annot, n_randsets = 100)
      stats = res_hyper_anno[[1]]
      stats <- subset(stats, FWER_overrep<=0.05)} else {stats <- data.frame(ontology=character(), node_id=character())}
    return(stats)
  }
  
  resultMyGO <- function(mygo_df){
    if(dim(mygo_df)[1]>0){
      jnk <- paste0(dim(mygo_df)[1], paste0(mygo_df$node_name, collapse = ":"), collapse = ";")} else {jnk <- NA}
    return(jnk)
  }
  
  # loop over the clusters
  myfile <- list.files(out_dir2, "^7_11_3")
  pombeBioMartGO_my <- readRDS(file.path(out_dir2, myfile))
  
  myfiles <- as.data.frame(list.files(out_dir3, "^7_9_X_.*_1.*SOMcluster_proteins_distance"))
  myfiles$prefix <- gsub("7_9_X_(.*)\\_1.*", "\\1", myfiles$`list.files(out_dir3, "^7_9_X_.*_1.*SOMcluster_proteins_distance")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)  
  myfiles <- myfiles[with(myfiles, order(prefix, decreasing = T)), ]
  
  
  for (myfile in 1:dim(myfiles)[1]) {
    print(myfile)
    df_class_distance <- readRDS(file.path(out_dir3, myfiles$filename[myfile]))
    df_class_distance$pG_GO <- gsub(".*\\-(.*)", "\\1", df_class_distance$pG)
    
    df <- df_class_distance[,c(6,2,4,5)]
    names(df)[1] <- "pG"
    rm(df_class_distance)
    
    df <- df %>%
      group_by(ClusterN) %>%
      dplyr::mutate(wtCount=sum(pG=="BIO"),pG=paste0(pG, collapse=";")) %>%
      as.data.frame()
    
    df$wtPercentage <- round((100*(df$wtCount)/df$SizeCluster),2)
    df <- as.data.frame(unique(df))
    df$GO <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_my))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    
    GO_NA_p <- sum(!is.na(df$GO[df$GO != "jnk"]))
    saveRDS(df, file.path(out_dir3, paste0("7_11_Y_5_", Sys.Date(), 
                                           "_Spombe_BiomartGO_4clusters_",myfiles$prefix[myfile],
                                           "_",GO_NA_p,".rds")))
    
  }
  ##########################################################3
  
  
  
  
  
  
  
  
  
  
  # 7.12.9.X # gene ontology for the strains targeting these clusters #################################################################
  myfiles <- as.data.frame(list.files(out_dir2, "^7_3"))
  myfiles$prefix <- gsub("7_3_.*\\_(.*)\\_clusters_som.rds", "\\1", myfiles$`list.files(out_dir2, "^7_3")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)
  myfiles <- myfiles[order(myfiles$prefix, decreasing = T),]  
  # my functions
  prepare4go <- function(indice, column){
    jnk <- as.data.frame(strsplit(df[indice, column], ";"))
    if(dim(jnk)[1]>0){
      jnk$is_candidate <- 1
      names(jnk)[1] <- "gene_ids"
      if(length(grep("REV|CON", jnk$gene_ids)) >0){
        jnk <- jnk[-c(grep("REV|CON", jnk$gene_ids)),]
      }
    }
    return(jnk)
  }
  myGO <- function(my_df, my_annot){
    if(dim(my_df)[1] > 0){
      res_hyper_anno = go_enrich(my_df, annotations=my_annot, n_randsets = 100)
      stats = res_hyper_anno[[1]]
      stats <- subset(stats, FWER_overrep<=0.05)} else {stats <- data.frame(ontology=character(), node_id=character())}
    return(stats)
  }
  resultMyGO <- function(mygo_df){
    if(dim(mygo_df)[1]>0){
      jnk <- paste0(dim(mygo_df)[1], paste0(mygo_df$node_name, collapse = ":"), collapse = ";")} else {jnk <- NA}
    return(jnk)
  }
  
  # loop over the clusters
  myfile <- list.files("ScreenProteome/8_20190718_proteinClusterCor/", "^8_11_1")
  pombeBioMartGO_my <- readRDS(file.path("ScreenProteome/8_20190718_proteinClusterCor/", myfile))
  
  for (myfile in 1:dim(myfiles)[1]) {
    print(myfile)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[myfile]))
    
    df_cluster_averages_jnk <- as.data.frame(df_som$codes[[1]])
    df_cluster_averages_jnk$cluster <- rownames(df_cluster_averages_jnk)
    df_cluster_averages_jnk <- melt(df_cluster_averages_jnk, "cluster")
    
    df_cluster_averages_jnk$Strain <- gsub("([^;]*)\\;.*", "\\1", df_cluster_averages_jnk$variable)
    df_cluster_averages_jnk <- df_cluster_averages_jnk[abs(df_cluster_averages_jnk$value) >= 2,]
    
    df <- df_cluster_averages_jnk %>%
      group_by(cluster) %>%
      dplyr::mutate(Strain=paste0(Strain, collapse=";")) %>%
      as.data.frame()
    df <- df[,c(4,1)]
    df <- as.data.frame(unique(df))
    
    df$GO <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_my))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    # now MF
    df$GO_MF <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    pombeBioMartGO_MF <- subset(pombeBioMartGO_my, GO.domain == "molecular_function")
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO_MF[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_MF))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    
    # now BP
    df$GO_BP <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    pombeBioMartGO_BP <- subset(pombeBioMartGO_my, GO.domain == "biological_process")
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO_BP[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_BP))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    
    GO_NA_p <- sum(!is.na(df$GO))
    saveRDS(df, file.path(out_dir2, paste0("7_12_9_X_", Sys.Date(), 
                                           "_Spombe_BiomartGO_4clusters_",myfiles$prefix[myfile],
                                           "_",GO_NA_p,".rds")))
    
  }
  
  # 7.13 # nem for 400 clusters and initial plots for 400 clusters ##################
  myfile <- list.files(out_dir2, "7_11_X_5.*400")
  go_400 <- readRDS(file.path(out_dir2, myfile))
  
  myfiles <- list.files(out_dir2, "^7_3.*400")
  df_som <- readRDS(file.path(out_dir2, myfiles))
    
  df_class_distance <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif))
  names(df_class_distance) <- c("Strain", "ClusterN")  
  df_data <- as.data.frame(df_som$data[[1]])
  df_data$Strain <- rownames(df_data)  
  df_data <- merge(df_data, df_class_distance, by.x="Strain", by.y="Strain", all=FALSE)
  rm(df_som)
  rm(df_class_distance)
  
  go_400 <- go_400[go_400$wtPercentage < 20,]
  df_data <- df_data[df_data$ClusterN %in% go_400$ClusterN,]
  rownames(df_data) <- df_data$Strain
  df_data <- df_data[,-1]
  
  library(nem)
  if(resAndprint){
  pdf(file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 1:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                           "_400_cluster_",mycluster,
                                           ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_11_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 11:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_34_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 34:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_103_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 103:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_128_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 128:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_142_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 142:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_158_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 158:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_204_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 204:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_207_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 207:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_234_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 234:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_240_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 240:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_249_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 249:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_256_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 256:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_259_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 259:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_268_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 268:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_282_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 282:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_288_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 288:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_291_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 291:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_296_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 296:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_311_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 311:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_315_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 315:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_323_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 323:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_327_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 327:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("7_13_nem_331_", Sys.Date(), "_NEM_333_400_clusters.pdf")), height = 8, width = 12)
  for (i in 331:length(go_400$ClusterN)) {
    print(i)
    mycluster <- go_400$ClusterN[i]
    my_df_data <- as.data.frame(t(df_data[df_data$ClusterN == mycluster,1:2889]))
    my_df_data <- remove.factors(my_df_data)
    my_df_data[abs(my_df_data) < 1] <- NA
    my_df_data <- my_df_data[rowSums(is.na(my_df_data)) != (dim(my_df_data)[2]),]
    my_df_data[my_df_data < -1] <- -1
    my_df_data[my_df_data > 1] <- 1
    my_df_data[is.na(my_df_data)] <- 0
    my_df_data <- as.matrix(my_df_data)
    res2 <- nem(my_df_data, inference = "ModuleNetwork")
    p <- plot.nem(res2, remove.singletons=TRUE)
    print(p)
    saveRDS(res2, file.path(out_dir2, paste0("7_13_nem_", Sys.Date(), 
                                             "_400_cluster_",mycluster,
                                             ".rds")))
    
  }
  dev.off()
  }
  # 7.13.X # nem apply to all the clusters #########################################
  
  # 7.14 # decided for 400 clusters # cont working to make figures #########################
  # 7.14.1 # but first make a table in which one they belong to what cluster ###########
  myfiles <- as.data.frame(list.files(out_dir2, "^7_3.*rds"))
  myfiles$prefix <- gsub("7_3_.*\\_(.*)\\_clusters_som.rds", "\\1", myfiles$`list.files(out_dir2, "^7_3.*rds")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)
  myfiles <- myfiles[order(myfiles$prefix, decreasing = F),]  
  
  df_som <- readRDS(file.path(out_dir2, myfiles$filename[1]))
  df_class <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif))
  names(df_class) <- c("pG", "SOM_1")
  
  for (myfile in 2:dim(myfiles)[1]) {
    print(myfile)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[myfile]))
    df_class_distance <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif))
    names(df_class_distance) <- c("pG", paste0("SOM_", myfiles$prefix[myfile]))
    df_class <- merge(df_class, df_class_distance, by=1, all=FALSE)
  }
  rm(df_som)
  rm(df_class_distance)
  saveRDS(df_class, file.path(out_dir2, paste0("7_14_1_", Sys.Date(), "_strains_inWhichCluster_1-400.rds")))
  rm(myfiles)
  rm(df_class)
  # 7.14.2 # sampling based on cutoff 2 check the overlap and expected numbers ###########
  out_dir3 <- "ScreenProteome/7_20190718_strainClusterCor/7_14_2_correlation_strainSimilarity_numbers_check/"
  
  myfile <- list.files(out_dir2, "^7_1_pearson")
  df <- readRDS(file.path(out_dir2, myfile))
  df <- subset(df, nObs>0)
  df$p[df$p == 0] <- min(df$p[df$p != 0], na.rm = T)
  df$p_FDR <- p.adjust(df$p, method = "fdr", n = length(df$p))

  df$p_log <- -log10(df$p)
  df$p_FDR_log <- -log10(df$p_FDR)
  df$cor_abs <- abs(df$cor)
  df <- subset(df, Strain1 != Strain2)
  df <- remove.factors(df)
  
  # annotation files
  # # string #
  # pombeString <- read.delim("4896.protein.links.full.v10.5.txt.gz", sep=" ")
  # pombeString$Gene1 <- gsub("^4896\\.(.*)\\.1", "\\1", pombeString$protein1)
  # pombeString$Gene2 <- gsub("^4896\\.(.*)\\.1", "\\1", pombeString$protein2)
  # myProteins <- as.data.frame(unique(c(df$Strain1, df$Strain2)))
  # names(myProteins) <- "pG"
  # myProteins$WT <- FALSE
  # myProteins$WT[grep("BIO", myProteins$pG)] <- TRUE
  # myProteins <- remove.factors(myProteins)
  # myProteins <- as.data.frame(unique(myProteins[myProteins$WT == FALSE,]))
  # myProteins$strain <- gsub(".*\\-(.*)", "\\1",myProteins$pG)
  # myProteins <- unique(myProteins$strain)
  # 
  # pombeString <- subset(pombeString, Gene1 %in% myProteins)
  # pombeString <- subset(pombeString, Gene2 %in% myProteins)
  # pombeString <- pombeString[,c(17,18,3:16)]
  # pombeString2 <- pombeString[,c(2,1,3:16)]
  # names(pombeString2) <- names(pombeString)
  # pombeString <- rbind(pombeString, pombeString2)
  # pombeString <- unique(pombeString)
  # rm(pombeString2)
  # pombeString$identifier <- paste(pombeString$Gene1, pombeString$Gene2, sep="&")
  # saveRDS(pombeString, file.path(out_dir2, paste0("7_14_2_", Sys.Date(), "_SpombeString_all_myproteins.rds")))
  # # biogrid #
  # pombeBiogrid <- read.delim("BIOGRID-ORGANISM-Schizosaccharomyces_pombe_972h-3.4.160.tab.txt", sep="\t", skip=35)
  # 
  # geentic <- c("Dosage Growth Defect", "Dosage Lethality", "Dosage Rescue", "Negative Genetic", "Phenotypic Enhancement",
  #              "Phenotypic Suppression", "Positive Genetic", "Synthetic Growth Defect", "Synthetic Haploinsufficiency",
  #              "Synthetic Lethality", "Synthetic Rescue")
  # 
  # pombeBiogrid_genetic <- pombeBiogrid[pombeBiogrid$EXPERIMENTAL_SYSTEM %in% geentic,]
  # '%ni%' <- Negate('%in%')
  # pombeBiogrid_physical <- pombeBiogrid[pombeBiogrid$EXPERIMENTAL_SYSTEM %ni% geentic,]
  # 
  # pombeBiogrid_genetic <- subset(pombeBiogrid_genetic, INTERACTOR_A %in% myProteins | INTERACTOR_B %in% myProteins)
  # pombeBiogrid_physical <- subset(pombeBiogrid_physical, INTERACTOR_A %in% myProteins | INTERACTOR_B %in% myProteins)
  # 
  # pombeBiogrid_genetic <- pombeBiogrid_genetic[,c(1,2,7)]
  # pombeBiogrid_genetic2 <- pombeBiogrid_genetic[,c(2,1,3)]
  # names(pombeBiogrid_genetic2) <- names(pombeBiogrid_genetic)
  # pombeBiogrid_genetic <- rbind(pombeBiogrid_genetic, pombeBiogrid_genetic2)
  # pombeBiogrid_genetic <- unique(pombeBiogrid_genetic)
  # rm(pombeBiogrid_genetic2)
  # 
  # pombeBiogrid_physical <- pombeBiogrid_physical[,c(1,2,7)]
  # pombeBiogrid_physical2 <- pombeBiogrid_physical[,c(2,1,3)]
  # names(pombeBiogrid_physical2) <- names(pombeBiogrid_physical)
  # pombeBiogrid_physical <- rbind(pombeBiogrid_physical, pombeBiogrid_physical2)
  # pombeBiogrid_physical <- unique(pombeBiogrid_physical)
  # rm(pombeBiogrid_physical2)
  # 
  # 
  # pombeBiogrid_physical$identifier <- paste(pombeBiogrid_physical$INTERACTOR_A, pombeBiogrid_physical$INTERACTOR_B, sep="&")
  # pombeBiogrid_genetic$identifier <- paste(pombeBiogrid_genetic$INTERACTOR_A, pombeBiogrid_genetic$INTERACTOR_B, sep="&")
  # 
  # pombeBiogrid_physical$infoSource <- "Biogrid_physical"
  # pombeBiogrid_genetic$infoSource <- "Biogrid_genetic"
  # 
  # names(pombeBiogrid_physical)[1:2] <- names(pombeString)[1:2]
  # names(pombeBiogrid_genetic)[1:2] <- names(pombeString)[1:2]
  # 
  # saveRDS(pombeBiogrid_genetic, file.path(out_dir2, paste0("7_14_2_", Sys.Date(), "_SpombeBiogrid_genetic_myproteins.rds")))
  # saveRDS(pombeBiogrid_physical, file.path(out_dir2, paste0("7_14_2_", Sys.Date(), "_SpombeBiogrid_physical_myproteins.rds")))
  # rm(pombeBiogrid)
  myfile <- list.files(out_dir2, "7_14_2.*String")
  pombeString <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "7_14_2.*genetic")
  pombeBiogrid_genetic <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "7_14_2.*physical")
  pombeBiogrid_physical <- readRDS(file.path(out_dir2, myfile))
  rm(myfile)
  df <- df[-c(grep("Bio", rownames(df))),]
  df$Strain1 <- gsub(".*\\-(.*)","\\1", df$Strain1)
  df$Strain2 <- gsub(".*\\-(.*)","\\1", df$Strain2)
  rownames(df) <- paste(df$Strain1, df$Strain2, sep="&")
  
  df <- df[,3:6]

  myR_series <- seq(0.95,0.2,-0.05)
  myR_series <- seq(0.75,0.2,-0.05)
  
  corR2enrichment <- function(df, myR, pombeString, pombeBiogrid_genetic, pombeBiogrid_physical){
    df_signif <- subset(df, cor >= myR & p_FDR <= 0.05)
    df_signif_abs <- subset(df, abs(cor) >= myR & p_FDR <= 0.05)
    
    df_sampling <- data.frame(ko_significant=rownames(df_signif))
    df_sampling_abs <- data.frame(ko_significant=rownames(df_signif_abs))
    
    for (mycount in 1:1000) {
      sample_jnk <- sample(1:dim(df)[1], dim(df_sampling)[1], replace=TRUE)
      mysamples <- rownames(df)[sample_jnk]
      df_sampling <- cbind(df_sampling, mysamples)
      names(df_sampling)[dim(df_sampling)[2]] <- paste0("sampling_", mycount)
      
      sample_jnk <- sample(1:dim(df)[1], dim(df_sampling_abs)[1], replace=TRUE)
      mysamples <- rownames(df)[sample_jnk]
      df_sampling_abs <- cbind(df_sampling_abs, mysamples)
      names(df_sampling_abs)[dim(df_sampling_abs)[2]] <- paste0("sampling_", mycount)
    }
    
    myCounts_df <- data.frame(sample=colnames(df_sampling),
                              InSet_STRING_neighborhood_transferred=NA, 
                              InSet_STRING_fusion=NA, 
                              InSet_STRING_cooccurence=NA, 
                              InSet_STRING_homology=NA, 
                              InSet_STRING_coexpression=NA, 
                              InSet_STRING_coexpression_transferred=NA, 
                              InSet_STRING_experiments=NA, 
                              InSet_STRING_experiments_transferred=NA, 
                              InSet_STRING_database=NA, 
                              InSet_STRING_database_transferred=NA, 
                              InSet_STRING_textmining=NA, 
                              InSet_STRING_textmining_transferred=NA, 
                              InSet_STRING_combined_score=NA, 
                              InSet_Biogrid_genetic=NA,
                              InSet_Biogrid_physical=NA)
    
    myCounts_df_abs <- data.frame(sample=colnames(df_sampling_abs),
                                  InSet_STRING_neighborhood_transferred=NA, 
                                  InSet_STRING_fusion=NA, 
                                  InSet_STRING_cooccurence=NA, 
                                  InSet_STRING_homology=NA, 
                                  InSet_STRING_coexpression=NA, 
                                  InSet_STRING_coexpression_transferred=NA, 
                                  InSet_STRING_experiments=NA, 
                                  InSet_STRING_experiments_transferred=NA, 
                                  InSet_STRING_database=NA, 
                                  InSet_STRING_database_transferred=NA, 
                                  InSet_STRING_textmining=NA, 
                                  InSet_STRING_textmining_transferred=NA, 
                                  InSet_STRING_combined_score=NA, 
                                  InSet_Biogrid_genetic=NA,
                                  InSet_Biogrid_physical=NA)
    
    for (i in 1:dim(myCounts_df)[1]) {
      myCounts_df$InSet_STRING_neighborhood_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$neighborhood_transferred != 0])
      myCounts_df$InSet_STRING_fusion[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$fusion != 0])
      myCounts_df$InSet_STRING_cooccurence[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$cooccurence != 0])
      myCounts_df$InSet_STRING_homology[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$homology != 0])
      myCounts_df$InSet_STRING_coexpression[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression != 0])
      myCounts_df$InSet_STRING_coexpression_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression_transferred != 0])
      myCounts_df$InSet_STRING_experiments[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments != 0])
      myCounts_df$InSet_STRING_experiments_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments_transferred != 0])
      myCounts_df$InSet_STRING_database[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database != 0])
      myCounts_df$InSet_STRING_database_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database_transferred != 0])
      myCounts_df$InSet_STRING_textmining[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining != 0])
      myCounts_df$InSet_STRING_textmining_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining_transferred != 0])
      myCounts_df$InSet_STRING_combined_score[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$combined_score != 0])
      myCounts_df$InSet_Biogrid_genetic[i] <- sum(df_sampling[,i] %in% pombeBiogrid_genetic$identifier)
      myCounts_df$InSet_Biogrid_physical[i] <- sum(df_sampling[,i] %in% pombeBiogrid_physical$identifier)
      
      myCounts_df_abs$InSet_STRING_neighborhood_transferred[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$neighborhood_transferred != 0])
      myCounts_df_abs$InSet_STRING_fusion[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$fusion != 0])
      myCounts_df_abs$InSet_STRING_cooccurence[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$cooccurence != 0])
      myCounts_df_abs$InSet_STRING_homology[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$homology != 0])
      myCounts_df_abs$InSet_STRING_coexpression[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$coexpression != 0])
      myCounts_df_abs$InSet_STRING_coexpression_transferred[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$coexpression_transferred != 0])
      myCounts_df_abs$InSet_STRING_experiments[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$experiments != 0])
      myCounts_df_abs$InSet_STRING_experiments_transferred[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$experiments_transferred != 0])
      myCounts_df_abs$InSet_STRING_database[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$database != 0])
      myCounts_df_abs$InSet_STRING_database_transferred[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$database_transferred != 0])
      myCounts_df_abs$InSet_STRING_textmining[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$textmining != 0])
      myCounts_df_abs$InSet_STRING_textmining_transferred[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$textmining_transferred != 0])
      myCounts_df_abs$InSet_STRING_combined_score[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$combined_score != 0])
      myCounts_df_abs$InSet_Biogrid_genetic[i] <- sum(df_sampling_abs[,i] %in% pombeBiogrid_genetic$identifier)
      myCounts_df_abs$InSet_Biogrid_physical[i] <- sum(df_sampling_abs[,i] %in% pombeBiogrid_physical$identifier)
      
    }
    
    myCounts_df <- melt(myCounts_df, "sample")
    names(myCounts_df)[2] <- "Criteria"
    names(myCounts_df)[3] <- "HowMany"
    myCounts_df$sampleType <- "Significant"
    myCounts_df$sampleType[grep("sampling", myCounts_df$sample)] <- "Random"
    myCounts_df$Criteria <- gsub("InSet_", "", myCounts_df$Criteria)
    myCounts_df <- remove.factors(myCounts_df)
    
    myCounts_df_abs <- melt(myCounts_df_abs, "sample")
    names(myCounts_df_abs)[2] <- "Criteria"
    names(myCounts_df_abs)[3] <- "HowMany"
    myCounts_df_abs$sampleType <- "Significant"
    myCounts_df_abs$sampleType[grep("sampling", myCounts_df_abs$sample)] <- "Random"
    myCounts_df_abs$Criteria <- gsub("InSet_", "", myCounts_df_abs$Criteria)
    myCounts_df_abs <- remove.factors(myCounts_df_abs)
    
    mycriteria <- unique(myCounts_df$Criteria)
    pdf(file.path(out_dir3, paste0("7_14_2_", Sys.Date(), "_R_", myR,"_enrichment.pdf")), height = 8, width = 8)
    for (i in 1:length(mycriteria)) {
      x <- ecdf(subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random")$HowMany)
      y <- x(myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"])
      
      p <- ggplot(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"), 
                  aes(HowMany))+
        geom_density(fill="#e0e0e0")+
        geom_vline(xintercept = myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"], 
                   color="#67001f", size=1.01) +
        theme_classic()+
        geom_hline(yintercept=0, colour="white", size=1) +
        geom_rug(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"),
                 sides="b") +
        coord_cartesian(clip = "off") +
        theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
        xlim(0,max(subset(myCounts_df, Criteria==mycriteria[i])$HowMany))+
        theme(axis.text=element_text(size=12),
              axis.title=element_text(size=14,face="bold"))+
        xlab(gsub("_", " ", mycriteria[i])) +
        ggtitle(paste("p value = ", y, sep=""))
      
      print(p)
    }
    dev.off()
    
    mycriteria <- unique(myCounts_df_abs$Criteria)
    pdf(file.path(out_dir3, paste0("7_14_2_", Sys.Date(), "_abs_R_", myR,"_enrichment.pdf")), height = 8, width = 8)
    for (i in 1:length(mycriteria)) {
      x <- ecdf(subset(myCounts_df_abs, Criteria==mycriteria[i] & sampleType == "Random")$HowMany)
      y <- x(myCounts_df_abs$HowMany[myCounts_df_abs$Criteria==mycriteria[i] & myCounts_df_abs$sampleType != "Random"])
      
      p <- ggplot(data=subset(myCounts_df_abs, Criteria==mycriteria[i] & sampleType == "Random"), 
                  aes(HowMany))+
        geom_density(fill="#e0e0e0")+
        geom_vline(xintercept = myCounts_df_abs$HowMany[myCounts_df_abs$Criteria==mycriteria[i] & myCounts_df_abs$sampleType != "Random"], 
                   color="#67001f", size=1.01) +
        theme_classic()+
        geom_hline(yintercept=0, colour="white", size=1) +
        geom_rug(data=subset(myCounts_df_abs, Criteria==mycriteria[i] & sampleType == "Random"),
                 sides="b") +
        coord_cartesian(clip = "off") +
        theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
        xlim(0,max(subset(myCounts_df_abs, Criteria==mycriteria[i])$HowMany))+
        theme(axis.text=element_text(size=12),
              axis.title=element_text(size=14,face="bold"))+
        xlab(gsub("_", " ", mycriteria[i])) +
        ggtitle(paste("p value = ", y, sep=""))
      
      print(p)
    }
    dev.off()
  }
  
  for (myR in myR_series) {
    print(myR)
    corR2enrichment(df, myR, pombeString, pombeBiogrid_genetic, pombeBiogrid_physical)
  }
  #######################################################################################################################
  # 7.15 # Gene ontology based on the significantly correlating strains ##########################################
  myfile <- list.files(out_dir2, pattern = "^7_7_1.*")
  df_cor <- readRDS(file.path(out_dir2, myfile))
  df_cor <- df_cor[,1:5]
  df_cor$Strain1_ID <- gsub(".*\\-(.*)", "\\1", df_cor$Strain1)
  df_cor$Strain2_ID <- gsub(".*\\-(.*)", "\\1", df_cor$Strain2)
  myproteins <- unique(df_cor$Strain1_ID)
  df_cor <- subset(df_cor, p_pearson <= 0.05)
  df_cor <- subset(df_cor, Strain1 != Strain2)
  df_cor <- subset(df_cor, abs(cor_pearson) >= 0.5)
  df_cor <- df_cor[-grep("BIO", df_cor$Strain1),]
  df_cor <- df_cor[-grep("BIO", df_cor$Strain2),]
  
  df_cor <- df_cor %>%
    group_by(Strain1_ID) %>%
    dplyr::mutate(Strains_significant_cor = paste0(Strain2_ID, collapse = ";")) %>%
    as.data.frame()
  
  df_cor <- as.data.frame(unique(df_cor[,c(6,8)]))
  saveRDS(df_cor, file.path(out_dir2, paste0("7_15_0_", Sys.Date(), "_significantCorrelatingStrains.rds")))
  
  # 7.15.1 # gene ontology #########################################################################################
  '%ni%' <- Negate('%in%')
  # # my functions ##################################################################################################
  prepare4go <- function(indice, column){
    jnk <- as.data.frame(strsplit(df[indice, column], ";"))
    if(dim(jnk)[1]>0){
      jnk$is_candidate <- 1
      names(jnk)[1] <- "gene_ids"
      if(length(grep("REV|CON", jnk$gene_ids)) >0){
        jnk <- jnk[-c(grep("REV|CON", jnk$gene_ids)),]
      }
    }
    jnk <- unique(jnk)
    return(jnk)
  }
  myGO <- function(my_df, my_annot){
    if(dim(my_df)[1] > 0){
      res_hyper_anno = go_enrich(my_df, annotations=my_annot, n_randsets = 100)
      stats = res_hyper_anno[[1]]
      stats <- subset(stats, FWER_overrep<=0.05)} else {stats <- data.frame(ontology=character(), node_id=character())}
    return(stats)
  }
  
  resultMyGO <- function(mygo_df){
    if(dim(mygo_df)[1]>0){
      jnk <- paste0(dim(mygo_df)[1], paste0(mygo_df$node_name, collapse = ":"), collapse = ";")} else {jnk <- NA}
    return(jnk)
  }
  
  # loop over the strains ###########################################################################################
  myfile <- list.files(out_dir2, "^7_11_1")
  pombeBioMartGO_my <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^7_15_0")
  df_cor <- readRDS(file.path(out_dir2, myfile))

  df <- remove.factors(df_cor)
  df <- as.data.frame(df)
  rm(df_cor)
  df$GO <- "jnk"
  
  for (i in 1:dim(df)[1]) {
    tryCatch({
      print(i)
      df$GO[i] <- resultMyGO(myGO(prepare4go(i,2), pombeBioMartGO_my))
      print("done")
    }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
  }
  saveRDS(df, file.path(out_dir2, paste0("7_15_1_", Sys.Date(), "_significantCorrelatingStrains_GO.rds")))
  library(stringr)
  df$N_strains <- str_count(df$Strains_significant_cor, pattern = ";")
  df$N_strains <- 1+ df$N_strains
  saveRDS(df, file.path(out_dir2, paste0("7_15_1_", Sys.Date(), "_significantCorrelatingStrains_GO.rds")))
  
  jnk <- list.files(out_dir2, "7_15_1")
  df <- readRDS(file.path(out_dir2, jnk))
  df$N_terms <- gsub("([0-9]*).*", "\\1", df$GO)
  df$N_terms <- as.numeric(df$N_terms)
  write.table(df, file.path(out_dir2, paste0("7_15_2_", Sys.Date(), "_significantCorrelatingStrains_GO.txt")),
              quote = F, row.names = F, sep="\t")
  
  ################# LEFT here 20190925 ###########################################################################
  # 7.16 # corerlation measure trials again #########################################
  # 7.16.1 # calculate the correlation based on |Z| > 0.5, 1, 1.5, 2 and compare to the original one #############
  myfile <- list.files(path = out_dir2, pattern = "^7_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  
  mydf_05 <- mydf
  mydf_05[abs(mydf_05) <= 0.5] <- NA
  
  mydf_1 <- mydf
  mydf_1[abs(mydf_1) <= 1] <- NA

  mydf_15 <- mydf
  mydf_15[abs(mydf_15) <= 1.5] <- NA
  
  mydf_2 <- mydf
  mydf_2[abs(mydf_2) <= 2] <- NA
  
  corAndPvalue_method <- function(df, myCountSD){
    StrainCor <- corAndPvalue(df, y = NULL, 
                              use = "pairwise.complete.obs", 
                              alternative = c("two.sided", "less", "greater"), 
                              method="pearson")
    
    my_df <- as.data.frame(StrainCor[[1]])
    my_df$Strain <- rownames(my_df)
    my_df_melt <- melt(data = my_df, id="Strain")
    names(my_df_melt) <- c("Strain1", "Strain2", names(StrainCor)[1])
    my_df_melt$identifier <- paste(my_df_melt$Strain1, my_df_melt$Strain2, sep="&")
    rm(my_df)
    rownames(my_df_melt) <- my_df_melt$identifier
    my_df_melt <- my_df_melt[,-4]
    jnk <- c(2,5)
    for (i in jnk) {
      print(i)
      my_df_jnk <- as.data.frame(StrainCor[[i]])
      my_df_jnk$Strain <- rownames(my_df_jnk)
      my_df_jnk_melt <- melt(data = my_df_jnk, id="Strain")
      rm(my_df_jnk)
      names(my_df_jnk_melt) <- c("Strain1", "Strain2", names(StrainCor)[i])
      my_df_jnk_melt$identifier <- paste(my_df_jnk_melt$Strain1, my_df_jnk_melt$Strain2, sep="&")
      rownames(my_df_jnk_melt) <- my_df_jnk_melt$identifier
      my_df_jnk_melt <- my_df_jnk_melt[match(rownames(my_df_melt), rownames(my_df_jnk_melt)), ]
      my_df_jnk_melt <- as.data.frame(my_df_jnk_melt[,3])
      names(my_df_jnk_melt)[1] <- names(StrainCor)[i]
      my_df_melt <- cbind(my_df_melt, my_df_jnk_melt)
    }
    saveRDS(my_df_melt, file.path(out_dir2, paste0("7_16_1_",myCountSD,"_", Sys.Date(), "_corAndPvalue.rds")))
  }
  
  corAndPvalue_method(mydf, "all")
  corAndPvalue_method(mydf_05, "05")
  corAndPvalue_method(mydf_1, "10")
  corAndPvalue_method(mydf_15, "15")
  corAndPvalue_method(mydf_2, "20")
  # 7.16.2 # compare the correlations ##########################################
  myfiles <- list.files(out_dir2, "7_16_1_")
  
  df_all <- readRDS(file.path(out_dir2, myfiles[5]))
  df_05 <- readRDS(file.path(out_dir2, myfiles[1]))
  df_10 <- readRDS(file.path(out_dir2, myfiles[2]))
  df_15 <- readRDS(file.path(out_dir2, myfiles[3]))
  df_20 <- readRDS(file.path(out_dir2, myfiles[4]))
  
  jnk <- as.data.frame(cbind(df_all[,c(1,2,3)],
                             df_05$cor, df_10$cor, df_15$cor, df_20$cor))
  jnk[jnk == "NaN"] <- NA
  names(jnk)[3:7] <- c("c00", "c05", "c10", "c15", "c20")
  jnk_melt <- melt(jnk, c("Strain1", "Strain2"))
  
  jnk_melt$value[is.na(jnk_melt$value)] <- 0
  rm(df_all)
  rm(df_05)
  rm(df_10)
  rm(df_15)
  rm(df_20)
  
  saveRDS(jnk, file.path(out_dir2, paste0("7_16_2_1_", Sys.Date(), "_combined.rds")))
  saveRDS(jnk_melt, file.path(out_dir2, paste0("7_16_2_2_", Sys.Date(), "_combined_melt.rds")))
  
  myfiles <- list.files(out_dir2, "7_16_2_")
  jnk <- readRDS(file.path(out_dir2, myfiles[1]))
  jnk_melt <- readRDS(file.path(out_dir2, myfiles[2]))
  
  p0 <- ggplot(jnk_melt, aes(value)) +
    geom_density(aes(color=variable))
  
  p1 <- ggplot(jnk, aes(c00, c05)) +
    geom_point()
  
  p2 <- ggplot(jnk, aes(c00, c10)) +
    geom_point()
  
  p3 <- ggplot(jnk, aes(c00, c15)) +
    geom_point()
  
  p4 <- ggplot(jnk, aes(c00, c20)) +
    geom_point()
  
  p5 <- ggplot(jnk, aes(c05, c10)) +
    geom_point()
  
  p6 <- ggplot(jnk, aes(c05, c15)) +
    geom_point()
  
  p7 <- ggplot(jnk, aes(c05, c20)) +
    geom_point()
  
  p8 <- ggplot(jnk, aes(c10, c15)) +
    geom_point()
  
  p9 <- ggplot(jnk, aes(c10, c20)) +
    geom_point()
  
  p10 <- ggplot(jnk, aes(c15, c20)) +
    geom_point()

  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_0.png")), p0)
  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_1.png")), p1)
  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_2.png")), p2)
  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_3.png")), p3)
  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_4.png")), p4)
  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_5.png")), p5)
  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_6.png")), p6)
  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_7.png")), p7)
  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_8.png")), p8)
  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_9.png")), p9)
  ggsave(file.path(out_dir2, paste0("7_16_2_3_", Sys.Date(), "_plots_10.png")), p10)
  
  jnk[is.na(jnk)] <- 0
  cor(jnk)
  # and use biweight from wgcna !!! less sensitive to outliers !!! ######
  ######################################################################################################################
  
  
  # now MF
  df$GO_MF <- "jnk"
  df <- remove.factors(df)
  df <- as.data.frame(df)
  pombeBioMartGO_MF <- subset(pombeBioMartGO_my, GO.domain == "molecular_function")
  for (i in 1:dim(df)[1]) {
    tryCatch({
      print(i)
      df$GO_MF[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_MF))
      print("done")
    }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
  }
  
  # now BP
  df$GO_BP <- "jnk"
  df <- remove.factors(df)
  df <- as.data.frame(df)
  pombeBioMartGO_BP <- subset(pombeBioMartGO_my, GO.domain == "biological_process")
  for (i in 1:dim(df)[1]) {
    tryCatch({
      print(i)
      df$GO_BP[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_BP))
      print("done")
    }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
  }
  saveRDS(df, file.path(out_dir2, paste0("8_11_5_", Sys.Date(), "_Spombe_BiomartGO_4clusters.rds")))
  
  
  
  
  ################################################################################################################
  #################################
  
  
  ## check #
 
  # first try with 400 clusters ##########################################
  myfile <- list.files(out_dir2, "400_clusters")
  df_som <- readRDS(file.path(out_dir2, myfile))
  df_class_distance <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif, df_som$distances))
  rm(df_som)
  names(df_class_distance) <- c("Strain", "ClusterNumber", "Distance")
  df_class_distance$StrainType <- "KO"
  df_class_distance$StrainType[grep("WT", df_class_distance$Strain)] <- "WT"
  df_class_distance$Plate <- gsub("Sp([0-9]*)[A-Z]*.*", "\\1", df_class_distance$Strain)
  df_class_distance$Run <- gsub("Sp[0-9][0-9].*([0-9][0-9])\\-[A-Z].*", "\\1", df_class_distance$Strain)
  df_class_distance$KOgene <- gsub("Sp[0-9][0-9].*([0-9][0-9])\\-([A-Z].*)", "\\2", df_class_distance$Strain)
  jnk <- as.data.frame(table(df_class_distance[,c(2,4)]))
  jnk <- jnk[jnk$Freq != 0,]
  jnk <- as.data.frame(table(jnk$ClusterNumber))
  
  
  df_class_distance <- df_class_distance %>%
    
  
  
  #######################################################################
  ############
}
if(proteinCorCluster){
  out_dir2 <- "ScreenProteome/8_20190718_proteinClusterCor/"
  if(createCorSOM){
  # 8 # idea is to use all possible measures to assess similarities of expression profiles of proteins #####################
  # use Zscores as measures for clustering correlation etc. 
  # and all the proteins measured without power filtering
  myfile <- list.files(path = out_dir, pattern = "^6_11_1.*melt.*rds")
  df_screen <- readRDS(file.path(out_dir, myfile))
  # make a dataframe from the Zscore
  mydf <- df_screen[,c(2,3,5)]
  mydf <- dcast(mydf, Proteins ~ Strain, value.var="Zscore")
  rownames(mydf) <- mydf$Proteins
  mydf <- mydf[,-1]
  mydf <- mydf[rowSums(!is.na(mydf))!=0,]
  rm(df_screen)
  mydf <- as.data.frame(t(mydf))
  saveRDS(mydf, file.path(out_dir2, paste0("8_0_", Sys.Date(), "_mydf_Zscore.rds")))
  rm(mydf)
  # 8.1 # correlations P|S|K ###############################################################################################
  myfile <- list.files(path = out_dir2, pattern = "^8_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  
  corAndPvalue_method <- function(df, cor_method){
    proteinCor <- corAndPvalue(df, y = NULL, 
                               use = "pairwise.complete.obs", 
                               alternative = c("two.sided", "less", "greater"), 
                               method=cor_method)
    
    my_df <- as.data.frame(proteinCor[[1]])
    my_df$Protein <- rownames(my_df)
    my_df_melt <- melt(data = my_df, id="Protein")
    names(my_df_melt) <- c("Protein1", "Protein2", names(proteinCor)[1])
    my_df_melt$identifier <- paste(my_df_melt$Protein1, my_df_melt$Protein2, sep="&")
    rm(my_df)
    rownames(my_df_melt) <- my_df_melt$identifier
    my_df_melt <- my_df_melt[,-4]
    jnk <- c(2,5)
    for (i in jnk) {
      print(i)
      my_df_jnk <- as.data.frame(proteinCor[[i]])
      my_df_jnk$Protein <- rownames(my_df_jnk)
      my_df_jnk_melt <- melt(data = my_df_jnk, id="Protein")
      rm(my_df_jnk)
      names(my_df_jnk_melt) <- c("Protein1", "Protein2", names(proteinCor)[i])
      my_df_jnk_melt$identifier <- paste(my_df_jnk_melt$Protein1, my_df_jnk_melt$Protein2, sep="&")
      rownames(my_df_jnk_melt) <- my_df_jnk_melt$identifier
      my_df_jnk_melt <- my_df_jnk_melt[match(rownames(my_df_melt), rownames(my_df_jnk_melt)), ]
      my_df_jnk_melt <- as.data.frame(my_df_jnk_melt[,3])
      names(my_df_jnk_melt)[1] <- names(proteinCor)[i]
      my_df_melt <- cbind(my_df_melt, my_df_jnk_melt)
    }
    saveRDS(my_df_melt, file.path(out_dir2, paste0("8_1_",cor_method,"_", Sys.Date(), "_corAndPvalue.rds")))
  }
  
  corAndPvalue_method(mydf, "pearson")
  corAndPvalue_method(mydf, "spearman")
  corAndPvalue_method(mydf, "kendall")
  # wt
  mydf_wt <- mydf[grep("WT", rownames(mydf)), ]
  
  corAndPvalue_method <- function(df, cor_method){
    proteinCor <- corAndPvalue(df, y = NULL, 
                               use = "pairwise.complete.obs", 
                               alternative = c("two.sided", "less", "greater"), 
                               method=cor_method)
    
    my_df <- as.data.frame(proteinCor[[1]])
    my_df$Protein <- rownames(my_df)
    my_df_melt <- melt(data = my_df, id="Protein")
    names(my_df_melt) <- c("Protein1", "Protein2", names(proteinCor)[1])
    my_df_melt$identifier <- paste(my_df_melt$Protein1, my_df_melt$Protein2, sep="&")
    rm(my_df)
    rownames(my_df_melt) <- my_df_melt$identifier
    my_df_melt <- my_df_melt[,-4]
    jnk <- c(2,5)
    for (i in jnk) {
      print(i)
      my_df_jnk <- as.data.frame(proteinCor[[i]])
      my_df_jnk$Protein <- rownames(my_df_jnk)
      my_df_jnk_melt <- melt(data = my_df_jnk, id="Protein")
      rm(my_df_jnk)
      names(my_df_jnk_melt) <- c("Protein1", "Protein2", names(proteinCor)[i])
      my_df_jnk_melt$identifier <- paste(my_df_jnk_melt$Protein1, my_df_jnk_melt$Protein2, sep="&")
      rownames(my_df_jnk_melt) <- my_df_jnk_melt$identifier
      my_df_jnk_melt <- my_df_jnk_melt[match(rownames(my_df_melt), rownames(my_df_jnk_melt)), ]
      my_df_jnk_melt <- as.data.frame(my_df_jnk_melt[,3])
      names(my_df_jnk_melt)[1] <- names(proteinCor)[i]
      my_df_melt <- cbind(my_df_melt, my_df_jnk_melt)
    }
    saveRDS(my_df_melt, file.path(out_dir2, paste0("8_1_wt_",cor_method,"_", Sys.Date(), "_corAndPvalue.rds")))
  }
  
  corAndPvalue_method(mydf_wt, "pearson")
  corAndPvalue_method(mydf_wt, "spearman")
  corAndPvalue_method(mydf_wt, "kendall")
  
  # ko
  mydf_ko <- mydf[-c(grep("WT", rownames(mydf))), ]
  
  corAndPvalue_method <- function(df, cor_method){
    proteinCor <- corAndPvalue(df, y = NULL, 
                               use = "pairwise.complete.obs", 
                               alternative = c("two.sided", "less", "greater"), 
                               method=cor_method)
    
    my_df <- as.data.frame(proteinCor[[1]])
    my_df$Protein <- rownames(my_df)
    my_df_melt <- melt(data = my_df, id="Protein")
    names(my_df_melt) <- c("Protein1", "Protein2", names(proteinCor)[1])
    my_df_melt$identifier <- paste(my_df_melt$Protein1, my_df_melt$Protein2, sep="&")
    rm(my_df)
    rownames(my_df_melt) <- my_df_melt$identifier
    my_df_melt <- my_df_melt[,-4]
    jnk <- c(2,5)
    for (i in jnk) {
      print(i)
      my_df_jnk <- as.data.frame(proteinCor[[i]])
      my_df_jnk$Protein <- rownames(my_df_jnk)
      my_df_jnk_melt <- melt(data = my_df_jnk, id="Protein")
      rm(my_df_jnk)
      names(my_df_jnk_melt) <- c("Protein1", "Protein2", names(proteinCor)[i])
      my_df_jnk_melt$identifier <- paste(my_df_jnk_melt$Protein1, my_df_jnk_melt$Protein2, sep="&")
      rownames(my_df_jnk_melt) <- my_df_jnk_melt$identifier
      my_df_jnk_melt <- my_df_jnk_melt[match(rownames(my_df_melt), rownames(my_df_jnk_melt)), ]
      my_df_jnk_melt <- as.data.frame(my_df_jnk_melt[,3])
      names(my_df_jnk_melt)[1] <- names(proteinCor)[i]
      my_df_melt <- cbind(my_df_melt, my_df_jnk_melt)
    }
    saveRDS(my_df_melt, file.path(out_dir2, paste0("8_1_ko_",cor_method,"_", Sys.Date(), "_corAndPvalue.rds")))
  }
  
  corAndPvalue_method(mydf_ko, "pearson")
  corAndPvalue_method(mydf_ko, "spearman")
  corAndPvalue_method(mydf_ko, "kendall")
  
  
  
  # 8.2 # partial correlations P ###############################################################################################
  myfile <- list.files(path = out_dir2, pattern = "^8_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  
  ProteinCor <- partial.r(mydf, use = "pairwise.complete.obs", method="pearson")
  
  my_df <- as.data.frame(ProteinCor)
  my_df$Protein <- rownames(my_df)
  my_df_melt <- melt(data = my_df, id="Protein")
  names(my_df_melt) <- c("Protein1", "Protein2", "partialR")
  my_df_melt$identifier <- paste(my_df_melt$Protein1, my_df_melt$Protein2, sep="&")
  rm(my_df)
  rownames(my_df_melt) <- my_df_melt$identifier
  my_df_melt <- my_df_melt[,-4]
  saveRDS(my_df_melt, file.path(out_dir2, paste0("8_2_pearson_", Sys.Date(), "_partialR.rds")))
  # 8.3 # clustering with som ###############################################################################################
  library(kohonen)
  
  myfile <- list.files(path = out_dir2, pattern = "^8_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  mydf <- as.matrix(t(mydf))
  
  for (i in 1:20) {
    print(i)
    df_som <- supersom(mydf, grid = somgrid(i, i, "hexagonal"), rlen = 1000, normalizeDataLayers = FALSE, maxNA.fraction = 3769)
    saveRDS(df_som, file.path(out_dir2, paste0("8_3_", Sys.Date(), "_", i*i,"_clusters_som.rds")))
  }
  # 8.7 # overlap of the strains they are regulated together ########################################################
  # 8.7.1 # put the correlation of the pairs together first
  myfiles <- list.files(out_dir2, pattern = "^8_1.*")
  
  df_jnk <- readRDS(file.path(out_dir2, myfiles[1]))
  names(df_jnk) <- paste(names(df_jnk), "_kendall", sep="")
  df_jnk$identifier <- rownames(df_jnk)
  df_jnk <- df_jnk[,3:6]
  
  df_jnk2 <- readRDS(file.path(out_dir2, myfiles[2]))
  names(df_jnk2) <- paste(names(df_jnk2), "_pearson", sep="")
  df_jnk2$identifier <- rownames(df_jnk2)
  df_jnk2 <- df_jnk2[,3:6]
  
  df_jnk <- merge(df_jnk, df_jnk2, by.x="identifier", by.y="identifier", all=FALSE)
  
  df_jnk2 <- readRDS(file.path(out_dir2, myfiles[3]))
  names(df_jnk2)[3:5] <- paste(names(df_jnk2)[3:5], "_spearman", sep="")
  df_jnk2$identifier <- rownames(df_jnk2)
  
  df_jnk <- merge(df_jnk, df_jnk2, by.x="identifier", by.y="identifier", all=FALSE)
  rm(df_jnk2)
  saveRDS(df_jnk, file.path(out_dir2, paste0("8_7_1_", Sys.Date(), "_all_corAndPvalue.rds")))
  rm(df_jnk)
  rm(myfiles)
  # 8.7.2 # integrate the coregulation information
  myfile <- list.files(path = out_dir, pattern = "^6_12_1.*melt.*rds")
  df_screen <- readRDS(file.path(out_dir, myfile))
  df_screen <- df_screen[!is.na(df_screen$NormalizedValue),]
  # myfile <- list.files(path = out_dir2, pattern = "^8_7_1.*rds")
  # df_cor <- readRDS(file.path(out_dir2, myfile))
  # df_cor <- df_cor[,c(8,9,7,5,6,10,11,2,3)]
  # names(df_cor)[3] <- "nObservations"
  # saveRDS(df_cor, file.path(out_dir2, paste0("8_7_1_", Sys.Date(), "_all_corAndPvalue.rds")))

  myfile <- list.files(path = out_dir2, pattern = "^8_7_1.*rds")
  df_cor <- readRDS(file.path(out_dir2, myfile))
  
  df_cor$Protein1_nMeasured <- NA
  df_cor$Protein2_nMeasured <- NA
  
  df_cor$Protein1_nRegulated_P <- NA
  df_cor$Protein2_nRegulated_P <- NA
  
  df_cor$Protein1_nRegulated_ecdf <- NA
  df_cor$Protein2_nRegulated_ecdf <- NA
  
  df_cor$common_nMeasured <- NA
  df_cor$common_nRegulated_P <- NA
  df_cor$common_nRegulated_ecdf <- NA

  df_cor$common_nRegulated_P_sameDir <- NA
  df_cor$common_nRegulated_ecdf_sameDir <- NA
  df_cor <- remove.factors(df_cor)
  
  for (i in 1:dim(df_cor)[1]) {
    print(i)
    p1 <- df_cor$Protein1[i]
    p2 <- df_cor$Protein2[i]
    df_screen_jnk1 <- subset(df_screen, Proteins==p1)
    df_screen_jnk2 <- subset(df_screen, Proteins==p2)
    
    df_cor$Protein1_nMeasured[i] <- dim(df_screen_jnk1)[1]
    df_cor$Protein2_nMeasured[i] <- dim(df_screen_jnk2)[1]
    
    df_cor$Protein1_nRegulated_P[i] <- sum(df_screen_jnk1$myFDR_changing == TRUE)
    df_cor$Protein2_nRegulated_P[i] <- sum(df_screen_jnk2$myFDR_changing == TRUE)
    
    df_cor$Protein1_nRegulated_ecdf[i] <- sum(df_screen_jnk1$myecdf_changing == TRUE)
    df_cor$Protein2_nRegulated_ecdf[i] <- sum(df_screen_jnk2$myecdf_changing == TRUE)
    
    df_cor$common_nMeasured[i] <- length(intersect(df_screen_jnk1$Strain, 
                                                   df_screen_jnk2$Strain))
    df_cor$common_nRegulated_P[i] <- length(intersect(df_screen_jnk1$Strain[df_screen_jnk1$myFDR_changing == TRUE], 
                                                      df_screen_jnk2$Strain[df_screen_jnk2$myFDR_changing == TRUE]))
    df_cor$common_nRegulated_ecdf[i] <- length(intersect(df_screen_jnk1$Strain[df_screen_jnk1$myecdf_changing == TRUE], 
                                                         df_screen_jnk2$Strain[df_screen_jnk2$myecdf_changing == TRUE]))
    
    df_screen_jnk1_1 <- subset(df_screen_jnk1, myFDR_changing==TRUE)
    df_screen_jnk2_1 <- subset(df_screen_jnk2, myFDR_changing==TRUE)
    df_screen_jnk1_1$identifier <- paste(df_screen_jnk1_1$Strain, df_screen_jnk1_1$myFDR_changing_category)
    df_screen_jnk2_1$identifier <- paste(df_screen_jnk2_1$Strain, df_screen_jnk2_1$myFDR_changing_category)
    df_cor$common_nRegulated_P_sameDir[i] <- length(intersect(df_screen_jnk1_1$identifier, 
                                                              df_screen_jnk2_1$identifier))
    
    df_screen_jnk1_1 <- subset(df_screen_jnk1, myecdf_changing==TRUE)
    df_screen_jnk2_1 <- subset(df_screen_jnk2, myecdf_changing==TRUE)
    df_screen_jnk1_1$identifier <- paste(df_screen_jnk1_1$Strain, df_screen_jnk1_1$myecdf_changing_category)
    df_screen_jnk2_1$identifier <- paste(df_screen_jnk2_1$Strain, df_screen_jnk2_1$myecdf_changing_category)
    df_cor$common_nRegulated_ecdf_sameDir[i] <- length(intersect(df_screen_jnk1_1$identifier, 
                                                                 df_screen_jnk2_1$identifier))
    
  }
  saveRDS(df_cor, file.path(out_dir2, paste0("8_7_2_", Sys.Date(), "_all_corAndPvalue_commonRegulation.rds")))
  
  # 8.8 # check the som clusters and grouping #######################################################################
  myfiles <- as.data.frame(list.files(out_dir2, pattern = "^8_3.*"))
  myfiles$nCluster <- NA
  names(myfiles)[1] <- "filename"
  myfiles$nCluster <- gsub("^8_3_2019-07-[0-9]*\\_([0-9]*)\\_clusters_som.rds$", "\\1", myfiles$filename)
  myfiles$nCluster <- as.numeric(myfiles$nCluster)
  # size of the groups
  myfile <- list.files(path = out_dir2, pattern = "^8_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  
  mydf <- as.data.frame(colnames(mydf))
  
  for (i in 1:dim(myfiles)[1]) {
    print(i)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[i]))
    jnk <- df_som$unit.classif
    mydf <- cbind(mydf, jnk)
    names(mydf)[dim(mydf)[2]] <- paste0("somCluster_", myfiles$nCluster[i])
  }
  rm(df_som)
  
  names(mydf)[1] <- "pG"
  mydf <- melt(mydf, id="pG")
  mydf$nCluster <- gsub("somCluster\\_([0-9]*)", "\\1", mydf$variable)
  
  mydf_sizes <- as.data.frame(table(mydf[,3:4]))
  mydf_sizes <- mydf_sizes[mydf_sizes$Freq != 0,]
  names(mydf_sizes)[1] <- "whichCluster"
  mydf_sizes <- remove.factors(mydf_sizes)
  
  for (i in 1:dim(mydf_sizes)[2]) {
    mydf_sizes[,i] <- as.numeric(mydf_sizes[,i])
  }
  
  p0 <- ggplot(mydf_sizes, aes(as.factor(nCluster), Freq)) +
    geom_boxplot() +
    theme_classic() +
    xlab("Number of som clusters") +
    ylab("Number of proteins in each cluster - log10") +
    theme(axis.text = element_text(size = 12),
          axis.title = element_text(size=14))
  
  p1 <- ggplot(mydf_sizes, aes(as.factor(nCluster), Freq)) +
    geom_boxplot() +
    scale_y_log10() +
    theme_classic() +
    xlab("Number of som clusters") +
    ylab("Number of proteins in each cluster - log10") +
    theme(axis.text = element_text(size = 12),
          axis.title = element_text(size=14))
  
  p2 <- ggplot(mydf_sizes, aes(as.factor(nCluster), Freq)) +
    geom_boxplot() +
    theme_classic() +
    xlab("Number of som clusters") +
    ylab("Number of proteins in each cluster - log10") +
    theme(axis.text = element_text(size = 12),
          axis.title = element_text(size=14)) +
    ylim(0,500)
  df_keep <- mydf
  names(df_keep) <- c("pG", "somCluster", "whichCluster", "somClusterNumber")
  # distance within or between the groups
  myfile <- list.files(path = out_dir2, pattern = "^8_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  
  mydf <- as.data.frame(colnames(mydf))
  
  for (i in 1:dim(myfiles)[1]) {
    print(i)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[i]))
    df_som_jnk <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif, df_som$distances))
    names(df_som_jnk) <- c("pG", paste0("Cluster_",myfiles$nCluster[i]), paste0("Distance_",myfiles$nCluster[i]))
    mydf <- merge(mydf, df_som_jnk, by=1, all=FALSE)
  }
  rm(df_som)
  rm(df_som_jnk)
  names(mydf)[1] <- "pG"
  col2keep <- grep("Distance", names(mydf))
  mydf <- mydf[,c(1,col2keep)]
  mydf <- melt(mydf, id="pG")
  mydf$nCluster <- gsub("Distance\\_([0-9]*)", "\\1", mydf$variable)
  names(mydf)[3] <- "Distance"
  
  mydf$identifier <- paste(mydf$pG, mydf$nCluster)
  df_keep$identifier <- paste(df_keep$pG, df_keep$somClusterNumber)
  
  df_keep <- df_keep[,c(5,1,3)]
  mydf <- mydf[,c(5,4,3)]
  
  df_keep <- merge(df_keep, mydf, by.x="identifier", by.y="identifier", all=FALSE)
  rm(mydf)
  df_keep <- df_keep[,2:5]
  names(df_keep)[3] <- "SOM_nCluster"
  df_keep <- remove.factors(df_keep)
  
  saveRDS(df_keep, file.path(out_dir2, paste0("8_8_1_", Sys.Date(), "_Sizes_Distances_SOM.rds")))
  
  for (i in 2:dim(df_keep)[2]) {
    df_keep[,i] <- as.numeric(df_keep[,i])
  }
  
  df_keep <- df_keep %>%
    group_by(whichCluster, SOM_nCluster) %>%
    dplyr::mutate(AverageDistance = mean(as.numeric(Distance)),
                  Size = n()) %>%
    as.data.frame()
  
  df_keep <- df_keep %>%
    group_by(whichCluster, SOM_nCluster) %>%
    dplyr::mutate(Q3Distance = quantile(as.numeric(Distance),0.75)[[1]]) %>%
    as.data.frame()
  
  df_keep <- df_keep %>%
    group_by(whichCluster, SOM_nCluster) %>%
    dplyr::mutate(Q3Distance_keep = AverageDistance<Q3Distance) %>%
    as.data.frame()
  
  df_keep <- df_keep %>%
    group_by(SOM_nCluster, Q3Distance_keep) %>%
    dplyr::mutate(Q3Distance_keep_size = n()) %>%
    as.data.frame()
  
  
  df_keep <- df_keep %>%
    group_by(SOM_nCluster) %>%
    dplyr::mutate(AverageDistance_median = median(AverageDistance),
                  Size_median = median(Size)) %>%
    as.data.frame()
  
  
  p3 <- ggplot(df_keep, aes(as.factor(SOM_nCluster), Q3Distance_keep_size))+
    geom_point(aes(color=Q3Distance_keep), size=4) +
    theme_classic()

  
  
  p4 <- ggplot(df_keep, aes(AverageDistance))+
    geom_density() +
    scale_x_log10() +
    theme_classic() +
    facet_wrap(~SOM_nCluster, scales = "free")
  
  
  p5 <- ggplot(df_keep, aes(Size))+
    geom_density() +
    scale_x_log10() +
    theme_classic() +
    facet_wrap(~SOM_nCluster, scales = "free")
  
  p6 <- ggplot(data=as.data.frame(unique(df_keep[,c(3,10,11)])), aes(Size_median, AverageDistance_median)) +
    geom_point(aes(color=as.factor(SOM_nCluster))) + 
    scale_y_log10() +
    scale_x_log10() +
    guides(color=FALSE) +
    geom_label_repel(aes(label=SOM_nCluster))+
    theme_classic()

  p7 <- ggplot(data=as.data.frame(unique(df_keep[,c(3,10,11)])), aes(Size_median, AverageDistance_median)) +
    geom_point(aes(color=as.factor(SOM_nCluster))) + 
    guides(color=FALSE) +
    geom_label_repel(aes(label=SOM_nCluster)) +
    xlim(0,200) +
    ylim(0,2000) +
    theme_classic()
  
  saveRDS(df_keep, file.path(out_dir2, paste0("8_8_1_", Sys.Date(), "_Sizes_Distances_SOM.rds")))
  
  # add the correlation information as well
  myfile <- list.files(out_dir2, "^8_7_1")
  df_cor <- readRDS(file.path(out_dir2, myfile))
  
  myclusters <- unique(df_keep$SOM_nCluster)
  
  myclusters_df <- data.frame(SameCluster=character(), 
                              median_pearson= numeric(),
                              median_spearman=numeric(),
                              median_kendall=numeric(),
                              NCluster=numeric())
  
  for (i in 1:length(myclusters)) {
    print(i)
    df_jnk <- subset(df_keep, SOM_nCluster==myclusters[i])
    df_jnk <- df_jnk[,1:2]
    
    names(df_jnk)[2] <- "Protein1_cluster"
    df_cor_jnk <- merge(df_cor, df_jnk, by.x="Protein1", by.y="pG", all=FALSE)
    names(df_jnk)[2] <- "Protein2_cluster"
    df_cor_jnk <- merge(df_cor_jnk, df_jnk, by.x="Protein2", by.y="pG", all=FALSE)
    
    df_cor_jnk$SameCluster <- df_cor_jnk$Protein1_cluster == df_cor_jnk$Protein2_cluster
    
    df_cor_jnk <- df_cor_jnk %>%
      group_by(SameCluster) %>%
      dplyr::mutate(median_pearson=median(cor_pearson, na.rm = T),
                    median_spearman=median(cor_spearman, na.rm = T),
                    median_kendall=median(cor_kendall, na.rm = T)) %>%
      as.data.frame()
    
    df_cor_jnk <- as.data.frame(unique(df_cor_jnk[,12:15]))
    
    df_cor_jnk$NCluster <- myclusters[i]
    myclusters_df <- as.data.frame(rbind(myclusters_df, df_cor_jnk))
    }

  saveRDS(myclusters_df, file.path(out_dir2, paste0("8_8_2_", Sys.Date(), "_SOMcluster_correlations.rds")))
  
  myclusters_df <- melt(myclusters_df, id=c("SameCluster", "NCluster"))
  myclusters_df <- remove.factors(myclusters_df)
  myclusters_df$NCluster <- as.numeric(myclusters_df$NCluster)
  
  p8 <- ggplot(myclusters_df, aes(as.factor(NCluster), value))+
    geom_point(aes(color=SameCluster), size=4) +
    theme_classic()+
    facet_grid(variable~.)
  # save the plots
  pdf(file.path(out_dir2, paste0("8_8_3_", Sys.Date(), "_SOM_plots.pdf")), height = 8, width = 10)
  print(p0)
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  print(p5)
  print(p6)
  print(p7)
  print(p8)
  dev.off()
  rm(df_cor)
  rm(df_cor_jnk)
  rm(df_jnk)
  rm(df_keep)
  rm(jnk)
  rm(myclusters_df)
  rm(mydf_sizes)
  rm(myfiles)
  rm(p0)
  rm(p1)
  rm(p2)
  rm(p3)
  rm(p4)
  rm(p5)
  rm(p6)
  rm(p7)
  rm(p8)
  }
  if(clusters==36){
  # 8.9 # work with supersom 36 clusters #######################################
  myfile <- list.files(out_dir2, "36_clusters")
  df_som <- readRDS(file.path(out_dir2, myfile))
  
  df_class_distance <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif, df_som$distances))
  
  df_cluster_averages <- as.data.frame(df_som$codes[[1]])
  df_data <- as.data.frame(df_som$data[[1]])
  
  df_cluster_distances <- as.data.frame(matrix(NA, nrow=36, ncol=36))
  
  rownames(df_cluster_distances) <- rownames(df_cluster_averages)
  colnames(df_cluster_distances) <- rownames(df_cluster_averages)
  for (i in 1:dim(df_cluster_distances)[1]) {
    print(i)
    df_cluster_averages_jnk <- df_cluster_averages
    jnk <- as.data.frame(matrix(as.numeric(rep(as.numeric(df_cluster_averages_jnk[i,]),36)), 
                                nrow = dim(df_cluster_averages_jnk)[1], 
                  ncol = dim(df_cluster_averages_jnk)[2], byrow = TRUE))
    jnk <- remove.factors(jnk)
    df_cluster_averages_jnk <- df_cluster_averages_jnk - jnk
    df_cluster_averages_jnk <- df_cluster_averages_jnk^2
    df_cluster_averages_jnk <- rowSums(df_cluster_averages_jnk)
    df_cluster_distances[i,] <- df_cluster_averages_jnk
  }
  rm(df_cluster_averages_jnk)
  rm(jnk)
  rm(df_cluster_averages)
  df_cluster_distances[df_cluster_distances==0] <- NA
  df_cluster_distances$ClusterN <- 1:36
  df_cluster_distances <- melt(df_cluster_distances, id="ClusterN")
  names(df_cluster_distances)[2] <- "Distance2ClusterN"
  names(df_cluster_distances)[3] <- "Distance"
  df_cluster_distances$Distance2ClusterN <- gsub("V", "", df_cluster_distances$Distance2ClusterN)
  df_cluster_distances <- remove.factors(df_cluster_distances)
  df_cluster_distances$Distance2ClusterN <- as.numeric(df_cluster_distances$Distance2ClusterN)
  df_cluster_distances <- df_cluster_distances[!is.na(df_cluster_distances$Distance),]
  
  rm(df_data)
  rm(df_som)
  
  names(df_class_distance) <- c("pG", "ClusterN", "Distance")
  df_class_distance$Distance <- as.numeric(df_class_distance$Distance)
  df_class_distance <- df_class_distance %>%
    group_by(ClusterN) %>%
    dplyr::mutate(averageDistance = median(Distance),
                  SizeCluster=n()) %>%
    as.data.frame() %>%
    remove.factors() %>%
    as.data.frame()
  
  df_class_distance$ClusterN <- as.numeric(df_class_distance$ClusterN)
  
  meanDistance_cluster <- as.data.frame(unique(df_class_distance[,c(2,4,5)]))
  
  p0 <- ggplot(df_class_distance, aes(as.factor(ClusterN), Distance))+
    geom_boxplot() +
    scale_y_log10() +
    theme_classic() +
    xlab("Cluster Number supersom_36") +
    ylab("within class distance")
  
  p1 <- ggplot(df_cluster_distances, aes(as.factor(ClusterN), Distance))+
    geom_boxplot() +
    scale_y_log10() +
    theme_classic() +
    xlab("Cluster Number supersom_36") +
    ylab("distance to other clusters")+
    geom_point(data=meanDistance_cluster, aes(as.factor(ClusterN), averageDistance), color="red") +
    geom_text(data=meanDistance_cluster, aes(x=as.factor(ClusterN), y=60000, label=SizeCluster))
  
  saveRDS(df_class_distance, file.path(out_dir2, paste0("8_9_1_", Sys.Date(), "_SOMcluster_proteins_distance.rds")))
  saveRDS(df_cluster_distances, file.path(out_dir2, paste0("8_9_2_", Sys.Date(), "_SOMcluster_btw_cluster_distances.rds")))
  rm(meanDistance_cluster)
  rm(df_cluster_distances)
  
  pdf(file.path(out_dir2, paste0("8_9_3_", Sys.Date(), "_SOM_36_plots.pdf")), height = 8, width = 10)
  print(p0)
  print(p1)
  dev.off()
  rm(p0)
  rm(p1)
  myfile <- list.files(out_dir2, "^8_9_1")
  df_class_distance <- readRDS(file.path(out_dir2, myfile))
  df_class_distance$pG_GO <- gsub("([^;]*)\\;.*", "\\1", df_class_distance$pG)
  write.table(df_class_distance, 
              file.path(out_dir2, 
                        paste0("8_9_1_", Sys.Date(), 
                               "_SOMcluster_proteins_distance.txt")),
              quote = F, row.names = F, col.names = T, sep="\t")
  
  # 8.10 # GeneOntology supersom_36 #######################################
  myproteins <- splitColumnBySep(df_class_distance, "pG")
  myproteins <- myproteins$pG
  myproteins <- myproteins[-c(grep("REV|CON", myproteins))]
  '%ni%' <- Negate('%in%')
  # GO-biomart # prepare # DONE
  # pombeBioMartGO <- read.delim("mart_export_Spombe_GO.txt")
  # pombeBioMartGO <- subset(pombeBioMartGO, GO.term.accession != "")
  # pombeBioMartGO_my <- subset(pombeBioMartGO, Gene.stable.ID %in% myproteins)
  # exp_code <- c("EXP", "IDA", "IPI", "IMP", "IGI", "IEP", "HTP", "HDA", "HMP", "HGI", "HEP")
  # pombeBioMartGO_my <- subset(pombeBioMartGO_my, GO.term.evidence.code %ni% c("ND", "NAS"))
  # pombeBioMartGO_exp <- subset(pombeBioMartGO_my, GO.term.evidence.code %in% exp_code)
  # saveRDS(pombeBioMartGO_my, file.path(out_dir2, paste0("8_10_1_", Sys.Date(), "_Spombe_BiomaRtGO_myProteins.rds")))
  # saveRDS(pombeBioMartGO_exp, file.path(out_dir2, paste0("8_10_2_", Sys.Date(), "_Spombe_BiomaRtGO_expOnly_myProteins.rds")))
  # rm(pombeBioMartGO)
  # GO-pombase_go # prepare # DONE
  # GO <- read.delim("gene_association.pombase.gz", skip=42, header=FALSE)
  # GO_my <- subset(GO, V2 %in% myproteins)
  # rm(GO)
  # exp_code <- c("EXP", "IDA", "IPI", "IMP", "IGI", "IEP", "HTP", "HDA", "HMP", "HGI", "HEP")
  # GO_my <- subset(GO_my, V7 %ni% c("ND", "NAS"))
  # GO_exp <- subset(GO_my, V7 %in% exp_code)
  # GO_my <- GO_my[,c(2,5)]
  # names(GO_my) <- c("gene", "go_id")
  # GO_exp <- GO_exp[,c(2,5)]
  # names(GO_exp) <- c("gene", "go_id")
  # saveRDS(GO_my, file.path(out_dir2, paste0("8_10_3_", Sys.Date(), "_Spombe_pombaseGO_myProteins.rds")))
  # saveRDS(GO_exp, file.path(out_dir2, paste0("8_10_4_", Sys.Date(), "_Spombe_pombaseGO_expOnly_myProteins.rds")))
  # rm(GO_exp)
  # rm(GO_my)
  # my functions
  prepare4go <- function(indice, column){
    jnk <- as.data.frame(strsplit(df[indice, column], ";"))
    if(dim(jnk)[1]>0){
      jnk$is_candidate <- 1
      names(jnk)[1] <- "gene_ids"
      if(length(grep("REV|CON", jnk$gene_ids)) >0){
      jnk <- jnk[-c(grep("REV|CON", jnk$gene_ids)),]
      }
      }
    return(jnk)
  }
  myGO <- function(my_df, my_annot){
    if(dim(my_df)[1] > 0){
      res_hyper_anno = go_enrich(my_df, annotations=my_annot, n_randsets = 100)
      stats = res_hyper_anno[[1]]
      stats <- subset(stats, FWER_overrep<=0.05)} else {stats <- data.frame(ontology=character(), node_id=character())}
    return(stats)
  }
  
  resultMyGO <- function(mygo_df){
    if(dim(mygo_df)[1]>0){
      jnk <- paste0(dim(mygo_df)[1], paste0(mygo_df$node_name, collapse = ":"), collapse = ";")} else {jnk <- NA}
    return(jnk)
  }
  # loop over the clusters
  myfile <- list.files(out_dir2, "^8_10_1")
  pombeBioMartGO_my <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_9_1")
  df_class_distance <- readRDS(file.path(out_dir2, myfile))
  # use biomart for now
  # myfile <- list.files(out_dir2, "^8_10_3")
  # pombaseGO_my <- readRDS(file.path(out_dir2, myfile))
  df <- df_class_distance[,c(1,2,4,5)]
  rm(df_class_distance)
  df <- df %>%
    group_by(ClusterN) %>%
    dplyr::mutate(pG=paste0(pG, collapse=";")) %>%
    as.data.frame()
  df <- as.data.frame(unique(df))
  df$GO <- "jnk"
  df <- remove.factors(df)
  df <- as.data.frame(df)
  
  for (i in 1:dim(df)[1]) {
    tryCatch({
      print(i)
      df$GO[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_my))
      print("done")
    }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
  }
  # now MF
  df$GO_MF <- "jnk"
  df <- remove.factors(df)
  df <- as.data.frame(df)
  pombeBioMartGO_MF <- subset(pombeBioMartGO_my, GO.domain == "molecular_function")
  for (i in 1:dim(df)[1]) {
    tryCatch({
      print(i)
      df$GO_MF[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_MF))
      print("done")
    }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
  }

  # now BP
  df$GO_BP <- "jnk"
  df <- remove.factors(df)
  df <- as.data.frame(df)
  pombeBioMartGO_BP <- subset(pombeBioMartGO_my, GO.domain == "biological_process")
  for (i in 1:dim(df)[1]) {
    tryCatch({
      print(i)
      df$GO_BP[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_BP))
      print("done")
    }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
  }
  saveRDS(df, file.path(out_dir2, paste0("8_10_5_", Sys.Date(), "_Spombe_BiomartGO_4clusters.rds")))
  unlink(list.dirs("C:/Users/PROTEO~1/AppData/Local/Temp/"), recursive = TRUE)
  # 8.11 # GeneOntology supersom_36 # only 1st protein in the group ########
  myfile <- list.files(out_dir2, "^8_9_1")
  df_class_distance <- readRDS(file.path(out_dir2, myfile))
  df_class_distance$pG_GO <- gsub("([^;]*)\\;.*", "\\1", df_class_distance$pG)
  
  myproteins <- df_class_distance$pG_GO
  '%ni%' <- Negate('%in%')
  # GO-biomart # prepare # DONE
  # pombeBioMartGO <- read.delim("mart_export_Spombe_GO.txt")
  # pombeBioMartGO <- subset(pombeBioMartGO, GO.term.accession != "")
  # pombeBioMartGO_my <- subset(pombeBioMartGO, Gene.stable.ID %in% myproteins)
  # exp_code <- c("EXP", "IDA", "IPI", "IMP", "IGI", "IEP", "HTP", "HDA", "HMP", "HGI", "HEP")
  # pombeBioMartGO_my <- subset(pombeBioMartGO_my, GO.term.evidence.code %ni% c("ND", "NAS"))
  # pombeBioMartGO_exp <- subset(pombeBioMartGO_my, GO.term.evidence.code %in% exp_code)
  # saveRDS(pombeBioMartGO_my, file.path(out_dir2, paste0("8_11_1_", Sys.Date(), "_Spombe_BiomaRtGO_myProteins.rds")))
  # saveRDS(pombeBioMartGO_exp, file.path(out_dir2, paste0("8_11_2_", Sys.Date(), "_Spombe_BiomaRtGO_expOnly_myProteins.rds")))
  # rm(pombeBioMartGO)
  # GO-pombase_go # prepare # DONE
  # GO <- read.delim("gene_association.pombase.gz", skip=42, header=FALSE)
  # GO_my <- subset(GO, V2 %in% myproteins)
  # rm(GO)
  # exp_code <- c("EXP", "IDA", "IPI", "IMP", "IGI", "IEP", "HTP", "HDA", "HMP", "HGI", "HEP")
  # GO_my <- subset(GO_my, V7 %ni% c("ND", "NAS"))
  # GO_exp <- subset(GO_my, V7 %in% exp_code)
  # GO_my <- GO_my[,c(2,5)]
  # names(GO_my) <- c("gene", "go_id")
  # GO_exp <- GO_exp[,c(2,5)]
  # names(GO_exp) <- c("gene", "go_id")
  # saveRDS(GO_my, file.path(out_dir2, paste0("8_11_3_", Sys.Date(), "_Spombe_pombaseGO_myProteins.rds")))
  # saveRDS(GO_exp, file.path(out_dir2, paste0("8_11_4_", Sys.Date(), "_Spombe_pombaseGO_expOnly_myProteins.rds")))
  # rm(GO_exp)
  # rm(GO_my)
  # my functions
  prepare4go <- function(indice, column){
    jnk <- as.data.frame(strsplit(df[indice, column], ";"))
    if(dim(jnk)[1]>0){
      jnk$is_candidate <- 1
      names(jnk)[1] <- "gene_ids"
      if(length(grep("REV|CON", jnk$gene_ids)) >0){
        jnk <- jnk[-c(grep("REV|CON", jnk$gene_ids)),]
      }
    }
    return(jnk)
  }
  myGO <- function(my_df, my_annot){
    if(dim(my_df)[1] > 0){
      res_hyper_anno = go_enrich(my_df, annotations=my_annot, n_randsets = 100)
      stats = res_hyper_anno[[1]]
      stats <- subset(stats, FWER_overrep<=0.05)} else {stats <- data.frame(ontology=character(), node_id=character())}
    return(stats)
  }
  
  resultMyGO <- function(mygo_df){
    if(dim(mygo_df)[1]>0){
      jnk <- paste0(dim(mygo_df)[1], paste0(mygo_df$node_name, collapse = ":"), collapse = ";")} else {jnk <- NA}
    return(jnk)
  }

  # loop over the clusters
  myfile <- list.files(out_dir2, "^8_11_1")
  pombeBioMartGO_my <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_9_1")
  df_class_distance <- readRDS(file.path(out_dir2, myfile))
  df_class_distance$pG_GO <- gsub("([^;]*)\\;.*", "\\1", df_class_distance$pG)
  
  # use biomart for now
  # myfile <- list.files(out_dir2, "^8_10_3")
  # pombaseGO_my <- readRDS(file.path(out_dir2, myfile))
  df <- df_class_distance[,c(6,2,4,5)]
  names(df)[1] <- "pG"
  rm(df_class_distance)
  df <- df %>%
    group_by(ClusterN) %>%
    dplyr::mutate(pG=paste0(pG, collapse=";")) %>%
    as.data.frame()
  df <- as.data.frame(unique(df))
  df$GO <- "jnk"
  df <- remove.factors(df)
  df <- as.data.frame(df)
  
  for (i in 1:dim(df)[1]) {
    tryCatch({
      print(i)
      df$GO[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_my))
      print("done")
    }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
  }
  # now MF
  df$GO_MF <- "jnk"
  df <- remove.factors(df)
  df <- as.data.frame(df)
  pombeBioMartGO_MF <- subset(pombeBioMartGO_my, GO.domain == "molecular_function")
  for (i in 1:dim(df)[1]) {
    tryCatch({
      print(i)
      df$GO_MF[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_MF))
      print("done")
    }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
  }
  
  # now BP
  df$GO_BP <- "jnk"
  df <- remove.factors(df)
  df <- as.data.frame(df)
  pombeBioMartGO_BP <- subset(pombeBioMartGO_my, GO.domain == "biological_process")
  for (i in 1:dim(df)[1]) {
    tryCatch({
      print(i)
      df$GO_BP[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_BP))
      print("done")
    }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
  }
  saveRDS(df, file.path(out_dir2, paste0("8_11_5_", Sys.Date(), "_Spombe_BiomartGO_4clusters.rds")))

  
  # 8.12 # figures for the paper ######################################
  # 8.12.1 # correlation of correlations # stopped for now way too big for a scatterplot #############################
  library("plot3D")
  myfile <- list.files(out_dir2, "^8_1.*pearson")
  c_wt <- readRDS(file.path(out_dir2, myfile[3]))
  c_ko <- readRDS(file.path(out_dir2, myfile[1]))
  c_all <- readRDS(file.path(out_dir2, myfile[2]))
  
  c_all$identifier <- rownames(c_all)
  c_all <- c_all[,c(6,3)]
  names(c_all)[2] <- "cor_all"
  
  c_wt$identifier <- rownames(c_wt)
  c_wt <- c_wt[,c(6,3)]
  names(c_wt)[2] <- "cor_wt"
  
  c_ko$identifier <- rownames(c_ko)
  c_ko <- c_ko[,c(6,3)]
  names(c_ko)[2] <- "cor_ko"
  
  cor_combined <- merge(c_ko, c_wt, by=1, all=FALSE)
  cor_combined <- merge(cor_combined, c_all, by=1, all=FALSE)
  rm(c_all)
  rm(c_ko)
  rm(c_wt)
  cor_combined <- as.data.frame(cor_combined)
  cor_combined <- remove.factors(cor_combined)
  cor_combined[cor_combined == "NaN"] <- NA
  saveRDS(cor_combined, file.path(out_dir2, paste0("8_12_1_1_", Sys.Date(), "_protein_cor_pearson_combined.rds")))
  
  # scatter3D(x=cor_combined$cor_ko, 
  #           y=cor_combined$cor_wt, 
  #           z=cor_combined$cor_all, colvar = NULL, col = NULL, add = FALSE)
  # 8.12.2 # volcanoplot for the ko correlations of proteins #########
  myfile <- list.files(out_dir2, "^8_1_ko_pearson")
  c_ko <- readRDS(file.path(out_dir2, myfile))
  c_ko[c_ko=="NaN"] <- NA
  c_ko$p[c_ko$p == 0] <- min(c_ko$p[c_ko$p != 0], na.rm = T)
  c_ko$p_l10 <- -log10(c_ko$p)
  ggplot(c_ko, aes(cor))+
    geom_density()
  ggplot(c_ko, aes(p_l10))+
    geom_density()
  
  p1 <- ggplot(c_ko, aes(cor, p_l10))+
    geom_density_2d() +
    xlab("Pearson R") +
    ylab("-log10(p-value)")+
    theme_classic()
  
  saveRDS(c_ko, file.path(out_dir2, paste0("8_12_2_", Sys.Date(), "_ko_pearson_corAndPvalue.rds")))
  ggsave(filename = file.path(out_dir2, paste0("8_12_2_2_", Sys.Date(), "_ko_cor_P.pdf")), 
         plot = p1,
         width = 4,
         height = 4) # not saving too big try again later
  # 8.12.3 # sampling for significant interactions correlations #########
  myfile <- list.files(out_dir2, "^8_12_2")
  df <- readRDS(file.path(out_dir2, myfile[2]))
  
  df2 <- subset(df, nObs>0)
  rm(df)
  df2$p_FDR <- p.adjust(df2$p, method = "fdr", n = length(df2$p))
  df2 <- df2[,-6]
  df2 <- df2[,c(1,2,5,3,4,6)]
  df2$p_log <- -log10(df2$p)
  df2$p_FDR_log <- -log10(df2$p_FDR)
  df2$cor_abs <- abs(df2$cor)
  df2 <- subset(df2, Protein1 != Protein2)
  
  df_cor <- cor(df2[,3:9])
  df_cor_partial <- partial.r(df2[,c(3,9,8)], method="pearson")
  
  # cor(df2$p_log, df2$nObs)
  # cor(df2$cor, df2$nObs)
  # cor(df2$p, abs(df2$cor))
  # cor(df2$p_log, abs(df2$cor))
  # 
  # cor(df2$p_FDR, df2$nObs)
  # cor(df2$p_FDR, abs(df2$cor))
  
  nodes <- as.data.frame(rownames(df_cor_partial))
  nodes$id <- rownames(nodes)
  nodes <- nodes[,2:1]
  names(nodes)[2] <- "label"
  
  
  edges <- melt(df_cor_partial)
  edges <- as.data.frame(edges)
  edges <- remove.factors(edges)
  names(edges) <- c("source", "destination", "weight")
  edges[edges=="p_FDR_log"] <- "p"
  edges[edges=="cor_abs"] <- "|cor|"
  my_network <- network(edges, vertex.attr = nodes, 
                        matrix.type = "edgelist", 
                        directed=FALSE, ignore.eval = FALSE)
  
  # df_cor_partial <- as.matrix(df_cor_partial)
  # diag(df_cor_partial) <- 0
  # g<-network.initialize(3)    #Initialize the network
  # network.adjacency(df_cor_partial,g)
  # 
  # my_network <- network(df_cor_partial, matrix.type = "adjacency", ignore.eval = FALSE)
  p2 <- ggplot(my_network, aes(x = x, y = y, xend = xend, yend = yend)) +
    geom_edges(aes(color=as.factor(sign(weight))), size=2) +
    geom_edgelabel(aes(label=round(weight,2), 
                       color=as.factor(sign(weight))), size=10) +
    geom_nodetext(aes(label = vertex.names),
                   fontface = "bold", size=10, color="black") +
    theme_blank() +
    scale_color_manual(values=c("#67001f", "#1a1a1a"))+
    guides(color=FALSE)
  rm(edges)
  rm(nodes)
  rm(df_cor_partial)
  rm(df_cor)
  df <- df2
  rm(df2)
  ggsave(filename = file.path(out_dir2, paste0("8_12_3_0_", Sys.Date(), "_pcor_nObsCorP_.pdf")), 
         plot = p2,
         width = 4,
         height = 4)
  # group the pairs based on observation quantiles
  df$nObs_group <- 1
  # set groups for number of observations, 100 groups
  for (i in 1:99) {
    print(i)
    df$nObs_group[df$nObs > quantile(df$nObs, i/100)] <- i+1
  }
  
  saveRDS(df, file.path(out_dir2, paste0("8_12_3_1_", Sys.Date(), "_ko_pearson_grouped.rds")))
  # calculate possibility of being significant
  df$nObs_group_signifPossible <- NA
  jnk <- unique(df$nObs_group)
  
  for (i in jnk) {
    print(i)
    jnk2 <- sum(df$p_FDR[df$nObs_group == i] <= 0.05, na.rm=TRUE)/ length(df$p_FDR[df$nObs_group == i])
    df$nObs_group_signifPossible[df$nObs_group == i] <- jnk2
  }
  saveRDS(df, file.path(out_dir2, paste0("8_12_3_1_", Sys.Date(), "_ko_pearson_grouped.rds")))
  
  df_signif <- subset(df, abs(cor) >=0.8 & p_FDR <= 0.05)
  # sampling based on ko's
  df_jnk <- unique(df[,c(10,11)])
  df_jnk$numberSample <- round(dim(df_signif)[1]*df_jnk$nObs_group_signifPossible/sum(df_jnk$nObs_group_signifPossible),0)
  df_sampling_ko <- data.frame(ko_significant=rownames(df_signif))
  for (mycount in 1:1000) {
    print(mycount)
    mysamples <- NULL
    for (i in 1:dim(df_jnk)[1]) {
      df2_subset <- subset(df, nObs_group == df_jnk$nObs_group[i])
      sample_jnk <- sample(1:dim(df2_subset)[1], df_jnk$numberSample[i], replace=FALSE)
      mysamples <- c(mysamples, rownames(df2_subset)[sample_jnk])
    }
    sample_jnk <- sample(1:length(mysamples), dim(df_sampling_ko)[1], replace=FALSE)
    mysamples <- mysamples[sample_jnk]
    
    df_sampling_ko <- cbind(df_sampling_ko, mysamples)
    names(df_sampling_ko)[dim(df_sampling_ko)[2]] <- paste0("sampling_", mycount)
  }
  
  saveRDS(df_sampling_ko, file.path(out_dir2, paste0("8_12_3_2_", Sys.Date(), "_df_sampling_08.rds")))
  rm(df_jnk)
  rm(df2)
  rm(df2_subset)
  # 8.12.4 # significant interactions correlations #########
  myfile <- list.files(out_dir2, "^8_12_3_2_")
  df_sampling <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_12_3_1_")
  df <- readRDS(file.path(out_dir2, myfile))
  df <- remove.factors(df)
  # 8.12.4.1 # STRING interactions # ALL ######################
  pombeString <- read.delim("4896.protein.links.full.v10.5.txt.gz", sep=" ")
  pombeString$Gene1 <- gsub("^4896\\.(.*)\\.1", "\\1", pombeString$protein1)
  pombeString$Gene2 <- gsub("^4896\\.(.*)\\.1", "\\1", pombeString$protein2)
  
  myProteins <- as.data.frame(unique(c(df$Protein1, df$Protein2)))
  names(myProteins) <- "pG"
  myProteins <- splitColumnBySep(myProteins, "pG")
  myProteins <- unique(myProteins[-c(grep("REV|CON", myProteins$pG)),])
  pombeString <- subset(pombeString, Gene1 %in% myProteins)
  pombeString <- subset(pombeString, Gene2 %in% myProteins)
  pombeString <- pombeString[,c(17,18,3:16)]
  pombeString2 <- pombeString[,c(2,1,3:16)]
  names(pombeString2) <- names(pombeString)
  pombeString <- rbind(pombeString, pombeString2)
  pombeString <- unique(pombeString)
  rm(pombeString2)
  pombeString$identifier <- paste(pombeString$Gene1, pombeString$Gene2, sep="&")
  saveRDS(pombeString, file.path(out_dir2, paste0("8_12_4_1_", Sys.Date(), "_SpombeString_all_myproteins.rds")))
  
  # 8.12.4.2 # BIOGRID ###################################
  pombeBiogrid <- read.delim("BIOGRID-ORGANISM-Schizosaccharomyces_pombe_972h-3.4.160.tab.txt", sep="\t", skip=35)
  
  geentic <- c("Dosage Growth Defect", "Dosage Lethality", "Dosage Rescue", "Negative Genetic", "Phenotypic Enhancement",
               "Phenotypic Suppression", "Positive Genetic", "Synthetic Growth Defect", "Synthetic Haploinsufficiency",
               "Synthetic Lethality", "Synthetic Rescue")
  
  pombeBiogrid_genetic <- pombeBiogrid[pombeBiogrid$EXPERIMENTAL_SYSTEM %in% geentic,]
  '%ni%' <- Negate('%in%')
  pombeBiogrid_physical <- pombeBiogrid[pombeBiogrid$EXPERIMENTAL_SYSTEM %ni% geentic,]
  
  pombeBiogrid_genetic <- subset(pombeBiogrid_genetic, INTERACTOR_A %in% myProteins | INTERACTOR_B %in% myProteins)
  pombeBiogrid_physical <- subset(pombeBiogrid_physical, INTERACTOR_A %in% myProteins | INTERACTOR_B %in% myProteins)
  
  pombeBiogrid_genetic <- pombeBiogrid_genetic[,c(1,2,7)]
  pombeBiogrid_genetic2 <- pombeBiogrid_genetic[,c(2,1,3)]
  names(pombeBiogrid_genetic2) <- names(pombeBiogrid_genetic)
  pombeBiogrid_genetic <- rbind(pombeBiogrid_genetic, pombeBiogrid_genetic2)
  pombeBiogrid_genetic <- unique(pombeBiogrid_genetic)
  rm(pombeBiogrid_genetic2)
  
  pombeBiogrid_physical <- pombeBiogrid_physical[,c(1,2,7)]
  pombeBiogrid_physical2 <- pombeBiogrid_physical[,c(2,1,3)]
  names(pombeBiogrid_physical2) <- names(pombeBiogrid_physical)
  pombeBiogrid_physical <- rbind(pombeBiogrid_physical, pombeBiogrid_physical2)
  pombeBiogrid_physical <- unique(pombeBiogrid_physical)
  rm(pombeBiogrid_physical2)
  
  
  pombeBiogrid_physical$identifier <- paste(pombeBiogrid_physical$INTERACTOR_A, pombeBiogrid_physical$INTERACTOR_B, sep="&")
  pombeBiogrid_genetic$identifier <- paste(pombeBiogrid_genetic$INTERACTOR_A, pombeBiogrid_genetic$INTERACTOR_B, sep="&")
  
  pombeBiogrid_physical$infoSource <- "Biogrid_physical"
  pombeBiogrid_genetic$infoSource <- "Biogrid_genetic"
  
  names(pombeBiogrid_physical)[1:2] <- names(pombeString)[1:2]
  names(pombeBiogrid_genetic)[1:2] <- names(pombeString)[1:2]
  
  saveRDS(pombeBiogrid_genetic, file.path(out_dir2, paste0("8_12_4_2_1_", Sys.Date(), "_SpombeBiogrid_genetic_myproteins.rds")))
  saveRDS(pombeBiogrid_physical, file.path(out_dir2, paste0("8_12_4_2_2_", Sys.Date(), "_SpombeBiogrid_physical_myproteins.rds")))
  rm(pombeBiogrid)
  # 8.12.4.3 # test how many of them real ###############################################################################
  myCounts_df <- data.frame(sample=colnames(df_sampling),
                            NumberInteractions=dim(df_sampling)[1], 
                            InSet_STRING_neighborhood_transferred=NA, 
                            OutOf_STRING_neighborhood_transferred=sum(pombeString$neighborhood_transferred != 0),
                            InSet_STRING_fusion=NA, 
                            OutOf_STRING_fusion=sum(pombeString$fusion != 0),
                            InSet_STRING_cooccurence=NA, 
                            OutOf_STRING_cooccurence=sum(pombeString$cooccurence != 0),
                            InSet_STRING_homology=NA, 
                            OutOf_STRING_homology=sum(pombeString$homology != 0),
                            InSet_STRING_coexpression=NA, 
                            OutOf_STRING_coexpression=sum(pombeString$coexpression != 0),
                            InSet_STRING_coexpression_transferred=NA, 
                            OutOf_STRING_coexpression_transferred=sum(pombeString$coexpression_transferred != 0),
                            InSet_STRING_experiments=NA, 
                            OutOf_STRING_experiments=sum(pombeString$experiments != 0),
                            InSet_STRING_experiments_transferred=NA, 
                            OutOf_STRING_experiments_transferred=sum(pombeString$experiments_transferred != 0),
                            InSet_STRING_database=NA, 
                            OutOf_STRING_database=sum(pombeString$database != 0),
                            InSet_STRING_database_transferred=NA, 
                            OutOf_STRING_database_transferred=sum(pombeString$database_transferred != 0),
                            InSet_STRING_textmining=NA, 
                            OutOf_STRING_textmining=sum(pombeString$textmining != 0),
                            InSet_STRING_textmining_transferred=NA, 
                            OutOf_STRING_textmining_transferred=sum(pombeString$textmining_transferred != 0),
                            InSet_STRING_combined_score=NA, 
                            OutOf_STRING_combined_score=sum(pombeString$combined_score != 0),
                            InSet_Biogrid_genetic=NA, OutOf_Biogrid_genetic=dim(pombeBiogrid_genetic)[1],
                            InSet_Biogrid_physical=NA, OutOf_Biogrid_physical=dim(pombeBiogrid_physical)[1])
  rm(df)
  for (i in 1:dim(myCounts_df)[1]) {
    print(i)
    myCounts_df$InSet_STRING_neighborhood_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$neighborhood_transferred != 0])
    myCounts_df$InSet_STRING_fusion[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$fusion != 0])
    myCounts_df$InSet_STRING_cooccurence[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$cooccurence != 0])
    myCounts_df$InSet_STRING_homology[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$homology != 0])
    myCounts_df$InSet_STRING_coexpression[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression != 0])
    myCounts_df$InSet_STRING_coexpression_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression_transferred != 0])
    myCounts_df$InSet_STRING_experiments[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments != 0])
    myCounts_df$InSet_STRING_experiments_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments_transferred != 0])
    myCounts_df$InSet_STRING_database[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database != 0])
    myCounts_df$InSet_STRING_database_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database_transferred != 0])
    myCounts_df$InSet_STRING_textmining[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining != 0])
    myCounts_df$InSet_STRING_textmining_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining_transferred != 0])
    myCounts_df$InSet_STRING_combined_score[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$combined_score != 0])
    
    myCounts_df$InSet_Biogrid_genetic[i] <- sum(df_sampling[,i] %in% pombeBiogrid_genetic$identifier)
    myCounts_df$InSet_Biogrid_physical[i] <- sum(df_sampling[,i] %in% pombeBiogrid_physical$identifier)
  }
  saveRDS(myCounts_df, file.path(out_dir2, paste0("8_12_4_3_1_", Sys.Date(), "_mycounts_myproteins.rds")))
  rm(df_sampling)
  rm(pombeBiogrid_genetic)
  rm(pombeBiogrid_physical)
  rm(pombeString)
  
  myfile <- list.files(out_dir2, "^8_12_4_3_1")
  myCounts_df <- readRDS(file.path(out_dir2, myfile))
  myCounts_df <- myCounts_df[,c(1, grep("InSet", names(myCounts_df)))]
  myCounts_df <- melt(myCounts_df, "sample")
  names(myCounts_df)[2] <- "Criteria"
  names(myCounts_df)[3] <- "HowMany"
  myCounts_df$sampleType <- "Significant"
  myCounts_df$sampleType[grep("sampling", myCounts_df$sample)] <- "Random"
  myCounts_df$Criteria <- gsub("InSet_", "", myCounts_df$Criteria)
  myCounts_df <- remove.factors(myCounts_df)
  
  mycriteria <- unique(myCounts_df$Criteria)
  
  pdf(file.path(out_dir2, paste0("8_12_4_3_2_", Sys.Date(), "_EnrichedInteractionPlots.pdf")), height = 8, width = 8)
  for (i in 1:length(mycriteria)) {
    x <- ecdf(subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random")$HowMany)
    y <- x(myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"])
    
    p <- ggplot(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"), 
                aes(HowMany))+
      geom_density(fill="#e0e0e0")+
      geom_vline(xintercept = myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"], 
                 color="#67001f", size=1.01) +
      theme_classic()+
      geom_hline(yintercept=0, colour="white", size=1) +
      geom_rug(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"),
               sides="b") +
      coord_cartesian(clip = "off") +
      theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
      xlim(0,max(subset(myCounts_df, Criteria==mycriteria[i])$HowMany))+
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      xlab(gsub("_", " ", mycriteria[i])) +
      ggtitle(paste("p value = ", y, sep=""))
    
    print(p)
  }
  dev.off()

  
  # 8.12.5 # significant interactions correlations notgrouped #########
  myfile <- list.files(out_dir2, "^8_12_3_2_")
  df_sampling <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_12_3_1_")
  df <- readRDS(file.path(out_dir2, myfile))
  df <- remove.factors(df)
  # 8.12.5.1 # STRING interactions # ALL ######################
  pombeString <- read.delim("4896.protein.links.full.v10.5.txt.gz", sep=" ")
  pombeString$Gene1 <- gsub("^4896\\.(.*)\\.1", "\\1", pombeString$protein1)
  pombeString$Gene2 <- gsub("^4896\\.(.*)\\.1", "\\1", pombeString$protein2)
  
  myProteins <- unique(c(df$Protein1, df$Protein2))
  pombeString <- subset(pombeString, Gene1 %in% myProteins)
  pombeString <- subset(pombeString, Gene2 %in% myProteins)
  pombeString <- pombeString[,c(17,18,3:16)]
  pombeString2 <- pombeString[,c(2,1,3:16)]
  names(pombeString2) <- names(pombeString)
  pombeString <- rbind(pombeString, pombeString2)
  pombeString <- unique(pombeString)
  rm(pombeString2)
  pombeString$identifier <- paste(pombeString$Gene1, pombeString$Gene2, sep="&")
  saveRDS(pombeString, file.path(out_dir2, paste0("8_12_5_1_", Sys.Date(), "_SpombeString_all_myproteins.rds")))
  
  # 8.12.5.2 # BIOGRID ###################################
  pombeBiogrid <- read.delim("BIOGRID-ORGANISM-Schizosaccharomyces_pombe_972h-3.4.160.tab.txt", sep="\t", skip=35)
  
  geentic <- c("Dosage Growth Defect", "Dosage Lethality", "Dosage Rescue", "Negative Genetic", "Phenotypic Enhancement",
               "Phenotypic Suppression", "Positive Genetic", "Synthetic Growth Defect", "Synthetic Haploinsufficiency",
               "Synthetic Lethality", "Synthetic Rescue")
  
  pombeBiogrid_genetic <- pombeBiogrid[pombeBiogrid$EXPERIMENTAL_SYSTEM %in% geentic,]
  '%ni%' <- Negate('%in%')
  pombeBiogrid_physical <- pombeBiogrid[pombeBiogrid$EXPERIMENTAL_SYSTEM %ni% geentic,]
  
  pombeBiogrid_genetic <- subset(pombeBiogrid_genetic, INTERACTOR_A %in% myProteins | INTERACTOR_B %in% myProteins)
  pombeBiogrid_physical <- subset(pombeBiogrid_physical, INTERACTOR_A %in% myProteins | INTERACTOR_B %in% myProteins)
  
  pombeBiogrid_genetic <- pombeBiogrid_genetic[,c(1,2,7)]
  pombeBiogrid_genetic2 <- pombeBiogrid_genetic[,c(2,1,3)]
  names(pombeBiogrid_genetic2) <- names(pombeBiogrid_genetic)
  pombeBiogrid_genetic <- rbind(pombeBiogrid_genetic, pombeBiogrid_genetic2)
  pombeBiogrid_genetic <- unique(pombeBiogrid_genetic)
  rm(pombeBiogrid_genetic2)
  
  pombeBiogrid_physical <- pombeBiogrid_physical[,c(1,2,7)]
  pombeBiogrid_physical2 <- pombeBiogrid_physical[,c(2,1,3)]
  names(pombeBiogrid_physical2) <- names(pombeBiogrid_physical)
  pombeBiogrid_physical <- rbind(pombeBiogrid_physical, pombeBiogrid_physical2)
  pombeBiogrid_physical <- unique(pombeBiogrid_physical)
  rm(pombeBiogrid_physical2)
  
  
  pombeBiogrid_physical$identifier <- paste(pombeBiogrid_physical$INTERACTOR_A, pombeBiogrid_physical$INTERACTOR_B, sep="&")
  pombeBiogrid_genetic$identifier <- paste(pombeBiogrid_genetic$INTERACTOR_A, pombeBiogrid_genetic$INTERACTOR_B, sep="&")
  
  pombeBiogrid_physical$infoSource <- "Biogrid_physical"
  pombeBiogrid_genetic$infoSource <- "Biogrid_genetic"
  
  names(pombeBiogrid_physical)[1:2] <- names(pombeString)[1:2]
  names(pombeBiogrid_genetic)[1:2] <- names(pombeString)[1:2]
  
  saveRDS(pombeBiogrid_genetic, file.path(out_dir2, paste0("8_12_5_2_1_", Sys.Date(), "_SpombeBiogrid_genetic_myproteins.rds")))
  saveRDS(pombeBiogrid_physical, file.path(out_dir2, paste0("8_12_5_2_2_", Sys.Date(), "_SpombeBiogrid_physical_myproteins.rds")))
  rm(pombeBiogrid)
  # 8.12.5.3 # test how many of them real ###############################################################################
  myCounts_df <- data.frame(sample=colnames(df_sampling),
                            NumberInteractions=dim(df_sampling)[1], 
                            InSet_STRING_neighborhood_transferred=NA, 
                            OutOf_STRING_neighborhood_transferred=sum(pombeString$neighborhood_transferred != 0),
                            InSet_STRING_fusion=NA, 
                            OutOf_STRING_fusion=sum(pombeString$fusion != 0),
                            InSet_STRING_cooccurence=NA, 
                            OutOf_STRING_cooccurence=sum(pombeString$cooccurence != 0),
                            InSet_STRING_homology=NA, 
                            OutOf_STRING_homology=sum(pombeString$homology != 0),
                            InSet_STRING_coexpression=NA, 
                            OutOf_STRING_coexpression=sum(pombeString$coexpression != 0),
                            InSet_STRING_coexpression_transferred=NA, 
                            OutOf_STRING_coexpression_transferred=sum(pombeString$coexpression_transferred != 0),
                            InSet_STRING_experiments=NA, 
                            OutOf_STRING_experiments=sum(pombeString$experiments != 0),
                            InSet_STRING_experiments_transferred=NA, 
                            OutOf_STRING_experiments_transferred=sum(pombeString$experiments_transferred != 0),
                            InSet_STRING_database=NA, 
                            OutOf_STRING_database=sum(pombeString$database != 0),
                            InSet_STRING_database_transferred=NA, 
                            OutOf_STRING_database_transferred=sum(pombeString$database_transferred != 0),
                            InSet_STRING_textmining=NA, 
                            OutOf_STRING_textmining=sum(pombeString$textmining != 0),
                            InSet_STRING_textmining_transferred=NA, 
                            OutOf_STRING_textmining_transferred=sum(pombeString$textmining_transferred != 0),
                            InSet_STRING_combined_score=NA, 
                            OutOf_STRING_combined_score=sum(pombeString$combined_score != 0),
                            InSet_Biogrid_genetic=NA, OutOf_Biogrid_genetic=dim(pombeBiogrid_genetic)[1],
                            InSet_Biogrid_physical=NA, OutOf_Biogrid_physical=dim(pombeBiogrid_physical)[1])
  rm(df)
  for (i in 1:dim(myCounts_df)[1]) {
    print(i)
    myCounts_df$InSet_STRING_neighborhood_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$neighborhood_transferred != 0])
    myCounts_df$InSet_STRING_fusion[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$fusion != 0])
    myCounts_df$InSet_STRING_cooccurence[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$cooccurence != 0])
    myCounts_df$InSet_STRING_homology[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$homology != 0])
    myCounts_df$InSet_STRING_coexpression[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression != 0])
    myCounts_df$InSet_STRING_coexpression_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression_transferred != 0])
    myCounts_df$InSet_STRING_experiments[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments != 0])
    myCounts_df$InSet_STRING_experiments_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments_transferred != 0])
    myCounts_df$InSet_STRING_database[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database != 0])
    myCounts_df$InSet_STRING_database_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database_transferred != 0])
    myCounts_df$InSet_STRING_textmining[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining != 0])
    myCounts_df$InSet_STRING_textmining_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining_transferred != 0])
    myCounts_df$InSet_STRING_combined_score[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$combined_score != 0])
    
    myCounts_df$InSet_Biogrid_genetic[i] <- sum(df_sampling[,i] %in% pombeBiogrid_genetic$identifier)
    myCounts_df$InSet_Biogrid_physical[i] <- sum(df_sampling[,i] %in% pombeBiogrid_physical$identifier)
  }
  saveRDS(myCounts_df, file.path(out_dir2, paste0("8_12_5_3_1_", Sys.Date(), "_mycounts_myproteins.rds")))
  rm(df_sampling)
  rm(pombeBiogrid_genetic)
  rm(pombeBiogrid_physical)
  rm(pombeString)
  
  myfile <- list.files(out_dir2, "^8_12_5_3_1")
  myCounts_df <- readRDS(file.path(out_dir2, myfile))
  myCounts_df <- myCounts_df[,c(1, grep("InSet", names(myCounts_df)))]
  myCounts_df <- melt(myCounts_df, "sample")
  names(myCounts_df)[2] <- "Criteria"
  names(myCounts_df)[3] <- "HowMany"
  myCounts_df$sampleType <- "Significant"
  myCounts_df$sampleType[grep("sampling", myCounts_df$sample)] <- "Random"
  myCounts_df$Criteria <- gsub("InSet_", "", myCounts_df$Criteria)
  myCounts_df <- remove.factors(myCounts_df)
  
  mycriteria <- unique(myCounts_df$Criteria)
  
  pdf(file.path(out_dir2, paste0("8_12_5_3_2_", Sys.Date(), "_EnrichedInteractionPlots.pdf")), height = 8, width = 8)
  for (i in 1:length(mycriteria)) {
    x <- ecdf(subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random")$HowMany)
    y <- x(myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"])
    
    p <- ggplot(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"), 
                aes(HowMany))+
      geom_density(fill="#e0e0e0")+
      geom_vline(xintercept = myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"], 
                 color="#67001f", size=1.01) +
      theme_classic()+
      geom_hline(yintercept=0, colour="white", size=1) +
      geom_rug(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"),
               sides="b") +
      coord_cartesian(clip = "off") +
      theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
      xlim(0,max(subset(myCounts_df, Criteria==mycriteria[i])$HowMany))+
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      xlab(gsub("_", " ", mycriteria[i])) +
      ggtitle(paste("p value = ", y, sep=""))
    
    print(p)
  }
  dev.off()
  
  
  # 8.12.6 # group them based on string-biogrid info and plot correlations ######
  myfiles <- list.files(out_dir2, "^8_12_5_[1-2]")
  SpombeString <- readRDS(file.path(out_dir2, myfiles[1]))
  SpombeBiogridPhysical <- readRDS(file.path(out_dir2, myfiles[3]))
  SpombeBiogridGenetic <- readRDS(file.path(out_dir2, myfiles[2]))
  
  myfile <- list.files(out_dir2, "^8_12_3_1")
  df <-  readRDS(file.path(out_dir2, myfile))
  
  df_jnk <- df[-c(grep(";", rownames(df))),]
  df_jnk$identifier <- rownames(df_jnk)
  
  names(SpombeBiogridGenetic)[3] <- "Biogrid_Genetic"
  SpombeBiogridGenetic <- SpombeBiogridGenetic[,c(3,4)]
  SpombeBiogridGenetic <- SpombeBiogridGenetic %>%
    group_by(identifier) %>%
    dplyr::mutate(Biogrid_Genetic=paste0(Biogrid_Genetic, collapse = ";")) %>%
    unique() %>%
    as.data.frame()
  
  names(SpombeBiogridPhysical)[3] <- "Biogrid_Physical"
  SpombeBiogridPhysical <- SpombeBiogridPhysical[,c(3,4)]
  SpombeBiogridPhysical <- SpombeBiogridPhysical %>%
    group_by(identifier) %>%
    dplyr::mutate(Biogrid_Physical=paste0(Biogrid_Physical, collapse = ";")) %>%
    unique() %>%
    as.data.frame()
  
  SpombeString <- SpombeString[,3:17]
  
  df_jnk <- merge(df_jnk, SpombeBiogridGenetic, by.x="identifier", by.y="identifier", all.x=TRUE)
  dim(df_jnk)
  df_jnk <- merge(df_jnk, SpombeBiogridPhysical, by.x="identifier", by.y="identifier", all.x=TRUE)
  dim(df_jnk)
  df_jnk <- merge(df_jnk, SpombeString, by.x="identifier", by.y="identifier", all.x=TRUE)
  dim(df_jnk)
  rm(df)
  rm(SpombeBiogridGenetic)
  rm(SpombeBiogridPhysical)
  rm(SpombeString)
  
  df <- df_jnk
  rm(df_jnk)

  pdf(file.path(out_dir2, paste0("8_12_6_1_", Sys.Date(), "_Plots_CorDistribution_Interactors.pdf")), height = 6, width = 6)
  for (i in 13:28) {
    print(i)
    df_jnk <- df[,c(5,6,7,i)]
    df_jnk <- remove.factors(df_jnk)
    df_jnk[,4][df_jnk[,4]==0] <- NA
    df_jnk$group <- !is.na(df_jnk[,4])
    
    p <- ggplot(df_jnk, aes(cor))+
      geom_density(aes(color=group), size=1.01)+
      theme_classic()+
      geom_hline(yintercept=0, colour="white", size=1) +
      coord_cartesian(clip = "off") +
      theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
      xlim(-1,1)+
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      xlab(gsub("_", " ", names(df_jnk)[4]))+
      scale_color_manual(values=c("#1a1a1a", "#b2182b"))
    
    
    print(p)
  }
  dev.off()
  pdf(file.path(out_dir2, paste0("8_12_6_2_", Sys.Date(), "_Plots_CorECDF_Interactors.pdf")), height = 6, width = 6)
  for (i in c(13,14,16:28)) {
    print(i)
    df_jnk <- df[,c(5,6,7,i)]
    df_jnk <- remove.factors(df_jnk)
    df_jnk[,4][df_jnk[,4]==0] <- NA
    df_jnk$group <- !is.na(df_jnk[,4])
    
    cor_TRUE <- df_jnk$cor[df_jnk$group == TRUE]
    cor_FALSE <- df_jnk$cor[df_jnk$group == FALSE]
    pvalue <- ks.test(cor_TRUE, cor_FALSE)$`p.value`
    
    p <- ggplot(df_jnk, aes(cor, color=group))+
      stat_ecdf(size=1.1) +
      theme_classic() +
      geom_hline(yintercept = 0, color="white", size=1.1) +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      scale_color_manual(values=c("#1a1a1a", "#b2182b")) +
      guides(color=FALSE)+
      annotate("text", x = -.5, y = 1, label = paste0("KS p-value = ", pvalue), size=5.5)+ 
      xlim(-1,1)+
      xlab(gsub("_", " ", names(df_jnk)[4])) +
      ylab("ecdf")
    print(p)
  }
  dev.off()
  # 8.12.7 # pca with som 36 clusters ##################################
  myfile <- list.files(out_dir2, "^8_9_1")
  df_class_distance <- readRDS(file.path(out_dir2, myfile))
  df_class_distance$pG_GO <- gsub("([^;]*)\\;.*", "\\1", df_class_distance$pG)
  myfile <- list.files(out_dir2, "^8_11_5.*Spombe_BiomartGO")
  jnk <- readRDS(file.path(out_dir2, myfile))
  jnk <- jnk[,c(2,5,6,7)]
  jnk$GO <- !is.na(jnk$GO)
  jnk$GO_MF <- !is.na(jnk$GO_MF)
  jnk$GO_BP <- !is.na(jnk$GO_BP)
  
  df_class_distance <- merge(df_class_distance, jnk, by.x="ClusterN", by.y="ClusterN", all=TRUE)
  rm(jnk)
 
  myfile <- list.files(path = out_dir2, pattern = "^8_0.*rds")
  mydf <- readRDS(file.path(out_dir2, myfile))
  jnk <- df_class_distance[,c(1,2)]
  # pca
  df_pca <- as.data.frame(t(mydf))
  df_pca[is.na(df_pca)] <- 0
  df.pca <- prcomp(df_pca, center = FALSE, scale. = FALSE) 
  
  df_pca$pG <- rownames(df_pca)
  df_pca <- merge(df_pca, jnk, by.x="pG", by.y="pG", all=FALSE)
  df_pca$ClusterN <- as.factor(df_pca$ClusterN)
  rm(jnk)
  rm(mydf)

  pca_var_1_2 <- autoplot(df.pca, data = df_pca, colour = 'ClusterN', x=1, y=2)+
    guides(colour=FALSE)+
    theme_classic() +
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  pca_var_1_3 <- autoplot(df.pca, data = df_pca, colour = 'ClusterN', x=1, y=3)+
    guides(colour=FALSE)+
    theme_classic() +
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  pca_var_2_3 <- autoplot(df.pca, data = df_pca, colour = 'ClusterN', x=2, y=3)+
    guides(colour=FALSE)+
    theme_classic() +
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  pca_var_1_4 <- autoplot(df.pca, data = df_pca, colour = 'ClusterN', x=1, y=4)+
    guides(colour=FALSE)+
    theme_classic() +
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  pca_var_2_4 <- autoplot(df.pca, data = df_pca, colour = 'ClusterN', x=2, y=4)+
    guides(colour=FALSE)+
    theme_classic() +
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  pca_var_3_4 <- autoplot(df.pca, data = df_pca, colour = 'ClusterN', x=3, y=4)+
    guides(colour=FALSE)+
    theme_classic() +
    theme(axis.text=element_text(size=12),
          axis.title=element_text(size=14,face="bold"))
  pdf(file.path(out_dir2, paste0("8_12_7_1_", Sys.Date(), "_pca_som36_Zscore.pdf")), height = 6, width = 6)
  print(pca_var_1_2)
  print(pca_var_1_3)
  print(pca_var_1_4)
  print(pca_var_2_3)
  print(pca_var_2_4)
  print(pca_var_3_4)
  dev.off()  
  # 8.12.8 # individual analysis for each som 36 clusters ##################################
  myfile <- list.files(out_dir2, "36_clusters")
  df_som <- readRDS(file.path(out_dir2, myfile))
  
  df_class_distance <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif, df_som$distances))
  names(df_class_distance) <- c("pG", "ClusterN", "Distance")
  df_cluster_averages <- as.data.frame(df_som$codes[[1]])
  df_data <- as.data.frame(df_som$data[[1]])

  myfile <- list.files(out_dir2, "8_9_2")
  df_cluster_distances <- readRDS(file.path(out_dir2, myfile))
  
  myfile <- list.files(out_dir2, "^8_11_5.*Spombe_BiomartGO")
  df_GO <- readRDS(file.path(out_dir2, myfile))
  
  myfile <- list.files(out_dir2, "^8_12_3_1")
  df_cor <- readRDS(file.path(out_dir2, myfile))
  df_cor <- df_cor[,c(1,2,4)]
  jnk <- df_class_distance[,1:2]
  df_cor <- merge(df_cor, jnk, by.x="Protein1", by.y="pG", all=FALSE)
  names(df_cor)[4] <- "Cluster_Protein1"
  df_cor <- merge(df_cor, jnk, by.x="Protein2", by.y="pG", all=FALSE)
  names(df_cor)[5] <- "Cluster_Protein2"
  df_cor$SameCluster <- df_cor$Cluster_Protein1 == df_cor$Cluster_Protein2
  
  pdf(file.path(out_dir2, paste0("8_12_8_1_", Sys.Date(), "_individualPlots_som36.pdf")), height = 10, width = 10)
  for (i in 1:36) {
    print(i)
    df_class_distance_jnk <- subset(df_class_distance, ClusterN==i)
    df_cluster_distances_jnk <- subset(df_cluster_distances, ClusterN==i)
    df_cluster_averages_jnk <- df_cluster_averages[rownames(df_cluster_averages)==paste0("V", i, sep=""),]
    df_data_jnk <- df_data[rownames(df_data) %in% df_class_distance_jnk$pG,]
    df_cor_jnk <- df_cor[df_cor$Cluster_Protein1==i,]
    
    # pca
    df_pca <- as.data.frame(df_data)
    df_pca[is.na(df_pca)] <- 0
    df.pca <- prcomp(df_pca, center = FALSE, scale. = FALSE) 
    df_pca$pG <- rownames(df_pca)
    jnk <- df_class_distance[,1:2]
    jnk$ClusterN <- jnk$ClusterN == i
    df_pca <- merge(df_pca, jnk, by.x="pG", by.y="pG", all=FALSE)
    df_pca$ClusterN <- as.factor(df_pca$ClusterN)
    rm(jnk)
    pca_var_1_2 <- autoplot(df.pca, data = df_pca, colour = 'ClusterN', alpha = 'ClusterN', 
                            shape='ClusterN', size='ClusterN', x=1, y=2)+
      guides(colour=FALSE, shape=FALSE, size=FALSE, alpha=FALSE)+
      theme_classic() +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold")) +
      scale_color_manual(values=c("#bababa", "#b2182b")) +
      scale_shape_manual(values=c(1,19)) +
      scale_size_manual(values=c(1,3)) +
      scale_alpha_manual(values=c(0.4,1))
    rm(df_pca)
    rm(df.pca)
    # distances 
    df_class_distance_jnk <- remove.factors(df_class_distance_jnk)
    df_class_distance_jnk$Distance <- as.numeric(df_class_distance_jnk$Distance)
    p_dist <- ggplot(df_class_distance_jnk, aes(Distance, y=..scaled..)) +
      geom_density(size=1.01) +
      geom_density(data=df_cluster_distances_jnk, 
                   aes(Distance, y=..scaled..), 
                   color="#b2182b", size=1.01) +
      theme_classic() +
      geom_hline(yintercept = 0, color="white", size=1.01) +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))
    # cor
    df_cor_jnk <- remove.factors(df_cor_jnk)
    p_cor <- ggplot(df_cor_jnk, aes(cor, y=..scaled..)) +
      geom_density(aes(color=SameCluster), size=1.01) +
      theme_classic() +
      geom_hline(yintercept = 0, color="white", size=1.01) +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      scale_color_manual(values=c("#1a1a1a", "#b2182b")) +
      guides(color=FALSE)
    
    # cor, ecdf, ks test
    cor_TRUE <- df_cor_jnk$cor[df_cor_jnk$SameCluster == TRUE]
    cor_FALSE <- df_cor_jnk$cor[df_cor_jnk$SameCluster == FALSE]
    pvalue <- ks.test(cor_TRUE, cor_FALSE)$`p.value`
    
    p_cor2 <- ggplot(df_cor_jnk, aes(cor, color=SameCluster)) +
      stat_ecdf(size=1.1) +
      theme_classic() +
      geom_hline(yintercept = 0, color="white", size=1.1) +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      scale_color_manual(values=c("#1a1a1a", "#b2182b")) +
      guides(color=FALSE)+
      annotate("text", x = -.5, y = 1, label = paste0("KS p-value = ", pvalue), size=5.5)    
    
    # expression profile
    df_cluster_averages_jnk$cluster <- rownames(df_cluster_averages_jnk)
    df_cluster_averages_jnk <- melt(df_cluster_averages_jnk, "cluster")
    df_cluster_averages_jnk$variable <- factor(df_cluster_averages_jnk$variable,
                                               levels = df_cluster_averages_jnk$variable[order(df_cluster_averages_jnk$value)])

    df_data_jnk$cluster <- rownames(df_data_jnk)
    df_data_jnk <- melt(df_data_jnk, "cluster")
    df_data_jnk$variable <- factor(df_data_jnk$variable,
                                   levels = df_cluster_averages_jnk$variable[order(df_cluster_averages_jnk$value)])
    
    p_expression <- ggplot(df_data_jnk, aes(variable, y=value, group = cluster)) +
      geom_point(color="#bababa", alpha=0.5)+
      geom_line(color="#bababa") +
      geom_point(data=df_cluster_averages_jnk,
                aes(variable, y=value), color="#b2182b") +
      geom_line(data=df_cluster_averages_jnk,
                aes(variable, y=value), color="#b2182b") +
      theme_classic() +
      theme(axis.text.y = element_text(size=12),
            axis.text.x = element_blank(),
            axis.title=element_text(size=14,face="bold")) +
      xlab("Strains ordered") +
      ylab("Z-score")
    
    df_cluster_averages_jnk$Strain <- gsub(".*\\-(.*)", "\\1", df_cluster_averages_jnk$variable)
    Strains_reg <- df_cluster_averages_jnk[abs(df_cluster_averages_jnk$value) >= 2,]
    if(dim(Strains_reg)[1]>0){
      write.table(Strains_reg, 
                  file.path(out_dir2, 
                            paste0("8_12_8_2_", Sys.Date(), 
                                   "_proteins_cluster",i,"_Regulated_Strains.txt")),
                  quote = F, row.names = F, col.names = T, sep="\t")}
    p_print <- ggarrange(pca_var_1_2, 
                         ggarrange(p_dist, p_cor, p_cor2, nrow=1, ncol = 3),
                         p_expression, nrow=3, ncol=1)
    print(p_print)
  }
  dev.off()
  }
  if(checkNumberClusters){
  ## go over different cluster #################################################################
  # 8.9.X # work with different supersom clusters #######################################
  myfiles <- as.data.frame(list.files(out_dir2, "^8_3"))
  myfiles$prefix <- gsub("8_3_.*\\_(.*)\\_clusters_som.rds", "\\1", myfiles$`list.files(out_dir2, "^8_3")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)
  
  for (myfile in 2:dim(myfiles)[1]) {
    print(myfile)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[myfile]))
    
    df_class_distance <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif, df_som$distances))
    
    df_cluster_averages <- as.data.frame(df_som$codes[[1]])
    df_data <- as.data.frame(df_som$data[[1]])
    
    df_cluster_distances <- as.data.frame(matrix(NA, nrow=myfiles$prefix[myfile], ncol=myfiles$prefix[myfile]))
    
    rownames(df_cluster_distances) <- rownames(df_cluster_averages)
    colnames(df_cluster_distances) <- rownames(df_cluster_averages)
    
    for (i in 1:dim(df_cluster_distances)[1]) {
      print(i)
      df_cluster_averages_jnk <- df_cluster_averages
      jnk <- as.data.frame(matrix(as.numeric(rep(as.numeric(df_cluster_averages_jnk[i,]),myfiles$prefix[myfile])), 
                                  nrow = dim(df_cluster_averages_jnk)[1], 
                                  ncol = dim(df_cluster_averages_jnk)[2], byrow = TRUE))
      jnk <- remove.factors(jnk)
      df_cluster_averages_jnk <- df_cluster_averages_jnk - jnk
      df_cluster_averages_jnk <- df_cluster_averages_jnk^2
      df_cluster_averages_jnk <- rowSums(df_cluster_averages_jnk)
      df_cluster_distances[i,] <- df_cluster_averages_jnk
    }
    
    rm(df_cluster_averages_jnk)
    rm(jnk)
    rm(df_cluster_averages)
    df_cluster_distances[df_cluster_distances==0] <- NA
    df_cluster_distances$ClusterN <- 1:myfiles$prefix[myfile]
    df_cluster_distances <- melt(df_cluster_distances, id="ClusterN")
    names(df_cluster_distances)[2] <- "Distance2ClusterN"
    names(df_cluster_distances)[3] <- "Distance"
    df_cluster_distances$Distance2ClusterN <- gsub("V", "", df_cluster_distances$Distance2ClusterN)
    df_cluster_distances <- remove.factors(df_cluster_distances)
    df_cluster_distances$Distance2ClusterN <- as.numeric(df_cluster_distances$Distance2ClusterN)
    df_cluster_distances <- df_cluster_distances[!is.na(df_cluster_distances$Distance),]
    
    rm(df_data)
    rm(df_som)
    
    names(df_class_distance) <- c("pG", "ClusterN", "Distance")
    df_class_distance$Distance <- as.numeric(df_class_distance$Distance)
    df_class_distance <- df_class_distance %>%
      group_by(ClusterN) %>%
      dplyr::mutate(averageDistance = median(Distance),
                    SizeCluster=n()) %>%
      as.data.frame() %>%
      remove.factors() %>%
      as.data.frame()
    
    df_class_distance$ClusterN <- as.numeric(df_class_distance$ClusterN)
    
    meanDistance_cluster <- as.data.frame(unique(df_class_distance[,c(2,4,5)]))
    
    p0 <- ggplot(df_class_distance, aes(as.factor(ClusterN), Distance))+
      geom_boxplot() +
      scale_y_log10() +
      theme_classic() +
      xlab(paste0("Cluster Number supersom ", myfiles$prefix[myfile])) +
      ylab("within class distance")
    
    p1 <- ggplot(df_cluster_distances, aes(as.factor(ClusterN), Distance))+
      geom_boxplot() +
      scale_y_log10() +
      theme_classic() +
      xlab(paste0("Cluster Number supersom ", myfiles$prefix[myfile])) +
      ylab("distance to other clusters")+
      geom_point(data=meanDistance_cluster, aes(as.factor(ClusterN), averageDistance), color="red") +
      geom_text(data=meanDistance_cluster, aes(x=as.factor(ClusterN), y=0, label=SizeCluster))
    
    saveRDS(df_class_distance, file.path(out_dir2, paste0("8_9_X_", myfiles$prefix[myfile],"_1_", Sys.Date(), "_SOMcluster_proteins_distance.rds")))
    saveRDS(df_cluster_distances, file.path(out_dir2, paste0("8_9_X_", myfiles$prefix[myfile],"_2_", Sys.Date(), "_SOMcluster_btw_cluster_distances.rds")))

    pdf(file.path(out_dir2, paste0("8_9_X_", myfiles$prefix[myfile],"_3_", Sys.Date(), "_SOM_36_plots.pdf")), height = 8, width = 10)
    print(p0)
    print(p1)
    dev.off()
    rm(p0)
    rm(p1)
   
    
    df_class_distance$pG_GO <- gsub("([^;]*)\\;.*", "\\1", df_class_distance$pG)
    write.table(df_class_distance, 
                file.path(out_dir2, 
                          paste0("8_9_X_", myfiles$prefix[myfile],"_4_", Sys.Date(), 
                                 "_SOMcluster_proteins_distance.txt")),
                quote = F, row.names = F, col.names = T, sep="\t")
  }
  
  # 8.11.X # GeneOntology different supersom clusters # biomart # only 1st protein in the group ########
  '%ni%' <- Negate('%in%')
  # my functions
  prepare4go <- function(indice, column){
    jnk <- as.data.frame(strsplit(df[indice, column], ";"))
    if(dim(jnk)[1]>0){
      jnk$is_candidate <- 1
      names(jnk)[1] <- "gene_ids"
      if(length(grep("REV|CON", jnk$gene_ids)) >0){
        jnk <- jnk[-c(grep("REV|CON", jnk$gene_ids)),]
      }
    }
    return(jnk)
  }
  myGO <- function(my_df, my_annot){
    if(dim(my_df)[1] > 0){
      res_hyper_anno = go_enrich(my_df, annotations=my_annot, n_randsets = 100)
      stats = res_hyper_anno[[1]]
      stats <- subset(stats, FWER_overrep<=0.05)} else {stats <- data.frame(ontology=character(), node_id=character())}
    return(stats)
  }
  
  resultMyGO <- function(mygo_df){
    if(dim(mygo_df)[1]>0){
      jnk <- paste0(dim(mygo_df)[1], paste0(mygo_df$node_name, collapse = ":"), collapse = ";")} else {jnk <- NA}
    return(jnk)
  }
  
  # loop over the clusters
  myfile <- list.files(out_dir2, "^8_11_1")
  pombeBioMartGO_my <- readRDS(file.path(out_dir2, myfile))
  
  myfiles <- as.data.frame(list.files(out_dir2, "^8_9_X_.*_1.*SOMcluster_proteins_distance"))
  myfiles$prefix <- gsub("8_9_X_(.*)\\_1.*", "\\1", myfiles$`list.files(out_dir2, "^8_9_X_.*_1.*SOMcluster_proteins_distance")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)  
  
  for (myfile in 2:dim(myfiles)[1]) {
    print(myfile)
    df_class_distance <- readRDS(file.path(out_dir2, myfiles$filename[myfile]))
    df_class_distance$pG_GO <- gsub("([^;]*)\\;.*", "\\1", df_class_distance$pG)
    
    df <- df_class_distance[,c(6,2,4,5)]
    names(df)[1] <- "pG"
    rm(df_class_distance)
    df <- df %>%
      group_by(ClusterN) %>%
      dplyr::mutate(pG=paste0(pG, collapse=";")) %>%
      as.data.frame()
    df <- as.data.frame(unique(df))
    df$GO <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_my))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    # now MF
    df$GO_MF <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    pombeBioMartGO_MF <- subset(pombeBioMartGO_my, GO.domain == "molecular_function")
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO_MF[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_MF))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    
    # now BP
    df$GO_BP <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    pombeBioMartGO_BP <- subset(pombeBioMartGO_my, GO.domain == "biological_process")
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO_BP[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_BP))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    
    GO_NA_p <- sum(!is.na(df$GO))
    saveRDS(df, file.path(out_dir2, paste0("8_11_X_5_", Sys.Date(), 
                                           "_Spombe_BiomartGO_4clusters_",myfiles$prefix[myfile],
                                           "_",GO_NA_p,".rds")))
    
  }
  ##########################################################3
  
  
  
  
  

  
 
  # 8.11.Y # GeneOntology different supersom clusters # pombase # only 1st protein in the group ########
  out_dir3 <- "ScreenProteome/8_20190718_proteinClusterCor/8_11_Y/"
  '%ni%' <- Negate('%in%')
  # my functions
  prepare4go <- function(indice, column){
    jnk <- as.data.frame(strsplit(df[indice, column], ";"))
    if(dim(jnk)[1]>0){
      jnk$is_candidate <- 1
      names(jnk)[1] <- "gene_ids"
      if(length(grep("REV|CON", jnk$gene_ids)) >0){
        jnk <- jnk[-c(grep("REV|CON", jnk$gene_ids)),]
      }
    }
    return(jnk)
  }
  myGO <- function(my_df, my_annot){
    if(dim(my_df)[1] > 0){
      res_hyper_anno = go_enrich(my_df, annotations=my_annot, n_randsets = 100)
      stats = res_hyper_anno[[1]]
      stats <- subset(stats, FWER_overrep<=0.05)} else {stats <- data.frame(ontology=character(), node_id=character())}
    return(stats)
  }
  
  resultMyGO <- function(mygo_df){
    if(dim(mygo_df)[1]>0){
      jnk <- paste0(dim(mygo_df)[1], paste0(mygo_df$node_name, collapse = ":"), collapse = ";")} else {jnk <- NA}
    return(jnk)
  }
  
  # loop over the clusters
  myfile <- list.files(out_dir2, "^8_11_3")
  pombeBioMartGO_my <- readRDS(file.path(out_dir2, myfile))
  
  myfiles <- as.data.frame(list.files(out_dir3, "^8_9_X_.*_1.*SOMcluster_proteins_distance"))
  myfiles$prefix <- gsub("8_9_X_(.*)\\_1.*", "\\1", myfiles$`list.files(out_dir3, "^8_9_X_.*_1.*SOMcluster_proteins_distance")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)  
  myfiles <- myfiles[order(myfiles$prefix, decreasing = T),]  
  
  for (myfile in 1:dim(myfiles)[1]) {
    print(myfile)
    df_class_distance <- readRDS(file.path(out_dir3, myfiles$filename[myfile]))
    df_class_distance$pG_GO <- gsub("([^;]*)\\;.*", "\\1", df_class_distance$pG)
    
    df <- df_class_distance[,c(6,2,4,5)]
    names(df)[1] <- "pG"
    rm(df_class_distance)
    df <- df %>%
      group_by(ClusterN) %>%
      dplyr::mutate(pG=paste0(pG, collapse=";")) %>%
      as.data.frame()
    df <- as.data.frame(unique(df))
    df$GO <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_my))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    GO_NA_p <- sum(!is.na(df$GO))
    saveRDS(df, file.path(out_dir3, paste0("8_11_Y_5_", Sys.Date(), 
                                           "_Spombe_BiomartGO_4clusters_",myfiles$prefix[myfile],
                                           "_",GO_NA_p,".rds")))
    
  }
  ##########################################################3
  
  
  
  
  
  
  
  
  
  # 8.12.8.X # individual analysis for each som X clusters ##################################
  myfiles <- as.data.frame(list.files(out_dir2, "^8_3"))
  myfiles$prefix <- gsub("8_3_.*\\_(.*)\\_clusters_som.rds", "\\1", myfiles$`list.files(out_dir2, "^8_3")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)
  
  myfile <- list.files(out_dir2, "^8_11_5.*Spombe_BiomartGO")
  df_GO <- readRDS(file.path(out_dir2, myfile))
  
  myfile <- list.files(out_dir2, "^8_12_3_1")
  df_cor <- readRDS(file.path(out_dir2, myfile))
  df_cor <- df_cor[,c(1,2,4)]
  
  # my functions
  prepare4go <- function(indice, column){
    jnk <- as.data.frame(strsplit(df[indice, column], ";"))
    if(dim(jnk)[1]>0){
      jnk$is_candidate <- 1
      names(jnk)[1] <- "gene_ids"
      if(length(grep("REV|CON", jnk$gene_ids)) >0){
        jnk <- jnk[-c(grep("REV|CON", jnk$gene_ids)),]
      }
    }
    return(jnk)
  }
  myGO <- function(my_df, my_annot){
    if(dim(my_df)[1] > 0){
      res_hyper_anno = go_enrich(my_df, annotations=my_annot, n_randsets = 100)
      stats = res_hyper_anno[[1]]
      stats <- subset(stats, FWER_overrep<=0.05)} else {stats <- data.frame(ontology=character(), node_id=character())}
    return(stats)
  }
  resultMyGO <- function(mygo_df){
    if(dim(mygo_df)[1]>0){
      jnk <- paste0(dim(mygo_df)[1], paste0(mygo_df$node_name, collapse = ":"), collapse = ";")} else {jnk <- NA}
    return(jnk)
  }
  
  # loop over the clusters
  myfile <- list.files(out_dir2, "^8_11_1")
  pombeBioMartGO_my <- readRDS(file.path(out_dir2, myfile))
  
  for (myfile in 2:dim(myfiles)[1]) {
    print(myfile)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[myfile]))
    
    df_class_distance <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif, df_som$distances))
    names(df_class_distance) <- c("pG", "ClusterN", "Distance")
    df_cluster_averages <- as.data.frame(df_som$codes[[1]])
    df_data <- as.data.frame(df_som$data[[1]])
  
    myfile2 <- list.files(out_dir2, paste0("8_9_X_", myfiles$prefix[myfile], "_2"))
    df_cluster_distances <- readRDS(file.path(out_dir2, myfile2))

    jnk <- df_class_distance[,1:2]
    df_corX <- merge(df_cor, jnk, by.x="Protein1", by.y="pG", all=FALSE)
    names(df_corX)[4] <- "Cluster_Protein1"
    df_corX <- merge(df_corX, jnk, by.x="Protein2", by.y="pG", all=FALSE)
    names(df_corX)[5] <- "Cluster_Protein2"
    df_corX$SameCluster <- df_corX$Cluster_Protein1 == df_corX$Cluster_Protein2
  
  pdf(file.path(out_dir2, paste0("8_12_8_X_",myfiles$prefix[myfile],"_", Sys.Date(), "_individualPlots_som.pdf")), height = 10, width = 10)
  for (i in 1:myfiles$prefix[myfile]) {
    print("i")
    print(i)
    df_class_distance_jnk <- subset(df_class_distance, ClusterN==i)
    df_cluster_distances_jnk <- subset(df_cluster_distances, ClusterN==i)
    df_cluster_averages_jnk <- df_cluster_averages[rownames(df_cluster_averages)==paste0("V", i, sep=""),]
    df_data_jnk <- df_data[rownames(df_data) %in% df_class_distance_jnk$pG,]
    df_cor_jnk <- df_corX[df_corX$Cluster_Protein1==i,]
    
    # pca
    df_pca <- as.data.frame(df_data)
    df_pca[is.na(df_pca)] <- 0
    df.pca <- prcomp(df_pca, center = FALSE, scale. = FALSE) 
    df_pca$pG <- rownames(df_pca)
    jnk <- df_class_distance[,1:2]
    jnk$ClusterN <- jnk$ClusterN == i
    df_pca <- merge(df_pca, jnk, by.x="pG", by.y="pG", all=FALSE)
    df_pca$ClusterN <- as.factor(df_pca$ClusterN)
    rm(jnk)
    pca_var_1_2 <- autoplot(df.pca, data = df_pca, colour = 'ClusterN', alpha = 'ClusterN', 
                            shape='ClusterN', size='ClusterN', x=1, y=2)+
      guides(colour=FALSE, shape=FALSE, size=FALSE, alpha=FALSE)+
      theme_classic() +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold")) +
      scale_color_manual(values=c("#bababa", "#b2182b")) +
      scale_shape_manual(values=c(1,19)) +
      scale_size_manual(values=c(1,3)) +
      scale_alpha_manual(values=c(0.4,1))
    rm(df_pca)
    rm(df.pca)
    # distances 
    df_class_distance_jnk <- remove.factors(df_class_distance_jnk)
    df_class_distance_jnk$Distance <- as.numeric(df_class_distance_jnk$Distance)
    p_dist <- ggplot(df_class_distance_jnk, aes(Distance, y=..scaled..)) +
      geom_density(size=1.01) +
      geom_density(data=df_cluster_distances_jnk, 
                   aes(Distance, y=..scaled..), 
                   color="#b2182b", size=1.01) +
      theme_classic() +
      geom_hline(yintercept = 0, color="white", size=1.01) +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))
    # cor
    df_cor_jnk <- remove.factors(df_cor_jnk)
    p_cor <- ggplot(df_cor_jnk, aes(cor, y=..scaled..)) +
      geom_density(aes(color=SameCluster), size=1.01) +
      theme_classic() +
      geom_hline(yintercept = 0, color="white", size=1.01) +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      scale_color_manual(values=c("#1a1a1a", "#b2182b")) +
      guides(color=FALSE)
    
    # cor, ecdf, ks test
    pvalue <- NA
    cor_TRUE <- df_cor_jnk$cor[df_cor_jnk$SameCluster == TRUE]
    cor_FALSE <- df_cor_jnk$cor[df_cor_jnk$SameCluster == FALSE]
    if(min(length(cor_FALSE), length(cor_TRUE)) != 0){
    pvalue <- ks.test(cor_TRUE, cor_FALSE)$`p.value`}
    
    p_cor2 <- ggplot(df_cor_jnk, aes(cor, color=SameCluster)) +
      stat_ecdf(size=1.1) +
      theme_classic() +
      geom_hline(yintercept = 0, color="white", size=1.1) +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      scale_color_manual(values=c("#1a1a1a", "#b2182b")) +
      guides(color=FALSE)+
      annotate("text", x = -.5, y = 1, label = paste0("KS p-value = ", pvalue), size=5.5)    
    
    # expression profile
    df_cluster_averages_jnk$cluster <- rownames(df_cluster_averages_jnk)
    df_cluster_averages_jnk <- melt(df_cluster_averages_jnk, "cluster")
    df_cluster_averages_jnk$variable <- factor(df_cluster_averages_jnk$variable,
                                               levels = df_cluster_averages_jnk$variable[order(df_cluster_averages_jnk$value)])
    
    df_data_jnk$cluster <- rownames(df_data_jnk)
    df_data_jnk <- melt(df_data_jnk, "cluster")
    df_data_jnk$variable <- factor(df_data_jnk$variable,
                                   levels = df_cluster_averages_jnk$variable[order(df_cluster_averages_jnk$value)])
    
    
    df_cluster_averages_jnk$Strain <- gsub(".*\\-(.*)", "\\1", df_cluster_averages_jnk$variable)
    Strains_reg <- df_cluster_averages_jnk[abs(df_cluster_averages_jnk$value) >= 2,]
    if(dim(Strains_reg)[1]>0){
      write.table(Strains_reg, 
                  file.path(out_dir2, 
                            paste0("8_12_8_X_",myfiles$prefix[myfile],"_", Sys.Date(), 
                                   "_proteins_cluster",i,"_Regulated_Strains.txt")),
                  quote = F, row.names = F, col.names = T, sep="\t")}
    p_print <- ggarrange(pca_var_1_2, 
                         ggarrange(p_dist, p_cor, p_cor2, nrow=1, ncol = 3),
                         nrow=2, ncol=1)
    print(p_print)
  }
  dev.off()}
  
  # 8.12.9.X # gene ontology for the strains targeting these clusters #################################################################
  myfiles <- as.data.frame(list.files(out_dir2, "^8_3"))
  myfiles$prefix <- gsub("8_3_.*\\_(.*)\\_clusters_som.rds", "\\1", myfiles$`list.files(out_dir2, "^8_3")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)
  myfiles <- myfiles[order(myfiles$prefix, decreasing = T),]  
  
  # my functions
  prepare4go <- function(indice, column){
    jnk <- as.data.frame(strsplit(df[indice, column], ";"))
    if(dim(jnk)[1]>0){
      jnk$is_candidate <- 1
      names(jnk)[1] <- "gene_ids"
      if(length(grep("REV|CON", jnk$gene_ids)) >0){
        jnk <- jnk[-c(grep("REV|CON", jnk$gene_ids)),]
      }
    }
    return(jnk)
  }
  myGO <- function(my_df, my_annot){
    if(dim(my_df)[1] > 0){
      res_hyper_anno = go_enrich(my_df, annotations=my_annot, n_randsets = 100)
      stats = res_hyper_anno[[1]]
      stats <- subset(stats, FWER_overrep<=0.05)} else {stats <- data.frame(ontology=character(), node_id=character())}
    return(stats)
  }
  resultMyGO <- function(mygo_df){
    if(dim(mygo_df)[1]>0){
      jnk <- paste0(dim(mygo_df)[1], paste0(mygo_df$node_name, collapse = ":"), collapse = ";")} else {jnk <- NA}
    return(jnk)
  }
  
  # loop over the clusters
  myfile <- list.files("ScreenProteome/7_20190718_strainClusterCor/", "^7_11_1")
  pombeBioMartGO_my <- readRDS(file.path("ScreenProteome/7_20190718_strainClusterCor/", myfile))

  for (myfile in 1:dim(myfiles)[1]) {
    print(myfile)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[myfile]))
    
    df_cluster_averages_jnk <- as.data.frame(df_som$codes[[1]])
    df_cluster_averages_jnk$cluster <- rownames(df_cluster_averages_jnk)
    df_cluster_averages_jnk <- melt(df_cluster_averages_jnk, "cluster")
    
    df_cluster_averages_jnk$Strain <- gsub(".*\\-(.*)", "\\1", df_cluster_averages_jnk$variable)
    df_cluster_averages_jnk <- df_cluster_averages_jnk[abs(df_cluster_averages_jnk$value) >= 2,]
    
    df <- df_cluster_averages_jnk %>%
      group_by(cluster) %>%
      dplyr::mutate(Strain=paste0(Strain, collapse=";")) %>%
      as.data.frame()
    df <- df[,c(4,1)]
    df <- as.data.frame(unique(df))
    
    df$GO <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_my))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    # now MF
    df$GO_MF <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    pombeBioMartGO_MF <- subset(pombeBioMartGO_my, GO.domain == "molecular_function")
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO_MF[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_MF))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    
    # now BP
    df$GO_BP <- "jnk"
    df <- remove.factors(df)
    df <- as.data.frame(df)
    pombeBioMartGO_BP <- subset(pombeBioMartGO_my, GO.domain == "biological_process")
    for (i in 1:dim(df)[1]) {
      tryCatch({
        df$GO_BP[i] <- resultMyGO(myGO(prepare4go(i,1), pombeBioMartGO_BP))
      }, error=function(e){cat("ERROR :",conditionMessage(e), "\n")})
    }
    
    GO_NA_p <- sum(!is.na(df$GO))
    saveRDS(df, file.path(out_dir2, paste0("8_12_9_X_", Sys.Date(), 
                                           "_Spombe_BiomartGO_4clusters_",myfiles$prefix[myfile],
                                           "_",GO_NA_p,".rds")))
    
  }
  
  # 8.12.3-5.X # correlations and interactions sampling randomly !!! ###################
  # 8.12.3 # sampling for significant interactions correlations #########
  myR <- 0.8
  myfile <- list.files(out_dir2, "^8_12_2")
  df <- readRDS(file.path(out_dir2, myfile[2]))
  
  df2 <- subset(df, nObs>0)
  rm(df)
  df2$p_FDR <- p.adjust(df2$p, method = "fdr", n = length(df2$p))
  df2 <- df2[,-6]
  df2 <- df2[,c(1,2,5,3,4,6)]
  df2$p_log <- -log10(df2$p)
  df2$p_FDR_log <- -log10(df2$p_FDR)
  df2$cor_abs <- abs(df2$cor)
  df2 <- subset(df2, Protein1 != Protein2)
  
  df <- df2
  rm(df2)

  df_signif <- subset(df, abs(cor) >= myR & p_FDR <= 0.05)
  # sampling based on ko's
  df_sampling_ko <- data.frame(ko_significant=rownames(df_signif))
  for (mycount in 1:1000) {
    print(mycount)
    sample_jnk <- sample(1:dim(df)[1], dim(df_sampling_ko)[1], replace=FALSE)
    mysamples <- rownames(df)[sample_jnk]
    
    df_sampling_ko <- cbind(df_sampling_ko, mysamples)
    names(df_sampling_ko)[dim(df_sampling_ko)[2]] <- paste0("sampling_", mycount)
  }

  saveRDS(df, file.path(out_dir2, paste0("8_12_3_X_1_", Sys.Date(), "_ko_pearson_cor.rds")))
  saveRDS(df_sampling_ko, file.path(out_dir2, paste0("8_12_3_X_", Sys.Date(), "_df_sampling_",myR,".rds")))
  rm(df_signif)
  rm(df_sampling_ko)
  # 8.12.4 # significant interactions correlations #########
  myfile <- list.files(out_dir2, "^8_12_3_X_[^1]")
  df_sampling <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_12_3_X_1_")
  df <- readRDS(file.path(out_dir2, myfile))
  df <- remove.factors(df)
  # 8.12.4.3 # test how many of them real ###############################################################################
  myfile <- list.files(out_dir2, "^8_12_4_1")
  pombeString <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_12_4_2_1_")
  pombeBiogrid_genetic <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_12_4_2_2_")
  pombeBiogrid_physical <- readRDS(file.path(out_dir2, myfile))
  
  myCounts_df <- data.frame(sample=colnames(df_sampling),
                            NumberInteractions=dim(df_sampling)[1], 
                            InSet_STRING_neighborhood_transferred=NA, 
                            OutOf_STRING_neighborhood_transferred=sum(pombeString$neighborhood_transferred != 0),
                            InSet_STRING_fusion=NA, 
                            OutOf_STRING_fusion=sum(pombeString$fusion != 0),
                            InSet_STRING_cooccurence=NA, 
                            OutOf_STRING_cooccurence=sum(pombeString$cooccurence != 0),
                            InSet_STRING_homology=NA, 
                            OutOf_STRING_homology=sum(pombeString$homology != 0),
                            InSet_STRING_coexpression=NA, 
                            OutOf_STRING_coexpression=sum(pombeString$coexpression != 0),
                            InSet_STRING_coexpression_transferred=NA, 
                            OutOf_STRING_coexpression_transferred=sum(pombeString$coexpression_transferred != 0),
                            InSet_STRING_experiments=NA, 
                            OutOf_STRING_experiments=sum(pombeString$experiments != 0),
                            InSet_STRING_experiments_transferred=NA, 
                            OutOf_STRING_experiments_transferred=sum(pombeString$experiments_transferred != 0),
                            InSet_STRING_database=NA, 
                            OutOf_STRING_database=sum(pombeString$database != 0),
                            InSet_STRING_database_transferred=NA, 
                            OutOf_STRING_database_transferred=sum(pombeString$database_transferred != 0),
                            InSet_STRING_textmining=NA, 
                            OutOf_STRING_textmining=sum(pombeString$textmining != 0),
                            InSet_STRING_textmining_transferred=NA, 
                            OutOf_STRING_textmining_transferred=sum(pombeString$textmining_transferred != 0),
                            InSet_STRING_combined_score=NA, 
                            OutOf_STRING_combined_score=sum(pombeString$combined_score != 0),
                            InSet_Biogrid_genetic=NA, OutOf_Biogrid_genetic=dim(pombeBiogrid_genetic)[1],
                            InSet_Biogrid_physical=NA, OutOf_Biogrid_physical=dim(pombeBiogrid_physical)[1])
  rm(df)
  for (i in 1:dim(myCounts_df)[1]) {
    print(i)
    myCounts_df$InSet_STRING_neighborhood_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$neighborhood_transferred != 0])
    myCounts_df$InSet_STRING_fusion[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$fusion != 0])
    myCounts_df$InSet_STRING_cooccurence[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$cooccurence != 0])
    myCounts_df$InSet_STRING_homology[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$homology != 0])
    myCounts_df$InSet_STRING_coexpression[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression != 0])
    myCounts_df$InSet_STRING_coexpression_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression_transferred != 0])
    myCounts_df$InSet_STRING_experiments[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments != 0])
    myCounts_df$InSet_STRING_experiments_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments_transferred != 0])
    myCounts_df$InSet_STRING_database[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database != 0])
    myCounts_df$InSet_STRING_database_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database_transferred != 0])
    myCounts_df$InSet_STRING_textmining[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining != 0])
    myCounts_df$InSet_STRING_textmining_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining_transferred != 0])
    myCounts_df$InSet_STRING_combined_score[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$combined_score != 0])
    
    myCounts_df$InSet_Biogrid_genetic[i] <- sum(df_sampling[,i] %in% pombeBiogrid_genetic$identifier)
    myCounts_df$InSet_Biogrid_physical[i] <- sum(df_sampling[,i] %in% pombeBiogrid_physical$identifier)
  }
  saveRDS(myCounts_df, file.path(out_dir2, paste0("8_12_4_3_X_1_", Sys.Date(), "_mycounts_myproteins.rds")))
  rm(df_sampling)
  rm(pombeBiogrid_genetic)
  rm(pombeBiogrid_physical)
  rm(pombeString)
  
  myfile <- list.files(out_dir2, "^8_12_4_3_X_1")
  myCounts_df <- readRDS(file.path(out_dir2, myfile))
  myCounts_df <- myCounts_df[,c(1, grep("InSet", names(myCounts_df)))]
  myCounts_df <- melt(myCounts_df, "sample")
  names(myCounts_df)[2] <- "Criteria"
  names(myCounts_df)[3] <- "HowMany"
  myCounts_df$sampleType <- "Significant"
  myCounts_df$sampleType[grep("sampling", myCounts_df$sample)] <- "Random"
  myCounts_df$Criteria <- gsub("InSet_", "", myCounts_df$Criteria)
  myCounts_df <- remove.factors(myCounts_df)
  
  mycriteria <- unique(myCounts_df$Criteria)
  
  pdf(file.path(out_dir2, paste0("8_12_4_3_X_2_", Sys.Date(), "_EnrichedInteractionPlots.pdf")), height = 8, width = 8)
  for (i in 1:length(mycriteria)) {
    x <- ecdf(subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random")$HowMany)
    y <- x(myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"])
    
    p <- ggplot(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"), 
                aes(HowMany))+
      geom_density(fill="#e0e0e0")+
      geom_vline(xintercept = myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"], 
                 color="#67001f", size=1.01) +
      theme_classic()+
      geom_hline(yintercept=0, colour="white", size=1) +
      geom_rug(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"),
               sides="b") +
      coord_cartesian(clip = "off") +
      theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
      xlim(0,max(subset(myCounts_df, Criteria==mycriteria[i])$HowMany))+
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      xlab(gsub("_", " ", mycriteria[i])) +
      ggtitle(paste("p value = ", y, sep=""))
    
    print(p)
  }
  dev.off()
  
  
  # 8.12.3.Y # sampling for significant interactions correlations #### no R #####
  myfile <- list.files(out_dir2, "^8_12_3_X_1_")
  df <- readRDS(file.path(out_dir2, myfile))
  
  myR <- 0.6
  df_signif <- subset(df, abs(cor) >= myR & p_FDR <= 0.05)
  write.table(df_signif[,c(1,2,4)], 
              file.path(out_dir2, 
                        paste0("8_12_3_Y_", Sys.Date(), 
                               "significantInteractions_06.txt")),
              quote = F, row.names = F, col.names = T, sep="\t")
  jnk <- df_signif[,c(1,2,4)]
  jnk$cor <- abs(jnk$cor)
  write.table(jnk, 
              file.path(out_dir2, 
                        paste0("8_12_3_Y_", Sys.Date(), 
                               "significantInteractions_abs06.txt")),
              quote = F, row.names = F, col.names = T, sep="\t")
  # sampling based on ko's
  df_sampling_ko <- data.frame(ko_significant=rownames(df_signif))
  for (mycount in 1:1000) {
    print(mycount)
    sample_jnk <- sample(1:dim(df)[1], dim(df_sampling_ko)[1], replace=TRUE)
    mysamples <- rownames(df)[sample_jnk]
    
    df_sampling_ko <- cbind(df_sampling_ko, mysamples)
    names(df_sampling_ko)[dim(df_sampling_ko)[2]] <- paste0("sampling_", mycount)
  }
  rm(df_signif)

  df_sampling <- df_sampling_ko
  rm(df_sampling_ko)
  # 8.12.4.3.Y # test how many of them real ###############################################################################
  myfile <- list.files(out_dir2, "^8_12_4_1")
  pombeString <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_12_4_2_1_")
  pombeBiogrid_genetic <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_12_4_2_2_")
  pombeBiogrid_physical <- readRDS(file.path(out_dir2, myfile))
  
  myCounts_df <- data.frame(sample=colnames(df_sampling),
                            NumberInteractions=dim(df_sampling)[1], 
                            InSet_STRING_neighborhood_transferred=NA, 
                            OutOf_STRING_neighborhood_transferred=sum(pombeString$neighborhood_transferred != 0),
                            InSet_STRING_fusion=NA, 
                            OutOf_STRING_fusion=sum(pombeString$fusion != 0),
                            InSet_STRING_cooccurence=NA, 
                            OutOf_STRING_cooccurence=sum(pombeString$cooccurence != 0),
                            InSet_STRING_homology=NA, 
                            OutOf_STRING_homology=sum(pombeString$homology != 0),
                            InSet_STRING_coexpression=NA, 
                            OutOf_STRING_coexpression=sum(pombeString$coexpression != 0),
                            InSet_STRING_coexpression_transferred=NA, 
                            OutOf_STRING_coexpression_transferred=sum(pombeString$coexpression_transferred != 0),
                            InSet_STRING_experiments=NA, 
                            OutOf_STRING_experiments=sum(pombeString$experiments != 0),
                            InSet_STRING_experiments_transferred=NA, 
                            OutOf_STRING_experiments_transferred=sum(pombeString$experiments_transferred != 0),
                            InSet_STRING_database=NA, 
                            OutOf_STRING_database=sum(pombeString$database != 0),
                            InSet_STRING_database_transferred=NA, 
                            OutOf_STRING_database_transferred=sum(pombeString$database_transferred != 0),
                            InSet_STRING_textmining=NA, 
                            OutOf_STRING_textmining=sum(pombeString$textmining != 0),
                            InSet_STRING_textmining_transferred=NA, 
                            OutOf_STRING_textmining_transferred=sum(pombeString$textmining_transferred != 0),
                            InSet_STRING_combined_score=NA, 
                            OutOf_STRING_combined_score=sum(pombeString$combined_score != 0),
                            InSet_Biogrid_genetic=NA, OutOf_Biogrid_genetic=dim(pombeBiogrid_genetic)[1],
                            InSet_Biogrid_physical=NA, OutOf_Biogrid_physical=dim(pombeBiogrid_physical)[1])
  rm(df)
  for (i in 1:dim(myCounts_df)[1]) {
    print(i)
    myCounts_df$InSet_STRING_neighborhood_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$neighborhood_transferred != 0])
    myCounts_df$InSet_STRING_fusion[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$fusion != 0])
    myCounts_df$InSet_STRING_cooccurence[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$cooccurence != 0])
    myCounts_df$InSet_STRING_homology[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$homology != 0])
    myCounts_df$InSet_STRING_coexpression[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression != 0])
    myCounts_df$InSet_STRING_coexpression_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression_transferred != 0])
    myCounts_df$InSet_STRING_experiments[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments != 0])
    myCounts_df$InSet_STRING_experiments_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments_transferred != 0])
    myCounts_df$InSet_STRING_database[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database != 0])
    myCounts_df$InSet_STRING_database_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database_transferred != 0])
    myCounts_df$InSet_STRING_textmining[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining != 0])
    myCounts_df$InSet_STRING_textmining_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining_transferred != 0])
    myCounts_df$InSet_STRING_combined_score[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$combined_score != 0])
    
    myCounts_df$InSet_Biogrid_genetic[i] <- sum(df_sampling[,i] %in% pombeBiogrid_genetic$identifier)
    myCounts_df$InSet_Biogrid_physical[i] <- sum(df_sampling[,i] %in% pombeBiogrid_physical$identifier)
  }
  saveRDS(myCounts_df, file.path(out_dir2, paste0("8_12_4_3_Y_1_", Sys.Date(), "_mycounts_myproteins.rds")))
  rm(df_sampling)
  rm(pombeBiogrid_genetic)
  rm(pombeBiogrid_physical)
  rm(pombeString)
  
  myCounts_df <- myCounts_df[,c(1, grep("InSet", names(myCounts_df)))]
  myCounts_df <- melt(myCounts_df, "sample")
  names(myCounts_df)[2] <- "Criteria"
  names(myCounts_df)[3] <- "HowMany"
  myCounts_df$sampleType <- "Significant"
  myCounts_df$sampleType[grep("sampling", myCounts_df$sample)] <- "Random"
  myCounts_df$Criteria <- gsub("InSet_", "", myCounts_df$Criteria)
  myCounts_df <- remove.factors(myCounts_df)
  
  mycriteria <- unique(myCounts_df$Criteria)
  
  pdf(file.path(out_dir2, paste0("8_12_4_3_Y_2_", Sys.Date(), "_EnrichedInteractionPlots.pdf")), height = 8, width = 8)
  for (i in 1:length(mycriteria)) {
    x <- ecdf(subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random")$HowMany)
    y <- x(myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"])
    
    p <- ggplot(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"), 
                aes(HowMany))+
      geom_density(fill="#e0e0e0")+
      geom_vline(xintercept = myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"], 
                 color="#67001f", size=1.01) +
      theme_classic()+
      geom_hline(yintercept=0, colour="white", size=1) +
      geom_rug(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"),
               sides="b") +
      coord_cartesian(clip = "off") +
      theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
      xlim(0,max(subset(myCounts_df, Criteria==mycriteria[i])$HowMany))+
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      xlab(gsub("_", " ", mycriteria[i])) +
      ggtitle(paste("p value = ", y, sep=""))
    
    print(p)
  }
  dev.off()
  
  
  # 8.12.6 # group them based on string-biogrid info and plot correlations ######
  myfiles <- list.files(out_dir2, "^8_12_5_[1-2]")
  SpombeString <- readRDS(file.path(out_dir2, myfiles[1]))
  SpombeBiogridPhysical <- readRDS(file.path(out_dir2, myfiles[3]))
  SpombeBiogridGenetic <- readRDS(file.path(out_dir2, myfiles[2]))
  
  myfile <- list.files(out_dir2, "^8_12_3_1")
  df <-  readRDS(file.path(out_dir2, myfile))
  
  df_jnk <- df[-c(grep(";", rownames(df))),]
  df_jnk$identifier <- rownames(df_jnk)
  
  names(SpombeBiogridGenetic)[3] <- "Biogrid_Genetic"
  SpombeBiogridGenetic <- SpombeBiogridGenetic[,c(3,4)]
  SpombeBiogridGenetic <- SpombeBiogridGenetic %>%
    group_by(identifier) %>%
    dplyr::mutate(Biogrid_Genetic=paste0(Biogrid_Genetic, collapse = ";")) %>%
    unique() %>%
    as.data.frame()
  
  names(SpombeBiogridPhysical)[3] <- "Biogrid_Physical"
  SpombeBiogridPhysical <- SpombeBiogridPhysical[,c(3,4)]
  SpombeBiogridPhysical <- SpombeBiogridPhysical %>%
    group_by(identifier) %>%
    dplyr::mutate(Biogrid_Physical=paste0(Biogrid_Physical, collapse = ";")) %>%
    unique() %>%
    as.data.frame()
  
  SpombeString <- SpombeString[,3:17]
  
  df_jnk <- merge(df_jnk, SpombeBiogridGenetic, by.x="identifier", by.y="identifier", all.x=TRUE)
  dim(df_jnk)
  df_jnk <- merge(df_jnk, SpombeBiogridPhysical, by.x="identifier", by.y="identifier", all.x=TRUE)
  dim(df_jnk)
  df_jnk <- merge(df_jnk, SpombeString, by.x="identifier", by.y="identifier", all.x=TRUE)
  dim(df_jnk)
  rm(df)
  rm(SpombeBiogridGenetic)
  rm(SpombeBiogridPhysical)
  rm(SpombeString)
  
  df <- df_jnk
  rm(df_jnk)

  for (i in c(13,14,16:28)) {
    print(i)
    df_jnk <- df[,c(5,6,7,i)]
    df_jnk <- remove.factors(df_jnk)
    df_jnk[,4][df_jnk[,4]==0] <- NA
    df_jnk$group <- !is.na(df_jnk[,4])
    
    cor_TRUE <- df_jnk$cor[df_jnk$group == TRUE]
    cor_FALSE <- df_jnk$cor[df_jnk$group == FALSE]
    pvalue <- ks.test(cor_TRUE, cor_FALSE)$`p.value`
    
    p <- ggplot(df_jnk, aes(cor, color=group))+
      stat_ecdf(size=1.1) +
      theme_classic() +
      geom_hline(yintercept = 0, color="white", size=1.1) +
      theme(axis.text=element_text(size=12),
            axis.title=element_text(size=14,face="bold"))+
      scale_color_manual(values=c("#1a1a1a", "#b2182b")) +
      guides(color=FALSE)+
      annotate("text", x = -.5, y = 1, label = paste0("KS p-value = ", pvalue), size=5.5)+ 
      xlim(-1,1)+
      xlab(gsub("_", " ", names(df_jnk)[4])) +
      ylab("ecdf")
    ggsave(file.path(out_dir2, paste0("8_12_6_2_",names(df)[i],
                                      "_", Sys.Date(), "_Plots_CorECDF_Interactors.png")), p)  
}

  
  # 8.13 # check 8.11.X.5 and 8.12.9.X and common ones for the clusters ###########################
  myfiles <- as.data.frame(list.files(out_dir2, "^8.11.X.5"))
  myfiles$ClusterN <- gsub("8_11_X_5_.*_Spombe_BiomartGO_4clusters_(.*)_.*.rds", "\\1", myfiles$`list.files(out_dir2, "^8.11.X.5")`)
  myfiles$OntologyN <- gsub("8_11_X_5_.*_Spombe_BiomartGO_4clusters_.*_(.*).rds", "\\1", myfiles$`list.files(out_dir2, "^8.11.X.5")`)
  names(myfiles)[1] <- "filename"
  myfiles$ClusterN <- as.numeric(myfiles$ClusterN)
  myfiles$OntologyN <- as.numeric(myfiles$OntologyN)
  
  myfiles2 <- as.data.frame(list.files(out_dir2, "^8.12.9.X"))
  myfiles2$ClusterN <- gsub("8_12_9_X_.*_Spombe_BiomartGO_4clusters_(.*)_.*.rds", "\\1", myfiles2$`list.files(out_dir2, "^8.12.9.X")`)
  myfiles2$OntologyN <- gsub("8_12_9_X_.*_Spombe_BiomartGO_4clusters_.*_(.*).rds", "\\1", myfiles2$`list.files(out_dir2, "^8.12.9.X")`)
  names(myfiles2)[1] <- "filename"
  myfiles2$ClusterN <- as.numeric(myfiles2$ClusterN)
  myfiles2$OntologyN <- as.numeric(myfiles2$OntologyN)
  
  p1 <- ggplot(myfiles, aes(as.factor(ClusterN), OntologyN))+
    geom_point() +
    ylab("# clusters with gene ontology") +
    xlab("# SOM clusters, proteins")
  p2 <- ggplot(myfiles2, aes(as.factor(ClusterN), OntologyN))+
    geom_point() +
    ylab("# clusters, targets with GO") +
    xlab("# SOM clusters, proteins")
  
  myfiles <- myfiles[myfiles$ClusterN %in% myfiles2$ClusterN,]
  myclusters <- myfiles$ClusterN
  myfiles3 <- myfiles[,2:3]
  names(myfiles3)[2] <- "N_common_clusters"
  myfiles3$N_common_clusters <- NA
  myfiles3$N_confident_clusters <- NA
  for (i in 1:length(myclusters)) {
    print(i)
    go_1 <- readRDS(file.path(out_dir2, myfiles$filename[myfiles$ClusterN == myclusters[i]]))
    go_1 <- go_1[!is.na(go_1$GO),]
    go_1 <- go_1[go_1$GO != "jnk",]
    
    go_2 <- readRDS(file.path(out_dir2, myfiles2$filename[myfiles2$ClusterN == myclusters[i]]))
    go_2 <- go_2[!is.na(go_2$GO),]
    go_2 <- go_2[go_2$GO != "jnk",]
    go_2$cluster <- gsub("V", "", go_2$cluster)
    
    myfiles3$N_common_clusters[myfiles3$ClusterN==myclusters[i]] <- length(intersect(go_1$ClusterN, go_2$cluster))
  
    go_1 <- go_1[rowSums(is.na(go_1))!=2,]
    go_2 <- go_2[rowSums(is.na(go_2))!=2,]
    myfiles3$N_confident_clusters[myfiles3$ClusterN==myclusters[i]] <- length(intersect(go_1$ClusterN, go_2$cluster))
  }
  
  myfiles3 <- melt(myfiles3, "ClusterN")
  
  p3 <- ggplot(myfiles3, aes(as.factor(ClusterN), value))+
    geom_point(aes(color=variable)) +
    ylab("# common clusters with GO") +
    xlab("# SOM clusters, proteins")
  
  # for 400
  i <- 8
  go_1 <- readRDS(file.path(out_dir2, myfiles$filename[myfiles$ClusterN == myclusters[i]]))
  go_1 <- go_1[!is.na(go_1$GO),]
  go_1 <- go_1[go_1$GO != "jnk",]
  
  go_2 <- readRDS(file.path(out_dir2, myfiles2$filename[myfiles2$ClusterN == myclusters[i]]))
  go_2 <- go_2[!is.na(go_2$GO),]
  go_2 <- go_2[go_2$GO != "jnk",]
  go_2$cluster <- gsub("V", "", go_2$cluster)
  
  go_1 <- go_1[rowSums(is.na(go_1))!=2,]
  go_2 <- go_2[rowSums(is.na(go_2))!=2,]
  
  go_1 <- go_1[go_1$ClusterN %in% go_2$cluster,]
  go_2 <- go_2[go_2$cluster %in% go_1$ClusterN,]
  
  go_1$GO_count <- gsub("([0-9]*).*", "\\1", go_1$GO)
  go_1$GO_count <- as.numeric(go_1$GO_count)
  go_2$GO_count <- gsub("([0-9]*).*", "\\1", go_2$GO)
  go_2$GO_count <- as.numeric(go_2$GO_count)
  
  go_1_1 <- go_1[,c(2,4,8)]
  names(go_1_1) <- paste("go1", names(go_1_1))
  
  go_2_2 <- go_2[,c(2,6)]
  names(go_2_2) <- paste("go2", names(go_2_2))
  
  go3 <- merge(go_1_1, go_2_2, by=1)
  go3$`go1 GO_count` <- as.numeric(go3$`go1 GO_count`)
  go3$`go2 GO_count` <- as.numeric(go3$`go2 GO_count`)
  
  plot(go3$`go1 GO_count`, go3$`go2 GO_count`)
  
  pdf(file.path(out_dir2, paste0("8_13_", Sys.Date(), "_clusterNumber.pdf")), height = 8, width = 8)
  print(p1)
  print(p2)
  print(p3)
  dev.off()
  
  }
  # 8.14 # decided for 400 clusters # cont working to make figures #########################
  # 8.14.1 # but first make a table in which one they belong to what cluster ###########
  myfiles <- as.data.frame(list.files(out_dir2, "^8_3.*rds"))
  myfiles$prefix <- gsub("8_3_.*\\_(.*)\\_clusters_som.rds", "\\1", myfiles$`list.files(out_dir2, "^8_3.*rds")`)
  names(myfiles)[1] <- "filename"
  myfiles$prefix <- as.numeric(myfiles$prefix)
  myfiles <- myfiles[order(myfiles$prefix, decreasing = F),]  
  
  df_som <- readRDS(file.path(out_dir2, myfiles$filename[1]))
  df_class <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif))
  names(df_class) <- c("pG", "SOM_1")
  
  for (myfile in 2:dim(myfiles)[1]) {
    print(myfile)
    df_som <- readRDS(file.path(out_dir2, myfiles$filename[myfile]))
    df_class_distance <- as.data.frame(cbind(rownames(df_som$data[[1]]), df_som$unit.classif))
    names(df_class_distance) <- c("pG", paste0("SOM_", myfiles$prefix[myfile]))
    df_class <- merge(df_class, df_class_distance, by=1, all=FALSE)
  }
  rm(df_som)
  rm(df_class_distance)
  saveRDS(df_class, file.path(out_dir2, paste0("8_14_1_", Sys.Date(), "_pG_inWhichCluster_1-400.rds")))
  rm(myfiles)
  # 8.14.2 # sampling based on cutoff 2 check the overlap and expected numbers ###########
  out_dir3 <- "ScreenProteome/8_20190718_proteinClusterCor/8_14_2_correlation_coexpression_numbers_check/"
  
  myfile <- list.files(out_dir2, "^8_12_2")
  df <- readRDS(file.path(out_dir2, myfile))
  df2 <- subset(df, nObs>0)
  rm(df)
  df2$p_FDR <- p.adjust(df2$p, method = "fdr", n = length(df2$p))
  df2 <- df2[,-6]
  df2 <- df2[,c(1,2,5,3,4,6)]
  df2$p_log <- -log10(df2$p)
  df2$p_FDR_log <- -log10(df2$p_FDR)
  df2$cor_abs <- abs(df2$cor)
  df2 <- subset(df2, Protein1 != Protein2)
  df <- df2
  rm(df2)
  # annotation files
  myfile <- list.files(out_dir2, "^8_12_4_1")
  pombeString <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_12_4_2_1_")
  pombeBiogrid_genetic <- readRDS(file.path(out_dir2, myfile))
  myfile <- list.files(out_dir2, "^8_12_4_2_2_")
  pombeBiogrid_physical <- readRDS(file.path(out_dir2, myfile))
  
  myR_series <- seq(0.95,0.2,-0.05)
  
  corR2enrichment <- function(df, myR, pombeString, pombeBiogrid_genetic, pombeBiogrid_physical){
    df_signif <- subset(df, cor >= myR & p_FDR <= 0.05)
    df_signif_abs <- subset(df, abs(cor) >= myR & p_FDR <= 0.05)
    
    df_sampling <- data.frame(ko_significant=rownames(df_signif))
    df_sampling_abs <- data.frame(ko_significant=rownames(df_signif_abs))
    
    for (mycount in 1:1000) {
      sample_jnk <- sample(1:dim(df)[1], dim(df_sampling)[1], replace=TRUE)
      mysamples <- rownames(df)[sample_jnk]
      df_sampling <- cbind(df_sampling, mysamples)
      names(df_sampling)[dim(df_sampling)[2]] <- paste0("sampling_", mycount)
      
      sample_jnk <- sample(1:dim(df)[1], dim(df_sampling_abs)[1], replace=TRUE)
      mysamples <- rownames(df)[sample_jnk]
      df_sampling_abs <- cbind(df_sampling_abs, mysamples)
      names(df_sampling_abs)[dim(df_sampling_abs)[2]] <- paste0("sampling_", mycount)
    }
    
    myCounts_df <- data.frame(sample=colnames(df_sampling),
                              InSet_STRING_neighborhood_transferred=NA, 
                              InSet_STRING_fusion=NA, 
                              InSet_STRING_cooccurence=NA, 
                              InSet_STRING_homology=NA, 
                              InSet_STRING_coexpression=NA, 
                              InSet_STRING_coexpression_transferred=NA, 
                              InSet_STRING_experiments=NA, 
                              InSet_STRING_experiments_transferred=NA, 
                              InSet_STRING_database=NA, 
                              InSet_STRING_database_transferred=NA, 
                              InSet_STRING_textmining=NA, 
                              InSet_STRING_textmining_transferred=NA, 
                              InSet_STRING_combined_score=NA, 
                              InSet_Biogrid_genetic=NA,
                              InSet_Biogrid_physical=NA)
    
    myCounts_df_abs <- data.frame(sample=colnames(df_sampling_abs),
                              InSet_STRING_neighborhood_transferred=NA, 
                              InSet_STRING_fusion=NA, 
                              InSet_STRING_cooccurence=NA, 
                              InSet_STRING_homology=NA, 
                              InSet_STRING_coexpression=NA, 
                              InSet_STRING_coexpression_transferred=NA, 
                              InSet_STRING_experiments=NA, 
                              InSet_STRING_experiments_transferred=NA, 
                              InSet_STRING_database=NA, 
                              InSet_STRING_database_transferred=NA, 
                              InSet_STRING_textmining=NA, 
                              InSet_STRING_textmining_transferred=NA, 
                              InSet_STRING_combined_score=NA, 
                              InSet_Biogrid_genetic=NA,
                              InSet_Biogrid_physical=NA)
    
    for (i in 1:dim(myCounts_df)[1]) {
      myCounts_df$InSet_STRING_neighborhood_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$neighborhood_transferred != 0])
      myCounts_df$InSet_STRING_fusion[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$fusion != 0])
      myCounts_df$InSet_STRING_cooccurence[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$cooccurence != 0])
      myCounts_df$InSet_STRING_homology[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$homology != 0])
      myCounts_df$InSet_STRING_coexpression[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression != 0])
      myCounts_df$InSet_STRING_coexpression_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$coexpression_transferred != 0])
      myCounts_df$InSet_STRING_experiments[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments != 0])
      myCounts_df$InSet_STRING_experiments_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$experiments_transferred != 0])
      myCounts_df$InSet_STRING_database[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database != 0])
      myCounts_df$InSet_STRING_database_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$database_transferred != 0])
      myCounts_df$InSet_STRING_textmining[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining != 0])
      myCounts_df$InSet_STRING_textmining_transferred[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$textmining_transferred != 0])
      myCounts_df$InSet_STRING_combined_score[i] <- sum(df_sampling[,i] %in% pombeString$identifier[pombeString$combined_score != 0])
      myCounts_df$InSet_Biogrid_genetic[i] <- sum(df_sampling[,i] %in% pombeBiogrid_genetic$identifier)
      myCounts_df$InSet_Biogrid_physical[i] <- sum(df_sampling[,i] %in% pombeBiogrid_physical$identifier)
      
      myCounts_df_abs$InSet_STRING_neighborhood_transferred[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$neighborhood_transferred != 0])
      myCounts_df_abs$InSet_STRING_fusion[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$fusion != 0])
      myCounts_df_abs$InSet_STRING_cooccurence[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$cooccurence != 0])
      myCounts_df_abs$InSet_STRING_homology[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$homology != 0])
      myCounts_df_abs$InSet_STRING_coexpression[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$coexpression != 0])
      myCounts_df_abs$InSet_STRING_coexpression_transferred[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$coexpression_transferred != 0])
      myCounts_df_abs$InSet_STRING_experiments[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$experiments != 0])
      myCounts_df_abs$InSet_STRING_experiments_transferred[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$experiments_transferred != 0])
      myCounts_df_abs$InSet_STRING_database[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$database != 0])
      myCounts_df_abs$InSet_STRING_database_transferred[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$database_transferred != 0])
      myCounts_df_abs$InSet_STRING_textmining[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$textmining != 0])
      myCounts_df_abs$InSet_STRING_textmining_transferred[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$textmining_transferred != 0])
      myCounts_df_abs$InSet_STRING_combined_score[i] <- sum(df_sampling_abs[,i] %in% pombeString$identifier[pombeString$combined_score != 0])
      myCounts_df_abs$InSet_Biogrid_genetic[i] <- sum(df_sampling_abs[,i] %in% pombeBiogrid_genetic$identifier)
      myCounts_df_abs$InSet_Biogrid_physical[i] <- sum(df_sampling_abs[,i] %in% pombeBiogrid_physical$identifier)
      
    }
    
    myCounts_df <- melt(myCounts_df, "sample")
    names(myCounts_df)[2] <- "Criteria"
    names(myCounts_df)[3] <- "HowMany"
    myCounts_df$sampleType <- "Significant"
    myCounts_df$sampleType[grep("sampling", myCounts_df$sample)] <- "Random"
    myCounts_df$Criteria <- gsub("InSet_", "", myCounts_df$Criteria)
    myCounts_df <- remove.factors(myCounts_df)
    
    myCounts_df_abs <- melt(myCounts_df_abs, "sample")
    names(myCounts_df_abs)[2] <- "Criteria"
    names(myCounts_df_abs)[3] <- "HowMany"
    myCounts_df_abs$sampleType <- "Significant"
    myCounts_df_abs$sampleType[grep("sampling", myCounts_df_abs$sample)] <- "Random"
    myCounts_df_abs$Criteria <- gsub("InSet_", "", myCounts_df_abs$Criteria)
    myCounts_df_abs <- remove.factors(myCounts_df_abs)
    
    mycriteria <- unique(myCounts_df$Criteria)
    pdf(file.path(out_dir3, paste0("8_14_2_", Sys.Date(), "_R_", myR,"_enrichment.pdf")), height = 8, width = 8)
    for (i in 1:length(mycriteria)) {
      x <- ecdf(subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random")$HowMany)
      y <- x(myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"])
      
      p <- ggplot(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"), 
                  aes(HowMany))+
        geom_density(fill="#e0e0e0")+
        geom_vline(xintercept = myCounts_df$HowMany[myCounts_df$Criteria==mycriteria[i] & myCounts_df$sampleType != "Random"], 
                   color="#67001f", size=1.01) +
        theme_classic()+
        geom_hline(yintercept=0, colour="white", size=1) +
        geom_rug(data=subset(myCounts_df, Criteria==mycriteria[i] & sampleType == "Random"),
                 sides="b") +
        coord_cartesian(clip = "off") +
        theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
        xlim(0,max(subset(myCounts_df, Criteria==mycriteria[i])$HowMany))+
        theme(axis.text=element_text(size=12),
              axis.title=element_text(size=14,face="bold"))+
        xlab(gsub("_", " ", mycriteria[i])) +
        ggtitle(paste("p value = ", y, sep=""))
      
      print(p)
    }
    dev.off()
    
    mycriteria <- unique(myCounts_df_abs$Criteria)
    pdf(file.path(out_dir3, paste0("8_14_2_", Sys.Date(), "_abs_R_", myR,"_enrichment.pdf")), height = 8, width = 8)
    for (i in 1:length(mycriteria)) {
      x <- ecdf(subset(myCounts_df_abs, Criteria==mycriteria[i] & sampleType == "Random")$HowMany)
      y <- x(myCounts_df_abs$HowMany[myCounts_df_abs$Criteria==mycriteria[i] & myCounts_df_abs$sampleType != "Random"])
      
      p <- ggplot(data=subset(myCounts_df_abs, Criteria==mycriteria[i] & sampleType == "Random"), 
                  aes(HowMany))+
        geom_density(fill="#e0e0e0")+
        geom_vline(xintercept = myCounts_df_abs$HowMany[myCounts_df_abs$Criteria==mycriteria[i] & myCounts_df_abs$sampleType != "Random"], 
                   color="#67001f", size=1.01) +
        theme_classic()+
        geom_hline(yintercept=0, colour="white", size=1) +
        geom_rug(data=subset(myCounts_df_abs, Criteria==mycriteria[i] & sampleType == "Random"),
                 sides="b") +
        coord_cartesian(clip = "off") +
        theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
        xlim(0,max(subset(myCounts_df_abs, Criteria==mycriteria[i])$HowMany))+
        theme(axis.text=element_text(size=12),
              axis.title=element_text(size=14,face="bold"))+
        xlab(gsub("_", " ", mycriteria[i])) +
        ggtitle(paste("p value = ", y, sep=""))
      
      print(p)
    }
    dev.off()
  }

  for (myR in myR_series) {
    print(myR)
    corR2enrichment(df, myR, pombeString, pombeBiogrid_genetic, pombeBiogrid_physical)
  }
  # 8.14.3 # sampling based on cutoff 2 check the overlap and expected numbers ###########
  
  
  

  
  
  
  #############
  
  
  ##################################################################################################################
}
if(strain==protein){
  out_dir2 <- "ScreenProteome/PS_protein_strain_cor_compare_20190902/"
  # compare strain and protein correlations for the proteins measured & knock-out based on pearson #############
  # PS.1 # define the subset to compare !!! ##################
  myfile <- list.files(path= "ScreenProteome/8_20190718_proteinClusterCor/", pattern = "^8_1_pearson.*rds")
  proteinCor <- readRDS(file.path("ScreenProteome/8_20190718_proteinClusterCor/", myfile))
  proteinCor <- remove.factors(proteinCor)
  proteinCor$Protein1_split <- proteinCor$Protein1
  proteinCor$Protein2_split <- proteinCor$Protein2
  proteinCor <- splitColumnBySep(proteinCor, "Protein1_split")
  proteinCor <- splitColumnBySep(proteinCor, "Protein2_split")
  proteinCor <- as.data.frame(unique(proteinCor))
  myfile <- list.files(path= "ScreenProteome/7_20190718_strainClusterCor/", pattern = "^7_1_pearson.*rds")
  strainCor <- readRDS(file.path("ScreenProteome/7_20190718_strainClusterCor/", myfile))
  strainCor <- remove.factors(strainCor)
  strainCor$Strain1_SystemicID <- gsub("Sp.*\\-(.*)", "\\1", strainCor$Strain1)
  strainCor$Strain2_SystemicID <- gsub("Sp.*\\-(.*)", "\\1", strainCor$Strain2)
  
  genes2compare <- unique(intersect(unique(c(proteinCor$Protein1_split, proteinCor$Protein2_split)),
                             unique(c(strainCor$Strain1_SystemicID, strainCor$Strain2_SystemicID))))
  
  myProteinCor <- subset(proteinCor, Protein1_split %in% genes2compare & Protein2_split %in% genes2compare)
  myStrainCor <- subset(strainCor, Strain1_SystemicID %in% genes2compare & Strain1_SystemicID %in% genes2compare)
  
  myProteinCor <- myProteinCor[myProteinCor$nObs != 0,]
  myStrainCor <- myStrainCor[myStrainCor$nObs != 0,]
  
  myProteinCor$identifier <- paste(myProteinCor$Protein1_split, myProteinCor$Protein2_split, sep="_")
  myStrainCor$identifier <- paste(myStrainCor$Strain1_SystemicID, myStrainCor$Strain2_SystemicID, sep="_")
  
  rm(proteinCor)
  rm(strainCor)
  
  names(myProteinCor)[3:5] <- c("cor_proteins", "p_proteins", "nObs_proteins")
  names(myStrainCor)[3:5] <- c("cor_strains", "p_strains", "nObs_strains")
  
  combinedCor <- merge(myProteinCor, myStrainCor, by.x="identifier", by.y="identifier", all=FALSE)
  
  saveRDS(myProteinCor, file.path(out_dir2, paste0("PS_1_1_", Sys.Date(), "_myProteinCor_common.rds")))
  saveRDS(myStrainCor, file.path(out_dir2, paste0("PS_1_2_", Sys.Date(), "_myStrainCor_common.rds")))
  saveRDS(combinedCor, file.path(out_dir2, paste0("PS_1_3_", Sys.Date(), "_combinedCor_merged.rds")))
  # PS.2 # start to compare !!! ##################
  myfile <- list.files(path= out_dir2, pattern = "^PS_1_3_")
  combinedCor <- readRDS(file.path(out_dir2, myfile))
  
  p1 <- ggplot(combinedCor, aes(cor_proteins, cor_strains)) +
    geom_density2d()
  ggsave(file.path(out_dir2, paste0("PS_2_1_", Sys.Date(), "_p1.png")), p1)

  p1 <- ggplot(combinedCor, aes(cor_proteins)) +
    geom_histogram(bins=100)
  p2 <- ggplot(combinedCor, aes(cor_strains)) +
    geom_histogram(bins=100)
  ggsave(file.path(out_dir2, paste0("PS_2_3_", Sys.Date(), "_p3.png")), p1)
  ggsave(file.path(out_dir2, paste0("PS_2_4_", Sys.Date(), "_p4.png")), p2)
  
  combinedCor <- subset(combinedCor, Protein1 != Protein2)
  combinedCor <- subset(combinedCor, Strain1 != Strain2)
  
  combinedCor <- subset(combinedCor, p_strains<=0.05 & p_proteins<=0.05)
  
  p1 <- ggplot(combinedCor, aes(cor_proteins, cor_strains)) +
    geom_density2d()
  ggsave(file.path(out_dir2, paste0("PS_2_5_", Sys.Date(), "_filtered_p1.png")), p1)

  p1 <- ggplot(combinedCor, aes(cor_proteins)) +
    geom_histogram(bins=100)
  p2 <- ggplot(combinedCor, aes(cor_strains)) +
    geom_histogram(bins=100)
  ggsave(file.path(out_dir2, paste0("PS_2_7_", Sys.Date(), "_filtered_p3.png")), p1)
  ggsave(file.path(out_dir2, paste0("PS_2_8_", Sys.Date(), "_filtered_p4.png")), p2)
  saveRDS(combinedCor, file.path(out_dir2, paste0("PS_2_9_", Sys.Date(), "_combinedCor_merged_filteredSignificant.rds")))
  # overall they are the same so focus on the same direction different direction sub groups ###########
  # PS.3 # filter for similar ones and different !!! ##################
  myfile <- list.files(path= out_dir2, pattern = "^PS_2_9_")
  combinedCor <- readRDS(file.path(out_dir2, myfile))
  combinedCor$cor_multipled <- combinedCor$cor_proteins * combinedCor$cor_strains
  
  p1 <- ggplot(combinedCor, aes(cor_multipled)) +
    geom_histogram(bins=1000)
  ggsave(file.path(out_dir2, paste0("PS_3_1_", Sys.Date(), "_p1.png")), p1)
  rm(p1)
  
  # myfile <- list.files(path= out_dir2, pattern = "^PS_1_3_")
  # combinedCor <- readRDS(file.path(out_dir2, myfile))
  # combinedCor$cor_multipled <- combinedCor$cor_proteins * combinedCor$cor_strains
  
  cor_multiplied_cutOff <- 0.5
  combinedCor <- combinedCor[abs(combinedCor$cor_multipled) >= cor_multiplied_cutOff,]
  
  combinedCor$cor_multipled_type <- paste(sign(combinedCor$cor_proteins),
                                          sign(combinedCor$cor_strains), sep=":")
  saveRDS(combinedCor, file.path(out_dir2, paste0("PS_3_2_", Sys.Date(), "_combinedCor_merged_filteredSignificant_0_5.rds")))
  
  # all the strain correlations are positive
  combinedCor_proteinPositive <- subset(combinedCor, cor_proteins > 0)
  combinedCor_proteinNegative <- subset(combinedCor, cor_proteins < 0)
  saveRDS(combinedCor_proteinPositive, file.path(out_dir2, paste0("PS_3_3_", Sys.Date(), "_combinedCor_merged_filteredSignificant_0_5_positive.rds")))
  saveRDS(combinedCor_proteinNegative, file.path(out_dir2, paste0("PS_3_4_", Sys.Date(), "_combinedCor_merged_filteredSignificant_0_5_negative.rds")))
  
  combinedCor_proteinPositive <- combinedCor_proteinPositive[,c(14,15,16)]
  combinedCor_proteinNegative <- combinedCor_proteinNegative[,c(14,15,16)]
  
  write.table(combinedCor_proteinPositive, 
              file.path(out_dir2,
                        paste0("PS_3_5_", Sys.Date(), "_combinedCor_merged_filteredSignificant_0_5_positive.txt")),
              quote = F, row.names = F, sep="\t")
  write.table(combinedCor_proteinNegative, 
              file.path(out_dir2,
                        paste0("PS_3_6_", Sys.Date(), "_combinedCor_merged_filteredSignificant_0_5_negative.txt")),
              quote = F, row.names = F, sep="\t")
  # PS.4 # group genes based on their correlation pairs ##################
  myfile <- list.files(path= out_dir2, pattern = "^PS_2_9_")
  combinedCor <- readRDS(file.path(out_dir2, myfile))
  combinedCor$cor_multipled <- combinedCor$cor_proteins * combinedCor$cor_strains
  
  cor_multiplied_cutOff <- 0.5
  combinedCor$cor_multipled_aboveCutOff <- abs(combinedCor$cor_multipled) >= cor_multiplied_cutOff
  
  combinedCor$cor_multipled_type <- paste(sign(combinedCor$cor_proteins),
                                          sign(combinedCor$cor_strains), sep=":")
  combinedCor$cor_multipled_type[combinedCor$cor_multipled_aboveCutOff == FALSE] <- "0"
  
  myProteins_table <- as.data.frame(table(combinedCor[,c(14,18)]))
  myProteins_table <- myProteins_table %>%
    group_by(Strain1_SystemicID) %>%
    dplyr::mutate(Percentage=Freq/sum(Freq)) %>%
    as.data.frame()
  
  myProteins_table_2 <- as.data.frame(table(combinedCor[,c(14,17)]))
  myProteins_table_2 <- myProteins_table_2 %>%
    group_by(Strain1_SystemicID) %>%
    dplyr::mutate(Percentage=Freq/sum(Freq)) %>%
    as.data.frame()
  
  myProteins_table_2 <- myProteins_table_2[myProteins_table_2$cor_multipled_aboveCutOff == TRUE,]
  p <- ggplot(myProteins_table_2, aes(Freq, Percentage)) +
    geom_point()
  ggplotly(p)
  
  
  myProteins_table <- myProteins_table[myProteins_table$cor_multipled_type != 0,]
  myProteins_table <- myProteins_table %>%
    group_by(Strain1_SystemicID) %>%
    dplyr::mutate(Percentage_TRUE=Freq/sum(Freq)) %>%
    as.data.frame()
  myProteins_table <- myProteins_table[myProteins_table$Freq !=0,]
  rownames(myProteins_table) <- NULL
  
  write.table(myProteins_table_2, 
              file.path(out_dir2, paste0("PS_4_1_", Sys.Date(), "_myProteins_table_2.txt")),
              quote = F, row.names = F, sep="\t")
  myProteins_table$cor_multipled_type_type <- 0
  myProteins_table$cor_multipled_type_type[myProteins_table$cor_multipled_type == "-1:1"] <-  "Minus_plus"
  myProteins_table$cor_multipled_type_type[myProteins_table$cor_multipled_type == "1:1"] <-  "plus_plus"
  
  
  write.table(myProteins_table, 
              file.path(out_dir2, paste0("PS_4_2_", Sys.Date(), "_myProteins_table.txt")),
              quote = F, row.names = F, sep="\t")
  jnk <- as.data.frame(myProteins_table_2$Strain1_SystemicID)
  write.table(jnk, 
              file.path(out_dir2, paste0("PS_4_3_", Sys.Date(), "_myProteins_1815.txt")),
              quote = F, row.names = F, sep="\t")  
  
}
if(proteinExpression_differentStrains){
  # 12 # check the expression profiles of the viable / inviable genes #################
  # 12.1 # assess the viability of the each protein measured ##########################
  viability <- read.delim("FYPO_20191028_pombase.txt", header=FALSE)
  names(viability) <- c("ID", "category")
  
  myfile <- list.files(path = out_dir, pattern = "^6_5_1_.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  df_melt$StrainType <- "Knockout"
  df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wildtype"
  
  myproteins <- as.data.frame(unique(cbind(df_melt$Proteins, df_melt$Proteins)))
  names(myproteins) <- c("pG", "pGsplit")
  myproteins <- splitColumnBySep(myproteins, "pGsplit")
  myproteins <- merge(myproteins, viability, by.x="pGsplit", by.y="ID", all.x=TRUE)
  myproteins <- myproteins %>%
    group_by(pG) %>%
    dplyr::mutate(category_merged=paste0(unique(category), collapse=";")) %>%
    as.data.frame()
  myproteins$category_merged <- gsub("NA;", "", myproteins$category_merged)
  # unique(setdiff(df_melt$Proteins, viability$ID))
  myproteins <- as.data.frame(unique(myproteins[,c(2,5)]))
  # 12.2 # assess the expression levels (abundance) and standard deviation (variability)#######
  df_melt <- df_melt %>%
    group_by(Proteins) %>%
    dplyr::mutate(Mean_all=mean(NormalizedValue, na.rm=TRUE),
                  count_all=sum(!is.na(NormalizedValue)),
                  sd_all=sd(NormalizedValue, na.rm=TRUE)) %>%
    group_by(Proteins, StrainType) %>%
    dplyr::mutate(Mean_wtko=mean(NormalizedValue, na.rm=TRUE),
                  count_wtko=sum(!is.na(NormalizedValue)),
                  sd_wtko=sd(NormalizedValue, na.rm=TRUE)) %>%
    as.data.frame()
  df_proteins <- as.data.frame(unique(df_melt[,c(1,8:14)]))
  df_proteins_wt <- df_proteins[df_proteins$StrainType == "Wildtype",]
  df_proteins_ko <- df_proteins[df_proteins$StrainType == "Knockout",]
  df_proteins_ko <- df_proteins_ko[,c(1,6:8)]
  names(df_proteins_ko) <- gsub("wtko", "ko", names(df_proteins_ko))
  names(df_proteins_wt) <- gsub("wtko", "wt", names(df_proteins_wt))
  df_proteins <- merge(df_proteins_wt, df_proteins_ko, by=1)
  rm(df_proteins_ko)
  rm(df_proteins_wt)
  df_proteins <- merge(df_proteins, myproteins, by=1)
  df_proteins <- df_proteins[,-2]
  df_proteins_subset <- subset(df_proteins, category_merged == "inviable" | category_merged == "viable")
  for (i in 2:10) {
    df_proteins_subset[,i] <- as.numeric(df_proteins_subset[,i])
  }
  
  
  # abundance
  p1 <- ggplot(df_proteins_subset, aes(category_merged, y=Mean_all)) +
    geom_boxplot() +
    stat_compare_means(label.x = 1.2, label.y = 25, size=5)+
    theme_classic()+
    xlab("Gene essentiality") +
    ylab("Abundance") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold")) +
    guides(color=FALSE) +
    ylim(0,25) +
    ggtitle("mean all")
  # df_jnk <- df_melt[df_melt$Proteins == "SPAPB24D3.04c",]
  # rm(df_jnk)
  p2 <- ggplot(df_proteins_subset, aes(category_merged, y=Mean_wt)) +
    geom_boxplot() +
    stat_compare_means(label.x = 1.2, label.y = 25, size=5)+
    theme_classic()+
    xlab("Gene essentiality") +
    ylab("Abundance") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold")) +
    guides(color=FALSE) +
    ylim(0,25) +
    ggtitle("mean wt")
  p3 <- ggplot(df_proteins_subset, aes(category_merged, y=Mean_ko)) +
    geom_boxplot() +
    stat_compare_means(label.x = 1.2, label.y = 25, size=5)+
    theme_classic()+
    xlab("Gene essentiality") +
    ylab("Abundance") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold")) +
    guides(color=FALSE) +
    ylim(0,25) +
    ggtitle("mean ko")
  
  # count
  p4 <- ggplot(df_proteins_subset, aes(category_merged, y=count_all)) +
    geom_boxplot() +
    stat_compare_means(label.x = 1.2, label.y = 4000, size=5)+
    theme_classic()+
    xlab("Gene essentiality") +
    ylab("Number of measurements") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold")) +
    guides(color=FALSE) +
    ggtitle("count all")
  p5 <- ggplot(df_proteins_subset, aes(category_merged, y=count_wt)) +
    geom_boxplot() +
    stat_compare_means(label.x = 1.2, label.y = 500, size=5)+
    theme_classic()+
    xlab("Gene essentiality") +
    ylab("Number of measurements") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold")) +
    guides(color=FALSE) +
    ggtitle("count wt")
  p6 <- ggplot(df_proteins_subset, aes(category_merged, y=count_ko)) +
    geom_boxplot() +
    stat_compare_means(label.x = 1.2, label.y = 3500, size=5)+
    theme_classic()+
    xlab("Gene essentiality") +
    ylab("Number of measurements") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold")) +
    guides(color=FALSE) +
    ggtitle("count ko")
  
  # variation
  p7 <- ggplot(df_proteins_subset, aes(category_merged, y=sd_all)) +
    geom_boxplot() +
    stat_compare_means(label.x = 1.2, label.y = 1.3, size=5)+
    theme_classic()+
    xlab("Gene essentiality") +
    ylab("Variability") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold")) +
    guides(color=FALSE) +
    ggtitle("sd all")
  p8 <- ggplot(df_proteins_subset, aes(category_merged, y=sd_wt)) +
    geom_boxplot() +
    stat_compare_means(label.x = 1.2, label.y = 1.8, size=5)+
    theme_classic()+
    xlab("Gene essentiality") +
    ylab("Variability") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold")) +
    guides(color=FALSE) +
    ggtitle("sd wt")
  p9 <- ggplot(df_proteins_subset, aes(category_merged, y=sd_ko)) +
    geom_boxplot() +
    stat_compare_means(label.x = 1.2, label.y = 1.4, size=5)+
    theme_classic()+
    xlab("Gene essentiality") +
    ylab("Variability") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold")) +
    guides(color=FALSE) +
    ggtitle("sd ko")
  
  pdf(file.path(out_dir, paste0("12_2_1_",Sys.Date(),"_abundance.pdf")), width = 3, height = 3)
  print(p1)
  print(p2)
  print(p3)
  dev.off()
  pdf(file.path(out_dir, paste0("12_2_2_",Sys.Date(),"_counts.pdf")), width = 3, height = 3)
  print(p4)
  print(p5)
  print(p6)
  dev.off()
  pdf(file.path(out_dir, paste0("12_2_3_",Sys.Date(),"_variability.pdf")), width = 3, height = 3)
  print(p7)
  print(p8)
  print(p9)
  dev.off()
  
  saveRDS(df_proteins, file.path(out_dir, paste0("12_2_4_",Sys.Date(),"_df_proteins.rds")))
  saveRDS(df_proteins_subset, file.path(out_dir, paste0("12_2_5_",Sys.Date(),"_df_proteins_subset.rds")))
  # 13 # check the strains most different/growth defect/correlation #################
  # 13.1 # check the strains most different/growth defect .... #################
  myfile <- list.files(path = out_dir, pattern = "^6_12_1.*rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  df_melt <- df_melt[!is.na(df_melt$NormalizedValue),]
  df_melt <- df_melt %>%
    group_by(Strain) %>%
    dplyr::mutate(Identified=sum(!is.na(NormalizedValue)),
                  Regulated_p_05=sum(p_value<=0.05, na.rm=TRUE),
                  Regulated_p_01=sum(p_value<=0.01, na.rm=TRUE),
                  Regulated_pFDR_05=sum(pvalue_FDR<=0.05, na.rm=TRUE),
                  Regulated_pFDR_01=sum(pvalue_FDR<=0.01, na.rm=TRUE),
                  Regulated_ecdf_05=sum(myecdf<=0.025 | myecdf>=0.975, na.rm=TRUE),
                  Regulated_ecdf_01=sum(myecdf<=0.005 | myecdf>=0.995, na.rm=TRUE)) %>%
    as.data.frame()
  
  names(df_melt)
  df_melt <- as.data.frame(unique(df_melt[,c(3,15:21)]))
  df_melt <- df_melt[-c(grep("BIO", df_melt$Strain)),]
  df_melt$SytemicID <- gsub(".*\\-(.*)", "\\1", df_melt$Strain)
  
  myfile <- list.files(path = out_dir, pattern = "^G_1_3_.*.rds")
  decode_growth <- readRDS(file.path(out_dir, myfile))
  decode_growth <- decode_growth[,c(16,25,27)]
  
  df_melt <- merge(df_melt, decode_growth, by.x="SytemicID", by.y="Systemic.ID", all=FALSE)
  rm(decode_growth)
  saveRDS(df_melt, file.path(out_dir, paste0("13_1_1_", Sys.Date(), "_df_melt_numbers_growth.rds")))
  write.table(df_melt, file.path(out_dir, 
                                 paste0("13_1_1_", Sys.Date(), "_df_melt_numbers_growth.txt")),
              quote = F, row.names = F, sep="\t")
  # 13.2 # check the strains correlation coefficients -Normalized value#################
  myfile <- list.files(path = out_dir, pattern = "^6_12_1.*rds")
  df_melt2 <- readRDS(file.path(out_dir, myfile))
  df_melt2 <- df_melt2[!is.na(df_melt2$NormalizedValue),]
  
  mydf <- df_melt2[,c(2,3,4)]
  rm(df_melt2)
  mydf <- dcast(mydf, Proteins ~ Strain, value.var="NormalizedValue")
  rownames(mydf) <- mydf$Proteins
  mydf <- mydf[,-1]
  mydf <- mydf[rowSums(!is.na(mydf))!=0,]

  corAndPvalue_method <- function(df, cor_method){
    StrainCor <- corAndPvalue(df, y = NULL, 
                              use = "pairwise.complete.obs", 
                              alternative = c("two.sided", "less", "greater"), 
                              method=cor_method)
    
    my_df <- as.data.frame(StrainCor[[1]])
    my_df$Strain <- rownames(my_df)
    my_df_melt <- melt(data = my_df, id="Strain")
    names(my_df_melt) <- c("Strain1", "Strain2", names(StrainCor)[1])
    my_df_melt$identifier <- paste(my_df_melt$Strain1, my_df_melt$Strain2, sep="&")
    rm(my_df)
    rownames(my_df_melt) <- my_df_melt$identifier
    my_df_melt <- my_df_melt[,-4]
    jnk <- c(2,5)
    for (i in jnk) {
      print(i)
      my_df_jnk <- as.data.frame(StrainCor[[i]])
      my_df_jnk$Strain <- rownames(my_df_jnk)
      my_df_jnk_melt <- melt(data = my_df_jnk, id="Strain")
      rm(my_df_jnk)
      names(my_df_jnk_melt) <- c("Strain1", "Strain2", names(StrainCor)[i])
      my_df_jnk_melt$identifier <- paste(my_df_jnk_melt$Strain1, my_df_jnk_melt$Strain2, sep="&")
      rownames(my_df_jnk_melt) <- my_df_jnk_melt$identifier
      my_df_jnk_melt <- my_df_jnk_melt[match(rownames(my_df_melt), rownames(my_df_jnk_melt)), ]
      my_df_jnk_melt <- as.data.frame(my_df_jnk_melt[,3])
      names(my_df_jnk_melt)[1] <- names(StrainCor)[i]
      my_df_melt <- cbind(my_df_melt, my_df_jnk_melt)
    }
    saveRDS(my_df_melt, file.path(out_dir, paste0("13_2_1_",cor_method,"_", Sys.Date(), "_corAndPvalue.rds")))
  }
  
  corAndPvalue_method(mydf, "pearson")
  df_cor_N <- readRDS("ScreenProteome/13_2_1_pearson_2019-10-30_corAndPvalue.rds")
  rm(mydf)
  df_cor_N$Strain1_ID <- gsub(".*\\-(.*)", "\\1", df_cor_N$Strain1)
  df_cor_N$Strain2_ID <- gsub(".*\\-(.*)", "\\1", df_cor_N$Strain2)
  
  
  myfile <- list.files(path = out_dir, pattern = "^11_3_2_.*.rds")
  supptable1 <- readRDS(file.path(out_dir, myfile))
  table2merge <- supptable1[,c(19, 22)]
  table2merge <- table2merge[!is.na(table2merge$Systemic.ID),]
  table2merge <- as.data.frame(unique(table2merge))
  rm(supptable1)
  names(table2merge)[2] <- "BG_wt_strain1"
  df_cor_N <- merge(df_cor_N, table2merge, by.x="Strain1_ID", by.y="Systemic.ID", all.x=TRUE)
  table(df_cor_N$Strain1_ID[is.na(df_cor_N$BG_wt_strain1)])
  df_cor_N$BG_wt_strain1[is.na(df_cor_N$BG_wt_strain1)] <- "BIO"
  
  names(table2merge)[2] <- "BG_wt_strain2"
  df_cor_N <- merge(df_cor_N, table2merge, by.x="Strain2_ID", by.y="Systemic.ID", all.x=TRUE)
  table(df_cor_N$Strain2_ID[is.na(df_cor_N$BG_wt_strain2)])
  df_cor_N$BG_wt_strain2[is.na(df_cor_N$BG_wt_strain2)] <- "BIO"
  
  df_cor_N$group2compare1 <- "KO-KO"
  df_cor_N$group2compare1[df_cor_N$BG_wt_strain1 == "BIO" | df_cor_N$BG_wt_strain2 == "BIO"] <- "KO-BIO"
  df_cor_N$group2compare1[df_cor_N$BG_wt_strain1 == "BIO" & df_cor_N$BG_wt_strain2 == "BIO"] <- "BIO-BIO"
  
  df_cor_N$group2compare2 <- FALSE
  df_cor_N$group2compare2[df_cor_N$BG_wt_strain1 == df_cor_N$BG_wt_strain2] <- TRUE
  rm(table2merge)
  
  df_cor_N <- df_cor_N %>%
    group_by(Strain1) %>%
    dplyr::mutate(S1_pearsonR_median=median(cor, na.rm=TRUE)) %>%
    as.data.frame()
  df_cor_N <- df_cor_N %>%
    group_by(Strain1, group2compare1) %>%
    dplyr::mutate(S1_pearsonR_median_group1=median(cor, na.rm=TRUE)) %>%
    as.data.frame()
  df_cor_N <- df_cor_N %>%
    group_by(Strain1, group2compare2) %>%
    dplyr::mutate(S1_pearsonR_median_group2=median(cor, na.rm=TRUE)) %>%
    as.data.frame()
  df_cor_N <- df_cor_N %>%
    group_by(Strain1, group2compare1, group2compare2) %>%
    dplyr::mutate(S1_pearsonR_median_group1_2=median(cor, na.rm=TRUE)) %>%
    as.data.frame()
  names(df_cor_N)
  
  df_cor_N <- as.data.frame(unique(df_cor_N[,c(3,8,10:15)]))
  
  saveRDS(df_cor_N, file.path(out_dir, paste0("13_2_1_", Sys.Date(), "_df_cor_N_grouped.rds")))
  
  df_cor_N2plot <- df_cor_N[df_cor_N$BG_wt_strain1 != "BIO",]
  df_cor_N2plot$group2compare1 <- gsub("BIO", "wt", df_cor_N2plot$group2compare1)
  p1 <- ggplot(df_cor_N2plot, aes(group2compare1, S1_pearsonR_median_group1)) +
    geom_boxplot() +
    theme_classic() +
    xlab(NULL) +
    ylab("Pearson' R (intensity)") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold"))
  
  df_cor_N2plot <- subset(df_cor_N2plot, group2compare1 == "KO-KO")
  df_cor_N2plot$group2compare2[df_cor_N2plot$group2compare2 == TRUE] <- "Same"
  df_cor_N2plot$group2compare2[df_cor_N2plot$group2compare2 == FALSE] <- "Different"
  
  p2 <- ggplot(df_cor_N2plot, aes(group2compare2, S1_pearsonR_median_group2)) +
    geom_boxplot() +
    theme_classic() +
    xlab(NULL) +
    ggtitle("genetic background") +
    ylab("Pearson' R (intensity)") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold"))
  
  df_cor_N2plot <- subset(df_cor_N2plot, group2compare2 == "Same")
  p3 <- ggplot(df_cor_N2plot, aes(BG_wt_strain1, S1_pearsonR_median_group1_2)) +
    geom_boxplot() +
    theme_classic() +
    xlab(NULL) +
    ggtitle("genetic background") +
    ylab("Pearson' R (intensity)") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold"))
  ggsave(file.path(out_dir, paste0("13_2_2_", Sys.Date(), "_plot1_kowt_cor.pdf")),
         p1, width = 4, height = 4)
  ggsave(file.path(out_dir, paste0("13_2_3_", Sys.Date(), "_plot2_ko_genetic_bg_cor.pdf")),
         p2, width = 4, height = 4)
  ggsave(file.path(out_dir, paste0("13_2_4_", Sys.Date(), "_plot3_ko_ED_cor.pdf")),
         p3, width = 4, height = 4)
  
  rm(p1)
  rm(p2)
  rm(p3)
  rm(df_cor_N2plot)
  df_cor_N <- readRDS("ScreenProteome/13_2_1_2019-10-30_df_cor_N_grouped.rds")
  df_cor_N <- df_cor_N[df_cor_N$group2compare1 != "BIO-BIO",]
  df_cor_N <- df_cor_N[,c(1,3,6)]
  df_cor_N <- as.data.frame(unique(df_cor_N))
  df_cor_N <- df_cor_N[-c(grep("BIO", df_cor_N$Strain1)),]
  df_cor_N <- dcast(df_cor_N, Strain1~group2compare1, value.var="S1_pearsonR_median_group1")
  names(df_cor_N)[2] <- "cor2wt_Nintensity"
  names(df_cor_N)[3] <- "cor2ko_Nintensity"
  df_melt <- merge(df_melt, df_cor_N, by.x="Strain", by.y="Strain1")
  rm(df_cor_N)
  jnk <- cor(df_melt[,3:13])
  
  # add the scores #################################
  df_melt <- df_melt[with(df_melt, order(Regulated_p_05,decreasing = T)), ]
  df_melt$Score_p_05 <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(Regulated_p_01,decreasing = T)), ]
  df_melt$Score_p_01 <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(Regulated_pFDR_05,decreasing = T)), ]
  df_melt$Score_pFDR_05 <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(Regulated_pFDR_01,decreasing = T)), ]
  df_melt$Score_pFDR_01 <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(Regulated_ecdf_05,decreasing = T)), ]
  df_melt$Score_ecdf_05 <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(Regulated_ecdf_01,decreasing = T)), ]
  df_melt$Score_ecdf_01 <- 1:dim(df_melt)[1]
  
  df_melt <- df_melt[with(df_melt, order(cor2wt_Nintensity,decreasing = F)), ]
  df_melt$Score_cor2wt_Nintensity <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(cor2ko_Nintensity,decreasing = F)), ]
  df_melt$Score_cor2ko_Nintensity <- 1:dim(df_melt)[1]
  
  
  df_melt$FinalScore <- rowSums(df_melt[,grep("Score", names(df_melt))])

  # df_melt$FinalScore <- rowSums(df_melt[,c(15,17,19,20,21)])
  
  df_melt <- df_melt[with(df_melt, order(FinalScore,decreasing = F)), ]
  df_melt$Rank <- 1:dim(df_melt)[1]
  jnk <- cor(df_melt[,3:21])
  
  saveRDS(df_melt, file.path(out_dir, paste0("13_2_5_", Sys.Date(), "_df_melt_scored_growth.rds")))
  write.table(df_melt, file.path(out_dir, 
                                 paste0("13_2_5_", Sys.Date(), "_df_melt_scored_growth.txt")),
              quote = F, row.names = F, sep="\t")
  
  
  # 13.3 # calculate changes based on knock out's not wt's ###########################################
  myfile <- list.files(path = out_dir, pattern = "^4_2_4_1.*.rds")
  df_normalized <- readRDS(file.path(out_dir, myfile))
    
  numberOfStrains <- dim(df_normalized)[2]
  allCols <- 1:numberOfStrains
  wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
  koCols <- setdiff(allCols, wtCols) 
    
  ko_Mean <- rowMeans(df_normalized[, koCols], na.rm = T)
  ko_SD <- apply(df_normalized[, koCols],1,sd, na.rm=TRUE)
    
  df_normalized_Zscore <- df_normalized - ko_Mean
  df_normalized_Zscore <- df_normalized_Zscore / ko_SD
  
  saveRDS(df_normalized_Zscore, file.path(out_dir, paste0("13_3_1_", Sys.Date(), "_dfNormalized_Zscore_KO.rds")))
  rm(df_normalized)
  rm(df_normalized_Zscore)
    
  myfile <- list.files(path = out_dir, pattern = "^13_3_1_.*.rds")
  df_Zscore <- readRDS(file.path(out_dir, myfile))
    
  df_Zscore_pvalue <- 2*pnorm(-abs(as.matrix(df_Zscore)))
  df_Zscore_pvalue <- as.data.frame(df_Zscore_pvalue)
    
  saveRDS(df_Zscore_pvalue, file.path(out_dir, paste0("13_3_2_", Sys.Date(), "_dfNormalized_pvalue_KO.rds")))
  rm(df_Zscore)
  rm(df_Zscore_pvalue)
    
  myfile <- list.files(path = out_dir, pattern = "^13_3_2_.*.rds")
  df_Zscore_pvalue <- readRDS(file.path(out_dir, myfile))
    
  df_Zscore_pvalue$pG <- rownames(df_Zscore_pvalue)
  df_Zscore_pvalue_melt <- melt(df_Zscore_pvalue, id="pG")
  names(df_Zscore_pvalue_melt) <- c("Protein", "Gene", "pValue")
    
  df_Zscore_pvalue_melt$p_FDR <- p.adjust(df_Zscore_pvalue_melt$pValue, method = "fdr", n = length(df_Zscore_pvalue_melt$pValue))
  
  df_Zscore_pvalue_melt2 <- df_Zscore_pvalue_melt[,c(1,2,4)]
  df_Zscore_pvalue_melt2 <- dcast(df_Zscore_pvalue_melt2, Protein ~ Gene, value.var = "p_FDR")
  rownames(df_Zscore_pvalue_melt2) <- df_Zscore_pvalue_melt2$Protein
  df_Zscore_pvalue_melt2 <- df_Zscore_pvalue_melt2[,-1]
  
  saveRDS(df_Zscore_pvalue, file.path(out_dir, paste0("13_3_3_", Sys.Date(), "_dfNormalized_pvalue_FDRcorrected_KO.rds")))
  rm(df_Zscore_pvalue)
  rm(df_Zscore_pvalue_melt)
  rm(df_Zscore_pvalue_melt2)

  myfile <- list.files(path = out_dir, pattern = "^4_2_4_1.*.rds")
  df_normalized <- readRDS(file.path(out_dir, myfile))
  
  allCols <- 1:dim(df_normalized)[2]
  wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
  koCols <- setdiff(allCols, wtCols) 
    
  ko_Mean <- rowMeans(df_normalized[, koCols], na.rm = T)
    
  df_normalized_FC <- df_normalized - ko_Mean
  saveRDS(df_normalized_FC, file.path(out_dir, paste0("13_3_4_", Sys.Date(), "_dfNormalized_FC_KO.rds")))
  rm(df_normalized_FC)
  rm(df_normalized)
    
  jnk <- as.data.frame(list.files(path=out_dir, pattern = "13_3_[1-4]_.*.rds", recursive=FALSE))
  names(jnk) <- "jnk"
  jnk$code <- c("Zscore", "p_value", "pvalue_FDR","FC")
    
  myfile <- list.files(path = out_dir, pattern = "^4_2_4_1.*.rds")
  df <- readRDS(file.path(out_dir, myfile))
    
  df$Proteins <- rownames(df)
  df_melt <- melt(df, id="Proteins")
  rm(df)
  df_melt$identifier <- paste(df_melt$Proteins, df_melt$variable, sep="_")
  df_melt <- df_melt[,c(4,1,2,3)]
  names(df_melt)[3:4] <- c("Strain", "NormalizedValue")
    
  for (i in 1:dim(jnk)[1]) {
      print(i)
      df_jnk <- readRDS(file.path(out_dir, jnk$jnk[i]))
      df_jnk$Proteins <- rownames(df_jnk)
      df_melt_jnk <- melt(df_jnk, id="Proteins")
      df_melt_jnk$identifier <- paste(df_melt_jnk$Proteins, df_melt_jnk$variable, sep="_")
      df_melt_jnk <- df_melt_jnk[,c(4,3)]
      names(df_melt_jnk)[2] <- jnk$code[i]
      df_melt <- merge(df_melt, df_melt_jnk, by.x="identifier", by.y="identifier", all.x=TRUE)
      print(dim(df_melt))
    }
    
  df_melt <- df_melt[,-1]
  saveRDS(df_melt, file.path(out_dir, paste0("13_3_5_", Sys.Date(), "_meltAllInfo_KO.rds")))
    
  rm(df_jnk)
  rm(df_melt)
  rm(df_melt_jnk)
  rm(jnk)
  # 13.3.6 # calculate the Ntargets and merge to 13.2 for scoring !!! ####################################################
  myfile <- list.files(path = out_dir, pattern = "^13_3_5.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  
  df_melt <- df_melt[!is.na(df_melt$NormalizedValue),]
  df_melt <- df_melt %>%
    group_by(Strain) %>%
    dplyr::mutate(Identified=sum(!is.na(NormalizedValue)),
                  Regulated_p_05=sum(p_value<=0.05, na.rm=TRUE),
                  Regulated_p_01=sum(p_value<=0.01, na.rm=TRUE),
                  Regulated_pFDR_05=sum(pvalue_FDR<=0.05, na.rm=TRUE),
                  Regulated_pFDR_01=sum(pvalue_FDR<=0.01, na.rm=TRUE)) %>%
    as.data.frame()
  
  names(df_melt)
  df_melt <- as.data.frame(unique(df_melt[,c(2,9:12)]))
  
  df_melt <- df_melt[-c(grep("BIO", df_melt$Strain)),]
  names(df_melt) <- paste(names(df_melt), "KO", sep="_")
  
  saveRDS(df_melt, file.path(out_dir, paste0("13_3_6_", Sys.Date(), "_df_melt_numbers_growth.rds")))
  write.table(df_melt, file.path(out_dir, 
                                 paste0("13_3_6_", Sys.Date(), "_df_melt_numbers_growth.txt")),
              quote = F, row.names = F, sep="\t")
  
  df_melt_ko <- df_melt
  myfile <- list.files(path = out_dir, pattern = "^13_2_5.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  df_melt <- df_melt[,c(1:17,20,21)]
  df_melt <- merge(df_melt, df_melt_ko, by=1)
  rm(df_melt_ko)
  # add the new scores 
  df_melt <- df_melt[with(df_melt, order(Regulated_p_05_KO,decreasing = T)), ]
  df_melt$Score_p_05_KO <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(Regulated_p_01_KO,decreasing = T)), ]
  df_melt$Score_p_01_KO <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(Regulated_pFDR_05_KO,decreasing = T)), ]
  df_melt$Score_pFDR_05_KO <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(Regulated_pFDR_01_KO,decreasing = T)), ]
  df_melt$Score_pFDR_01_KO <- 1:dim(df_melt)[1]
  
  jnk <- cor(df_melt[,c(14:19, 24:27)])
  
  df_melt$FinalScore <- rowSums(df_melt[,grep("Score", names(df_melt))])
  
  df_melt$FinalScore <- rowSums(df_melt[,c(16,18,19,26)])
  
  df_melt <- df_melt[with(df_melt, order(FinalScore,decreasing = F)), ]
  df_melt$Rank <- 1:dim(df_melt)[1]
  
  
  saveRDS(df_melt, file.path(out_dir, paste0("13_3_7_", Sys.Date(), "_df_melt_scored_growth_KO.rds")))
  write.table(df_melt, file.path(out_dir, 
                                 paste0("13_3_7_", Sys.Date(), "_df_melt_scored_growth_KO.txt")),
              quote = F, row.names = F, sep="\t")
  # plots 2 send ##########################
  x <- ecdf(df_melt$Regulated_pFDR_05)
  df_melt$Regulated_pFDR_05_ecdf_func <- x(df_melt$Regulated_pFDR_05)
  
  p1 <- ggplot(df_melt, aes(Regulated_pFDR_05))+
    geom_histogram(color="black", bins = 100)+
    geom_point(aes(Regulated_pFDR_05, 800*Regulated_pFDR_05_ecdf_func), color="#b2182b", size=0.9) +
    scale_y_continuous(sec.axis = sec_axis(~./800, name = "Cumulative fraction", breaks = c(0,1))) +
    theme_classic() +
    xlab("# proteins regulated")+
    ylab("# knockout strains") +
    ggtitle("WT based, FDR(p-value) <= 0.05") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold"))
  
  x <- ecdf(df_melt$Regulated_pFDR_05_KO)
  df_melt$Regulated_pFDR_05_KO_ecdf_func <- x(df_melt$Regulated_pFDR_05_KO)
  
  p2 <- ggplot(df_melt, aes(Regulated_pFDR_05_KO))+
    geom_histogram(color="black", bins = 100)+
    geom_point(aes(Regulated_pFDR_05_KO, 600*Regulated_pFDR_05_KO_ecdf_func), color="#b2182b", size=0.9) +
    scale_y_continuous(sec.axis = sec_axis(~./600, name = "Cumulative fraction", breaks = c(0,1))) +
    theme_classic() +
    xlab("# proteins regulated")+
    ylab("# knockout strains") +
    ggtitle("KO based, FDR(p-value) <= 0.05") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold"))
  
  ggsave(file.path(out_dir, paste0("13_3_8_1_", Sys.Date(), "_WT_based_Ntarget_pFDR05.pdf")),
         p1, width = 4, height = 4)
  ggsave(file.path(out_dir, paste0("13_3_8_2_", Sys.Date(), "_KO_based_Ntarget_pFDR05.pdf")),
         p2, width = 4, height = 4)
  # 13.3.9 # add the outlier detection methods for most different #########################################
  # 13.3.9.1 # add the variation of the strain from standard mean #########################################
  myfile <- list.files(path = out_dir, pattern = "^4_2_4_1.*.rds")
  df_normalized <- readRDS(file.path(out_dir, myfile))
  allCols <- 1:dim(df_normalized)[2]
  wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
  koCols <- setdiff(allCols, wtCols) 
  
  wt_mean <- rowMeans(df_normalized[,wtCols], na.rm=TRUE)
  ko_mean <- rowMeans(df_normalized[,koCols], na.rm=TRUE)
  jnk <- cbind(wt_mean, ko_mean)
  
  df_normalized[1:5,1:5]
  df_var_wt <- df_normalized - wt_mean
  df_var_wt <- df_var_wt * df_var_wt
  df_var_wt <- as.data.frame(cbind(colnames(df_var_wt),
                                   colMeans(df_var_wt, na.rm=TRUE),
                                   apply(df_var_wt, 2, median, na.rm=TRUE)))
  names(df_var_wt) <- c("Strain", "Mean_var_wt", "Median_var_wt")
  df_var_ko <- df_normalized - ko_mean
  df_var_ko <- df_var_ko * df_var_ko
  df_var_ko <- as.data.frame(cbind(colnames(df_var_ko),
                                   colMeans(df_var_ko, na.rm=TRUE),
                                   apply(df_var_ko, 2, median, na.rm=TRUE)))
  names(df_var_ko) <- c("Strain", "Mean_var_ko", "Median_var_ko")
  
  df_var <- merge(df_var_ko, df_var_wt, by=1)
  rm(df_var_ko)
  rm(df_var_wt)
  
  myfile <- list.files(path = out_dir, pattern = "^13_3_7.*.rds")
  df_melt <- readRDS(file.path(out_dir, myfile))
  df_melt <- df_melt[,1:27]
  df_melt <- merge(df_melt, df_var, by=1, all.x=TRUE)
  
  df_melt <- df_melt[with(df_melt, order(Mean_var_ko,decreasing = T)), ]
  df_melt$Score_Mean_var_ko <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(Median_var_ko,decreasing = T)), ]
  df_melt$Score_Median_var_ko <- 1:dim(df_melt)[1]
  
  df_melt <- df_melt[with(df_melt, order(Mean_var_wt,decreasing = T)), ]
  df_melt$Score_Mean_var_wt <- 1:dim(df_melt)[1]
  df_melt <- df_melt[with(df_melt, order(Median_var_wt,decreasing = T)), ]
  df_melt$Score_Median_var_wt <- 1:dim(df_melt)[1]
  
  gmean <- function(x){return(exp(mean(log(x))))}
  # df_melt <- df_melt[,1:35]
  df_melt$FinalScore <- apply(df_melt[,c(16,18,19,26,33,35)], 1, gmean)
  df_melt <- df_melt[with(df_melt, order(FinalScore,decreasing = F)), ]
  df_melt$Rank <- 1:dim(df_melt)[1]
  
  saveRDS(df_melt, file.path(out_dir, paste0("13_3_9_1_1_", Sys.Date(), "_df_melt_scored_growth_KO_var.rds")))
  write.table(df_melt, file.path(out_dir, 
                                 paste0("13_3_9_1_1_", Sys.Date(), "_df_melt_scored_growth_KO_var.txt")),
              quote = F, row.names = F, sep="\t")
  # good top 400 !!! check the growth now !!! #########################################################
  df_melt$category <- df_melt$Rank <= 500
  
  jnk <- read.delim("20181110_finalfinalDecision2pick.txt", header = T)
  setdiff(jnk$V1, df_melt$SytemicID[df_melt$Rank <=400])
  
  ggplot(df_melt, aes(category, Zscore_ic)) +
    geom_boxplot(outlier.shape = NA) +
    stat_compare_means(label.x = 1.15, label.y=3, size = 5) +
    theme_classic()+
    xlab(NULL) +
    ylab("Growth rate (Z-score)") +
    ylim(-9, 3)
  
  
  df_melt <- df_melt[with(df_melt, order(Zscore_ic,decreasing = F)), ]
  df_melt$category2 <- 1:dim(df_melt)[1]
  df_melt$category2 <- df_melt$category2 <= 250
  
  ggplot(df_melt, aes(category2, Regulated_pFDR_01_KO)) +
    geom_boxplot() +
    stat_compare_means()
  
  jnk <- as.data.frame(cor(df_melt[,3:35]))
  
  ggplot(df_melt, aes(Regulated_p_05, Regulated_p_05_KO)) +
    geom_point() 
  
  df_melt$p05_difference <- df_melt$Regulated_p_05_KO / (df_melt$Regulated_p_05+0.1)
  
  ######## to skip ##########
  myfile <- list.files(path = out_dir, pattern = "^4_2_4_1.*.rds")
  df_normalized <- readRDS(file.path(out_dir, myfile))
  df_out <- as.data.frame(t(df_normalized[,-grep("WT_Bio", colnames(df_normalized))]))
  rm(df_normalized)

  df_out <- df_out[, colSums(!is.na(df_out)) == dim(df_out)[1]]

  distances <- dd.plot(df_out, quan=0.5, alpha=0.025)
  jnk <- as.data.frame(distances$outliers)
  jnk$strain <- rownames(jnk)
  
  saveRDS(jnk, file.path(subDir, "14_1_distancesKOs.rds"))
  
  outliers <- aq.plot(df_out, delta=qchisq(0.975, df = ncol(df_out)),
                      quan = 1, alpha = 0.05)
  jnk <- as.data.frame(outliers$outliers)
  jnk$strain <- rownames(jnk)
  saveRDS(jnk, file.path(subDir, "14_1_outliersKOs.rds"))
  jnk <- readRDS(file.path(subDir, "14_1_distancesKOs.rds"))
  names(jnk)[1] <- "Distance"
  StrainsChanging <- merge(StrainsChanging, jnk, by.x="Strains", by.y="strain", all=FALSE)
  
  jnk <- readRDS(file.path(subDir, "14_1_outliersKOs.rds"))
  names(jnk)[1] <- "Outliers"
  StrainsChanging <- merge(StrainsChanging, jnk, by.x="Strains", by.y="strain", all=FALSE)
  p4 <- ggplot(StrainsChanging, aes(y=NumberOfTargets, x=MeanCor))+
    geom_point(aes(color=Outliers, shape=Distance), alpha=0.6, size=2) +
    xlab("Mean correlation to wt's")+
    ggtitle("cor: -0.83")
  saveRDS(StrainsChanging, file.path(subDir, "14_1_StrainsDecisions.rds"))
  pdf(file.path(subDir, "14_1_plots.pdf"))
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  dev.off()
  ##########
  
  # 2 cont ### 20191030 #############################
  # 13.4 # correlations from Zscore ####################################################
  df_cor <- readRDS("ScreenProteome/7_20190718_strainClusterCor/7_7_1_2019-07-22_all_corAndPvalue.rds")
  df_cor$Strain1_ID <- gsub(".*\\-(.*)", "\\1", df_cor$Strain1)
  df_cor$Strain2_ID <- gsub(".*\\-(.*)", "\\1", df_cor$Strain2)
  
  
  myfile <- list.files(path = out_dir, pattern = "^11_3_2_.*.rds")
  supptable1 <- readRDS(file.path(out_dir, myfile))
  table2merge <- supptable1[,c(19, 22)]
  table2merge <- table2merge[!is.na(table2merge$Systemic.ID),]
  table2merge <- as.data.frame(unique(table2merge))
  rm(supptable1)
  names(table2merge)[2] <- "BG_wt_strain1"
  df_cor <- merge(df_cor, table2merge, by.x="Strain1_ID", by.y="Systemic.ID", all.x=TRUE)
  table(df_cor$Strain1_ID[is.na(df_cor$BG_wt_strain1)])
  df_cor$BG_wt_strain1[is.na(df_cor$BG_wt_strain1)] <- "BIO"
  
  names(table2merge)[2] <- "BG_wt_strain2"
  df_cor <- merge(df_cor, table2merge, by.x="Strain2_ID", by.y="Systemic.ID", all.x=TRUE)
  table(df_cor$Strain2_ID[is.na(df_cor$BG_wt_strain2)])
  df_cor$BG_wt_strain2[is.na(df_cor$BG_wt_strain2)] <- "BIO"
  
  df_cor$group2compare1 <- "KO-KO"
  df_cor$group2compare1[df_cor$BG_wt_strain1 == "BIO" | df_cor$BG_wt_strain2 == "BIO"] <- "KO-BIO"
  df_cor$group2compare1[df_cor$BG_wt_strain1 == "BIO" & df_cor$BG_wt_strain2 == "BIO"] <- "BIO-BIO"
  
  df_cor$group2compare2 <- FALSE
  df_cor$group2compare2[df_cor$BG_wt_strain1 == df_cor$BG_wt_strain2] <- TRUE
  rm(table2merge)
  
  df_cor <- df_cor %>%
    group_by(Strain1) %>%
    dplyr::mutate(S1_pearsonR_median=median(cor_pearson, na.rm=TRUE)) %>%
    as.data.frame()
  df_cor <- df_cor %>%
    group_by(Strain1, group2compare1) %>%
    dplyr::mutate(S1_pearsonR_median_group1=median(cor_pearson, na.rm=TRUE)) %>%
    as.data.frame()
  df_cor <- df_cor %>%
    group_by(Strain1, group2compare2) %>%
    dplyr::mutate(S1_pearsonR_median_group2=median(cor_pearson, na.rm=TRUE)) %>%
    as.data.frame()
  df_cor <- df_cor %>%
    group_by(Strain1, group2compare1, group2compare2) %>%
    dplyr::mutate(S1_pearsonR_median_group1_2=median(cor_pearson, na.rm=TRUE)) %>%
    as.data.frame()
  names(df_cor)
  df_cor <- as.data.frame(unique(df_cor[,c(3,12,14:19)]))
  
  saveRDS(df_cor, file.path(out_dir, paste0("13_4_1_", Sys.Date(), "_df_cor_grouped.rds")))
  
  jnk <- as.data.frame(table(df_cor[,2:4]))
  jnk <- jnk[jnk$Freq>0,]
  
  p1 <- ggplot(df_cor, aes(group2compare1, S1_pearsonR_median_group1)) +
    geom_boxplot(outlier.shape = NA) +
    theme_classic() +
    xlab(NULL) +
    ylim(-1,1) +
    ylab("Pearson' R (from Z-score)") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold"))
  
  df_cor2 <- subset(df_cor, group2compare1 == "KO-KO")
  p2 <- ggplot(df_cor2, aes(group2compare2, S1_pearsonR_median_group1)) +
    geom_boxplot(outlier.shape = NA) +
    theme_classic() +
    xlab(NULL) +
    ylim(-1,1) +
    ylab("Pearson' R (from Z-score)") +
    theme(axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold"))
  
  }

######

if(toCont){
# cont "diffRegBasedReplicates" and "ScreenQCSupplementaryPlots" # looks funny ignore for now
# cont with 10 for ecdf !!!! ## for screen replicate proteome comparison ###################
if(diffRegBasedReplicates){
  #### replicate diff reg 10%fdr == p=0.03 & fc=0.2  ##############################
  # 9 # compare the replicates and screen to assess tp/fp/fn/tn rates #############
  myfile <- list.files(path = "ReplicateProteome/1U_MBR/", pattern = "meltALL_imputed_Keep")
  df_rep <- readRDS(file.path("ReplicateProteome/1U_MBR/", myfile))
  myfile <- list.files(path = out_dir, pattern = "^6_5")
  df_screen <- readRDS(file.path(out_dir, myfile))
  # 9.1 # decide from replicates which strains is targeting what with which p-fc ######
  df_imp <- df_rep[,c(3,5,18)]
  df_imp <- dcast(df_imp, ProteinIDs ~ ReplicateID)
  rownames(df_imp) <- df_imp$ProteinIDs
  df_imp <- df_imp[,-1]

  experiments <- unique(gsub(".*\\_(.*)\\_[0-9]", "\\1", names(df_imp)))
  experiments <- c(experiments, "wt")
  myconditions <- experiments
  
  my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
  rows2keep <- my_comparisons$V2 == "wt"
  my_comparisons <- my_comparisons[rows2keep,]
  my_comparisons$ComparisonSize <- NA

  myPvalueCutOFF <- 0.03
  myFCCutOFF <- 0.2
  mydf_diffreg <- data.frame(KOstrain=character(),
                             pG=character(),
                             Mean_Strain=numeric(),
                             Mean_wt=numeric(),
                             log2FC_Strain_wt=numeric(),
                             pvalue=numeric())
  
  for (i in 1:dim(my_comparisons)[1]) {
    print(i)
    group1 <- my_comparisons$V1[i]
    group2 <- my_comparisons$V2[i]
    
    if(group1 %in% c("wt1","wt2")){
      group2Cols <- grep(group2, names(df_imp))
      
      df_group <- df_imp[,group2Cols]
      df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
      my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
      
      # original 
      group1Cols <- grep(group1, names(df_group))
      
      myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group, alternative = "two.sided", mu = 0, conf.level = 0.95)
      myPvalue <- myPvalue[,c(4:6,13)]
      myPvalue$pG <- rownames(myPvalue)
      myPvalue$KOstrain <- group1
      myPvalue <- myPvalue[,c(6,5,1,2,3,4)]
      names(myPvalue) <- names(mydf_diffreg)
      mydf_diffreg <- rbind(mydf_diffreg, myPvalue)
      rownames(mydf_diffreg) <- NULL
    } else {
    group1Cols <- grep(group1, names(df_imp))
    group2Cols <- grep(group2, names(df_imp))
    
    df_group <- df_imp[,c(group1Cols, group2Cols)]
    df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
    my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
    
    # original 
    group1Cols <- grep(group1, names(df_group))
    group2Cols <- grep(group2, names(df_group))

    myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
    myPvalue <- myPvalue[,c(4:6,13)]
    myPvalue$pG <- rownames(myPvalue)
    myPvalue$KOstrain <- group1
    myPvalue <- myPvalue[,c(6,5,1,2,3,4)]
    names(myPvalue) <- names(mydf_diffreg)
    mydf_diffreg <- rbind(mydf_diffreg, myPvalue)
    rownames(mydf_diffreg) <- NULL
    }
    }
  saveRDS(mydf_diffreg, file.path(out_dir, paste0("9_1_1_", Sys.Date(), "_replicateProteome_FC_pvalue.rds")))
  
  myfile <- list.files(path = out_dir, pattern = "^9_1_1")
  mydf_diffreg <- readRDS(file.path(out_dir, myfile))
  mydf_diffreg_significant <- subset(mydf_diffreg, abs(log2FC_Strain_wt)>=0.2 & pvalue<=0.03)
  rm(df_group)
  rm(df_imp)
  rm(df_rep)
  rm(myPvalue)
  jnk <- as.data.frame(table(mydf_diffreg_significant$KOstrain))
  my_comparisons <- merge(my_comparisons, jnk, by.x="V1", by.y="Var1", all.x=TRUE)
  names(my_comparisons)[4] <- "NumberOfTargets"
  
  jnk <- subset(mydf_diffreg, log2FC_Strain_wt>=0.2 & pvalue<=0.03)
  jnk <- as.data.frame(table(jnk$KOstrain))
  my_comparisons <- merge(my_comparisons, jnk, by.x="V1", by.y="Var1", all.x=TRUE)
  names(my_comparisons)[5] <- "NumberOfTargets_UP"
  
  jnk <- subset(mydf_diffreg, log2FC_Strain_wt<=-0.2 & pvalue<=0.03)
  jnk <- as.data.frame(table(jnk$KOstrain))
  my_comparisons <- merge(my_comparisons, jnk, by.x="V1", by.y="Var1", all.x=TRUE)
  names(my_comparisons)[6] <- "NumberOfTargets_DOWN"
  saveRDS(my_comparisons, file.path(out_dir, paste0("9_1_2_", Sys.Date(), "_replicateProteome_diffregCount_Strain.rds")))
  rm(jnk)
  rm(mydf_diffreg_significant)
  rm(my_comparisons)
  # 9.2 # check overlaps of identifications from screen and replicate proteomes ######
  df_screen$KOstrain <- gsub(".*\\-(.*)","\\1",df_screen$Strain)
  df_screen$KOstrain[grep("WT", df_screen$Strain)] <- "wt"
  
  df_screen_4replicates <- df_screen[df_screen$KOstrain %in% myconditions,]
  rm(df_screen)
  df_screen_4replicates <- df_screen_4replicates[!is.na(df_screen_4replicates$NormalizedValue),]
  
  mydf_scr_rep <- data.frame(KOstrain=unique(df_screen_4replicates$KOstrain),
                             Screen_pG_count=NA,
                             Replicate_pG_count=NA,
                             Overlap_pG_count=NA)
  
  df_screen_4replicates_overlap <- data.frame(matrix(ncol = 8, nrow = 0))
  colnames(df_screen_4replicates_overlap) <- colnames(df_screen_4replicates)
  
  mydf_diffreg_overlap <- data.frame(matrix(ncol = 6, nrow = 0))
  colnames(mydf_diffreg_overlap) <- colnames(mydf_diffreg)
  
  for (i in 1:dim(mydf_scr_rep)[1]) {
    print(i)
    myKOstrain <- mydf_scr_rep$KOstrain[i]
    df_screen_4replicates_jnk <- subset(df_screen_4replicates, KOstrain == myKOstrain)
    mydf_diffreg_jnk <- subset(mydf_diffreg, KOstrain == myKOstrain)
    mydf_scr_rep$Screen_pG_count[i] <- dim(df_screen_4replicates_jnk)[1] 
    mydf_scr_rep$Replicate_pG_count[i] <- dim(mydf_diffreg_jnk)[1]
    jnk <- unique(intersect(df_screen_4replicates_jnk$Proteins, mydf_diffreg_jnk$pG))
    mydf_scr_rep$Overlap_pG_count[i] <- length(jnk)
   
    df_screen_4replicates_overlap <- rbind(df_screen_4replicates_overlap, 
                                           df_screen_4replicates_jnk[df_screen_4replicates_jnk$Proteins %in% jnk,]) 
    mydf_diffreg_overlap <- rbind(mydf_diffreg_overlap,
                                  mydf_diffreg_jnk[mydf_diffreg_jnk$pG %in% jnk,]) 
    
  }
  myKOstrain <- "wt"
  df_screen_4replicates_jnk <- subset(df_screen_4replicates, KOstrain == myKOstrain)
  mydf_diffreg_jnk <- mydf_diffreg[grep("wt", mydf_diffreg$KOstrain),]
  
  mydf_scr_rep$Screen_pG_count[3] <- length(unique(df_screen_4replicates_jnk$Proteins))
  mydf_scr_rep$Replicate_pG_count[3] <- length(unique(mydf_diffreg_jnk$pG))
  jnk <- unique(intersect(df_screen_4replicates_jnk$Proteins, mydf_diffreg_jnk$pG))
  mydf_scr_rep$Overlap_pG_count[3] <- length(jnk)
  
  df_screen_4replicates_overlap <- rbind(df_screen_4replicates_overlap, 
                                         df_screen_4replicates_jnk[df_screen_4replicates_jnk$Proteins %in% jnk,]) 
  mydf_diffreg_overlap <- rbind(mydf_diffreg_overlap,
                                mydf_diffreg_jnk[mydf_diffreg_jnk$pG %in% jnk,]) 
  
  rm(jnk)
  rm(df_screen_4replicates_jnk)
  rm(mydf_diffreg_jnk)
  
  saveRDS(df_screen_4replicates_overlap, file.path(out_dir, paste0("9_2_1_", Sys.Date(), "_screenProteome_replicateOverlap.rds")))
  saveRDS(mydf_diffreg_overlap, file.path(out_dir, paste0("9_2_2_", Sys.Date(), "_replicateProteome_screenOverlap.rds")))
  
  mydf_scr_rep$Total_pG_count <- mydf_scr_rep$Screen_pG_count + mydf_scr_rep$Replicate_pG_count - mydf_scr_rep$Overlap_pG_count 
  mydf_scr_rep$Overlap_pG_Percentage <- round(100*mydf_scr_rep$Overlap_pG_count/mydf_scr_rep$Total_pG_count,1)
  saveRDS(mydf_scr_rep, file.path(out_dir, paste0("9_2_3_", Sys.Date(), "_OverlapCounts.rds")))
  
  mydf_scr_rep_melt <- melt(mydf_scr_rep, "KOstrain")
  
  p1 <- ggplot(mydf_scr_rep_melt, aes(variable, value)) +
    geom_boxplot(aes(color=variable), fill="black") +
    facet_grid(.~ variable, shrink=FALSE, scales = "free") +
    guides(color=FALSE)+
    xlab(NULL) +
    ylab(NULL) +
    scale_y_continuous(breaks = c(round(as.vector(apply(mydf_scr_rep[,2:6], 2, median)),0)))
  
  rm(df_screen_4replicates)
  rm(mydf_diffreg)
  rm(mydf_scr_rep)
  rm(mydf_scr_rep_melt)
  
  saveRDS(p1, file.path(out_dir, paste0("9_2_4_", Sys.Date(), "_p1.rds")))

  
  rm(p1)
  
  ### LEFT ###
  
  # 9.3 # iterate pvalue FC for finding optimal for TP/TN/FP/FN ######################
  df_screen_4replicates_overlap$pvalue_FDR <- as.numeric(df_screen_4replicates_overlap$pvalue_FDR)
  df_screen_4replicates_overlap$FC <- as.numeric(df_screen_4replicates_overlap$FC)
  
  mydf_diffreg_overlap_significant <- subset(mydf_diffreg_overlap, abs(log2FC_Strain_wt)>=0.2 & pvalue<=0.03)
  
  myPvalueCutOFF <- seq(0,0.5,0.005)
  myFCCutOFF <- seq(0,6,0.1)
  # myfile <- list.files(path=out_dir, pattern="^9_1_2_")
  # my_comparisons <- readRDS(file.path(out_dir, myfile))
  # rm(my_comparisons)
  
  mydf_scr_rep <- as.data.frame(mydf_scr_rep[,c(1,4)])
  
  my_P_FC <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
  my_P_FC2 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
  my_P_FC3 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
  my_P_FC4 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
  
  my_P_FC$group <- "TP"
  my_P_FC2$group <- "FP"
  my_P_FC3$group <- "TN"
  my_P_FC4$group <- "FN"
  my_P_FC <- as.data.frame(rbind(my_P_FC, my_P_FC2, my_P_FC3, my_P_FC4))
  rm(my_P_FC2)
  rm(my_P_FC3)
  rm(my_P_FC4)
  names(my_P_FC)[1] <- "myFCCutOFF"
  names(my_P_FC)[2] <- "myPvalueCutOFF"
  
  my_P_FC$col2add <- paste("myFCCutOFF", my_P_FC$myFCCutOFF ,"myPvalueCutOFF", my_P_FC$myPvalueCutOFF, my_P_FC$group, sep="_")
  
  new_jnk <- as.data.frame(matrix(NA, nrow = dim(mydf_scr_rep)[1], ncol = dim(my_P_FC)[1]))
  names(new_jnk) <- my_P_FC$col2add
  
  mydf_scr_rep <- as.data.frame(cbind(mydf_scr_rep, new_jnk))
  rm(new_jnk)
  rm(my_P_FC)
  saveRDS(mydf_scr_rep, file.path(out_dir, paste0("9_3_1_", Sys.Date(), "_mydf_scr_rep_TPFPTNFN.rds")))
  
  for (i in 1:dim(mydf_scr_rep)[1]) {
    print(i)
    group1 <- mydf_scr_rep$KOstrain[i]

    df_screen_4replicates_overlap_jnk <- subset(df_screen_4replicates_overlap, KOstrain == group1)
    mydf_diffreg_overlap_significant_jnk <- subset(mydf_diffreg_overlap_significant, KOstrain == group1)
    
    for (j in myPvalueCutOFF) {
      for (k in myFCCutOFF) {
        df_screen_4replicates_overlap_jnk_subset <- subset(df_screen_4replicates_overlap_jnk, 
                                                           pvalue_FDR <= j & abs(FC) >= k)
        
        mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "TP", sep="_")
        jnk1 <- length(intersect(df_screen_4replicates_overlap_jnk_subset$Proteins, mydf_diffreg_overlap_significant_jnk$pG))
        mydf_scr_rep[i,grep(mycolname, names(mydf_scr_rep))] <- jnk1
        
        mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "FP", sep="_")
        jnk2 <- length(setdiff(df_screen_4replicates_overlap_jnk_subset$Proteins,
                               mydf_diffreg_overlap_significant_jnk$pG))
        mydf_scr_rep[i,grep(mycolname, names(mydf_scr_rep))] <- jnk2
        
        mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "FN", sep="_")
        jnk3 <- length(setdiff(mydf_diffreg_overlap_significant_jnk$pG,
                               df_screen_4replicates_overlap_jnk_subset$Proteins))
        mydf_scr_rep[i,grep(mycolname, names(mydf_scr_rep))] <- jnk3
        
        mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "TN", sep="_")
        mydf_scr_rep[i,grep(mycolname, names(mydf_scr_rep))] <- mydf_scr_rep$Overlap_pG_count[i] - jnk1 - jnk2 - jnk3
        }
      }
  }
  saveRDS(mydf_scr_rep, file.path(out_dir, paste0("9_3_1_", Sys.Date(), "_mydf_scr_rep_TPFPTNFN.rds")))
  # 9.4 # check for the cutoffs ###############################################
  myfile <- list.files(path=out_dir, pattern="^9_3_1_.*rds")
  my_comparisons <- readRDS(file.path(out_dir, myfile[1]))
  
  df_screen_TP_transform <- function(df, myregex){
    jnkCols <- grep(myregex, names(df))
    jnk <- df[,c(1,jnkCols)]
    jnk <- melt(jnk, "KOstrain")
    jnk$pfc <- paste(gsub("myFCCutOFF_(.*)_myPvalueCutOFF_(.*)_.*", "\\2", jnk$variable),
                     gsub("myFCCutOFF_(.*)_myPvalueCutOFF_(.*)_.*", "\\1", jnk$variable),
                     sep="-")
    jnk <- jnk[,c(1,4,3)]
    jnk$mergeID <- paste(jnk$KOstrain, jnk$pfc, sep=";")
    names(jnk)[3] <- gsub("myFCCutOFF_.*_myPvalueCutOFF_.*_(.*)", "\\1", myregex)
    return(jnk)}
  
  
  df_2merge <- my_comparisons[,c(1,2)]
  df_TP <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_TP")
  df_TN <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_TN")
  df_FP <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_FP")
  df_FN <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_FN")
  
  df_TN <- df_TN[,c(4,3)]
  df_FP <- df_FP[,c(4,3)]
  df_FN <- df_FN[,c(4,3)]
  
  df_2merge <- merge(df_2merge, df_TP, by.x="KOstrain", by.y="KOstrain", all=FALSE)
  df_2merge <- merge(df_2merge, df_TN, by.x="mergeID", by.y="mergeID", all=FALSE)
  df_2merge <- merge(df_2merge, df_FN, by.x="mergeID", by.y="mergeID", all=FALSE)
  df_2merge <- merge(df_2merge, df_FP, by.x="mergeID", by.y="mergeID", all=FALSE)
  rm(df_TP)
  rm(df_TN)
  rm(df_FP)
  rm(df_FN)
  rm(my_comparisons)
  df_2merge$TPR <- df_2merge$TP / (df_2merge$TP + df_2merge$FN)
  df_2merge$FPR <- df_2merge$FP / (df_2merge$FP + df_2merge$TN)
  
  saveRDS(df_2merge, file.path(out_dir, paste0("9_4_1_", Sys.Date(), "_df_merged_melted_TPFPTNFN.rds")))
  # based on the average of the 94
  df_2merge_2 <- df_2merge %>%
    group_by(pfc) %>%
    dplyr::mutate(TPR_mean=mean(TPR), TPR_median=median(TPR),
                  FPR_mean=mean(FPR), FPR_median=median(FPR)) %>%
    as.data.frame()
  df_2merge_2 <- df_2merge_2[,c(4,11:14)]
  df_2merge_2 <- unique(df_2merge_2)
  df_2merge_2$Pvalue <- gsub("(.*)\\-.*", "\\1", df_2merge_2$pfc)
  
  # based on total number of genes categorised in all 94
  df_2merge_3 <- df_2merge[,4:8]
  df_2merge_3 <- df_2merge_3 %>%
    group_by(pfc) %>%
    dplyr::summarise_all(sum) %>%
    as.data.frame()
  df_2merge_3$TPR <- df_2merge_3$TP / (df_2merge_3$TP + df_2merge_3$FN)
  df_2merge_3$FPR <- df_2merge_3$FP / (df_2merge_3$FP + df_2merge_3$TN)
  
  
  ggplot(df_2merge, aes(FPR, TPR))+
    geom_point(aes(color=pfc))+
    guides(color=FALSE)
  
  ggplot(df_2merge_2, aes(FPR_median, TPR_median))+
    geom_point(aes(color=Pvalue))+
    guides(color=FALSE)
  
  p1 <- ggplot(df_2merge_3, aes(FPR, TPR))+
    geom_point()+
    geom_abline(slope = 1, intercept = 0, color="blue")+
    guides(color=FALSE)
  
  df_2merge_3$TPR_FPR <- df_2merge_3$TPR - df_2merge_3$FPR
  df_2merge_3$Pvalue <- gsub("(.*)\\-.*", "\\1", df_2merge_3$pfc)
  df_2merge_3 <- subset(df_2merge_3, Pvalue <= 0.05)
  df_2merge_3$FC <- gsub("(.*)\\-(.*)", "\\2", df_2merge_3$pfc)
  df_2merge_3 <- subset(df_2merge_3, FC <= 2)
  df_2merge_3$FDR <- df_2merge_3$FP / (df_2merge_3$FP + df_2merge_3$TP)
  
  p2 <- ggplot(df_2merge_3, aes(FC, TPR_FPR))+
    geom_point(aes(color=Pvalue)) 

  ggsave("ScreenProteome/p1.png", p1)
  ggsave("ScreenProteome/p2.png", p2)
  
  # 9.5 # check for the cutoffs for pvalue instead of corrected p value ################################
  myfile <- list.files(path=out_dir, pattern="^9_3_1_.*_noFDR.rds")
  my_comparisons <- readRDS(file.path(out_dir, myfile))
  
  df_screen_TP_transform <- function(df, myregex){
    jnkCols <- grep(myregex, names(df))
    jnk <- df[,c(1,jnkCols)]
    jnk <- melt(jnk, "KOstrain")
    jnk$pfc <- paste(gsub("myFCCutOFF_(.*)_myPvalueCutOFF_(.*)_.*", "\\2", jnk$variable),
                     gsub("myFCCutOFF_(.*)_myPvalueCutOFF_(.*)_.*", "\\1", jnk$variable),
                     sep="-")
    jnk <- jnk[,c(1,4,3)]
    jnk$mergeID <- paste(jnk$KOstrain, jnk$pfc, sep=";")
    names(jnk)[3] <- gsub("myFCCutOFF_.*_myPvalueCutOFF_.*_(.*)", "\\1", myregex)
    return(jnk)}
  
  
  df_2merge <- my_comparisons[,c(1,2)]
  df_TP <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_TP")
  df_TN <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_TN")
  df_FP <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_FP")
  df_FN <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_FN")
  
  df_TN <- df_TN[,c(4,3)]
  df_FP <- df_FP[,c(4,3)]
  df_FN <- df_FN[,c(4,3)]
  
  df_2merge <- merge(df_2merge, df_TP, by.x="KOstrain", by.y="KOstrain", all=FALSE)
  df_2merge <- merge(df_2merge, df_TN, by.x="mergeID", by.y="mergeID", all=FALSE)
  df_2merge <- merge(df_2merge, df_FN, by.x="mergeID", by.y="mergeID", all=FALSE)
  df_2merge <- merge(df_2merge, df_FP, by.x="mergeID", by.y="mergeID", all=FALSE)
  rm(df_TP)
  rm(df_TN)
  rm(df_FP)
  rm(df_FN)
  rm(my_comparisons)
  df_2merge$TPR <- df_2merge$TP / (df_2merge$TP + df_2merge$FN)
  df_2merge$FPR <- df_2merge$FP / (df_2merge$FP + df_2merge$TN)
  
  saveRDS(df_2merge, file.path(out_dir, paste0("9_5_1_", Sys.Date(), "_df_merged_melted_TPFPTNFN_noFDR.rds")))
  # # based on the average of the 94
  # df_2merge_2 <- df_2merge %>%
  #   group_by(pfc) %>%
  #   dplyr::mutate(TPR_mean=mean(TPR), TPR_median=median(TPR),
  #                 FPR_mean=mean(FPR), FPR_median=median(FPR)) %>%
  #   as.data.frame()
  # df_2merge_2 <- df_2merge_2[,c(4,11:14)]
  # df_2merge_2 <- unique(df_2merge_2)
  # df_2merge_2$Pvalue <- gsub("(.*)\\-.*", "\\1", df_2merge_2$pfc)
  # 
  # based on total number of genes categorised in all 94
  df_2merge_3 <- df_2merge[,4:8]
  df_2merge_3 <- df_2merge_3 %>%
    group_by(pfc) %>%
    dplyr::summarise_all(sum) %>%
    as.data.frame()
  df_2merge_3$TPR <- df_2merge_3$TP / (df_2merge_3$TP + df_2merge_3$FN)
  df_2merge_3$FPR <- df_2merge_3$FP / (df_2merge_3$FP + df_2merge_3$TN)
  
  
  # ggplot(df_2merge, aes(FPR, TPR))+
  #   geom_point(aes(color=pfc))+
  #   guides(color=FALSE)
  # 
  # ggplot(df_2merge_2, aes(FPR_median, TPR_median))+
  #   geom_point(aes(color=Pvalue))+
  #   guides(color=FALSE)
  # 
  # ggplot(df_2merge_3, aes(FPR, TPR))+
  #   geom_point()+
  #   geom_abline(slope = 1, intercept = 0, color="blue")+
  #   guides(color=FALSE)
  
  df_2merge_3$TPR_FPR <- df_2merge_3$TPR - df_2merge_3$FPR
  df_2merge_3$Pvalue <- gsub("(.*)\\-.*", "\\1", df_2merge_3$pfc)
  df_2merge_3 <- subset(df_2merge_3, Pvalue <= 0.05)
  df_2merge_3$FC <- gsub("(.*)\\-(.*)", "\\2", df_2merge_3$pfc)
  df_2merge_3 <- subset(df_2merge_3, FC <= 2)
  df_2merge_3$FDR <- df_2merge_3$FP / (df_2merge_3$FP + df_2merge_3$TP)
  
  ggplot(df_2merge_3, aes(FC, TPR_FPR))+
    geom_point(aes(color=Pvalue)) 
  
  df_2merge_3$TPRFPR_distance <- NA
  dist2d <- function(a,b,c) {
    v1 <- b - c
    v2 <- a - b
    m <- cbind(v1,v2)
    d <- abs(det(m))/sqrt(sum(v1*v1))
  } 
  for (i in 1:dim(df_2merge_3)[1]) {
    print(i)
    df_2merge_3$TPRFPR_distance[i] <- dist2d(c(df_2merge_3$TPR[i], df_2merge_3$FPR[i]), c(0,0), c(1,1))
  }
  
  ####################### still funny think about 9.4 and 9.5 ##########################################
  # 9.6 # check the correlatin of screen abundances to mean of the replicates ##########################
  myfile <- list.files(path = "ReplicateProteome/1U_MBR/", pattern = "meltALL_imputed_Keep")
  df_rep <- readRDS(file.path("ReplicateProteome/1U_MBR/", myfile))
  myfile <- list.files(path = out_dir, pattern = "^6_5")
  df_screen <- readRDS(file.path(out_dir, myfile))
  
  experiments <- unique(gsub(".*\\_(.*)\\_.*", "\\1", df_rep$SystemicIDko))
  experiments <- setdiff(c(experiments, "wt"), c("wt1", "wt2"))
  
  df_rep$SystemicIDko[grep("wt", df_rep$SystemicIDko)] <- "wt"
  df_rep <- df_rep[,c(3:5,18)]
  df_rep <- df_rep %>%
    group_by(ProteinIDs, SystemicIDko) %>%
    dplyr::mutate(mean_strain = mean(log2Imputed1_Keep, na.rm=TRUE)) %>%
    as.data.frame()

  df_rep1 <- df_rep[,c(1,3,4)]
  df_rep2 <- unique(df_rep[,c(1,2,5)])
  df_rep2$SystemicIDko <- paste(df_rep2$SystemicIDko, "_mean", sep="")
  df_rep2$mean_strain[is.nan(df_rep2$mean_strain)] <- NA
  names(df_rep2) <- names(df_rep1)
  df_rep <- rbind(df_rep1, df_rep2)
  df_rep <- dcast(df_rep, ProteinIDs ~ ReplicateID, value.var="log2Imputed1_Keep")
  rm(df_rep1)
  rm(df_rep2)
  
  df_screen$SysID <- gsub(".*\\-(.*)", "\\1", df_screen$Strain)
  df_screen$SysID[grep("WT", df_screen$Strain)] <- "wt"
  length(grep("wt", df_screen$SysID))
  df_screen$Keep <- df_screen$SysID %in% experiments
  df_screen2 <- df_screen[df_screen$Keep == TRUE, ]
  rm(df_screen)
  
  df_screen <- df_screen2[,c(1,2,3)]
  df_screen <- dcast(df_screen, Proteins ~ Strain, value.var="NormalizedValue")
  wt_cols <- grep("WT", names(df_screen))
  df_screen$wt_mean <- rowMeans(df_screen[,wt_cols], na.rm=TRUE)
  rm(df_screen2)
  names(df_screen)[557] <- "wt_mean_screen"
  df_jnk <- merge(df_screen, df_rep, by.x="Proteins", by.y="ProteinIDs", all=FALSE)
  rownames(df_jnk) <- df_jnk$Proteins
  df_jnk <- df_jnk[,-1]
  df_cor <- cor(df_jnk, use="pairwise.complete.obs", method="pearson")
  saveRDS(df_screen, file.path(out_dir, paste0("9_6_1_", Sys.Date(), "_df_screen_4cor.rds")))
  saveRDS(df_rep, file.path(out_dir, paste0("9_6_2_", Sys.Date(), "_df_replicates_4cor.rds")))
  saveRDS(df_jnk, file.path(out_dir, paste0("9_6_3_", Sys.Date(), "_df_merged_4cor.rds")))
  saveRDS(df_cor, file.path(out_dir, paste0("9_6_4_", Sys.Date(), "_df_cor.rds")))

  rm(df_screen)
  rm(df_rep)
  
  myfile <- list.files(path=out_dir, pattern="^9_6_4")
  df_cor <- readRDS(file.path(out_dir, myfile))
  
  df_cor <- as.data.frame(df_cor)
  df_cor$Strain1 <- rownames(df_cor)
  df_cor <- melt(df_cor, id="Strain1")
  names(df_cor) <- c("Strain1", "Strain2", "PearsonR")

  df_cor$Strain1_ID <- gsub(".*\\-(.*)", "\\1",df_cor$Strain1)
  df_cor$Strain1_ID[grep("rep", df_cor$Strain1_ID)] <- gsub("rep.*\\_(.*)\\_[0-9]","\\1", df_cor$Strain1_ID[grep("rep", df_cor$Strain1_ID)])
  df_cor$Strain1_ID[grep("BIO", df_cor$Strain1_ID)] <- "wt_screen"
  df_cor$Strain1_ID2 <- gsub("_mean", "", df_cor$Strain1_ID) 
  
  df_cor$Strain2_ID <- gsub(".*\\-(.*)", "\\1",df_cor$Strain2)
  df_cor$Strain2_ID[grep("rep", df_cor$Strain2_ID)] <- gsub("rep.*\\_(.*)\\_[0-9]","\\1", df_cor$Strain2_ID[grep("rep", df_cor$Strain2_ID)])
  df_cor$Strain2_ID[grep("BIO", df_cor$Strain2_ID)] <- "wt_screen"
  df_cor$Strain2_ID2 <- gsub("_mean", "", df_cor$Strain2_ID) 
  
  table(df_cor$Strain1_ID2)
  df_cor2 <- subset(df_cor, Strain1_ID2 == Strain2_ID2)
  df_cor2 <- subset(df_cor2, Strain1 != Strain2)
  df_cor2 <- df_cor2[-c(grep("wt", df_cor2$Strain2_ID2)),]
  
  df_cor2$AnyMean <- FALSE
  df_cor2$AnyMean[c(grep("mean", df_cor2$Strain1_ID), grep("mean", df_cor2$Strain2_ID))] <- TRUE
  df_cor2$AnyReplicate <- FALSE
  df_cor2$AnyReplicate[c(grep("rep", df_cor2$Strain1), grep("rep", df_cor2$Strain2))] <- TRUE
  df_cor2$Replicate2Mean <- df_cor2$AnyMean * df_cor2$AnyReplicate
  
  df_cor2$BothReplicate <- FALSE
  df_cor2$BothReplicate[intersect(grep("rep", df_cor2$Strain1), grep("rep", df_cor2$Strain2))] <- TRUE
  df_cor2$Replicate2Mean[df_cor2$BothReplicate==TRUE] <- 2
  
  df_cor2$Replicate2Mean[df_cor2$Replicate2Mean==0] <- "Screen_Replicate"
  df_cor2$Replicate2Mean[intersect(grep("Screen_Replicate", df_cor2$Replicate2Mean), c(grep("mean", df_cor2$Strain1), grep("mean", df_cor2$Strain2)))] <- "Screen_Replicate_mean"
  
  df_cor2$Replicate2Mean[df_cor2$Replicate2Mean==1] <- "Replicate_Replicate_mean"
  df_cor2$Replicate2Mean[df_cor2$Replicate2Mean==2] <- "Replicate_Replicate"  
  # names(df_jnk)[grep("wt_mean", names(df_jnk))]
  
  jnk <- round(cor(df_jnk$wt_mean_screen, df_jnk$wt_mean, use="pairwise.complete.obs", method="pearson"), 2)[1]
  
  p3 <- ggplot(df_jnk, aes(wt_mean_screen, wt_mean)) +
    geom_point() +
    geom_abline(slope=1, intercept = 0) +
    xlab("WT mean for screen") +
    ylab("WT mean for replicates") +
    geom_smooth(method="lm") +
    ggtitle(paste("cor:", jnk))
  
  df_cor2 <- df_cor2[df_cor2$AnyMean == FALSE, ]
  p4 <- ggplot(df_cor2, aes(PearsonR)) +
    geom_density(aes(fill=Replicate2Mean, color=Replicate2Mean), size=1, alpha=0.4) +
    labs(fill = NULL, color=NULL) +
    theme(legend.position="top", axis.title = element_text(size = 20), axis.text.x = element_text(size = 16),
          legend.text = element_text(size= 14))
  
  ############
  df_cor2 <- subset(df_cor, Strain1 != Strain2)
  df_cor2 <- df_cor2[-c(grep("wt", df_cor2$Strain2_ID2)),]
  df_cor2 <- df_cor2[-c(grep("wt", df_cor2$Strain1_ID2)),]
  df_cor2 <- df_cor2[-c(grep("mean", df_cor2$Strain1_ID)),]
  df_cor2 <- df_cor2[-c(grep("mean", df_cor2$Strain2_ID)),]
  
  df_cor2 <- df_cor2[,c(1,2,3,4,6)]
  df_cor2$SameStrain <- df_cor2$Strain1_ID == df_cor2$Strain2_ID
  
  df_cor2$Replicate1 <- FALSE
  df_cor2$Replicate1[c(grep("rep", df_cor2$Strain1))] <- TRUE
  
  df_cor2$Replicate2 <- FALSE
  df_cor2$Replicate2[c(grep("rep", df_cor2$Strain2))] <- TRUE
  df_cor2$Category <- NA
  
  df_cor2$Category[intersect(grep("TRUE", df_cor2$SameStrain), intersect(grep("TRUE", df_cor2$Replicate1), grep("TRUE", df_cor2$Replicate2)))] <- "SameStrain_Replicate_Replicate"
  df_cor2$Category[intersect(grep("FALSE", df_cor2$SameStrain), intersect(grep("TRUE", df_cor2$Replicate1), grep("TRUE", df_cor2$Replicate2)))] <- "DifferentStrain_Replicate_Replicate"
  
  df_cor2$Category[intersect(grep("TRUE", df_cor2$SameStrain), intersect(grep("FALSE", df_cor2$Replicate1), grep("TRUE", df_cor2$Replicate2)))] <- "SameStrain_Screen_Replicate"
  df_cor2$Category[intersect(grep("TRUE", df_cor2$SameStrain), intersect(grep("TRUE", df_cor2$Replicate1), grep("FALSE", df_cor2$Replicate2)))] <- "SameStrain_Screen_Replicate"
  
  df_cor2$Category[intersect(grep("FALSE", df_cor2$SameStrain), intersect(grep("FALSE", df_cor2$Replicate1), grep("TRUE", df_cor2$Replicate2)))] <- "DifferentStrain_Screen_Replicate"
  df_cor2$Category[intersect(grep("FALSE", df_cor2$SameStrain), intersect(grep("TRUE", df_cor2$Replicate1), grep("FALSE", df_cor2$Replicate2)))] <- "DifferentStrain_Screen_Replicate"
  df_cor2$Category[intersect(grep("FALSE", df_cor2$SameStrain), intersect(grep("FALSE", df_cor2$Replicate1), grep("FALSE", df_cor2$Replicate2)))] <- "DifferentStrain_Screen_Screen"
  
  p4 <- ggplot(df_cor2, aes(PearsonR)) +
    geom_density(aes(fill=Category, color=Category), size=1, alpha=0.4) +
    labs(fill = NULL, color=NULL) +
    theme(axis.title = element_text(size = 20), axis.text.x = element_text(size = 16),
          legend.text = element_text(size= 14))
  
  ggsave("ScreenProteome/p5.png", p4)
  
  ############ based on ecdf ######################################################
  
  
  
  
  # replicate diff reg 10% fdr == p=0.03 & fc=0.2 #################################
  #### replicate diff reg 10%fdr == p=0.03 & fc=0.2  ##############################
  # 10 # compare the replicates and screen to assess tp/fp/fn/tn rates #############
  myfile <- list.files(path = "ReplicateProteome/1U_MBR/", pattern = "meltALL_imputed_Keep")
  df_rep <- readRDS(file.path("ReplicateProteome/1U_MBR/", myfile))
  myfile <- list.files(path = out_dir, pattern = "^6_11_1.*melt.*rds")
  df_screen <- readRDS(file.path(out_dir, myfile))
  # 10.1 # decide from replicates which strains is targeting what with which p-fc ######
  df_imp <- df_rep[,c(3,5,18)]
  df_imp <- dcast(df_imp, ProteinIDs ~ ReplicateID)
  rownames(df_imp) <- df_imp$ProteinIDs
  df_imp <- df_imp[,-1]
  
  experiments <- unique(gsub(".*\\_(.*)\\_[0-9]", "\\1", names(df_imp)))
  experiments <- c(experiments, "wt")
  myconditions <- experiments

  myfile <- list.files(path = out_dir, pattern = "^9_1_1")
  mydf_diffreg <- readRDS(file.path(out_dir, myfile))
  mydf_diffreg_significant <- subset(mydf_diffreg, abs(log2FC_Strain_wt)>=0.2 & pvalue<=0.03)
  rm(df_imp)
  rm(df_rep)
  
  myfile <- list.files(path = out_dir, pattern = "^9_1_2")
  my_comparisons <- readRDS(file.path(out_dir, myfile))
  rm(mydf_diffreg_significant)
  rm(my_comparisons)
  # 10.2 # check overlaps of identifications from screen and replicate proteomes ######
  df_screen$KOstrain <- gsub(".*\\-(.*)","\\1",df_screen$Strain)
  df_screen$KOstrain[grep("WT", df_screen$Strain)] <- "wt"
  
  df_screen_4replicates <- df_screen[df_screen$KOstrain %in% myconditions,]
  rm(df_screen)
  df_screen_4replicates <- df_screen_4replicates[!is.na(df_screen_4replicates$NormalizedValue),]
  
  mydf_scr_rep <- data.frame(KOstrain=unique(df_screen_4replicates$KOstrain),
                             Screen_pG_count=NA,
                             Replicate_pG_count=NA,
                             Overlap_pG_count=NA)
  
  df_screen_4replicates_overlap <- data.frame(matrix(ncol = 8, nrow = 0))
  colnames(df_screen_4replicates_overlap) <- colnames(df_screen_4replicates)
  
  mydf_diffreg_overlap <- data.frame(matrix(ncol = 6, nrow = 0))
  colnames(mydf_diffreg_overlap) <- colnames(mydf_diffreg)
  
  for (i in 1:dim(mydf_scr_rep)[1]) {
    print(i)
    myKOstrain <- mydf_scr_rep$KOstrain[i]
    df_screen_4replicates_jnk <- subset(df_screen_4replicates, KOstrain == myKOstrain)
    mydf_diffreg_jnk <- subset(mydf_diffreg, KOstrain == myKOstrain)
    mydf_scr_rep$Screen_pG_count[i] <- dim(df_screen_4replicates_jnk)[1] 
    mydf_scr_rep$Replicate_pG_count[i] <- dim(mydf_diffreg_jnk)[1]
    jnk <- unique(intersect(df_screen_4replicates_jnk$Proteins, mydf_diffreg_jnk$pG))
    mydf_scr_rep$Overlap_pG_count[i] <- length(jnk)
    
    df_screen_4replicates_overlap <- rbind(df_screen_4replicates_overlap, 
                                           df_screen_4replicates_jnk[df_screen_4replicates_jnk$Proteins %in% jnk,]) 
    mydf_diffreg_overlap <- rbind(mydf_diffreg_overlap,
                                  mydf_diffreg_jnk[mydf_diffreg_jnk$pG %in% jnk,]) 
    
  }
  myKOstrain <- "wt"
  df_screen_4replicates_jnk <- subset(df_screen_4replicates, KOstrain == myKOstrain)
  mydf_diffreg_jnk <- mydf_diffreg[grep("wt", mydf_diffreg$KOstrain),]
  
  mydf_scr_rep$Screen_pG_count[3] <- length(unique(df_screen_4replicates_jnk$Proteins))
  mydf_scr_rep$Replicate_pG_count[3] <- length(unique(mydf_diffreg_jnk$pG))
  jnk <- unique(intersect(df_screen_4replicates_jnk$Proteins, mydf_diffreg_jnk$pG))
  mydf_scr_rep$Overlap_pG_count[3] <- length(jnk)
  
  df_screen_4replicates_overlap <- rbind(df_screen_4replicates_overlap, 
                                         df_screen_4replicates_jnk[df_screen_4replicates_jnk$Proteins %in% jnk,]) 
  mydf_diffreg_overlap <- rbind(mydf_diffreg_overlap,
                                mydf_diffreg_jnk[mydf_diffreg_jnk$pG %in% jnk,]) 
  
  rm(jnk)
  rm(df_screen_4replicates_jnk)
  rm(mydf_diffreg_jnk)
  
  saveRDS(df_screen_4replicates_overlap, file.path(out_dir, paste0("10_2_1_", Sys.Date(), "_screenProteome_replicateOverlap.rds")))
  saveRDS(mydf_diffreg_overlap, file.path(out_dir, paste0("10_2_2_", Sys.Date(), "_replicateProteome_screenOverlap.rds")))
  
  mydf_scr_rep$Total_pG_count <- mydf_scr_rep$Screen_pG_count + mydf_scr_rep$Replicate_pG_count - mydf_scr_rep$Overlap_pG_count 
  mydf_scr_rep$Overlap_pG_Percentage <- round(100*mydf_scr_rep$Overlap_pG_count/mydf_scr_rep$Total_pG_count,1)
  saveRDS(mydf_scr_rep, file.path(out_dir, paste0("10_2_3_", Sys.Date(), "_OverlapCounts.rds")))
  
  mydf_scr_rep_melt <- melt(mydf_scr_rep, "KOstrain")
  
  p1 <- ggplot(mydf_scr_rep_melt, aes(variable, value)) +
    geom_boxplot(aes(color=variable), fill="black") +
    facet_grid(.~ variable, shrink=FALSE, scales = "free") +
    guides(color=FALSE)+
    xlab(NULL) +
    ylab(NULL) +
    scale_y_continuous(breaks = c(round(as.vector(apply(mydf_scr_rep[,2:6], 2, median)),0)))
  
  rm(df_screen_4replicates)
  rm(mydf_diffreg)
  rm(mydf_scr_rep)
  rm(mydf_scr_rep_melt)
  
  saveRDS(p1, file.path(out_dir, paste0("10_2_4_", Sys.Date(), "_p1.rds")))
  rm(p1)
  # 10.3 # iterate pvalue FC for finding optimal for TP/TN/FP/FN ######################
  df_screen_4replicates_overlap$pvalue_FDR <- as.numeric(df_screen_4replicates_overlap$pvalue_FDR)
  df_screen_4replicates_overlap$FC <- as.numeric(df_screen_4replicates_overlap$FC)
  
  mydf_diffreg_overlap_significant <- subset(mydf_diffreg_overlap, abs(log2FC_Strain_wt)>=0.2 & pvalue<=0.03)
  
  myPvalueCutOFF <- seq(0,0.5,0.005)
  myFCCutOFF <- seq(0,6,0.1)
  # myfile <- list.files(path=out_dir, pattern="^9_1_2_")
  # my_comparisons <- readRDS(file.path(out_dir, myfile))
  # rm(my_comparisons)
  
  mydf_scr_rep <- as.data.frame(mydf_scr_rep[,c(1,4)])
  
  my_P_FC <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
  my_P_FC2 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
  my_P_FC3 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
  my_P_FC4 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
  
  my_P_FC$group <- "TP"
  my_P_FC2$group <- "FP"
  my_P_FC3$group <- "TN"
  my_P_FC4$group <- "FN"
  my_P_FC <- as.data.frame(rbind(my_P_FC, my_P_FC2, my_P_FC3, my_P_FC4))
  rm(my_P_FC2)
  rm(my_P_FC3)
  rm(my_P_FC4)
  names(my_P_FC)[1] <- "myFCCutOFF"
  names(my_P_FC)[2] <- "myPvalueCutOFF"
  
  my_P_FC$col2add <- paste("myFCCutOFF", my_P_FC$myFCCutOFF ,"myPvalueCutOFF", my_P_FC$myPvalueCutOFF, my_P_FC$group, sep="_")
  
  new_jnk <- as.data.frame(matrix(NA, nrow = dim(mydf_scr_rep)[1], ncol = dim(my_P_FC)[1]))
  names(new_jnk) <- my_P_FC$col2add
  
  mydf_scr_rep <- as.data.frame(cbind(mydf_scr_rep, new_jnk))
  rm(new_jnk)
  rm(my_P_FC)
  saveRDS(mydf_scr_rep, file.path(out_dir, paste0("9_3_1_", Sys.Date(), "_mydf_scr_rep_TPFPTNFN.rds")))
  
  for (i in 1:dim(mydf_scr_rep)[1]) {
    print(i)
    group1 <- mydf_scr_rep$KOstrain[i]
    
    df_screen_4replicates_overlap_jnk <- subset(df_screen_4replicates_overlap, KOstrain == group1)
    mydf_diffreg_overlap_significant_jnk <- subset(mydf_diffreg_overlap_significant, KOstrain == group1)
    
    for (j in myPvalueCutOFF) {
      for (k in myFCCutOFF) {
        df_screen_4replicates_overlap_jnk_subset <- subset(df_screen_4replicates_overlap_jnk, 
                                                           pvalue_FDR <= j & abs(FC) >= k)
        
        mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "TP", sep="_")
        jnk1 <- length(intersect(df_screen_4replicates_overlap_jnk_subset$Proteins, mydf_diffreg_overlap_significant_jnk$pG))
        mydf_scr_rep[i,grep(mycolname, names(mydf_scr_rep))] <- jnk1
        
        mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "FP", sep="_")
        jnk2 <- length(setdiff(df_screen_4replicates_overlap_jnk_subset$Proteins,
                               mydf_diffreg_overlap_significant_jnk$pG))
        mydf_scr_rep[i,grep(mycolname, names(mydf_scr_rep))] <- jnk2
        
        mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "FN", sep="_")
        jnk3 <- length(setdiff(mydf_diffreg_overlap_significant_jnk$pG,
                               df_screen_4replicates_overlap_jnk_subset$Proteins))
        mydf_scr_rep[i,grep(mycolname, names(mydf_scr_rep))] <- jnk3
        
        mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "TN", sep="_")
        mydf_scr_rep[i,grep(mycolname, names(mydf_scr_rep))] <- mydf_scr_rep$Overlap_pG_count[i] - jnk1 - jnk2 - jnk3
      }
    }
  }
  saveRDS(mydf_scr_rep, file.path(out_dir, paste0("10_3_1_", Sys.Date(), "_mydf_scr_rep_TPFPTNFN.rds")))
  # 10.4 # check for the cutoffs ###############################################
  myfile <- list.files(path=out_dir, pattern="^10_3_1_.*rds")
  my_comparisons <- readRDS(file.path(out_dir, myfile[1]))
  
  df_screen_TP_transform <- function(df, myregex){
    jnkCols <- grep(myregex, names(df))
    jnk <- df[,c(1,jnkCols)]
    jnk <- melt(jnk, "KOstrain")
    jnk$pfc <- paste(gsub("myFCCutOFF_(.*)_myPvalueCutOFF_(.*)_.*", "\\2", jnk$variable),
                     gsub("myFCCutOFF_(.*)_myPvalueCutOFF_(.*)_.*", "\\1", jnk$variable),
                     sep="-")
    jnk <- jnk[,c(1,4,3)]
    jnk$mergeID <- paste(jnk$KOstrain, jnk$pfc, sep=";")
    names(jnk)[3] <- gsub("myFCCutOFF_.*_myPvalueCutOFF_.*_(.*)", "\\1", myregex)
    return(jnk)}
  
  
  df_2merge <- my_comparisons[,c(1,2)]
  df_TP <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_TP")
  df_TN <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_TN")
  df_FP <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_FP")
  df_FN <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_FN")
  
  df_TN <- df_TN[,c(4,3)]
  df_FP <- df_FP[,c(4,3)]
  df_FN <- df_FN[,c(4,3)]
  
  df_2merge <- merge(df_2merge, df_TP, by.x="KOstrain", by.y="KOstrain", all=FALSE)
  df_2merge <- merge(df_2merge, df_TN, by.x="mergeID", by.y="mergeID", all=FALSE)
  df_2merge <- merge(df_2merge, df_FN, by.x="mergeID", by.y="mergeID", all=FALSE)
  df_2merge <- merge(df_2merge, df_FP, by.x="mergeID", by.y="mergeID", all=FALSE)
  rm(df_TP)
  rm(df_TN)
  rm(df_FP)
  rm(df_FN)
  rm(my_comparisons)
  df_2merge$TPR <- df_2merge$TP / (df_2merge$TP + df_2merge$FN)
  df_2merge$FPR <- df_2merge$FP / (df_2merge$FP + df_2merge$TN)
  
  saveRDS(df_2merge, file.path(out_dir, paste0("10_4_1_", Sys.Date(), "_df_merged_melted_TPFPTNFN.rds")))
  # based on the average of the 94
  df_2merge_2 <- df_2merge %>%
    group_by(pfc) %>%
    dplyr::mutate(TPR_mean=mean(TPR), TPR_median=median(TPR),
                  FPR_mean=mean(FPR), FPR_median=median(FPR)) %>%
    as.data.frame()
  df_2merge_2 <- df_2merge_2[,c(4,11:14)]
  df_2merge_2 <- unique(df_2merge_2)
  df_2merge_2$Pvalue <- gsub("(.*)\\-.*", "\\1", df_2merge_2$pfc)
  
  # based on total number of genes categorised in all 94
  df_2merge_3 <- df_2merge[,4:8]
  df_2merge_3 <- df_2merge_3 %>%
    group_by(pfc) %>%
    dplyr::summarise_all(sum) %>%
    as.data.frame()
  df_2merge_3$TPR <- df_2merge_3$TP / (df_2merge_3$TP + df_2merge_3$FN)
  df_2merge_3$FPR <- df_2merge_3$FP / (df_2merge_3$FP + df_2merge_3$TN)
  
  
  ggplot(df_2merge, aes(FPR, TPR))+
    geom_point(aes(color=pfc))+
    guides(color=FALSE)
  
  ggplot(df_2merge_2, aes(FPR_median, TPR_median))+
    geom_point(aes(color=Pvalue))+
    guides(color=FALSE)
  
  p1 <- ggplot(df_2merge_3, aes(FPR, TPR))+
    geom_point()+
    geom_abline(slope = 1, intercept = 0, color="blue")+
    guides(color=FALSE)
  
  df_2merge_3$TPR_FPR <- df_2merge_3$TPR - df_2merge_3$FPR
  df_2merge_3$Pvalue <- gsub("(.*)\\-.*", "\\1", df_2merge_3$pfc)
  df_2merge_3 <- subset(df_2merge_3, Pvalue <= 0.05)
  df_2merge_3$FC <- gsub("(.*)\\-(.*)", "\\2", df_2merge_3$pfc)
  df_2merge_3 <- subset(df_2merge_3, FC <= 2)
  df_2merge_3$FDR <- df_2merge_3$FP / (df_2merge_3$FP + df_2merge_3$TP)
  
  p2 <- ggplot(df_2merge_3, aes(FC, TPR_FPR))+
    geom_point(aes(color=Pvalue)) 
  
  ggsave("ScreenProteome/p10_1.png", p1)
  ggsave("ScreenProteome/p10_2.png", p2)
  
  # 10.5 # check for the cutoffs for pvalue instead of corrected p value ################################
  myfile <- list.files(path=out_dir, pattern="^10_3_1_.*_noFDR.rds")
  my_comparisons <- readRDS(file.path(out_dir, myfile))
  
  df_screen_TP_transform <- function(df, myregex){
    jnkCols <- grep(myregex, names(df))
    jnk <- df[,c(1,jnkCols)]
    jnk <- melt(jnk, "KOstrain")
    jnk$pfc <- paste(gsub("myFCCutOFF_(.*)_myPvalueCutOFF_(.*)_.*", "\\2", jnk$variable),
                     gsub("myFCCutOFF_(.*)_myPvalueCutOFF_(.*)_.*", "\\1", jnk$variable),
                     sep="-")
    jnk <- jnk[,c(1,4,3)]
    jnk$mergeID <- paste(jnk$KOstrain, jnk$pfc, sep=";")
    names(jnk)[3] <- gsub("myFCCutOFF_.*_myPvalueCutOFF_.*_(.*)", "\\1", myregex)
    return(jnk)}
  
  
  df_2merge <- my_comparisons[,c(1,2)]
  df_TP <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_TP")
  df_TN <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_TN")
  df_FP <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_FP")
  df_FN <- df_screen_TP_transform(my_comparisons, "myFCCutOFF_.*_myPvalueCutOFF_.*_FN")
  
  df_TN <- df_TN[,c(4,3)]
  df_FP <- df_FP[,c(4,3)]
  df_FN <- df_FN[,c(4,3)]
  
  df_2merge <- merge(df_2merge, df_TP, by.x="KOstrain", by.y="KOstrain", all=FALSE)
  df_2merge <- merge(df_2merge, df_TN, by.x="mergeID", by.y="mergeID", all=FALSE)
  df_2merge <- merge(df_2merge, df_FN, by.x="mergeID", by.y="mergeID", all=FALSE)
  df_2merge <- merge(df_2merge, df_FP, by.x="mergeID", by.y="mergeID", all=FALSE)
  rm(df_TP)
  rm(df_TN)
  rm(df_FP)
  rm(df_FN)
  rm(my_comparisons)
  df_2merge$TPR <- df_2merge$TP / (df_2merge$TP + df_2merge$FN)
  df_2merge$FPR <- df_2merge$FP / (df_2merge$FP + df_2merge$TN)
  
  saveRDS(df_2merge, file.path(out_dir, paste0("10_5_1_", Sys.Date(), "_df_merged_melted_TPFPTNFN_noFDR.rds")))
  # # based on the average of the 94
  # df_2merge_2 <- df_2merge %>%
  #   group_by(pfc) %>%
  #   dplyr::mutate(TPR_mean=mean(TPR), TPR_median=median(TPR),
  #                 FPR_mean=mean(FPR), FPR_median=median(FPR)) %>%
  #   as.data.frame()
  # df_2merge_2 <- df_2merge_2[,c(4,11:14)]
  # df_2merge_2 <- unique(df_2merge_2)
  # df_2merge_2$Pvalue <- gsub("(.*)\\-.*", "\\1", df_2merge_2$pfc)
  # 
  # based on total number of genes categorised in all 94
  df_2merge_3 <- df_2merge[,4:8]
  df_2merge_3 <- df_2merge_3 %>%
    group_by(pfc) %>%
    dplyr::summarise_all(sum) %>%
    as.data.frame()
  df_2merge_3$TPR <- df_2merge_3$TP / (df_2merge_3$TP + df_2merge_3$FN)
  df_2merge_3$FPR <- df_2merge_3$FP / (df_2merge_3$FP + df_2merge_3$TN)
  
  
  # ggplot(df_2merge, aes(FPR, TPR))+
  #   geom_point(aes(color=pfc))+
  #   guides(color=FALSE)
  # 
  # ggplot(df_2merge_2, aes(FPR_median, TPR_median))+
  #   geom_point(aes(color=Pvalue))+
  #   guides(color=FALSE)
  # 
  # ggplot(df_2merge_3, aes(FPR, TPR))+
  #   geom_point()+
  #   geom_abline(slope = 1, intercept = 0, color="blue")+
  #   guides(color=FALSE)
  
  df_2merge_3$TPR_FPR <- df_2merge_3$TPR - df_2merge_3$FPR
  df_2merge_3$Pvalue <- gsub("(.*)\\-.*", "\\1", df_2merge_3$pfc)
  df_2merge_3 <- subset(df_2merge_3, Pvalue <= 0.05)
  df_2merge_3$FC <- gsub("(.*)\\-(.*)", "\\2", df_2merge_3$pfc)
  df_2merge_3 <- subset(df_2merge_3, FC <= 2)
  df_2merge_3$FDR <- df_2merge_3$FP / (df_2merge_3$FP + df_2merge_3$TP)
  
  ggplot(df_2merge_3, aes(FC, TPR_FPR))+
    geom_point(aes(color=Pvalue)) 
  
  df_2merge_3$TPRFPR_distance <- NA
  dist2d <- function(a,b,c) {
    v1 <- b - c
    v2 <- a - b
    m <- cbind(v1,v2)
    d <- abs(det(m))/sqrt(sum(v1*v1))
  } 
  for (i in 1:dim(df_2merge_3)[1]) {
    print(i)
    df_2merge_3$TPRFPR_distance[i] <- dist2d(c(df_2merge_3$TPR[i], df_2merge_3$FPR[i]), c(0,0), c(1,1))
  }
  
  ####################### still funny think about 9.4 and 9.5 ##########################################
  # 10.6 # check the correlatin of screen abundances to mean of the replicates ##########################
  myfile <- list.files(path = "ReplicateProteome/1U_MBR/", pattern = "meltALL_imputed_Keep")
  df_rep <- readRDS(file.path("ReplicateProteome/1U_MBR/", myfile))
  myfile <- list.files(path = out_dir, pattern = "^6_5_1")
  df_screen <- readRDS(file.path(out_dir, myfile))
  
  experiments <- unique(gsub(".*\\_(.*)\\_.*", "\\1", df_rep$SystemicIDko))
  experiments <- setdiff(c(experiments, "wt"), c("wt1", "wt2"))
  
  df_rep$SystemicIDko[grep("wt", df_rep$SystemicIDko)] <- "wt"
  df_rep <- df_rep[,c(3:5,18)]
  df_rep <- df_rep %>%
    group_by(ProteinIDs, SystemicIDko) %>%
    dplyr::mutate(mean_strain = mean(log2Imputed1_Keep, na.rm=TRUE)) %>%
    as.data.frame()
  
  df_rep1 <- df_rep[,c(1,3,4)]
  df_rep2 <- unique(df_rep[,c(1,2,5)])
  df_rep2$SystemicIDko <- paste(df_rep2$SystemicIDko, "_mean", sep="")
  df_rep2$mean_strain[is.nan(df_rep2$mean_strain)] <- NA
  names(df_rep2) <- names(df_rep1)
  df_rep <- rbind(df_rep1, df_rep2)
  df_rep <- dcast(df_rep, ProteinIDs ~ ReplicateID, value.var="log2Imputed1_Keep")
  rm(df_rep1)
  rm(df_rep2)
  
  df_screen$SysID <- gsub(".*\\-(.*)", "\\1", df_screen$Strain)
  df_screen$SysID[grep("WT", df_screen$Strain)] <- "wt"
  length(grep("wt", df_screen$SysID))
  df_screen$Keep <- df_screen$SysID %in% experiments
  df_screen2 <- df_screen[df_screen$Keep == TRUE, ]
  rm(df_screen)
  
  df_screen <- df_screen2[,c(1,2,3)]
  df_screen <- dcast(df_screen, Proteins ~ Strain, value.var="NormalizedValue")
  wt_cols <- grep("WT", names(df_screen))
  df_screen$wt_mean <- rowMeans(df_screen[,wt_cols], na.rm=TRUE)
  rm(df_screen2)
  names(df_screen)[557] <- "wt_mean_screen"
  df_jnk <- merge(df_screen, df_rep, by.x="Proteins", by.y="ProteinIDs", all=FALSE)
  rownames(df_jnk) <- df_jnk$Proteins
  df_jnk <- df_jnk[,-1]
  df_cor <- cor(df_jnk, use="pairwise.complete.obs", method="pearson")
  saveRDS(df_screen, file.path(out_dir, paste0("10_6_1_", Sys.Date(), "_df_screen_4cor.rds")))
  saveRDS(df_rep, file.path(out_dir, paste0("10_6_2_", Sys.Date(), "_df_replicates_4cor.rds")))
  saveRDS(df_jnk, file.path(out_dir, paste0("10_6_3_", Sys.Date(), "_df_merged_4cor.rds")))
  saveRDS(df_cor, file.path(out_dir, paste0("10_6_4_", Sys.Date(), "_df_cor.rds")))
  
  rm(df_screen)
  rm(df_rep)
  
  myfile <- list.files(path=out_dir, pattern="^10_6_4")
  df_cor <- readRDS(file.path(out_dir, myfile))
  
  df_cor <- as.data.frame(df_cor)
  df_cor$Strain1 <- rownames(df_cor)
  df_cor <- melt(df_cor, id="Strain1")
  names(df_cor) <- c("Strain1", "Strain2", "PearsonR")
  
  df_cor$Strain1_ID <- gsub(".*\\-(.*)", "\\1",df_cor$Strain1)
  df_cor$Strain1_ID[grep("rep", df_cor$Strain1_ID)] <- gsub("rep.*\\_(.*)\\_[0-9]","\\1", df_cor$Strain1_ID[grep("rep", df_cor$Strain1_ID)])
  df_cor$Strain1_ID[grep("BIO", df_cor$Strain1_ID)] <- "wt_screen"
  df_cor$Strain1_ID2 <- gsub("_mean", "", df_cor$Strain1_ID) 
  
  df_cor$Strain2_ID <- gsub(".*\\-(.*)", "\\1",df_cor$Strain2)
  df_cor$Strain2_ID[grep("rep", df_cor$Strain2_ID)] <- gsub("rep.*\\_(.*)\\_[0-9]","\\1", df_cor$Strain2_ID[grep("rep", df_cor$Strain2_ID)])
  df_cor$Strain2_ID[grep("BIO", df_cor$Strain2_ID)] <- "wt_screen"
  df_cor$Strain2_ID2 <- gsub("_mean", "", df_cor$Strain2_ID) 
  
  table(df_cor$Strain1_ID2)
  df_cor2 <- subset(df_cor, Strain1_ID2 == Strain2_ID2)
  df_cor2 <- subset(df_cor2, Strain1 != Strain2)
  df_cor2 <- df_cor2[-c(grep("wt", df_cor2$Strain2_ID2)),]
  
  df_cor2$AnyMean <- FALSE
  df_cor2$AnyMean[c(grep("mean", df_cor2$Strain1_ID), grep("mean", df_cor2$Strain2_ID))] <- TRUE
  df_cor2$AnyReplicate <- FALSE
  df_cor2$AnyReplicate[c(grep("rep", df_cor2$Strain1), grep("rep", df_cor2$Strain2))] <- TRUE
  df_cor2$Replicate2Mean <- df_cor2$AnyMean * df_cor2$AnyReplicate
  
  df_cor2$BothReplicate <- FALSE
  df_cor2$BothReplicate[intersect(grep("rep", df_cor2$Strain1), grep("rep", df_cor2$Strain2))] <- TRUE
  df_cor2$Replicate2Mean[df_cor2$BothReplicate==TRUE] <- 2
  
  df_cor2$Replicate2Mean[df_cor2$Replicate2Mean==0] <- "Screen_Replicate"
  df_cor2$Replicate2Mean[intersect(grep("Screen_Replicate", df_cor2$Replicate2Mean), c(grep("mean", df_cor2$Strain1), grep("mean", df_cor2$Strain2)))] <- "Screen_Replicate_mean"
  
  df_cor2$Replicate2Mean[df_cor2$Replicate2Mean==1] <- "Replicate_Replicate_mean"
  df_cor2$Replicate2Mean[df_cor2$Replicate2Mean==2] <- "Replicate_Replicate"  
  # names(df_jnk)[grep("wt_mean", names(df_jnk))]
  
  jnk <- round(cor(df_jnk$wt_mean_screen, df_jnk$wt_mean, use="pairwise.complete.obs", method="pearson"), 2)[1]
  
  p3 <- ggplot(df_jnk, aes(wt_mean_screen, wt_mean)) +
    geom_point() +
    geom_abline(slope=1, intercept = 0) +
    xlab("WT mean for screen") +
    ylab("WT mean for replicates") +
    geom_smooth(method="lm") +
    ggtitle(paste("cor:", jnk))
  
  df_cor2 <- df_cor2[df_cor2$AnyMean == FALSE, ]
  p4 <- ggplot(df_cor2, aes(PearsonR)) +
    geom_density(aes(fill=Replicate2Mean, color=Replicate2Mean), size=1, alpha=0.4) +
    labs(fill = NULL, color=NULL) +
    theme(legend.position="top", axis.title = element_text(size = 20), axis.text.x = element_text(size = 16),
          legend.text = element_text(size= 14))
  
  ############
  df_cor2 <- subset(df_cor, Strain1 != Strain2)
  df_cor2 <- df_cor2[-c(grep("wt", df_cor2$Strain2_ID2)),]
  df_cor2 <- df_cor2[-c(grep("wt", df_cor2$Strain1_ID2)),]
  df_cor2 <- df_cor2[-c(grep("mean", df_cor2$Strain1_ID)),]
  df_cor2 <- df_cor2[-c(grep("mean", df_cor2$Strain2_ID)),]
  
  df_cor2 <- df_cor2[,c(1,2,3,4,6)]
  df_cor2$SameStrain <- df_cor2$Strain1_ID == df_cor2$Strain2_ID
  
  df_cor2$Replicate1 <- FALSE
  df_cor2$Replicate1[c(grep("rep", df_cor2$Strain1))] <- TRUE
  
  df_cor2$Replicate2 <- FALSE
  df_cor2$Replicate2[c(grep("rep", df_cor2$Strain2))] <- TRUE
  df_cor2$Category <- NA
  
  df_cor2$Category[intersect(grep("TRUE", df_cor2$SameStrain), intersect(grep("TRUE", df_cor2$Replicate1), grep("TRUE", df_cor2$Replicate2)))] <- "SameStrain_Replicate_Replicate"
  df_cor2$Category[intersect(grep("FALSE", df_cor2$SameStrain), intersect(grep("TRUE", df_cor2$Replicate1), grep("TRUE", df_cor2$Replicate2)))] <- "DifferentStrain_Replicate_Replicate"
  
  df_cor2$Category[intersect(grep("TRUE", df_cor2$SameStrain), intersect(grep("FALSE", df_cor2$Replicate1), grep("TRUE", df_cor2$Replicate2)))] <- "SameStrain_Screen_Replicate"
  df_cor2$Category[intersect(grep("TRUE", df_cor2$SameStrain), intersect(grep("TRUE", df_cor2$Replicate1), grep("FALSE", df_cor2$Replicate2)))] <- "SameStrain_Screen_Replicate"
  
  df_cor2$Category[intersect(grep("FALSE", df_cor2$SameStrain), intersect(grep("FALSE", df_cor2$Replicate1), grep("TRUE", df_cor2$Replicate2)))] <- "DifferentStrain_Screen_Replicate"
  df_cor2$Category[intersect(grep("FALSE", df_cor2$SameStrain), intersect(grep("TRUE", df_cor2$Replicate1), grep("FALSE", df_cor2$Replicate2)))] <- "DifferentStrain_Screen_Replicate"
  df_cor2$Category[intersect(grep("FALSE", df_cor2$SameStrain), intersect(grep("FALSE", df_cor2$Replicate1), grep("FALSE", df_cor2$Replicate2)))] <- "DifferentStrain_Screen_Screen"
  
  p4 <- ggplot(df_cor2, aes(PearsonR)) +
    geom_density(aes(fill=Category, color=Category), size=1, alpha=0.4) +
    labs(fill = NULL, color=NULL) +
    theme(axis.title = element_text(size = 20), axis.text.x = element_text(size = 16),
          legend.text = element_text(size= 14))
  
  ggsave("ScreenProteome/p10_5.png", p4)
  #########################
  # 10.7 # check the correlation of fold changes screen vs. the replicates #################
  myfile <- list.files(path = "ReplicateRNAprotein/", pattern = "replicateProteome_FC_pvalue")
  df_rep <- readRDS(file.path("ReplicateRNAprotein/", myfile))
  myfile <- list.files(path = out_dir, pattern = "^6_11_1.*melt.*rds")
  df_screen <- readRDS(file.path(out_dir, myfile))
  df_screen <- remove.factors(df_screen)
  df_screen$StrainID <- gsub(".*\\-(.*)", "\\1", df_screen$Strain)
  
  mystrains <- unique(df_rep$KOstrain)
  df_screen <- df_screen[df_screen$StrainID %in% mystrains,]
  df_screen <- df_screen[!is.na(df_screen$FC),]
  df_screen <- df_screen[,c(13,2,8,5,6,7,10)]
  
  my_cor_df <- as.data.frame(mystrains)
  my_cor_df$PearsonR <- NA
  pdf(file.path(out_dir, 
                paste0("10_7_1_", Sys.Date(), "_screen_replicate_correlation_plots.pdf")), 
      height = 8, width = 8)
  for (i in 1:length(mystrains)) {
    print(i)
    df_rep_jnk <- df_rep[df_rep$KOstrain %in% mystrains[i],]
    df_screen_jnk <- df_screen[df_screen$StrainID %in% mystrains[i],]
    
    df_jnk <- merge(df_rep_jnk, df_screen_jnk, by.x="pG", by.y="Proteins", all=FALSE)
    
    jnk <- cor(df_jnk$log2FC_Strain_wt, df_jnk$FC)[1]
    my_cor_df$PearsonR[i] <- jnk
  
    p <- ggplot(df_jnk, aes(FC, log2FC_Strain_wt)) +
      geom_hline(yintercept = 0, color="#404040", size=1) +
      geom_vline(xintercept = 0, color="#404040", size=1) +
      geom_point(size=2, alpha=0.7) +
      xlab("Screen log2(fold change)") +
      ylab("Replicates log2(fold change)") +
      theme_classic() +
      theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
            axis.text=element_text(size=14),
            axis.title=element_text(size=14,face="bold"),
            strip.text = element_text(size = 14, face="bold")) +
      ggtitle(mystrains[i]) +
      # annotate("text", x=ceiling(min(df_jnk$FC)), 
      #          y=ceiling(max(df_jnk$log2FC_Strain_wt)), 
      #          label=paste0("Pearson's R: ", round(jnk, 2)), size=5)
      annotate("text", x=-1, y=1, label=paste0("Pearson's R: ", round(jnk, 2)), size=5)
    print(p)
  }
  dev.off()
  saveRDS(my_cor_df, 
          file.path(out_dir,
                    paste0("10_7_2_",Sys.Date(),
                           "_correlation_coefficients.rds")))
  
  }
if(ScreenQCSupplementaryPlots){
  # 11 # check the run with TMT as variable modification ###########################
  # 11.1 # evidence file #######################################################
  pG <- read.delim(file.path(data_dir,"Screen_noLabel_TMT_varMod/combined/txt/proteinGroups.txt"))
  jnk <- pG$id
  pG <- my_pG_filter(pG,1,1)
  jnk <- pG$id
  rm(pG)
#  length(readLines("F:/Merve_Spombe_DelLibrary_TMT_all/Screen_all/Screen_noLabel_TMT_varMod/combined/txt/evidence.txt"))
  Evidence <- read.delim(file.path(data_dir,"Screen_noLabel_TMT_varMod/combined/txt/evidence.txt"))
  
  Evidence <- Evidence[Evidence$Protein.group.IDs %in% jnk,]
  saveRDS(Evidence, file.path(out_dir,paste0("11_1_",Sys.Date(),"_Evidence_TMTvarMod_notContaminant.rds")))
  
  # head(unique(Evidence$Vmod_TMT10plex.Lys126C.site.IDs))
  # head(unique(Evidence$Vmod_TMT10plex.Lys126C.Probabilities))
  
  jnk <- as.data.frame(table(Evidence[,c(19,3)]))
  jnk$Modifications_Vmod <- FALSE  
  jnk$Modifications_Vmod[grep("Vmod", jnk$Modifications)] <- TRUE
  
  jnk2 <- jnk %>%
    group_by(Experiment, Modifications_Vmod) %>%
    dplyr::mutate(Vmod_sum=sum(Freq)) %>%
    as.data.frame()
  jnk2 <- unique(jnk2[,c(1,4,5)])
  jnk2$Plate <- gsub("Sp([0-9]*)[A-Z][0-9]*", "\\1", jnk2$Experiment)
  
  p1 <- ggplot(jnk2, aes(Plate, Vmod_sum)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Total number of evidence, with/out label")+
    guides(color=FALSE)
  
  jnk3 <- jnk[,c(2,2)]
  jnk3$Modifications.1 <- gsub(" ", "", jnk3$Modifications.1) 
  jnk3 <- splitColumnBySep(jnk3, "Modifications.1", sep=",")
  jnk3 <- unique(jnk3$Modifications.1)
  jnk3 <- gsub("^[0-9](.*)", "\\1", jnk3)
  jnk3 <- unique(jnk3)

  jnk$Oxidation <- FALSE
  jnk$Oxidation[grep("Oxidation", jnk$Modifications)] <- TRUE
  
  jnk$Acetyl_ProteinNterm <- FALSE
  jnk$Acetyl_ProteinNterm[grep("Acetyl", jnk$Modifications)] <- TRUE
  
  jnk$Unmodified <- FALSE
  jnk$Unmodified[grep("Unmodified", jnk$Modifications)] <- TRUE
  
  jnk$Plate <- gsub("Sp([0-9]*)[A-Z][0-9]*", "\\1", jnk$Experiment)
  
  jnk$ModState <- paste(jnk$Modifications_Vmod, jnk$Oxidation,
                        jnk$Acetyl_ProteinNterm, jnk$Unmodified, sep=";")
  jnk2 <- jnk %>%
    group_by(Experiment, ModState) %>%
    dplyr::mutate(sumFreq=sum(Freq)) %>%
    as.data.frame()
  jnk2 <- unique(jnk2[,c(1,4:10)])
  
  jnk2$ModState2 <- NA
  jnk2$ModState2[jnk2$ModState == "FALSE;TRUE;FALSE;FALSE"] <- "2"
  jnk2$ModState2[jnk2$ModState == "TRUE;TRUE;FALSE;FALSE"] <- "1+2"
  jnk2$ModState2[jnk2$ModState == "TRUE;FALSE;FALSE;FALSE"] <- "1"
  jnk2$ModState2[jnk2$ModState == "FALSE;FALSE;TRUE;FALSE"] <- "3"
  jnk2$ModState2[jnk2$ModState == "TRUE;TRUE;TRUE;FALSE"] <- "1+2+3"
  jnk2$ModState2[jnk2$ModState == "TRUE;FALSE;TRUE;FALSE"] <- "1+3"
  jnk2$ModState2[jnk2$ModState == "FALSE;TRUE;TRUE;FALSE"] <- "2+3"
  jnk2$ModState2[jnk2$ModState == "FALSE;FALSE;FALSE;TRUE"] <- "0"
  
  
  jnk2$ModState2 <- factor(jnk2$ModState2, levels = c("1", "2", "3", "1+2", "1+3", "2+3", "1+2+3", "0"))
  
  jnk2 <- jnk2 %>%
    group_by(Experiment) %>%
    dplyr::mutate(pFreq = round((100*sumFreq) / sum(sumFreq),1)) %>%
    as.data.frame()
  
  p2 <- ggplot(jnk2, aes(Plate, sumFreq)) +
    geom_boxplot(aes(color=ModState2), fill="black") +
    xlab("MS plate number") +
    ylab("Total number of evidence, varying modifications")+
    scale_color_brewer(type="qual", palette="Spectral") +
    facet_grid(ModState2 ~.) +
    guides(color=FALSE)
  
  p3 <- ggplot(jnk2, aes(Plate, pFreq)) +
    geom_boxplot(aes(color=ModState2), fill="black") +
    xlab("MS plate number") +
    ylab("Percentage of evidence, varying modifications")+
    scale_color_brewer(type="qual", palette="Spectral") +
    facet_grid(ModState2 ~.) +
    guides(color=FALSE) +
    ylim(0,100)
  
  p4 <- ggplot(jnk2, aes(Plate, pFreq)) +
    geom_boxplot(aes(color=ModState2), fill="black") +
    xlab("MS plate number") +
    ylab("Percentage of evidence, varying modifications")+
    scale_color_brewer(type="qual", palette="Spectral") +
    facet_grid(ModState2 ~., scales="free") +
    guides(color=FALSE) 
  
 # peptide count
  jnk <- as.data.frame(Evidence[,c(59,19,3)])
  jnk$Modifications_Vmod <- FALSE  
  jnk$Modifications_Vmod[grep("Vmod", jnk$Modifications)] <- TRUE
  
  jnk2 <- jnk %>%
    group_by(Experiment, Modifications_Vmod) %>%
    dplyr::mutate(Peptide_count=length(unique(Peptide.ID))) %>%
    as.data.frame()
  
  jnk2 <- unique(jnk2[,c(2,4,5)])
  jnk2$Plate <- gsub("Sp([0-9]*)[A-Z][0-9]*", "\\1", jnk2$Experiment)
  
  p5 <- ggplot(jnk2, aes(Plate, Peptide_count)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Number of peptides, with/out label")+
    scale_color_brewer(type="qual", palette="Set1") +
    facet_grid(Modifications_Vmod ~.) +
    guides(color=FALSE) 
  
  p6 <- ggplot(jnk2, aes(Plate, Peptide_count)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Number of peptides, with/out label")+
    scale_color_brewer(type="qual", palette="Set1") +
    facet_grid(Modifications_Vmod ~., scales="free") +
    guides(color=FALSE) 
  
  jnk2 <- jnk2 %>%
    group_by(Experiment) %>%
    dplyr::mutate(pFreq = round((100*Peptide_count) / sum(Peptide_count),1)) %>%
    as.data.frame()
  
  p7 <- ggplot(jnk2, aes(Plate, pFreq)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Percentage of peptides, with/out label")+
    scale_color_brewer(type="qual", palette="Set1") +
    facet_grid(Modifications_Vmod ~.) +
    guides(color=FALSE) 
  
  p8 <- ggplot(jnk2, aes(Plate, pFreq)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Percentage of peptides, with/out label")+
    scale_color_brewer(type="qual", palette="Set1") +
    facet_grid(Modifications_Vmod ~., scales="free") +
    guides(color=FALSE) 
  
  # protein count
  jnk <- as.data.frame(Evidence[,c(58,19,3)])
  jnk$Modifications_Vmod <- FALSE  
  jnk$Modifications_Vmod[grep("Vmod", jnk$Modifications)] <- TRUE
  
  jnk2 <- jnk %>%
    group_by(Experiment, Modifications_Vmod) %>%
    dplyr::mutate(Peptide_count=length(unique(Protein.group.IDs))) %>%
    as.data.frame()
  
  jnk2 <- unique(jnk2[,c(2,4,5)])
  jnk2$Plate <- gsub("Sp([0-9]*)[A-Z][0-9]*", "\\1", jnk2$Experiment)
  
  p9 <- ggplot(jnk2, aes(Plate, Peptide_count)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Number of proteins, with/out label")+
    scale_color_brewer(type="qual", palette="Set1") +
    facet_grid(Modifications_Vmod ~.) +
    guides(color=FALSE) 
  
  p10 <- ggplot(jnk2, aes(Plate, Peptide_count)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Number of proteins, with/out label")+
    scale_color_brewer(type="qual", palette="Set1") +
    facet_grid(Modifications_Vmod ~., scales="free") +
    guides(color=FALSE) 
  
  jnk2 <- jnk2 %>%
    group_by(Experiment) %>%
    dplyr::mutate(pFreq = round((100*Peptide_count) / sum(Peptide_count),1)) %>%
    as.data.frame()
  
  p11 <- ggplot(jnk2, aes(Plate, pFreq)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Percentage of proteins, with/out label")+
    scale_color_brewer(type="qual", palette="Set1") +
    facet_grid(Modifications_Vmod ~.) +
    guides(color=FALSE) 
  
  p12 <- ggplot(jnk2, aes(Plate, pFreq)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Percentage of proteins, with/out label")+
    scale_color_brewer(type="qual", palette="Set1") +
    facet_grid(Modifications_Vmod ~., scales="free") +
    guides(color=FALSE) 
  
  
  # protein intensity
  jnk <- as.data.frame(Evidence[,c(58,54,19,3)])
  jnk$Modifications_Vmod <- FALSE  
  jnk$Modifications_Vmod[grep("Vmod", jnk$Modifications)] <- TRUE
  
  jnk2 <- jnk %>%
    group_by(Experiment, Modifications_Vmod, Protein.group.IDs) %>%
    dplyr::mutate(Intensity=sum(Intensity)) %>%
    as.data.frame()
  
  jnk2 <- unique(jnk2[,c(1,2,3,5)])
  jnk2$Plate <- gsub("Sp([0-9]*)[A-Z][0-9]*", "\\1", jnk2$Experiment)
  
  jnk2$Intensity[jnk2$Intensity==0] <- NA
  jnk2$Intensity <- log2(jnk2$Intensity)
  # jnk2$Intensity[is.na(jnk2$Intensity)] <- 0
  
  jnk3 <- jnk2
  jnk2$ID <- paste(jnk2$Protein.group.IDs, jnk2$Experiment, 
                   jnk2$Plate, sep=";")
  
  jnk3$ID <- paste(jnk3$Protein.group.IDs, jnk3$Experiment, 
                   jnk3$Plate, sep=";")
  jnk3 <- jnk3[,c(6,4,2)]
  jnk3 <- dcast(jnk3, ID ~ Modifications_Vmod, value.var="Intensity")
  
  jnk3 <- merge(jnk3, jnk2[,c(1,3,5,6)], by.x="ID", by.y="ID", all=FALSE)
  
  names(jnk3)[2] <- "notLabeled"
  names(jnk3)[3] <- "Labeled"
  
  jnk3 <- jnk3 %>%
    group_by(Protein.group.IDs) %>%
    dplyr::mutate(notLabeled_mean=mean(notLabeled, na.rm=TRUE),
                  Labeled_mean=mean(Labeled, na.rm=TRUE)) %>%
    as.data.frame()
  
  jnk3 <- subset(jnk3, !is.na(Labeled) | !is.na(notLabeled))
  jnk3$notLabeled_mean[is.nan(jnk3$notLabeled_mean)] <- 0
  jnk3$Labeled_mean[is.nan(jnk3$Labeled_mean)] <- 0
  
  jnk3$Protein.group.IDs <- factor(jnk3$Protein.group.IDs, 
                                   levels = jnk3$Protein.group.IDs[order(jnk3$Labeled_mean)])
  
  jnk4 <- as.data.frame(unique(jnk3[,c(4,7,8)]))
  jnk4$pvalue <- NA
  
  for (i in 2908:dim(jnk4)[1]) {
    print(i)
    mypg <- jnk4$Protein.group.IDs[i]
    jnk3_jnk <- subset(jnk3, Protein.group.IDs == mypg)
    jnk3_jnk[is.na(jnk3_jnk)] <- 0
    x <- t.test(jnk3_jnk$notLabeled, jnk3_jnk$Labeled, paired = TRUE)
    jnk4$pvalue[i] <- x$p.value
  }
  jnk4 <- jnk4[!is.na(jnk4$pvalue),]
  jnk4$pvalue[jnk4$pvalue == 0] <- NA
  jnk4$pvalue[is.na(jnk4$pvalue)] <- min(jnk4$pvalue, na.rm=TRUE)
  jnk4$log10pvalue <- -log10(jnk4$pvalue)
  
  jnk4$meanDF <- jnk4$Labeled_mean - jnk4$notLabeled_mean
  
  p13 <- ggplot(jnk4, aes(meanDF, log10pvalue)) +
    geom_point()+
    xlab("log2(label-non)")+
    ylab("-log10(pvalue")+
    ggtitle("protein groups, evidence, var mod")
  
  jnk3[is.na(jnk3)] <- 0
  
  p14 <- ggplot(jnk3, aes(Labeled, notLabeled)) +
    geom_point()+
    geom_abline(slope=1, intercept = 0, color="darkred") +
    xlab("log2(Labeled)")+
    ylab("log2(notLabeled)")+
    ggtitle("protein groups, evidence, var mod")
  p15 <- ggplot(jnk3, aes(Labeled, notLabeled)) +
    geom_hex()+
    geom_abline(slope=1, intercept = 0, color="darkred") +
    xlab("log2(Labeled)")+
    ylab("log2(notLabeled)")+
    ggtitle("protein groups, evidence, var mod")
  # 11.2 # save the plots #######################################################
  pdf(file.path(out_dir, paste0("11_2_1_", Sys.Date(), "_VarMod_Evidence_Plots.pdf")), height = 8, width = 10)
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  print(p5)
  print(p6)
  print(p7)
  print(p8)
  print(p9)
  print(p10)
  print(p11)
  print(p12)
  print(p13)
 # print(p14)
 # print(p15)
  dev.off()
  pdf(file.path(out_dir, paste0("11_2_2_", Sys.Date(), "_VarMod_Evidence_Plots.pdf")), height = 8, width = 10)
  print(p14)
  print(p15)
  dev.off()
  # 11.3 # noLabel #######################################################
  pG <- read.delim(file.path(data_dir,"Screen_noLabel/combined/txt/proteinGroups.txt"))
  pG <- my_pG_filter(pG,1,1)
  jnk <- grep("Intensity\\..*", names(pG))
  pG <- pG[,c(1,jnk)]
  pG[pG==0] <- NA
  jnk <- grep("Intensity\\..*", names(pG))
  pG[,jnk] <- log2(pG[,jnk]) 
  pG <- pG[,jnk]
  
  jnk <- data.frame(File=colnames(pG), NpG=colSums(!is.na(pG)),
                    MaxIntensity=apply(pG, 2, max, na.rm=T),
                    MedianIntensity=apply(pG, 2, median, na.rm=T))
  
  # jnk <- jnk[-grep("Protein.IDs", jnk$File),]
  jnk$RawFile <- gsub("Intensity\\.(Sp.*)", "\\1", jnk$File)
  jnk <- jnk[,2:5]
  
  saveRDS(jnk, file.path(out_dir,paste0("11_3_1_",Sys.Date(),"_pGcount_noLabel.rds")))
  rm(pG)
  
  ## merge2supplementaryTable1 #######################################################
  myfile <- list.files(path = out_dir, pattern = "^2_5_2_2_")
  ST1 <- read.delim(file.path(out_dir, myfile))
  names(ST1)[9] <- "NumberOfProteins_RespectiveLabel"
  names(ST1)[6] <- "MaxLog2Intensity_RespectiveLabel"
  names(ST1)[7] <- "MedianLog2Intensity_RespectiveLabel"
  names(ST1)[8] <- "NumberOfProtein_WholeRun_Labeled"
  names(ST1)[10] <- "NumberOfProteinsLess_RespectiveLabel_Labeled"
  
  names(jnk)[1] <- "NumberOfProteins_LabelFree"
  names(jnk)[2] <- "MaxLog2Intensity_LabelFree"
  names(jnk)[3] <- "MedianLog2Intensity_LabelFree"
  
  ST1 <- merge(ST1, jnk, by.x="RawFileSuffix", by.y="RawFile", all=FALSE)

  ST1 <- ST1[,c(2,1,3:10,24:26,11:23)]
  rm(jnk)
  saveRDS(ST1, file.path(out_dir, paste0("11_3_2_", Sys.Date(), "_SupplementaryTable1_ScreenDecode_wLabelFree.rds")))
  write.table(ST1, file.path(out_dir,paste0("11_3_3_", Sys.Date(), "_SupplementaryTable1_ScreenDecode_wLabelFree.txt")),
              quote = F, row.names = F, sep="\t")
  
  # SupplementaryTable1 - Figures #######################################################
  ST1_plot <- ST1[,c(2,6,7,8,10,11,12,13,14)]
  ST1_plot$Plate_MS <- gsub("Sp([0-9]*)C.*", "\\1", ST1_plot$RawFileSuffix)
  
  p1 <- ggplot(ST1_plot, aes(Plate_MS, NumberOfProtein_WholeRun_Labeled)) +
    geom_boxplot(color="#4575b4", fill="#252525", outlier.shape = NA) +
    xlab("Processed Plate Number") +
    ylab("Number of Protein Groups in the Run") +
    geom_boxplot(aes(y=NumberOfProteins_LabelFree),color="#d73027", fill="#252525", outlier.shape = NA)
  
  p1_1 <- ggplot(ST1_plot, aes(Plate_MS, NumberOfProtein_WholeRun_Labeled)) +
    geom_boxplot(color="#4575b4", fill="#252525", outlier.shape = NA) +
    xlab("Processed Plate Number") +
    ylab("Number of Protein Groups in the Run, labeled") +
    ylim(0,2000)
  
  p1_2 <- ggplot(ST1_plot, aes(Plate_MS, NumberOfProteins_LabelFree)) +
    geom_boxplot(color="#d73027", fill="#252525", outlier.shape = NA) +
    xlab("Processed Plate Number") +
    ylab("Number of Protein Groups in the Run, not labeled") +
    ylim(0,2000)
  
  # p2 <- ggplot(ST1_plot, aes(NumberOfProtein_WholeRun, NumberOfProteins_LabelFree)) +
  #   geom_point(aes(color=Analyzed_ReMeasured), size=3, alpha=0.8) +
  #   xlab("Number of Protein Groups in the Run") +
  #   ylab("Number of Protein Groups in the Run - Label Free") +
  #   scale_color_brewer(type = "div", palette = 7)
  
  # p3 <- ggplot(ST1_plot, aes(NumberOfProteinsLess_Sample, NumberOfProteins_LabelFree)) +
  #   geom_point(aes(color=Analyzed_ReMeasured), size=3, alpha=0.8) +
  #   xlab("Number of Protein Groups Less in the Sample") +
  #   ylab("Number of Protein Groups in the Run - Label Free") +
  #   scale_color_brewer(type = "div", palette = 7)
  
  # p4 <- p1 + geom_violin(aes(y=55*MaxLog2Intensity), fill="#238b45") +
  #   geom_violin(aes(y=55*MedianLog2Intensity), fill="#74c476") +
  #   scale_y_continuous(sec.axis = sec_axis(~./55, name = "Log2 intensity", breaks = c(10,15,20,25)))

  
  p2 <- ggplot(ST1_plot, aes(Plate_MS, MaxLog2Intensity_RespectiveLabel)) +
    geom_boxplot(color="#4575b4", fill="#252525", outlier.shape = NA) +
    xlab("Processed Plate Number") +
    ylab("Maximum log2(intensity), labeled") +
    ylim(0,25)
  
  p3 <- ggplot(ST1_plot, aes(Plate_MS, MedianLog2Intensity_RespectiveLabel)) +
    geom_boxplot(color="#4575b4", fill="#252525", outlier.shape = NA) +
    xlab("Processed Plate Number") +
    ylab("Median log2(intensity), labeled") +
    ylim(0,20)
  
    
  # ST1_plot <- ST1[,c(14,6,7,8,10,11,12)]
  # ST1_plot$Plate_KO <- gsub("Sp([0-9]*)[A-Z].*", "\\1", ST1_plot$Position_KO_Library)
  # ST1_plot <- ST1_plot[grep("ToBeAnalyzed", ST1_plot$Analyzed_ReMeasured),]
  # ST1_plot <- ST1_plot[-c(grep("DidntGrow|Empty|WildType", ST1_plot$Plate_KO)),]
  # 
  # p5 <- ggplot(ST1_plot, aes(Plate_KO, NumberOfProtein_WholeRun)) +
  #   geom_boxplot(color="#4575b4", fill="#252525", outlier.shape = NA) +
  #   xlab("Library Plate Number") +
  #   ylab("Number of Protein Groups in the Run") +
  #   geom_boxplot(aes(y=NumberOfProteins_LabelFree),color="#d73027", fill="#252525", outlier.shape = NA)
  # 
  # p6 <- p5 + geom_violin(aes(y=55*MaxLog2Intensity), fill="#238b45") +
  #   geom_violin(aes(y=55*MedianLog2Intensity), fill="#74c476") +
  #   scale_y_continuous(sec.axis = sec_axis(~./55, name = "Log2 intensity", breaks = c(10,15,20,25)))

  p4 <- ggplot(ST1_plot, aes(Plate_MS, MaxLog2Intensity_LabelFree)) +
    geom_boxplot(color="#4575b4", fill="#252525", outlier.shape = NA) +
    xlab("Processed Plate Number") +
    ylab("Maximum log2(intensity), not labeled") +
    ylim(0,35)
  
  p5 <- ggplot(ST1_plot, aes(Plate_MS, MedianLog2Intensity_LabelFree)) +
    geom_boxplot(color="#4575b4", fill="#252525", outlier.shape = NA) +
    xlab("Processed Plate Number") +
    ylab("Median log2(intensity), not labeled") +
    ylim(0,30)
  
  pdf(file.path(out_dir, paste0("11_3_4_", Sys.Date(), "_QC_MS_Library_labeled_notLabeled.pdf")), height = 8, width = 10)
  print(p1_1)
  print(p1_2)
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  print(p5)
  dev.off()
  # 11.1-3 # redone 20190716 ##############################################
  myfile <- list.files(path=out_dir, pattern = "11_1.*Evidence.*rds")
  Evidence <- readRDS(file.path(out_dir, myfile))  
  
  jnk <- as.data.frame(table(Evidence[,c(19,3)]))
  jnk$Modifications_Vmod <- FALSE  
  jnk$Modifications_Vmod[grep("Vmod", jnk$Modifications)] <- TRUE
  
  jnk2 <- jnk %>%
    group_by(Experiment, Modifications_Vmod) %>%
    dplyr::mutate(Vmod_sum=sum(Freq)) %>%
    as.data.frame()
  jnk2 <- unique(jnk2[,c(1,4,5)])
  jnk2$Plate <- gsub("Sp([0-9]*)[A-Z][0-9]*", "\\1", jnk2$Experiment)
  
  p1 <- ggplot(jnk2, aes(Plate, Vmod_sum)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Total number of evidence, with/out label")+
    guides(color=FALSE)
  
  p1 <- ggplot(jnk2, aes(Vmod_sum))+
    geom_density(aes(fill=Modifications_Vmod, color=Modifications_Vmod), adjust = 2) +
    scale_color_brewer(type="qual", palette="Set1") +
    guides(color=FALSE, fill=FALSE) +
    xlab("Number of evidences")+
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=1) +
    geom_rug(sides="b", aes(color=Modifications_Vmod)) +
    coord_cartesian(clip = "off") +
    theme(plot.margin = margin(1, 1, 1, 1, "cm"))
  

  jnk2 <- jnk2 %>%
    group_by(Experiment) %>%
    dplyr::mutate(pFreq = round((100*Vmod_sum) / sum(Vmod_sum),1)) %>%
    as.data.frame()
  
  
  
  p2 <- ggplot(jnk2, aes(pFreq))+
    geom_density(aes(fill=Modifications_Vmod, color=Modifications_Vmod), adjust = 2) +
    scale_color_brewer(type="qual", palette="Set1") +
    guides(color=FALSE, fill=FALSE) +
    xlab("Percentage of evidences")+
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=1) +
    geom_rug(sides="b", aes(color=Modifications_Vmod)) +
    coord_cartesian(clip = "off") +
    theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
    xlim(0,100)
  
  pdf(file.path(out_dir, paste0("11_1-3_", Sys.Date(), "_QC_MS_Library_summary_evidenceswithlabel.pdf")), height = 4, width = 4)
  print(p1)
  print(p2)
  dev.off()
   

  
  
  
  
  
  # 11.4 # Labeled summary file #######################################################
  df_summary <- read.delim(file.path(data_dir,"Screen_1U_noMBR/combined/txt/summary.txt"))
  df_summary[df_summary==""] <- NA
  df_summary <- df_summary[rowSums(is.na(df_summary))<48,]
  df_summary <- df_summary[,colSums(is.na(df_summary))<470]
  
  df_summary_raw <- df_summary[grep("Sp", df_summary$Raw.file),]
  df_summary_raw <- df_summary_raw[,c(2,12,13,15:43)]
  df_summary_raw <- df_summary_raw[,c(1:5,7:9,11:32)]
  df_summary_raw$Plate <- gsub("Sp([0-9]*)C.*", "\\1", df_summary_raw$Experiment)
  
  
  df_summary_raw2 <- melt(df_summary_raw, id=c("Experiment", "Plate"), stringsAsFactors=FALSE)
  
  jnk <- unique(df_summary_raw2$variable)
  df_summary_raw2$value <- as.numeric(df_summary_raw2$value)
  jnk <- jnk[-25]
  jnk <- as.data.frame(jnk)
  jnk$Label <- c("MS", "MS/MS", "MS/MS Submitted", "MS/MS Submitted (SIL)",
                 "MS/MS Submitted (PEAK)", "MS/MS Identified",
                 "MS/MS Identified (SIL)", "MS/MS Identified (PEAK)",
                 "MS/MS Identified [%]", 	"MS/MS Identified (SIL) [%]",
                 "MS/MS Identified (PEAK) [%]",	"Peptide Sequences Identified",
                 "Peaks",	"Peaks Sequenced", 	"Peaks Sequenced [%]",
                 "Peaks Repeatedly Sequenced",	"Peaks Repeatedly Sequenced [%]",
                 "Isotope Patterns", "Isotope Patterns Sequenced",
                 "Isotope Patterns Sequenced (z>1)",
                 "Isotope Patterns Sequenced [%]",
                 "Isotope Patterns Sequenced (z>1) [%]",
                 "Isotope Patterns Repeatedly Sequenced",
                 "Isotope Patterns Repeatedly Sequenced [%]",
                 "Av. Absolute Mass Deviation [ppm]",
                 "Mass Standard Deviation [ppm]",
                 "Av. Absolute Mass Deviation [mDa]",
                 "Mass Standard Deviation [mDa]")
  jnk <- remove.factors(jnk)
  
  pdf(file.path(out_dir, paste0("11_4_2_", Sys.Date(), "_QC_MS_Library_summary_labeled_individual.pdf")), height = 8, width = 10)
  for (i in 1:dim(jnk)[1]) {
    print(i)
    j <- jnk$jnk[i]
    df_summary_raw2_jnk <- subset(df_summary_raw2, variable == j)
    
    p <- ggplot(df_summary_raw2_jnk, aes(Plate, value))+
      geom_rug(sides="r", outside = TRUE, 
               length = unit(0.05, "npc"), position = "jitter") +
      coord_cartesian(clip = "off") +
      theme(plot.margin = margin(1, 1, 1, 1, "cm")) +
      geom_jitter(aes(color=variable)) +
      scale_color_brewer(type="qual", palette="Set1") +
      guides(color=FALSE) +
      xlab("Processed Plate number") +
      ylab(jnk$Label[i])+
      ylim(0,max(df_summary_raw2_jnk$value))+
      theme_classic()+
      geom_hline(yintercept = min(df_summary_raw2_jnk$value), size=1.2)
    
    
    print(p)
  }
  dev.off()
  
  pdf(file.path(out_dir, paste0("11_4_3_", Sys.Date(), "_QC_MS_Library_summary_labeled_individual_histogram.pdf")), height = 8, width = 10)
  for (i in 1:dim(jnk)[1]) {
    print(i)
    j <- jnk$jnk[i]
    df_summary_raw2_jnk <- subset(df_summary_raw2, variable == j)
    
    p <- ggplot(df_summary_raw2_jnk, aes(value))+
      geom_density(aes(color=variable), fill="#404040", adjust = 2) +
      scale_color_brewer(type="qual", palette="Set1") +
      guides(color=FALSE) +
      xlab(jnk$Label[i])+
      xlim(0,max(df_summary_raw2_jnk$value))+
      theme_classic()+
      geom_hline(yintercept=0, colour="white", size=1) +
      geom_rug(sides="b") +
      coord_cartesian(clip = "off") +
      theme(plot.margin = margin(1, 1, 1, 1, "cm"))
    
    print(p)
  }
  dev.off()
  # 11.5 # pG count identified, -contaminants, -wt_tech, -fdr filtering ############
  # pg identified
  pG <- read.delim(file.path(data_dir,"Screen_1U_noMBR/combined/txt/proteinGroups.txt"))
  repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG))
  pG_rep <- pG[,c(1,repCol)]
  pG_rep[pG_rep==0] <- NA
  
  mydf <- data.frame(Strain=names(pG_rep), Identified=colSums(!is.na(pG_rep)))
  # filtered contaminants
  pG <- my_pG_filter(pG,1,1)
  repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG))
  pG_rep <- pG[,c(1,repCol)]
  pG_rep[pG_rep==0] <- NA
  
  jnk <- data.frame(Strain=names(pG_rep), Filtered=colSums(!is.na(pG_rep)))
  mydf <- merge(mydf, jnk, by=1, all=FALSE)
  rm(pG)
  rm(pG_rep)
  rm(jnk)
  #manage names
  myfile <- list.files(path = out_dir, pattern = "^11_3_2_.*rds")
  pG <- readRDS(file.path(out_dir, myfile))
  pG$Identifier <- paste(pG$Position_MS_Plate, pG$Systemic.ID, sep="-")
  pG$Identifier[grep("Bio", pG$Identifier)] <- paste(pG$Position_MS_Plate[grep("Bio", pG$Identifier)], 
                                                     "BIO", sep="-")
  pG$Identifier[grep("Tech", pG$Identifier)] <- paste(pG$Position_MS_Plate[grep("Tech", pG$Identifier)], 
                                                     "TECH", sep="-")
  
  pG <- pG[,c(3,16,27)]
  mydf <- merge(mydf, pG, by=1, all= TRUE)
  mydf$Identifier[1] <-  mydf$Strain[1]
  # filtered wt tech
  myfile <- list.files(path = out_dir, pattern = "^3_1_.*rds")
  pG_rep <- readRDS(file.path(out_dir, myfile))
  pG_rep$Protein.IDs <- rownames(pG_rep)
  pG_rep[pG_rep==0] <- NA
  
  jnk <- data.frame(Strain=names(pG_rep), Filtered_wtTech=colSums(!is.na(pG_rep)))
  mydf <- merge(mydf, jnk, by.x="Identifier", by.y="Strain", all=TRUE)
  # filtered power
  myfile <- list.files(path = out_dir, pattern = "^5_1_.*rds")
  pG_rep <- readRDS(file.path(out_dir, myfile))
  pG_rep$Protein.IDs <- rownames(pG_rep)
  pG_rep[pG_rep==0] <- NA
  
  jnk <- data.frame(Strain=names(pG_rep), Filtered_power=colSums(!is.na(pG_rep)))
  mydf <- merge(mydf, jnk, by.x="Identifier", by.y="Strain", all=TRUE)
  rm(jnk)
  rm(pG_rep)
  rm(pG)
  names(mydf)[6] <- "WT_Tech_filter"
  names(mydf)[7] <- "WT_Bio_Power_filter"
  mydf <- mydf[,c(1,2,5,3,4,6,7)]
  
  mydf$Plate_KO <- gsub("Sp([0-9]*)[A-Z].*", "\\1",mydf$Position_KO_Library)
  mydf$Plate_MS <- gsub("Sp([0-9]*)[A-Z].*", "\\1",mydf$Identifier)
  
  saveRDS(mydf, file.path(out_dir,paste0("11_5_",Sys.Date(),"_pG_counts2plot.rds")))
  # plots
  myfile <- list.files(path=out_dir, pattern="^11_5")
  mydf <- readRDS(file.path(out_dir, myfile))
  
  mydf_melt <- melt(mydf, id=c("Identifier", "Strain", "Position_KO_Library",
                          "Plate_KO", "Plate_MS"))
  
  mydf_melt$Plate_MS[mydf_melt$Plate_MS == "Protein.IDs"] <- "all"
  
  p1 <- ggplot(mydf_melt, aes(Plate_MS, value)) + 
    geom_boxplot(aes(color=variable), fill="#404040") +
    theme_bw() +
    facet_grid(variable~.) +
    scale_color_brewer(type="div", palette="Spectral") +
    guides(color=FALSE) +
    ylim(0,3000)+
    xlab("Processed Plate Number") +
    ylab("Number of proteins") +
    ggtitle("All raw files")
  
  mydf2 <- mydf[!is.na(mydf$WT_Bio_Power_filter),]
  mydf_melt <- melt(mydf2, id=c("Identifier", "Strain", "Position_KO_Library",
                               "Plate_KO", "Plate_MS"))
  
  mydf_melt$Plate_MS[mydf_melt$Plate_MS == "Protein.IDs"] <- "all"
  
  p2 <- ggplot(mydf_melt, aes(Plate_MS, value)) + 
    geom_boxplot(aes(color=variable), fill="#404040") +
    theme_bw() +
    facet_grid(variable~.) +
    scale_color_brewer(type="div", palette="Spectral") +
    guides(color=FALSE) +
    ylim(0,3000)+
    xlab("Processed Plate Number") +
    ylab("Number of proteins") +
    ggtitle("Raw files for further analysis")

  p3 <- ggplot(mydf_melt, aes(variable, value)) + 
    geom_boxplot(aes(color=variable), fill="#404040") +
    theme_bw() +
    scale_color_brewer(type="div", palette="Spectral") +
    guides(color=FALSE) +
    ylim(0,3000)+
    xlab("Steps of processing") +
    ylab("Number of proteins") +
    ggtitle("Raw files for further analysis")
  
  pdf(file.path(out_dir, paste0("11_5_1_", Sys.Date(), "_quantified_Plots.pdf")), height = 8, width = 10)
  print(p1)
  print(p2)
  print(p3)
  dev.off()
  # 11.6 # remeasured vs. analyzed what is repeated ################
  myfile <- list.files(path = out_dir, pattern = "^11_3_2.*.rds")
  ST1 <- readRDS(file.path(out_dir, myfile))
  ST1 <- ST1[ST1$StrainType=="Knock-out",]
  
  ST1$Original <- ST1$Position_MS_Plate == ST1$Position_KO_Library
  ST1$Analyzed_ReMeasured2 <- "ToBeAnalyzed"
  ST1$Analyzed_ReMeasured2[grep("Remeasured", ST1$Analyzed_ReMeasured)] <- "Remeasured"
  
  
  
  p3 <- ggplot(data = subset(ST1, Original == TRUE), aes(NumberOfProteinsLess_RespectiveLabel_Labeled))+
    geom_histogram(data = subset(ST1, Original == TRUE & Analyzed_ReMeasured2== "ToBeAnalyzed"), 
                 color="#006837", fill="#bababa")+
    geom_hline(yintercept = 0, size=1, color="white")+
    theme_classic()+
    geom_jitter(data = subset(ST1, Original == TRUE & Analyzed_ReMeasured2!= "ToBeAnalyzed"), 
                 aes(x=NumberOfProteinsLess_RespectiveLabel_Labeled, y=1),
               color="#a50026", size=2, width = 1, height = 1) +
    xlab("Number of proteins identified, less than the run")
  
  p2 <- ggplot(data = subset(ST1, Original == TRUE), aes(MedianLog2Intensity_RespectiveLabel))+
    geom_histogram(data = subset(ST1, Original == TRUE & Analyzed_ReMeasured2== "ToBeAnalyzed"), 
                   color="#006837", fill="#bababa")+
    geom_hline(yintercept = 0, size=1, color="white")+
    theme_classic()+
    geom_jitter(data = subset(ST1, Original == TRUE & Analyzed_ReMeasured2!= "ToBeAnalyzed"), 
                aes(x=MedianLog2Intensity_RespectiveLabel, y=1),
                color="#a50026", size=2, width = 1, height = 1) +
    xlab("Median log2(intensity) in the label")
  
  
  p1 <- ggplot(data = subset(ST1, Original == TRUE), aes(NumberOfProteins_RespectiveLabel))+
    geom_histogram(data = subset(ST1, Original == TRUE & Analyzed_ReMeasured2== "ToBeAnalyzed"), 
                   color="#006837", fill="#bababa")+
    geom_hline(yintercept = 0, size=1, color="white")+
    theme_classic()+
    geom_jitter(data = subset(ST1, Original == TRUE & Analyzed_ReMeasured2!= "ToBeAnalyzed"), 
                aes(x=NumberOfProteins_RespectiveLabel, y=1),
                color="#a50026", size=2, width = 1, height = 1) +
    xlab("Number of proteins identified in the sample")
  
  jnk <- as.data.frame(table(ST1$Position_KO_Library))
  jnk <- jnk[jnk$Freq>1,]
  
  jnk <- ST1[ST1$Position_KO_Library %in% jnk$Var1,]

  jnk_jnk <- jnk[,c(9,19,28)]
  jnk_jnk <- dcast(jnk_jnk, Systemic.ID ~ Analyzed_ReMeasured2, 
                   fun.aggregate = function(x) paste(x, collapse = ";"), value.var="NumberOfProteins_RespectiveLabel")
  
  jnk_jnk <- splitColumnBySep(jnk_jnk, "Remeasured")
  jnk_jnk$ToBeAnalyzed <- as.numeric(jnk_jnk$ToBeAnalyzed)
  jnk_jnk$Remeasured <- as.numeric(jnk_jnk$Remeasured)
  
  p4 <- ggplot(jnk_jnk, aes(Remeasured, ToBeAnalyzed))+
    geom_point()+
    xlim(0, max(jnk_jnk$Remeasured)) +
    ylim(0, max(jnk_jnk$ToBeAnalyzed)) +
    theme_classic()+
    geom_abline(slope = 1, intercept = 0, color="#313695") +
    xlab("Number of proteins identified in discarded sample") +
    ylab("Number of proteins identified in kept sample")
  
  jnk_jnk <- jnk[,c(7,19,28)]
  jnk_jnk <- dcast(jnk_jnk, Systemic.ID ~ Analyzed_ReMeasured2, 
                   fun.aggregate = function(x) paste(x, collapse = ";"), value.var="MedianLog2Intensity_RespectiveLabel")
  
  jnk_jnk <- splitColumnBySep(jnk_jnk, "Remeasured")
  jnk_jnk$ToBeAnalyzed <- as.numeric(jnk_jnk$ToBeAnalyzed)
  jnk_jnk$Remeasured <- as.numeric(jnk_jnk$Remeasured)
  
  p5 <- ggplot(jnk_jnk, aes(Remeasured, ToBeAnalyzed))+
    geom_point()+
    xlim(0, max(jnk_jnk$Remeasured)) +
    ylim(0, max(jnk_jnk$ToBeAnalyzed)) +
    theme_classic()+
    geom_abline(slope = 1, intercept = 0, color="#313695") +
    xlab("Median(log2(intensity)) discarded sample") +
    ylab("Median(log2(intensity))kept sample")
  
  pdf(file.path(out_dir, paste0("11_6_", Sys.Date(), "_QC_MS_Library_Analyzed_Remeasured.pdf")), height = 8, width = 10)
  print(p1)
  print(p2)
  print(p3)
  print(p4)
  print(p5)
  dev.off()
  
  # 11.7 # overlabeling analysis # "Screen_overlabeling_HSTY" ##################
  pG <- read.delim(file.path(data_dir,"Screen_overlabeling_HSTY/combined/txt/proteinGroups.txt"))
  jnk <- pG$id
  pG <- my_pG_filter(pG,1,1)
  jnk <- pG$id
  rm(pG)
  #  length(readLines("F:/Merve_Spombe_DelLibrary_TMT_all/Screen_all/Screen_noLabel_TMT_varMod/combined/txt/evidence.txt"))
  Evidence <- read.delim(file.path(data_dir,"Screen_overlabeling_HSTY/combined/txt/evidence.txt"))
  
  Evidence <- Evidence[Evidence$Protein.group.IDs %in% jnk,]
  saveRDS(Evidence, file.path(out_dir,paste0("11_7_",Sys.Date(),"_Evidence_TMToverlabelingHSTY_notContaminant.rds")))
  
  # plots #
  jnk <- as.data.frame(table(Evidence[,c(18,3)]))
  jnk$Modifications_Vmod <- FALSE  
  jnk$Modifications_Vmod[grep("Vmod", jnk$Modifications)] <- TRUE
  
  jnk2 <- jnk %>%
    group_by(Experiment, Modifications_Vmod) %>%
    dplyr::mutate(Vmod_sum=sum(Freq)) %>%
    as.data.frame()
  jnk2 <- unique(jnk2[,c(1,4,5)])
  jnk2$Plate <- gsub("Sp([0-9]*)[A-Z][0-9]*", "\\1", jnk2$Experiment)
  
  p1 <- ggplot(jnk2, aes(Plate, Vmod_sum)) +
    geom_boxplot(aes(color=Modifications_Vmod), fill="black") +
    xlab("MS plate number") +
    ylab("Total number of evidence, with/out label")+
    guides(color=FALSE)
  
  p1 <- ggplot(jnk2, aes(Vmod_sum))+
    geom_density(aes(fill=Modifications_Vmod, color=Modifications_Vmod), adjust = 2) +
    scale_color_brewer(type="qual", palette="Set1") +
    guides(color=FALSE, fill=FALSE) +
    xlab("Number of evidences")+
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=1) +
    geom_rug(sides="b", aes(color=Modifications_Vmod)) +
    coord_cartesian(clip = "off") +
    theme(plot.margin = margin(1, 1, 1, 1, "cm"))
  
  
  jnk2 <- jnk2 %>%
    group_by(Experiment) %>%
    dplyr::mutate(pFreq = round((100*Vmod_sum) / sum(Vmod_sum),1)) %>%
    as.data.frame()
  
  
  
  p2 <- ggplot(jnk2, aes(pFreq))+
    geom_density(aes(fill=Modifications_Vmod, color=Modifications_Vmod), adjust = 2) +
    scale_color_brewer(type="qual", palette="Set1") +
    guides(color=FALSE, fill=FALSE) +
    xlab("Percentage of evidences")+
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=1) +
    geom_rug(sides="b", aes(color=Modifications_Vmod)) +
    coord_cartesian(clip = "off") +
    theme(plot.margin = margin(1, 1, 1, 1, "cm"))+
    xlim(0,100)
  
  p3 <- ggplot(data=subset(jnk2, Modifications_Vmod == TRUE), aes(pFreq))+
    geom_density(adjust = 2) +
    scale_color_brewer(type="qual", palette="Set1") +
    guides(color=FALSE, fill=FALSE) +
    xlab("Percentage of evidences")+
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=1) +
    geom_rug(sides="b", aes(color=Modifications_Vmod)) +
    coord_cartesian(clip = "off") +
    theme(plot.margin = margin(1, 1, 1, 1, "cm"))
  
  pdf(file.path(out_dir, paste0("11_7_", Sys.Date(), "_QC_MS_Library_summary_evidencesOverlabeling.pdf")), height = 4, width = 4)
  print(p1)
  print(p2)
  print(p3)
  dev.off()
  
  
  
  
  
  ########################################################
  
}}
#####################################################################################################################



