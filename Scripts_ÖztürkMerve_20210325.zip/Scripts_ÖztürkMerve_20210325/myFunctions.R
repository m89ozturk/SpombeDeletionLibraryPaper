#1. # myFunctions ##############################################################################################
getColForExperiment <- function(dataframe, experiment){
  expRegex <- paste0("^Reporter.intensity.[0-9].", experiment)
  expCol <- grep(expRegex, names(dataframe))
  pg_exp <- dataframe[, c(1, expCol)]
  pg_exp <- pg_exp[rowSums(pg_exp[,2:dim(pg_exp)[2]]) != 0,]
  pg_exp[pg_exp == 0] <- NA
  return(pg_exp)
}
calculateStatistics <- function(dataframe){
  dataframe[,2:11] <- log2(dataframe[,2:11])
  dataframe$var <- apply(dataframe[,2:11], 1, var, na.rm=T)
  dataframe$sd <- apply(dataframe[,2:11], 1, sd, na.rm=T)
  dataframe$mean <- apply(dataframe[,2:11], 1, mean, na.rm=T)
  dataframe$upper <- dataframe$mean + 2.5*dataframe$sd
  dataframe$lower <- dataframe$mean - 2.5*dataframe$sd
  xyz1 <- NULL
  for (i in 2:11) {
    xyz <- dataframe[,i] > dataframe$upper | dataframe[,i] < dataframe$lower
    xyz1 <- cbind(xyz1, xyz) 
  }
  
  dataframe$color <- dataframe$var >=0.2
  dataframe$color2 <- rowSums(xyz1)
  return(dataframe)
}

normalize2wt <- function(dataframe, col2norm){
  dataframe <- cbind(dataframe[,1],dataframe[,2:11]-dataframe[,col2norm], dataframe[,c(12:dim(dataframe)[2])])
  names(dataframe)[1] <- "id"
  return(dataframe)
}
normalize2wtTech <- function(dataframe, col2norm){
  dataframe <- dataframe-dataframe[,col2norm]
  return(dataframe)
}
medianNorm4strains <- function(dataframe){
  for (i in 2:11) {
    dataframe[,i] <- dataframe[,i]-median(dataframe[,i], na.rm = T)
  }
  return(dataframe)
} 
medianNorm4strainsDF <- function(dataframe, dimDF){
  jnk_df <- dataframe[,2:dimDF]
  med_all <- median(apply(jnk_df, 2, median, na.rm=TRUE))
  for (i in 2:dimDF) {
    dataframe[,i] <- dataframe[,i]-median(dataframe[,i], na.rm = T) + med_all
  }
  return(dataframe)
}  

plotpca2d_ggplot <- function(pairvector, pr_comp, experiment_regex='(Sp[0-9][0-9])([A-z]*[0-9]*)') {
  highest_pc <- max(unlist(pairvector))
  prcomp_table <- as.data.frame(pr_comp$x[,1:highest_pc])
  
  prcomp_table$replicate <- as.factor(sub(experiment_regex,'\\2', rownames(prcomp_table)))
  prcomp_table$condition <- as.factor(sub(experiment_regex,'\\1', rownames(prcomp_table)))
  
  x_label <- paste0("PC", pairvector[1])
  y_label <- paste0("PC", pairvector[2])
  pca_graph1_prcomp <- 
    ggplot(prcomp_table, 
           aes_string(x=x_label, 
                      y=y_label, 
                      group='condition')) + 
    geom_point(aes(shape=condition, color=condition)) + 
    xlab(sprintf('%s - %.1f%%', 
                 x_label, 
                 summary(pr_comp)$importance[2,pairvector[1]] * 100)) +
    ylab(sprintf('%s - %.1f%%', 
                 y_label, 
                 summary(pr_comp)$importance[2,pairvector[2]] * 100)) +
    scale_shape_manual(values=c(rep(c(15,16,17,18,5,6,7,8), each=8))) +
    # scale_color_manual(values=rep(brewer.pal(9, 'Set1')[-6], 
    #                               ceiling(length(experiments)/8))) +
    #    geom_text_repel(aes(label=replicate), size=1) +
    ggtitle('Principal component analysis with all replicates')+
    theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
          axis.text=element_text(size=16),
          axis.title=element_text(size=18,face="bold"))
  print(pca_graph1_prcomp)
}
plotpca2d_ggplot_wt <- function(pairvector, pr_comp, experiment_regex='(Sp[0-9][0-9])([A-z]*[0-9]*)') {
  highest_pc <- max(unlist(pairvector))
  prcomp_table <- as.data.frame(pr_comp$x[,1:highest_pc])
  
  prcomp_table$replicate <- as.factor(sub(experiment_regex,'\\2', rownames(prcomp_table)))
  prcomp_table$replicate <- gsub("\\.[0-9]*", "", prcomp_table$replicate)
  
  prcomp_table$condition <- as.factor(sub(experiment_regex,'\\1', rownames(prcomp_table)))
  
  x_label <- paste0("PC", pairvector[1])
  y_label <- paste0("PC", pairvector[2])
  pca_graph1_prcomp <- 
    ggplot(prcomp_table, 
           aes_string(x=x_label, 
                      y=y_label, 
                      group='condition')) + 
    geom_point(aes(shape=replicate, color=condition), size=3) + 
    xlab(sprintf('%s - %.1f%%', 
                 x_label, 
                 summary(pr_comp)$importance[2,pairvector[1]] * 100)) +
    ylab(sprintf('%s - %.1f%%', 
                 y_label, 
                 summary(pr_comp)$importance[2,pairvector[2]] * 100)) +
    scale_shape_manual(values=c(12,15,16,17)) +
    # scale_color_manual(values=rep(brewer.pal(9, 'Set1')[-6], 
    #                               ceiling(length(experiments)/8))) +
    #    geom_text_repel(aes(label=replicate), size=1) +
#    ggtitle('Principal component analysis with all replicates')+
    theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
          axis.text=element_text(size=10),
          axis.title=element_text(size=12,face="bold"))
  return(pca_graph1_prcomp)
}
plotpca2d_ggplot_ko <- function(pairvector, pr_comp, experiment_regex='(Sp[0-9][0-9])([A-z]*[0-9]*)') {
  highest_pc <- max(unlist(pairvector))
  prcomp_table <- as.data.frame(pr_comp$x[,1:highest_pc])

  prcomp_table$replicate <- as.factor(sub(experiment_regex,'\\2', rownames(prcomp_table)))
  prcomp_table$replicate <- gsub("\\.1", "", prcomp_table$replicate)
  
  prcomp_table$condition <- as.factor(sub(experiment_regex,'\\1', rownames(prcomp_table)))
  
  x_label <- paste0("PC", pairvector[1])
  y_label <- paste0("PC", pairvector[2])
  pca_graph1_prcomp <- 
    ggplot(prcomp_table, 
           aes_string(x=x_label, 
                      y=y_label, 
                      group='condition')) + 
    geom_point(aes(shape=replicate, color=condition), size=3) + 
    xlab(sprintf('%s - %.1f%%', 
                 x_label, 
                 summary(pr_comp)$importance[2,pairvector[1]] * 100)) +
    ylab(sprintf('%s - %.1f%%', 
                 y_label, 
                 summary(pr_comp)$importance[2,pairvector[2]] * 100)) +
    scale_shape_manual(values=c(12,15,16,17)) +
    scale_color_manual(values=rep(brewer.pal(9, 'Set1')[-6],
                                 ceiling(length(experiments)/8))) +
#    geom_text_repel(aes(label=replicate), size=1) +
#    ggtitle('Principal component analysis with all replicates')+
    theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
          axis.text=element_text(size=10),
          axis.title=element_text(size=12,face="bold"))
  return(pca_graph1_prcomp)
}




TMT_plots <- function(df, expNum){
  pg_ident <- df
  repInt_col <- grep("^Reporter.intensity.[0-9].", names(pg_ident))
  experiments <- unique(gsub("^Reporter.intensity.[0-9].(.*)$", "\\1",names(pg_ident)[repInt_col]))
  strains <- unique(gsub("^Reporter.intensity.([0-9]).(.*)$", "\\1",names(pg_ident)[repInt_col]))
  my_pg <- pg_ident[,c(1, repInt_col)]
  
  my_pg_exp <- getColForExperiment(my_pg, experiments[expNum])
  my_pg_exp_ <- calculateStatistics(my_pg_exp)
  my_pg_exp_ <- normalize2wt(my_pg_exp_, 2)
  #  my_pg_exp_ <- medianNorm4strains(my_pg_exp_)
  
  my_pg_exp_m <- melt(my_pg_exp_, id=c("id", "color","var" ,"sd", "mean","upper", "lower", "color2")) 
  my_pg_exp_m$variable <- gsub("Reporter.intensity.", "", my_pg_exp_m$variable)
  
  gg_box <- ggplot(my_pg_exp_m, aes(variable, value))+ 
    geom_violin() +
    geom_boxplot() +
    geom_jitter(width = 0.2)
  ggsave(file.path(out_dir, paste(output_expr,experiments[expNum],'BoxPlot.pdf', sep = "_")),
         gg_box, height=4, width=6)
  #print(gg_box)
  
  gg_p_line <- ggplot(my_pg_exp_m, aes(variable, value, group=id, color=as.factor(color2)))+ 
    geom_point(alpha=0.5) +
    geom_line(aes(alpha=as.factor(color2)))
  ggsave(file.path(out_dir, paste(output_expr,experiments[expNum],'LinePlot.pdf', sep = "_")),
         gg_p_line, height=4, width=6)
  #print(gg_p_line)
  
  
  # heatmap hierarchical clustering
  ## cluster
  ## Ward Hierarchical Clustering
  d <- dist(t(my_pg_exp_[,2:11]), method = "euclidean") # distance matrix
  fit <- hclust(d, method="ward")
  
  pdf(file.path(out_dir, paste(output_expr,experiments[expNum],'Hclust.pdf', sep = "_")), width = 6, height = 6)
  plot(fit) # display dendogram
  groups <- cutree(fit, k=3) # cut tree into 5 clusters
  # draw dendogram with red borders around the 5 clusters
  rect.hclust(fit, k=3, border="red") 
  dev.off()
  ############################################################## my favourite
  # Ward Hierarchical Clustering with Bootstrapped p values
  x6 <- my_pg_exp_[,2:11]
  
  fit <- pvclust(x6, method.hclust="ward",
                 method.dist="euclidean")
  
  pdf(file.path(out_dir, paste(output_expr,experiments[expNum],'PVclust.pdf', sep = "_")), width = 6, height = 6)
  plot(fit) # dendogram with p values
  # add rectangles around groups highly supported by the data
  pvrect(fit, alpha=.95) 
  dev.off()
  ####################################### heatmap
  x6 <- my_pg_exp_[,2:11]
  x6[is.na(x6)] =0
  hc_m <- x6
  #row.names(hc_m) <- my_pg_exp_[,1]
  names(hc_m) <- gsub("Reporter.intensity.", "", names(hc_m))
  
  my_palette <- colorRampPalette(c("red", "black", "green"))(n = 449)
  col_breaks = c(seq(-1,-0.5,length=150), # for red
                 seq(-0.49,0.49,length=150),  # for yellow
                 seq(0.5,1,length=150)) # for green
  
  pdf(file.path(out_dir, paste(output_expr,experiments[expNum],'Heatmap.pdf', sep = "_")), width = 7, height = 7)
  heatmap.2(as.matrix(hc_m), col=my_palette, breaks = col_breaks, trace="none", keysize = 1.2,key.title = NA,
            labRow = NA, density.info="histogram", margins =c(6,6))
  dev.off()
  ########
}

get_CI_x_min <- function(population, CI){
  jnk <- t.test(population, conf.level=CI)[[4]][1]
  return(jnk)
}
get_CI_x_max <- function(population, CI){
  jnk <- t.test(population, conf.level=CI)[[4]][2]
  return(jnk)
}

get_CI_x_max_real <- function(population, CI){
  a <- mean(population)
  s <- sd(population)
  n <- length(population)
  erroR <- qnorm(1-((1-CI)/2))*s/sqrt(n)
  return(a+erroR)
}

get_CI_x_min_real <- function(population, CI){
  a <- mean(population)
  s <- sd(population)
  n <- length(population)
  erroR <- qnorm(1-((1-CI)/2))*s/sqrt(n)
  return(a-erroR)
}

changeRepIntNames <- function(df){
  names(df) <- gsub("Reporter.intensity.corrected.","", names(df))
  
  repInt_decode <- read.delim("7_ReporterIntensityDecode_values.txt")
  repInt_decode$idMatch <- gsub("Reporter.intensity.corrected.","", repInt_decode$colNames)
  repInt_decode2Match <- repInt_decode[,c(8,9)]
  
  df <- as.data.frame(t(df))
  df$Strains <- rownames(df)
  
  df <- merge(df, repInt_decode2Match, by.x="Strains", by.y="idMatch")
  df <- df[, c(dim(df)[2], 1:(dim(df)[2]-1))]
  df <- df[,-2]
  rownames(df) <- df$ReLabel
  df <- df[,-1]
  df <- as.data.frame(t(df))
  return(df)
}

calculateDFupDown <- function(df, colMin, colMax, numberOfStrains){
  df_upDown <- df[,1:numberOfStrains]
  for(i in 1:numberOfStrains){
    jnk_down <- df[,i] < df[,colMin]
    jnk_up <- df[,i] > df[,colMax]
    jnk <- as.data.frame(cbind(jnk_down, jnk_up))
    jnk$UpDown <- as.numeric(jnk$jnk_up)-as.numeric(jnk$jnk_down)
    df_upDown[,i] <- jnk$UpDown
  }
  return(df_upDown)
}

calculateUpDownNumberOfGenes <- function(df, upDown){
  df_jnk <- as.data.frame(colSums(df==upDown, na.rm = TRUE))
  names(df_jnk) <- "Count"
  df_jnk$Strain <- rownames(df_jnk)
  return(df_jnk)
}

getDFvsColVariation <- function(DF, Col){
  DF_jnk <- DF
  for (i in 1:dim(DF)[2]) {
    DF_jnk[,i] <- (DF_jnk[,i] - Col[,1])^2
  }
  return(DF_jnk)
}

ecdf_fun <- function(x,perc) ecdf(x)(perc)

splitColumnBySep <- function(df, column, sep=";"){
  nameCol <- column
  names(df)[grep(column, names(df))] <- "column"
  df2 <- df %>%
    mutate(column = strsplit(column, sep)) %>%
    unnest(column)
  names(df2)[grep("column", names(df2))] <- nameCol
return(df2)
}

my_pG_filter <- function(pg, uniqueP, razorP){
  if (sum(is.na(pg$Only.identified.by.site)) != dim(pg)[1]) {
    pg <- subset(pg, Only.identified.by.site!= "+")
  }
  if (sum(is.na(pg$Reverse)) != dim(pg)[1]) {
    pg <- subset(pg, Reverse!= "+")
  }
  if (sum(is.na(pg$Potential.contaminant)) != dim(pg)[1]) {
    pg <- subset(pg, Potential.contaminant!= "+")
  }
  pg_ident <- subset(pg, Unique.peptides >= uniqueP & Razor...unique.peptides >= razorP)
  #  pg_ident[pg_ident==0] <- NA
  return(pg_ident)
}

putInShape_df <- function(df_normalized, koLibrary){
  df_net <- as.data.frame(t(df_normalized))
  df_net$Strains <- rownames(df_net)
  # exchange strain positions to gene names #
  nameExchange <- koLibrary[,2:3]
  df_net <- merge(df_net, nameExchange, by.x="Strains", by.y = "FinalPosition", all = F)
  rownames(df_net) <- df_net$Systemic.ID
  df_net <- df_net[,-c(1, dim(df_net)[2])]
  df_net <- as.data.frame(t(df_net))
  return(df_net)
}


my.t.test.p.value <- function(x,y) {
  obj<-try(t.test(x,y), silent=TRUE)
  if (is(obj, "try-error")) return(NA) else return(obj$p.value)
}


myQCnormalization <- function(df, jnk_text){
  df <- as.data.frame(df)
  df$pg <- rownames(df)
  df_melt <- melt(df, id="pg")
  names(df_melt)[2:3] <- c("Strain", "NormIntensity")
  df_melt$Plate <- gsub("Sp([0-9][0-9]).*","\\1" ,df_melt$Strain)
  df <- df[,-grep("pg", colnames(df))]
  
  df_cor <- as.data.frame(cor(df, use="pairwise.complete.obs", method="pearson")) 
  df_cor$Strain1 <- rownames(df_cor)
  df_cor_melt <- melt(df_cor, id="Strain1")
  names(df_cor_melt)[2:3] <- c("Strain2", "Pearson_R")
  
  df_cor_melt$S1Plate <- gsub("Sp([0-9][0-9]).*", "\\1", df_cor_melt$Strain1)
  df_cor_melt$S2Plate <- gsub("Sp([0-9][0-9]).*", "\\1", df_cor_melt$Strain2)
  
  df_cor_melt$S1RUN <- gsub("Sp[0-9][0-9].*([0-9][0-9])", "\\1", df_cor_melt$Strain1)
  df_cor_melt$S2RUN <- gsub("Sp[0-9][0-9].*([0-9][0-9])", "\\1", df_cor_melt$Strain2)
  df_cor_melt$S1RUN <- paste(df_cor_melt$S1Plate, df_cor_melt$S1RUN, sep="_")
  df_cor_melt$S2RUN <- paste(df_cor_melt$S2Plate, df_cor_melt$S2RUN, sep="_")
  
  df_cor_melt <- subset(df_cor_melt, Strain1 != Strain2)
  df_cor_melt$Pearson_R <- as.numeric(df_cor_melt$Pearson_R)
  
  
  df_cor_melt$Category <- NA
  df_cor_melt$Category[df_cor_melt$S1Plate == df_cor_melt$S2Plate] <- "SamePlate"
  df_cor_melt$Category[df_cor_melt$S1RUN == df_cor_melt$S2RUN] <- "SameRun"
  df_cor_melt$Category[is.na(df_cor_melt$Category)] <- "Other"
  
  df_cor_melt$CategoryStrains <- "ko_ko"
  S1wttech <- grep("WT_Tech", df_cor_melt$Strain1)
  S2wttech <- grep("WT_Tech", df_cor_melt$Strain2)
  S1wtbio <- grep("WT_Bio", df_cor_melt$Strain1)
  S2wtbio <- grep("WT_Bio", df_cor_melt$Strain2)
  df_cor_melt$CategoryStrains[union(S1wtbio, union(S1wttech, union(S2wtbio, S2wttech)))] <- "ko_WT"
  df_cor_melt$CategoryStrains[intersect(union(S1wtbio, S1wttech),union(S2wtbio, S2wttech))] <- "WT"
  df_cor_melt$CategoryStrains[intersect(S1wttech, S2wttech)] <- "WT_Tech"
  df_cor_melt$CategoryStrains[intersect(S1wtbio, S2wtbio)] <- "WT_Bio"
  # table(df_cor_melt$CategoryStrains)
  # head(df_cor_melt[df_cor_melt$CategoryStrains == "WT_Bio",])
  
  df_cor_melt$Category_CategoryStrains <- paste(df_cor_melt$Category, df_cor_melt$CategoryStrains, sep=";")
  # table(df_cor_melt$Category_CategoryStrains)
  print("making plots")
  # plots
  df_melt_x <- as.data.frame(df_melt[,c(2,3)])
  df_melt_x <- df_melt_x %>% 
    group_by(Strain) %>% 
    do( tidy(t(quantile(.$NormIntensity, na.rm=TRUE))) )  %>%
    as.data.frame() %>%
    melt(id="Strain") %>%
    as.data.frame()
  df_melt_x$Plate <- gsub("Sp([0-9][0-9]).*","\\1" ,df_melt_x$Strain)
  
  
  df_bp1 <- ggplot(data = subset(df_melt_x, variable=="X0."), aes(x=value, color=Plate))+
    geom_density() +
    guides(color=FALSE) +
    xlab(NULL)+
    ggtitle("quantile=0")
  df_bp2 <- ggplot(data = subset(df_melt_x, variable=="X25."), aes(x=value, color=Plate))+
    geom_density() +
    guides(color=FALSE) +
    xlab(NULL)+
    ggtitle("quantile=25")
  df_bp3 <- ggplot(data = subset(df_melt_x, variable=="X50."), aes(x=value, color=Plate))+
    geom_density() +
    guides(color=FALSE) +
    xlab(NULL)+
    ggtitle("quantile=50")
  df_bp4 <- ggplot(data = subset(df_melt_x, variable=="X75."), aes(x=value, color=Plate))+
    geom_density() +
    guides(color=FALSE) +
    xlab(NULL)+
    ggtitle("quantile=75")
  df_bp5 <- ggplot(data = subset(df_melt_x, variable=="X100."), aes(x=value, color=Plate))+
    geom_density() +
    guides(color=FALSE) +
    xlab(NULL)+
    ggtitle("quantile=100")
  
  df_melt_x <- as.data.frame(df_melt[,c(2,3)])
  df_melt_x <- df_melt_x %>% 
    group_by(Strain) %>% 
    summarise_all(mean, na.rm=TRUE)  %>%
    as.data.frame() %>%
    melt(id="Strain") %>%
    as.data.frame()
  df_melt_x$Plate <- gsub("Sp([0-9][0-9]).*","\\1" ,df_melt_x$Strain)
  
  df_bp6 <- ggplot(df_melt_x, aes(x=value, color=Plate))+
    geom_density() +
    guides(color=FALSE) +
    xlab(NULL)+
    ggtitle("mean")
  
  # df_cor #
  df_cor_melt_x <- as.data.frame(df_cor_melt[,c(8,3)])
  df_cor_melt_x <- df_cor_melt_x %>% 
    group_by(Category) %>% 
    do( tidy(t(quantile(.$Pearson_R, na.rm=TRUE))) )  %>%
    as.data.frame() %>%
    melt(id="Category") %>%
    as.data.frame()
  #  my_comparison <- list(c("SamePlate","SameRun"), c("SamePlate","Other"), c("Other","SameRun"))
  df_cor_bp <- ggplot(df_cor_melt_x, aes(x=Category, y=value))+
    geom_point(color="darkgrey") +
    geom_point(data = subset(df_cor_melt_x, variable=="X25." | variable=="X75."), aes(x=Category, y=value), size=2, color="darkblue") +
    geom_point(data = subset(df_cor_melt_x, variable=="X50."), aes(x=Category, y=value), color="darkred", size=3) +
    #    stat_compare_means(comparisons = my_comparison)  +
    xlab(NULL) +
    ylab("Pearson_R")+
    theme(axis.text.x = element_text(angle = 90, hjust = 1))
  
  
  
  df_cor_melt_x <- as.data.frame(df_cor_melt[,c(9,3)])
  df_cor_melt_x <- df_cor_melt_x %>% 
    group_by(CategoryStrains) %>% 
    do( tidy(t(quantile(.$Pearson_R, na.rm=TRUE))) )  %>%
    as.data.frame() %>%
    melt(id="CategoryStrains") %>%
    as.data.frame()
  df_cor_bp2 <- ggplot(df_cor_melt_x, aes(x=CategoryStrains, y=value))+
    geom_point(color="darkgrey") +
    geom_point(data = subset(df_cor_melt_x, variable=="X25." | variable=="X75."), aes(x=CategoryStrains, y=value), size=2, color="darkblue") +
    geom_point(data = subset(df_cor_melt_x, variable=="X50."), aes(x=CategoryStrains, y=value), color="darkred", size=3) +
    #    stat_compare_means(comparisons = my_comparison)  +
    xlab(NULL) +
    ylab("Pearson_R")+
    theme(axis.text.x = element_text(angle = 90, hjust = 1))
  
  
  df_cor_melt_x <- as.data.frame(df_cor_melt[,c(10,3)])
  df_cor_melt_x <- df_cor_melt_x %>% 
    group_by(Category_CategoryStrains) %>% 
    do( tidy(t(quantile(.$Pearson_R, na.rm=TRUE))) )  %>%
    as.data.frame() %>%
    melt(id="Category_CategoryStrains") %>%
    as.data.frame()
  df_cor_bp3 <- ggplot(df_cor_melt_x, aes(x=Category_CategoryStrains, y=value))+
    geom_point(color="darkgrey") +
    geom_point(data = subset(df_cor_melt_x, variable=="X25." | variable=="X75."), aes(x=Category_CategoryStrains, y=value), size=2, color="darkblue") +
    geom_point(data = subset(df_cor_melt_x, variable=="X50."), aes(x=Category_CategoryStrains, y=value), color="darkred", size=3) +
    #    stat_compare_means(comparisons = my_comparison)  +
    xlab(NULL) +
    ylab("Pearson_R")+
    theme(axis.text.x = element_text(angle = 90, hjust = 1))
  
  # pca
  df_pca <- as.data.frame(t(df))
  df_pca[is.na(df_pca)] <- 0
  df.pca <- prcomp(df_pca, center = FALSE, scale. = FALSE) 
  df_pca$Plate <- gsub("Sp([0-9][0-9]).*", "\\1", rownames(df_pca))
  rownames(df_pca) <- gsub("Sp(.*)", "\\1", rownames(df_pca))
  
  pca_var <- autoplot(df.pca, data = df_pca, colour = 'Plate', shape=FALSE, label.size=2)+
    guides(colour=FALSE)
  pca_var2 <- autoplot(df.pca, data = df_pca, colour = 'Plate')+
    guides(colour=FALSE)
  print("saving plots")
  
  # pca_wt-ko
  jnk <- as.data.frame(names(df))
  names(jnk) <- "jnk"
  jnk$strain <- gsub(".*\\-(.*)", "\\1", jnk$jnk)
  jnk$rename <- paste("Knockout", jnk$strain, sep="-")
  jnk$strain2 <- gsub("(.*)\\-(.*)", "\\1", jnk$jnk)
  jnk$rename[grep("BIO|TECH", jnk$strain)] <- paste(jnk$strain[grep("BIO|TECH", jnk$strain)], 
                                                    jnk$strain2[grep("BIO|TECH", jnk$strain)], sep="-")
  
  # sum(names(df)==jnk$jnk)
  names(df) <- jnk$rename
  
  df_pca <- as.data.frame(t(df))
  df_pca[is.na(df_pca)] <- 0
  df.pca <- prcomp(df_pca, center = FALSE, scale. = FALSE) 
  df_pca$Plate <- gsub("(.*)\\-.*", "\\1", rownames(df_pca))
  rownames(df_pca) <- gsub("(.*)\\-(.*)", "\\2", rownames(df_pca))
  
  pca_var3 <- autoplot(df.pca, data = df_pca, colour = 'Plate', shape=FALSE, label.size=2)
  pca_var4 <- autoplot(df.pca, data = df_pca, colour = 'Plate')
  
  print("saving plots")
  
  p <- ggarrange(ggarrange(df_bp2,df_bp3,df_bp4, df_bp6, ncol=4),
                 ggarrange(df_cor_bp, df_cor_bp2, df_cor_bp3, ncol = 3, widths = c(1,1,3)),
                 ggarrange(pca_var2, pca_var, ncol = 2), 
                 ggarrange(pca_var3, pca_var4, ncol = 2),nrow = 4, heights = c(1,1,2,2))
  p <- annotate_figure(p, top = text_grob(jnk_text, face = "bold", size = 14))
  
  return(p)
}



effectOfNormalization <- function(originalDF, normalizedDF){
  df_measured <- originalDF
  df_measured[df_measured==0] <- NA
  
  df_measured_jnk <- df_measured
  df_measured_jnk[!is.na(df_measured_jnk)] <- 1
  
  
  df_normalized <- as.data.frame(normalizedDF)
  commonCols <- intersect(names(df_normalized), names(df_measured_jnk))
  
  df_normalized <- df_normalized[,names(df_normalized) %in% commonCols]
  df_measured <- df_measured[,names(df_measured) %in% commonCols]
  
  df_measured_jnk <- df_measured_jnk[,names(df_measured_jnk) %in% commonCols]
  
  df_normalized <- setcolorder(df_normalized, names(df_measured_jnk))
  df_normalized_measured <- df_normalized * df_measured_jnk
  
  df_jnk_measured <- df_normalized_measured
  
  df_jnk_notMeasured <- df_jnk_measured
  df_jnk_notMeasured[!is.na(df_jnk_notMeasured)] <- 0
  df_jnk_notMeasured[is.na(df_jnk_notMeasured)] <- 1
  df_jnk_notMeasured[df_jnk_notMeasured==0] <- NA
  
  df_jnk_notMeasured <- df_jnk_notMeasured * df_normalized
  
  n1 <- as.numeric(as.matrix(df_measured))
  n2 <- as.numeric(as.matrix(df_jnk_measured))
  n3 <- as.numeric(as.matrix(df_jnk_notMeasured))
  
  df_jnk_jnk <- as.data.frame(cbind(n1,n2,n3))
  names(df_jnk_jnk) <- c("RealMeasured", "MeasuredValuesNormalized", "NotMeasuredValuesNormalized")
  df_jnk_jnk_melt <- melt(df_jnk_jnk)
  
  h1 <- ggplot(df_jnk_jnk, aes(RealMeasured))+
    geom_density(size=2)+
    ggtitle("Real Measured values")
  
  h2 <- ggplot(df_jnk_jnk, aes(MeasuredValuesNormalized))+
    geom_density(size=2)+
    ggtitle("Measured Values Normalized")
  
  h3 <- ggplot(df_jnk_jnk, aes(NotMeasuredValuesNormalized))+
    geom_density(size=2)+
    ggtitle("Not Measured Values Normalized")
  
  h4 <- ggplot(df_jnk_jnk_melt, aes(value))+
    geom_density(aes(fill=variable, color=variable), alpha=0.5, size=1)+
    ylim(0,0.25)
  
  p <- ggarrange(ggarrange(h1, h3, h2,ncol = 3), h4, nrow = 2)
  
  return(p)
}

cor2originalData <- function(originalDF, normalizedDF){
  df_measured <- originalDF
  df_measured[df_measured==0] <- NA
  
  df_normalized <- as.data.frame(normalizedDF)
  commonCols <- intersect(names(df_normalized), names(df_measured))
  
  df_normalized <- df_normalized[,names(df_normalized) %in% commonCols]
  df_measured <- df_measured[,names(df_measured) %in% commonCols]
  
  df_normalized <- setcolorder(df_normalized, names(df_measured))
  
  
  df_cor <- data.frame(Strain=colnames(df_measured), Measured_vs_Normalized_Pearson=NA, 
                       Measured_vs_Normalized_Spearman=NA)
  for (i in 1:dim(df_cor)[1]) {
    jnk <- cor(df_measured[,i], df_normalized[,i], use="pairwise.complete.obs", method="pearson")
    df_cor$Measured_vs_Normalized_Pearson[i] <- jnk
    
    jnk <- cor(df_measured[,i], df_normalized[,i], use="pairwise.complete.obs", method="spearman")
    df_cor$Measured_vs_Normalized_Spearman[i] <- jnk
  }
  df_cor_melt <- melt(df_cor, id.vars = "Strain")
  cp <- ggplot(df_cor_melt, aes(value))+
    geom_density(aes(fill=variable, color=variable), alpha=0.5, size=1)
  return(cp)
}

wtBioPowerEstimate <- function(df){
  df[df==0] <- NA
  jnk <- grep("WT_Tech", names(df))
  if(length(jnk)>0){
    df <- df[, -jnk]}
  
  wtBioCol <- grep("WT_Bio", names(df))
  df_wtBio <- df[ ,wtBioCol]
  
  wt_count <- rowSums(!is.na(df_wtBio))
  wt_SD <- apply(df_wtBio, 1, sd, na.rm=TRUE)
  wt_mean <- apply(df_wtBio, 1, mean, na.rm=TRUE)
  
  # power estimate
  # power with sample size #
  powerTable <- data.frame(Genes=rownames(df_wtBio),
                           n=wt_count, mu0= wt_mean,
                           sigma = wt_SD,
                           alpha=0.001, FC=1)
  
  powerTable$Power <- NA
  
  for (i in 1:dim(powerTable)[1]) {
    n <- powerTable$n[i]
    z <- qnorm(1 - powerTable$alpha[i])
    mu0 <- powerTable$mu0[i]
    sigma <- powerTable$sigma[i]
    
    powerTable$Power[i] <- pnorm(mu0 + z * sigma/sqrt(n), mean = mu0+powerTable$FC[i], 
                                 sd=sigma/sqrt(n), lower.tail = F)
  }
  
  return(powerTable)
}


my.shapiro.test <- function(x){
  y <- shapiro.test(x)
  return(y$p.value)
}



