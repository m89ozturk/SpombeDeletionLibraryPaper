options(stringsAsFactors=FALSE) #
# .libPaths(c(.libPaths(), "U:/Merve/Rpackages")) 

# setwd("U:/Merve/AllinAll_Mrv_IMB/Project/R_Projects/2017_TMT_SpDelLib/20190424_FinalDatasets")
setwd("E:/Merve/20190424_FinalDatasets/")

source("myFunctions.R")
# source("U:/Merve/AllinAll_Mrv_IMB/R_course/Rtraining_Teresa/201611_teresa_LFQ/extra_fun_LFQ.R")
source("extra_fun_LFQ.R")

out_dir <- "ReplicateTranscriptome/"
data_dir <- "X:/_MS_DATA_OUT/Merve/Sequencing/20190408_imb_butter_2018_05-08_merged_slurm2/analysis/results/"
# 1 # load the libraries #######################################################################################
library(dplyr)
library(plotly)
library(tidyr)
library(knitr)
library(plyr)
library(reshape2)
library(ggplot2)
library(RColorBrewer)
library(parallel)
library(pcaMethods)
library(fBasics)
library(stats)
library(pvclust)
library(ggrepel)
library(cluster)
library(factoextra)
library(psych)
library(gridExtra)
library("ape")
library(ggpubr)
library(ggfortify)
library(broom)
library(data.table)
library(WGCNA)
library(e1071)
library(ggsignif)
library(corrplot)
library(GGally)
library(network)
library(sna)
library(igraph)
library(ggnetwork)
library(VennDiagram)
library(quantmod)
library(threejs)
library(crosstalk)
library(htmltools)
library(GOfuncR)
library(corrplot)
library(PerformanceAnalytics)
library(matrixTests)
######################################################################################################
# 2 # compare the DeSeq vs DeSeq_MM ##################################################################
data_dir_deseq2 <- paste0(data_dir, "DE_DESeq2/")
data_dir_deseq2MM <- paste0(data_dir, "DE_DESeq2_MM/")
myfile <- "allSamples.robustRPKM.csv"
df_deseq2 <- read.csv(file.path(data_dir_deseq2, myfile))
df_deseq2MM <- read.csv(file.path(data_dir_deseq2MM, myfile))
plot(df_deseq2$A1_1.robustRPKM, df_deseq2MM$A1_1.robustRPKM)
rm(df_deseq2MM)
rm(df_deseq2)
rm(data_dir_deseq2MM)
rm(data_dir_deseq2)
# MM looks like not deduplicated so use the one without "MM" ########################################
# 3 # start working with the robustRPKM file == robustCPM (change during calculations) ##############
data_dir <- paste0(data_dir, "DE_DESeq2/")
myfile <- "allSamples.robustRPKM.csv"
df <- read.csv(file.path(data_dir, myfile))
# sum(is.na(df))
# sum(df==0)
CPMcols <- grep("robustRPKM", names(df))
df <- df[,c(1, CPMcols)]
# 3.1 # 1.006722 is the 25% quantile to remove the values less than this ! ################################
df_melt <- melt(df, "gene_id")
df_melt <- as.data.frame(df_melt)
df_melt$plate <- gsub(".*\\_([0-9]*)\\.robustRPKM", "\\1", df_melt$variable)
df_melt$position <- gsub("(.*)\\_([0-9]*)\\.robustRPKM", "\\1", df_melt$variable)
df_melt$value[df_melt$value==0] <- NA
df_melt$value <- log2(df_melt$value)
df_melt$value[is.na(df_melt$value)] <- 0
quantile(df_melt$value)
p0 <- ggplot(df_melt, aes(value))+
  geom_density(aes(color=position))+
  guides(color=FALSE)+
  geom_vline(xintercept = 1.006722)
myCPM_cutOFF <- quantile(df_melt$value, 0.25)[[1]]
saveRDS(df_melt, file.path(out_dir,paste0("3_1_",Sys.Date(),"_originalCPMvalues_melt.rds")))
rm(df_melt)


rownames(df) <- df$gene_id
df <- df[,-1]
df[df==0] <- NA
hist(rowSums(!is.na(df)),385)
jnk <- as.data.frame(table(rowSums(!is.na(df))))
rm(jnk)
# overall the identification rates are better for the transcriptome but use the same approach for imputing !!! ####
# 3.2 # change the names of the data frame ###############################################################
df_2code <- read.delim("20181110_finalfinalDecision2pick.txt")
df_2code$newID <- paste(df_2code$NewPosition_Row, df_2code$NewPosition_Column, sep="")
df_2code <- df_2code[,c(1,8)]

jnk <- as.data.frame(names(df))
names(jnk) <- "colname"
jnk$ID <- gsub("(.*)\\_([0-9]*)\\.robustRPKM", "\\1", jnk$colname)
jnk$replicateID <- gsub("(.*)\\_([0-9]*)\\.robustRPKM", "\\2", jnk$colname)
df_2code <- merge(df_2code, jnk, by.x="newID", by.y="ID", all=FALSE)
rm(jnk)
df_2code$newName <- paste(df_2code$newID,"-", df_2code$Systemic.ID,"_", df_2code$replicateID, sep="")
df_2code <- df_2code[,c(3,5)]

df <- as.data.frame(t(df))
df$oldName <- rownames(df)
df <- merge(df, df_2code, by.x="oldName", by.y="colname", all=FALSE)
rownames(df) <- df$newName
df <- df[,-c(1,dim(df)[2])]
df <- as.data.frame(t(df))
saveRDS(df, file.path(out_dir,paste0("3_2_",Sys.Date(),"_originalCPMvalues_colnamesFixed.rds")))
rm(df)
rm(df_2code)
# 3.3 # log2 transform, impute, and filter ###############################################################
myfile <- list.files(path=out_dir, pattern = "^3_2_.*rds")
df <- readRDS(file.path(out_dir, myfile))
df[df==0] <- NA
df <- log2(df)
hist(rowSums(!is.na(df)),385)
df <- df[rowSums(!is.na(df))!=0,]

# df[is.na(df)] <- 0
df$geneID <- rownames(df)
df <- melt(df, "geneID")
names(df) <- c("geneID", "sample", "log2CPM")

df <-  df %>%
  group_by(geneID) %>%
  dplyr::mutate(geneID_count=sum(!is.na(log2CPM))) %>%
  as.data.frame()

p1 <- ggplot(df, aes(geneID_count)) +
  geom_density(size=2) +
  xlab("Number of measured") +
  ylab("Density") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

df$SystemicIDko <- gsub(".*\\-(.*)\\_[0-9]*", "\\1", df$sample)
df$SystemicIDko[grep("wt", df$SystemicIDko)] <- "wt"

df <-  df %>%
  group_by(geneID, SystemicIDko) %>%
  dplyr::mutate(Replicate_measured_count=sum(!is.na(log2CPM))) %>%
  as.data.frame()

p2 <- ggplot(df, aes(Replicate_measured_count)) +
  geom_density(size=2) +
  xlab("Number of measured, replicates") +
  ylab("Density") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

p3 <- ggplot(df, aes(Replicate_measured_count, log2CPM)) +
  geom_boxplot(aes(group=Replicate_measured_count)) +
  xlab("Number of measured, replicates") +
  ylab("Measured intensity") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

# impute
myconditions <- unique(df$SystemicIDko)

intensity_matrix <- df[,1:3]
intensity_matrix <- dcast(intensity_matrix, geneID ~ sample)
rownames(intensity_matrix) <- intensity_matrix$geneID
intensity_matrix <- intensity_matrix[,-1]
intensity_matrix <- as.matrix(intensity_matrix)

intensity_matrix2 <- get_imputation_bpca_bycond(norm_matrix=intensity_matrix, 
                                                conditions=myconditions, cores=1, repCount=1)
intensity_matrix <- as.data.frame(intensity_matrix2)  
rm(intensity_matrix2)
saveRDS(intensity_matrix,file.path(out_dir, paste0("3_3_", Sys.Date(), "_bpcaImputed_1rep_df.rds")))

intensity_matrix$ProteinIDs <- rownames(intensity_matrix)
intensity_matrix <- melt(intensity_matrix, id="ProteinIDs")

intensity_matrix$mergeID <- paste(intensity_matrix$ProteinIDs, intensity_matrix$variable, sep="=")
intensity_matrix <- as.data.frame(intensity_matrix[,3:4])
names(intensity_matrix)[1] <- "log2Imputed1"
df$mergeID <- paste(df$geneID, df$sample, sep="=")

df <- merge(df, intensity_matrix, by.x="mergeID", by.y="mergeID", all=FALSE)
rm(intensity_matrix)

df <-  df %>%
  group_by(geneID) %>%
  dplyr::mutate(ProteinIDs_measured_count=sum(!is.na(log2CPM))) %>%
  as.data.frame()

df <-  df %>%
  group_by(geneID, SystemicIDko) %>%
  dplyr::mutate(Replicate_measured_count=sum(!is.na(log2CPM))) %>%
  as.data.frame()

df <-  df %>%
  group_by(geneID) %>%
  dplyr::mutate(ProteinIDs_imputed_count=sum(!is.na(log2Imputed1))) %>%
  as.data.frame()

df <-  df %>%
  group_by(geneID, SystemicIDko) %>%
  dplyr::mutate(Replicate_imputed_count=sum(!is.na(log2Imputed1))) %>%
  as.data.frame()
saveRDS(df,file.path(out_dir, paste0("3_3_", Sys.Date(), "_dfALL_imputed.rds")))
# filter for protein coding and above certain value
myfile <- list.files(path=out_dir, pattern="^3_3.*ALL\\_imputed.rds")
df <- readRDS(file.path(out_dir, myfile))
df2 <- readRDS("2_b_geneType_geneID_ALL.rds")
df <- merge(df, df2, by.x="geneID", by.y="geneID", all=FALSE)

p4 <- ggplot(df, aes(biotype, log2CPM)) +
  geom_boxplot()+
  xlab(NULL)+
  ylab("Normalized intensity")
  
df2 <- as.data.frame(table(df[,c(7,12)]))
df2 <- df2[df2$Freq!=0,]
df2$Freq2 <- round(100*df2$Freq/sum(df2$Freq),2)
df2$mycolor <- df2$Freq2>=1
p5 <- ggplot(df2, aes(biotype, Replicate_measured_count)) +
  geom_point(aes(size=Freq, color=mycolor)) +
  geom_text(aes(label=Freq2),size = 3, vjust = 0, nudge_y = 0.2) +
  xlab(NULL)+
  ylab("measured count")
rm(df2)

df_count <- as.data.frame(table(df[,c(7,11)]))
df_count <- as.data.frame(subset(df_count, Freq !=0))
df_count$Freq2 <- round(100*df_count$Freq/sum(df_count$Freq),1)
df_count$Type <- paste(df_count$Replicate_measured_count, df_count$Replicate_imputed_count, sep="_")

p6 <- ggplot(df_count, aes(x=Type, y=Freq)) +
  geom_bar(stat = "identity") +
  xlab("Measured_Imputed") +
  ylab("Count") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14)) +
  geom_text(aes(label=Freq, y = Freq + 150000), position = position_dodge(0.9), vjust = 0, size=3)+
  geom_text(aes(label=Freq2, y = Freq + 100000), position = position_dodge(0.9), vjust = 0, size=3)
rm(df_count)

df2 <- as.data.frame(subset(df, biotype == "protein_coding"))
df2$log2CPM[is.na(df2$log2CPM)] <- 0
df2$log2Imputed1[is.na(df2$log2Imputed1)] <- 0

df2 <-  df2 %>%
  group_by(geneID) %>%
  dplyr::mutate(meanCPM=mean(log2CPM)) %>%
  as.data.frame()
df2 <-  df2 %>%
  group_by(geneID) %>%
  dplyr::mutate(meanImp=mean(log2Imputed1)) %>%
  as.data.frame()

p7 <- ggplot(df2, aes(meanCPM))+
  geom_density(size=2)+
  geom_density(aes(x=meanImp), color="red", size=2, alpha=0.5, linetype="dashed")+
  geom_vline(xintercept = myCPM_cutOFF, color="blue")

df2 <- df2[df2$meanImp>myCPM_cutOFF,]
saveRDS(df2,file.path(out_dir, paste0("3_3_", Sys.Date(), "_df_proteinCoding4710_imputed.rds")))
pdf(file.path(out_dir, paste0("3_3_", Sys.Date(), "_plots4filtering.pdf")), width = 10, height = 8)
print(p0)
print(p1)
print(p2)
print(p3)
print(p4)
print(p5)
print(p6)
print(p7)
dev.off()
rm(p0)
rm(p1)
rm(p2)
rm(p3)
rm(p4)
rm(p5)
rm(p6)
rm(p7)
rm(df)
rm(df2)
# 3.4 # Keep the imputations if "Replicate_measured_count >= 3 ###############################################################
myfile <- list.files(path=out_dir, pattern="^3_3_.*proteinCoding")
df <- readRDS(file.path(out_dir, myfile))
df$log2CPM[df$log2CPM==0] <- NA
df$log2Imputed1[df$log2Imputed1==0] <- NA

df$Keep <- FALSE
table(df$Keep) # FALSE = 1808640
df$Keep[!is.na(df$log2CPM)] <- TRUE
table(df$Keep) # TRUE = 1806829 = 99.9% &&& FALSE = 1811

df$Keep[df$Replicate_measured_count >= 3] <- TRUE
table(df$Keep) # TRUE = 1808347 = 99.9838% &&& FALSE = 293


df$log2Imputed1_Keep <- df$log2Imputed1
df$log2Imputed1_Keep[df$Keep == FALSE] <- NA

saveRDS(df,file.path(out_dir, paste0("3_4_", Sys.Date(), "_dfALL_imputed_Keep.rds")))

df <- df[,c(3,1,16)]
intensity_matrix <- dcast(df, geneID ~ sample)
rownames(intensity_matrix) <- intensity_matrix$geneID
intensity_matrix <- intensity_matrix[,-1]

saveRDS(intensity_matrix,file.path(out_dir, paste0("3_4_", Sys.Date(), "_bpcaImputed_3rep_df.rds")))
rm(intensity_matrix)
rm(df)

# 3.5 # check if filtered for wt count how many pG/ko replicate ##########################################
myfile <- list.files(path=out_dir, pattern = "bpcaImputed_3rep")
df <- readRDS(file.path(out_dir, myfile))

wt_col <- grep("wt", names(df))
jnk <- rowSums(!is.na(df[,wt_col]))
jnk2 <- as.data.frame(table(jnk))

p1 <- ggplot(jnk2, aes(x=as.factor(jnk), Freq)) +
  geom_bar(stat="identity") +
  geom_text(aes(label=Freq), position=position_dodge(width=0.9), vjust=-0.25, size=6)+
  xlab("WT number of measured") +
  ylab("Number of proteins")

df_wt8 <- df[jnk==8,]
rm(df_wt8)
rm(jnk2)
# all genes have 8 values in wt measurements #
experiments <- unique(gsub(".*\\-(.*)\\_[0-9]", "\\1", names(df)))
experiments <- setdiff(experiments, c("wt1", "wt2"))
# experiments <- c(experiments, "wt")

my_df <- data.frame(Strain=experiments, Original_4=NA, Original_2=NA, Original_1=NA, Original_0=NA)
  
for (i in 1:dim(my_df)[1]) {
  print(i)
  myexp <- my_df$Strain[i]
  df_jnk <- df[,grep(myexp, names(df))]
  jnk <- as.data.frame(table(rowSums(!is.na(df_jnk))))
  my_df$Original_4[i] <- max(0,jnk$Freq[jnk$Var1 == 4])
  my_df$Original_2[i] <- max(0,jnk$Freq[jnk$Var1 == 2])
  my_df$Original_1[i] <- max(0,jnk$Freq[jnk$Var1 == 1])
  my_df$Original_0[i] <- max(0,jnk$Freq[jnk$Var1 == 0])
}

my_df_melt <- melt(my_df, id="Strain")
my_df_melt$RefDF <- gsub("(.*)\\_[0-9]", "\\1", my_df_melt$variable)
my_df_melt$Count <- gsub("(.*)\\_([0-9])", "\\2", my_df_melt$variable)

p2 <- ggplot(my_df_melt, aes(as.factor(Count), value)) +
  geom_boxplot()+
  facet_grid(RefDF ~ ., scales="free")+
  xlab("Count ko") +
  ylab("Number of proteins")+
  ggtitle("4700-4710 genes have values in all replicates")

pdf(file.path(out_dir, paste0("3_5_", Sys.Date(), "_plotsAfterfiltering.pdf")), width = 10, height = 8)
print(p1)
print(p2)
dev.off()
rm(p1)
rm(p2)
rm(df)
rm(df_jnk)
rm(jnk)
rm(my_df)
rm(my_df_melt)
# 3.6 # diffreg criteria after imputation ##########################################
myfile <- list.files(path=out_dir, pattern = "ALL_imputed_Keep.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))

df_imp <- pG_mbr_melt[,c(3,1,16)]
df_imp <- dcast(df_imp, geneID ~ sample)
rownames(df_imp) <- df_imp$geneID
df_imp <- df_imp[,-1]

wt_col <- grep("wt", names(df_imp))
ko_col <- setdiff(1:384, wt_col)

myPvalue <- row_t_equalvar(df_imp[, wt_col], df_imp[, ko_col], alternative = "two.sided", mu = 0, conf.level = 0.95)
p1 <- ggplot(myPvalue, aes(mean.diff, -log10(pvalue)))+
  geom_point() +
  xlab("WT-KO")+
  ylab("-log10(pvalue)")+
  ggtitle("wt-allKO transcriptome")
ggsave(file.path(out_dir, paste0("3_6_", Sys.Date(), "_Volcano-wt-ko.pdf")), p1)
rm(p1)
# 3.6.1 # 4 vs 4 wt1, wt2 ########################
experiments <- unique(gsub(".*\\-(.*)\\_[0-9]", "\\1", names(df_imp)))
# experiments <- setdiff(experiments, c("wt1", "wt2"))
# experiments <- c(experiments, "wt")
myconditions <- experiments

my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
rows2keep <- unique(c(grep("^wt", my_comparisons$V1), grep("^wt", my_comparisons$V2)))
my_comparisons <- my_comparisons[rows2keep,]
#my_comparisons <- rbind(my_comparisons, c("wt1", "wt2"))
rm(pG_mbr_melt)
my_comparisons$ComparisonSize <- NA

library(combinat)
jnk <- permn(c(1,1,2,2))
jnk2 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
jnk2 <- unique(jnk2)
rm(jnk)

myPvalueCutOFF <- seq(0,0.05,0.005)
myFCCutOFF <- seq(0,2,0.05)
my_P_FC <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
# my_P_FC <- as.data.frame(subset(my_P_FC, group1 != group2))
my_P_FC2 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))

my_P_FC$group <- "Original"
my_P_FC2$group <- "Shuffle_FDR"
my_P_FC <- as.data.frame(rbind(my_P_FC2, my_P_FC))
rm(my_P_FC2)
names(my_P_FC)[1] <- "myFCCutOFF"
names(my_P_FC)[2] <- "myPvalueCutOFF"

my_P_FC$col2add <- paste("myFCCutOFF", my_P_FC$myFCCutOFF ,"myPvalueCutOFF", my_P_FC$myPvalueCutOFF, my_P_FC$group, sep="_")

new_jnk <- as.data.frame(matrix(NA, nrow = dim(my_comparisons)[1], ncol = dim(my_P_FC)[1]))
names(new_jnk) <- my_P_FC$col2add

my_comparisons <- as.data.frame(cbind(my_comparisons, new_jnk))
rm(new_jnk)
rm(my_P_FC)
# i.e. SPBPB10D8.06c=86 180
for (i in 1:dim(my_comparisons)[1]) {
  print(i)
  group1 <- my_comparisons$V1[i]
  group2 <- my_comparisons$V2[i]
  
  group1Cols <- grep(group1, names(df_imp))
  group2Cols <- grep(group2, names(df_imp))
  
  df_group <- df_imp[,c(group1Cols, group2Cols)]
  df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
  my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
  
  for (j in myPvalueCutOFF) {
    for (k in myFCCutOFF) {
      # original 
      group1Cols <- grep(group1, names(df_group))
      group2Cols <- grep(group2, names(df_group))
      
      myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
      myPvalue <- myPvalue[,c(6,13)]
      myPvalue$mean.diff <- abs(myPvalue$mean.diff)
      
      myPvalue_dim_original <- dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1]
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Original", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- myPvalue_dim_original
      
      # shuffle 
      shuffled_values <- NULL
      for (groups2compare1 in 1:dim(jnk2)[1]) {
        for (groups2compare2 in 1:dim(jnk2)[1]) {
          mygrouping <- data.frame(mycolname=names(df_group), 
                                   mygroup=c(t(jnk2[groups2compare1,]), t(jnk2[groups2compare2,])))
          
          group1Cols <- grep("1", mygrouping$mygroup)
          group2Cols <- grep("2", mygrouping$mygroup)
          
          myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
          myPvalue <- myPvalue[,c(6,13)]
          myPvalue$mean.diff <- abs(myPvalue$mean.diff)
          shuffled_values <- c(shuffled_values, dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1])
          }
      }
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Shuffle_FDR", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- round(100*mean(shuffled_values)/(1+myPvalue_dim_original),0)
      }
  }
  saveRDS(my_comparisons, file.path(out_dir, paste0("3_6_1_", Sys.Date(), "_myComparisons_permuted.rds")))
  
}

# 3.6.2 # 4ko vs 8wt = 2+4 ########################
experiments <- unique(gsub(".*\\-(.*)\\_[0-9]", "\\1", names(df_imp)))
experiments <- setdiff(experiments, c("wt1", "wt2"))
experiments <- c(experiments, "wt")
myconditions <- experiments

my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
rows2keep <- unique(c(grep("^wt", my_comparisons$V1), grep("^wt", my_comparisons$V2)))
my_comparisons <- my_comparisons[rows2keep,]
#my_comparisons <- rbind(my_comparisons, c("wt1", "wt2"))
rm(pG_mbr_melt)
my_comparisons$ComparisonSize <- NA

library(combinat)
jnk <- permn(c(1,1,2,2))
jnk2 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
jnk2 <- unique(jnk2)
jnk <- permn(c(1,1,1,1,2,2,2,2))
jnk3 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
jnk3 <- unique(jnk3)
rm(jnk)

myPvalueCutOFF <- seq(0,0.05,0.005)
myFCCutOFF <- seq(0,2,0.05)
my_P_FC <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
# my_P_FC <- as.data.frame(subset(my_P_FC, group1 != group2))
my_P_FC2 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))

my_P_FC$group <- "Original"
my_P_FC2$group <- "Shuffle_FDR"
my_P_FC <- as.data.frame(rbind(my_P_FC2, my_P_FC))
rm(my_P_FC2)
names(my_P_FC)[1] <- "myFCCutOFF"
names(my_P_FC)[2] <- "myPvalueCutOFF"

my_P_FC$col2add <- paste("myFCCutOFF", my_P_FC$myFCCutOFF ,"myPvalueCutOFF", my_P_FC$myPvalueCutOFF, my_P_FC$group, sep="_")

new_jnk <- as.data.frame(matrix(NA, nrow = dim(my_comparisons)[1], ncol = dim(my_P_FC)[1]))
names(new_jnk) <- my_P_FC$col2add

my_comparisons <- as.data.frame(cbind(my_comparisons, new_jnk))
rm(new_jnk)
rm(my_P_FC)
for (i in 1:dim(my_comparisons)[1]) {
  print(i)
  group1 <- my_comparisons$V1[i]
  group2 <- my_comparisons$V2[i]
  
  group1Cols <- grep(group1, names(df_imp))
  group2Cols <- grep(group2, names(df_imp))
  
  df_group <- df_imp[,c(group1Cols, group2Cols)]
  df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
  my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
  
  for (j in myPvalueCutOFF) {
    for (k in myFCCutOFF) {
      # original 
      group1Cols <- grep(group1, names(df_group))
      group2Cols <- grep(group2, names(df_group))
      
      myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
      myPvalue <- myPvalue[,c(6,13)]
      myPvalue$mean.diff <- abs(myPvalue$mean.diff)
      
      myPvalue_dim_original <- dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1]
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Original", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- myPvalue_dim_original
      
      # shuffle 
      shuffled_values <- NULL
      for (groups2compare1 in 1:dim(jnk2)[1]) {
        for (groups2compare2 in 1:dim(jnk3)[1]) {
          mygrouping <- data.frame(mycolname=names(df_group), 
                                   mygroup=c(t(jnk2[groups2compare1,]), t(jnk3[groups2compare2,])))
          
          group1Cols <- grep("1", mygrouping$mygroup)
          group2Cols <- grep("2", mygrouping$mygroup)
          
          myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
          myPvalue <- myPvalue[,c(6,13)]
          myPvalue$mean.diff <- abs(myPvalue$mean.diff)
          shuffled_values <- c(shuffled_values, dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1])
        }
      }
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Shuffle_FDR", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- round(100*mean(shuffled_values)/(1+myPvalue_dim_original),0)
    }
  }
  saveRDS(my_comparisons, file.path(out_dir, paste0("3_6_2_", Sys.Date(), "_myComparisons_permuted.rds")))
}

# 3.6.3 # decide FC and pvalue based on FDR ########################
myfiles <- list.files(path=out_dir, pattern="^3_6_[1-9]_.*rds")

my_comparisons <- readRDS(file.path(out_dir, myfiles[1]))

my_comparisons$identifier <- paste(my_comparisons$V1, my_comparisons$V2,
                                   my_comparisons$ComparisonSize, sep="-")
my_comparisons <- my_comparisons[,-c(grep("V1|V2|ComparisonSize", names(my_comparisons)))]

my_comparisons1 <- my_comparisons[,c(grep("identifier", names(my_comparisons)),
                                     grep("Original", names(my_comparisons)))]
my_comparisons2 <- my_comparisons[,c(grep("identifier", names(my_comparisons)),
                                     grep("Shuffle", names(my_comparisons)))]
# number of proteins changing #
my_comparisons1 <- melt(my_comparisons1, id.vars="identifier")
my_comparisons1$FoldChange <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_.*", "\\1", my_comparisons1$variable)
my_comparisons1$Pvalue <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_(.*)\\_.*", "\\2", my_comparisons1$variable)
my_comparisons1$pfc <- paste(my_comparisons1$Pvalue, my_comparisons1$FoldChange)

my_comparisons1$WT <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\1", my_comparisons1$identifier)
my_comparisons1$Strain <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\2", my_comparisons1$identifier)

my_comparisons1 <- my_comparisons1 %>%
  group_by(pfc) %>%
  dplyr::mutate(pfc_fdr = quantile(value, 0.5)[1]) %>%
  as.data.frame()

my_comparisons1_1 <- unique(my_comparisons1[,c(4,5,6,9)])
names(my_comparisons1_1)[4] <- "NumberChanging" 
ggplot(my_comparisons1_1, aes(FoldChange, NumberChanging))+
  geom_point(aes(color=Pvalue)) 
# percentage FDR #
my_comparisons2 <- melt(my_comparisons2, id.vars="identifier")
my_comparisons2$FoldChange <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_.*", "\\1", my_comparisons2$variable)
my_comparisons2$Pvalue <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_(.*)\\_.*\\_.*", "\\2", my_comparisons2$variable)
my_comparisons2$pfc <- paste(my_comparisons2$Pvalue, my_comparisons2$FoldChange)

my_comparisons2$WT <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\1", my_comparisons2$identifier)
my_comparisons2$Strain <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\2", my_comparisons2$identifier)

my_comparisons2 <- my_comparisons2 %>%
  group_by(pfc) %>%
  dplyr::mutate(pfc_fdr = quantile(value, 0.5)[1]) %>%
  as.data.frame()

my_comparisons3 <- unique(my_comparisons2[,c(4,5,6,9)])

ggplot(my_comparisons3, aes(FoldChange, pfc_fdr))+
  geom_point(aes(color=Pvalue)) +
  #facet_grid(FoldChange ~., scales = "free")+
  ylim(0,100)

my_comparisons_4_4 <- merge(my_comparisons1_1, my_comparisons3, by.x="pfc", by.y="pfc")
my_comparisons_4_4 <- my_comparisons_4_4[,c(1:4, 7)]

ggplot(my_comparisons_4_4, aes(FoldChange.x, pfc_fdr))+
  geom_point(aes(color=Pvalue.x)) +
  geom_point(aes(y=NumberChanging, color=Pvalue.x), shape=12)


# for the 4 vs 8 ##
my_comparisons <- readRDS(file.path(out_dir, myfiles[2]))

my_comparisons$identifier <- paste(my_comparisons$V1, my_comparisons$V2,
                                   my_comparisons$ComparisonSize, sep="-")
my_comparisons <- my_comparisons[,-c(grep("V1|V2|ComparisonSize", names(my_comparisons)))]

my_comparisons1 <- my_comparisons[,c(grep("identifier", names(my_comparisons)),
                                     grep("Original", names(my_comparisons)))]
my_comparisons2 <- my_comparisons[,c(grep("identifier", names(my_comparisons)),
                                     grep("Shuffle", names(my_comparisons)))]
# number of proteins changing #
my_comparisons1 <- melt(my_comparisons1, id.vars="identifier")
my_comparisons1$FoldChange <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_.*", "\\1", my_comparisons1$variable)
my_comparisons1$Pvalue <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_(.*)\\_.*", "\\2", my_comparisons1$variable)
my_comparisons1$pfc <- paste(my_comparisons1$Pvalue, my_comparisons1$FoldChange)

my_comparisons1$WT <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\1", my_comparisons1$identifier)
my_comparisons1$Strain <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\2", my_comparisons1$identifier)

my_comparisons1 <- my_comparisons1 %>%
  group_by(pfc) %>%
  dplyr::mutate(pfc_fdr = quantile(value, 0.5)[1]) %>%
  as.data.frame()

my_comparisons1_1 <- unique(my_comparisons1[,c(4,5,6,9)])
names(my_comparisons1_1)[4] <- "NumberChanging" 
ggplot(my_comparisons1_1, aes(FoldChange, NumberChanging))+
  geom_point(aes(color=Pvalue)) 
# percentage FDR ##
my_comparisons2 <- melt(my_comparisons2, id.vars="identifier")
my_comparisons2$FoldChange <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_.*", "\\1", my_comparisons2$variable)
my_comparisons2$Pvalue <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_(.*)\\_.*\\_.*", "\\2", my_comparisons2$variable)
my_comparisons2$pfc <- paste(my_comparisons2$Pvalue, my_comparisons2$FoldChange)

my_comparisons2$WT <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\1", my_comparisons2$identifier)
my_comparisons2$Strain <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\2", my_comparisons2$identifier)

my_comparisons2 <- my_comparisons2 %>%
  group_by(pfc) %>%
  dplyr::mutate(pfc_fdr = quantile(value, 0.5)[1]) %>%
  as.data.frame()

my_comparisons3 <- unique(my_comparisons2[,c(4,5,6,9)])

ggplot(my_comparisons3, aes(FoldChange, pfc_fdr))+
  geom_point(aes(color=Pvalue)) +
  #facet_grid(FoldChange ~., scales = "free")+
  ylim(0,100)

my_comparisons_4_8 <- merge(my_comparisons1_1, my_comparisons3, by.x="pfc", by.y="pfc")
my_comparisons_4_8 <- my_comparisons_4_8[,c(1:4, 7)]

ggplot(my_comparisons_4_8, aes(FoldChange.x, pfc_fdr))+
  geom_point(aes(color=Pvalue.x)) +
  geom_point(aes(y=NumberChanging, color=Pvalue.x), shape=12)

names(my_comparisons_4_4)[2] <- "FC"
names(my_comparisons_4_4)[3] <- "p"
names(my_comparisons_4_4)[4] <- "Changing_4_4" 
names(my_comparisons_4_4)[5] <- "FDR_4_4" 
names(my_comparisons_4_8)[4] <- "Changing_4_8" 
names(my_comparisons_4_8)[5] <- "FDR_4_8" 

my_comparisons_4_8 <- my_comparisons_4_8[,c(1,4,5)]
my_comparisons <- merge(my_comparisons_4_4, my_comparisons_4_8,
                        by.x="pfc", by.y="pfc")
rm(my_comparisons1)
rm(my_comparisons1_1)
rm(my_comparisons2)
rm(my_comparisons3)
rm(my_comparisons_4_4)
rm(my_comparisons_4_8)

saveRDS(my_comparisons, file.path(out_dir, paste0("3_6_3_", Sys.Date(), "_FDR.rds")))
# 3.6.4 # decide FC and pvalue based on FDR - plots ########################
myfile <- list.files(path=out_dir, pattern="^3_6_3.*rds")
my_comparisons <- readRDS(file.path(out_dir, myfile))
my_comparisons$candidateCutOff <- FALSE

my_comparisons$candidateCutOff[my_comparisons$Changing_4_8 == max(my_comparisons$Changing_4_8[my_comparisons$FDR_4_8<=10])] <- TRUE


my_comparisons$candidateCutOff[my_comparisons$FDR_4_8<=10]

p1 <- ggplot(my_comparisons, aes(FDR_4_4, FDR_4_8))+
  geom_point()

p2 <- ggplot(my_comparisons, aes(Changing_4_4, Changing_4_8))+
  geom_point()

p3 <- ggplot(my_comparisons, aes(FDR_4_8, Changing_4_8))+
  geom_point(aes(color=candidateCutOff, size=candidateCutOff))+
  guides(color=NULL)

p0 <- ggplot(my_comparisons, aes(FC, FDR_4_8))+
  geom_point(aes(color=p, size=candidateCutOff))

myfile <- list.files(path=out_dir, pattern="^3_6_2_.*rds")
my_comparisons_original <- readRDS(file.path(out_dir, myfile))


jnk <- my_comparisons[my_comparisons$candidateCutOff == TRUE,]
my_comparisons_original2 <- my_comparisons_original[,c(1:3,
                                                       grep(paste0("myFCCutOFF_", jnk$FC,
                                                                   "_myPvalueCutOFF_", jnk$p,"_"), 
                                                            names(my_comparisons_original)))]
names(my_comparisons_original2)[4] <- "FP"
names(my_comparisons_original2)[5] <- "Original"
p4 <- ggplot(my_comparisons_original2, aes(Original, 
                                           FP))+
  geom_point(aes(color=ComparisonSize), size=4)+
  xlab("Number of proteins changing") +
  ylab("False positive %") +
  guides(color=NULL) +
  geom_hline(yintercept = c(2,68.5), linetype="dashed") +
  geom_vline(xintercept = c(8.3,263.4), linetype="dashed")+
  geom_hline(yintercept = 10, color="darkred") +
  geom_vline(xintercept = 57.5, color="darkred")+
  geom_rug()


p5 <- ggplot(my_comparisons, aes(FC, p))+
  geom_tile(aes(fill=FDR_4_8)) +
  geom_tile(data=subset(my_comparisons, candidateCutOff == TRUE),aes(fill=FDR_4_8),color="black") +
  geom_text(aes(label=round(Changing_4_8,0)), size=3)+
  scale_fill_gradient2(midpoint = 10)
pdf(file.path(out_dir, paste0("3_6_4_", Sys.Date(), "_FDR_pFC_0-005_0-6.pdf")), height = 8, width = 14)
print(p1)
print(p2)
print(p3)
print(p0)
print(p5)
print(p4)
dev.off()
rm(jnk)
rm(my_comparisons)
rm(my_comparisons_original)
rm(my_comparisons_original2)
rm(p0)
rm(p1)
rm(p2)
rm(p3)
rm(p4)
rm(p5)

# use FC=0.6, p=0.005 ###############################################
# 20190718 # 4ko vs 8wt =2+4 but smaller intervals ####################################################
# 3.7 # diffreg criteria after imputation # 4ko vs 8wt = 2+4 ###########################################
myfile <- list.files(path=out_dir, pattern = "ALL_imputed_Keep.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))

df_imp <- pG_mbr_melt[,c(3,1,16)]
df_imp <- dcast(df_imp, geneID ~ sample)
rownames(df_imp) <- df_imp$geneID
df_imp <- df_imp[,-1]

wt_col <- grep("wt", names(df_imp))
ko_col <- setdiff(1:384, wt_col)

experiments <- unique(gsub(".*\\-(.*)\\_[0-9]", "\\1", names(df_imp)))
experiments <- setdiff(experiments, c("wt1", "wt2"))
experiments <- c(experiments, "wt")
myconditions <- experiments

my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
rows2keep <- unique(c(grep("^wt", my_comparisons$V1), grep("^wt", my_comparisons$V2)))
my_comparisons <- my_comparisons[rows2keep,]
#my_comparisons <- rbind(my_comparisons, c("wt1", "wt2"))
rm(pG_mbr_melt)
my_comparisons$ComparisonSize <- NA

library(combinat)
jnk <- permn(c(1,1,2,2))
jnk2 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
jnk2 <- unique(jnk2)
jnk <- permn(c(1,1,1,1,2,2,2,2))
jnk3 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
jnk3 <- unique(jnk3)
rm(jnk)

myPvalueCutOFF <- seq(0,0.05,0.0001)
myFCCutOFF <- seq(0,2,0.001)
my_P_FC <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
# my_P_FC <- as.data.frame(subset(my_P_FC, group1 != group2))
my_P_FC2 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))

my_P_FC$group <- "Original"
my_P_FC2$group <- "Shuffle_FDR"
my_P_FC <- as.data.frame(rbind(my_P_FC2, my_P_FC))
rm(my_P_FC2)
names(my_P_FC)[1] <- "myFCCutOFF"
names(my_P_FC)[2] <- "myPvalueCutOFF"

my_P_FC$col2add <- paste("myFCCutOFF", my_P_FC$myFCCutOFF ,"myPvalueCutOFF", my_P_FC$myPvalueCutOFF, my_P_FC$group, sep="_")

new_jnk <- as.data.frame(matrix(NA, nrow = dim(my_comparisons)[1], ncol = dim(my_P_FC)[1]))
names(new_jnk) <- my_P_FC$col2add

my_comparisons <- as.data.frame(cbind(my_comparisons, new_jnk))
rm(new_jnk)
rm(my_P_FC)
for (i in 1:dim(my_comparisons)[1]) {
  print(i)
  group1 <- my_comparisons$V1[i]
  group2 <- my_comparisons$V2[i]
  
  group1Cols <- grep(group1, names(df_imp))
  group2Cols <- grep(group2, names(df_imp))
  
  df_group <- df_imp[,c(group1Cols, group2Cols)]
  df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
  my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
  
  for (j in myPvalueCutOFF) {
    for (k in myFCCutOFF) {
      # original 
      group1Cols <- grep(group1, names(df_group))
      group2Cols <- grep(group2, names(df_group))
      
      myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
      myPvalue <- myPvalue[,c(6,13)]
      myPvalue$mean.diff <- abs(myPvalue$mean.diff)
      
      myPvalue_dim_original <- dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1]
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Original", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- myPvalue_dim_original
      
      # shuffle 
      shuffled_values <- NULL
      for (groups2compare1 in 1:dim(jnk2)[1]) {
        for (groups2compare2 in 1:dim(jnk3)[1]) {
          mygrouping <- data.frame(mycolname=names(df_group), 
                                   mygroup=c(t(jnk2[groups2compare1,]), t(jnk3[groups2compare2,])))
          
          group1Cols <- grep("1", mygrouping$mygroup)
          group2Cols <- grep("2", mygrouping$mygroup)
          
          myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
          myPvalue <- myPvalue[,c(6,13)]
          myPvalue$mean.diff <- abs(myPvalue$mean.diff)
          shuffled_values <- c(shuffled_values, dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1])
        }
      }
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Shuffle_FDR", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- round(100*mean(shuffled_values)/(1+myPvalue_dim_original),0)
    }
  }
  saveRDS(my_comparisons, file.path(out_dir, paste0("3_7_", Sys.Date(), "_myComparisons_permuted.rds")))
}
saveRDS(my_comparisons, file.path(out_dir, paste0("3_7_", Sys.Date(), "_myComparisons_permuted.rds")))

