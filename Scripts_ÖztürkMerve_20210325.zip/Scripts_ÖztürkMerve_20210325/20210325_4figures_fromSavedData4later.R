options(stringsAsFactors =FALSE) #
setwd("E:/Merve/PaperFigures/20200329_All_figures_combined_newFormat/Figures_Data_20210325/")
source("myFunctions.R")
source("extra_fun_LFQ.R")
# 1 # load the libraries #######################################################################################
library(stringr)
library(extrafont)
loadfonts(device = "win")
# font_import()
# library(ggVennDiagram)
library(dplyr)
library(scales)
#library(egg)
library(MASS)
library(plotly)
library(tidyr)
library(knitr)
library(plyr)
library(reshape2)
library(ggplot2)
library(RColorBrewer)
library(parallel)
library(pcaMethods)
library(fBasics)
library(stats)
library(pvclust)
library(ggrepel)
library(cluster)
library(factoextra)
library(psych)
library(gridExtra)
library("ape")
library(ggpubr)
library(ggfortify)
library(broom)
library(data.table)
library(WGCNA)
library(e1071)
library(ggsignif)
library(corrplot)
library(GGally)
library(network)
library(sna)
library(igraph)
library(ggnetwork)
library(VennDiagram)
library(quantmod)
library(threejs)
library(crosstalk)
library(htmltools)
library(GOfuncR)
library(corrplot)
library(PerformanceAnalytics)
library(matrixTests)
library(pheatmap)
library("taRifx")
library(VennDiagram)
#############################################################################################
#############################################################################################
if(figure1){
# Figure 1 a is the screen scheme ##########################################################################
# Figure 1b # heatmap of measured proteins ###################################################
  df_mymat <- readRDS("Figure_1_b_heatmap_DATA.rds")
  df_mymat$strain <- gsub("Knockout", "knockout", df_mymat$strain)
  names(df_mymat)[3] <- "log2(intensity)"
  
  p2 <- ggplot(df_mymat, aes(variable, pG)) +
    geom_tile(aes(fill=`log2(intensity)`)) +
    theme_classic() +
    #geom_rect(ymin=0, ymax=Inf, xmin=0, xmax=Inf, fill=NA, color="black") +
    #geom_hline(yintercept = 2922-513, color="darkred") +
    theme(axis.title = element_blank(), 
          axis.text = element_blank(),
          axis.ticks = element_blank(),
          axis.line = element_blank(), 
          legend.key.size = unit(0.3, "cm"),
          strip.text = element_text(size=3, vjust = 0),
          legend.title = element_text(size=3),
          legend.text = element_text(size=3),
          legend.position = "bottom",
          # legend.box = "horizontal",
          legend.background = element_blank(),
          strip.background = element_blank()) +
    facet_grid(. ~ strain, scales ="free_x", space = "free_x") +
    scale_fill_gradient(low="black", high="yellow") 
  
  df_jnk <- df_mymat[df_mymat$strain == "3,308 Knockout strains",c(1,2,3)]
  df_jnk <- dcast(df_jnk, pG ~ variable)
  rownames(df_jnk) <- df_jnk$pG
  df_jnk <- df_jnk[,-1]
  df_jnk[df_jnk==0] <- NA
  
  min(colSums(!is.na(df_jnk)))
  max(colSums(!is.na(df_jnk)))
  mean(colSums(!is.na(df_jnk)))
  median(colSums(!is.na(df_jnk)))
  
  ggsave("Figure_1_b_heatmap.png", p2, dpi = 600, units = "cm", width = 4, height = 5)
}
if(Extendedfigure1){
  # ExtendedFigure 1a-e # labeled sample id comparisons # histograms ###################################
  df_summary_raw2 <- readRDS("ExtFigure_1_ch_histograms_DATA.rds")
  jnk2 <- readRDS("ExtFigure_1_ch_histograms_DATA2.rds")
  
  
  F1a <- ggplot(data=subset(df_summary_raw2, variable == "MS"), aes(value))+
    geom_histogram(color="#000000", fill="#f0f0f0", binwidth=150) +
    guides(color=FALSE) +
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=0.5) +
    geom_rug(sides="b") +
    xlab(jnk2$Label[jnk2$jnk=="MS"])+
    xlim(0,max(subset(df_summary_raw2, variable == "MS")$value))+
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold")) +
    ylab("Count") +
    annotate("text", x=0, y=60, label="n = 469", size=3, hjust=0) 
    
  
  F1b <- ggplot(data=subset(df_summary_raw2, variable == "MS.MS"), aes(value))+
    geom_histogram(color="#000000", fill="#f0f0f0", binwidth=1000) +
    guides(color=FALSE) +
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=0.5) +
    geom_rug(sides="b") +
    xlab(jnk2$Label[jnk2$jnk=="MS.MS"])+
    xlim(0,(max(subset(df_summary_raw2, variable == "MS.MS")$value)+1000))+
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold")) +
    ylab("Count") +
    annotate("text", x=0, y=130, label="n = 469", size=3, hjust=0) 
  
  
  F1c <- ggplot(data=subset(df_summary_raw2, variable == "MS.MS.Identified"), aes(value))+
    geom_histogram(color="#000000", fill="#f0f0f0", binwidth=200) +
    guides(color=FALSE) +
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=0.5) +
    geom_rug(sides="b") +
    #xlab(jnk2$Label[jnk2$jnk=="MS.MS.Identified"])+
    xlim(0,(max(subset(df_summary_raw2, variable == "MS.MS.Identified")$value)+1000))+
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold")) +
    ylab("Count")+
    xlab("MS/MS identified") +
    annotate("text", x=0, y=35, label="n = 469", size=3, hjust=0) 
  
  
  
  
  F1d <- ggplot(data=subset(df_summary_raw2, variable == "Peptide.Sequences.Identified"), aes(value))+
    geom_histogram(color="#000000", fill="#f0f0f0", binwidth=200) +
    guides(color=FALSE) +
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=0.5) +
    geom_rug(sides="b") +
    #xlab(jnk2$Label[jnk2$jnk=="Peptide.Sequences.Identified"])+
    xlim(0,(max(subset(df_summary_raw2, variable == "Peptide.Sequences.Identified")$value)+1000))+
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold")) +
    ylab("Count") +
    xlab("Peptide sequences identified") +
    annotate("text", x=0, y=60, label="n = 469", size=3, hjust=0) 
  
  
  F1e <- ggplot(data=subset(df_summary_raw2, variable == "pG"), aes(value))+
    geom_histogram(color="#000000", fill="#f0f0f0", bins=50) +
    guides(color=FALSE) +
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=0.5) +
    geom_rug(sides="b") +
    xlab(jnk2$Label[jnk2$jnk=="pG"])+
    xlim(0,(max(subset(df_summary_raw2, variable == "pG")$value)+100))+
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold")) +
    ylab("Count") +
    xlab("Protein groups identified")+
    annotate("text", x=0, y=60, label="n = 469", size=3, hjust=0)
  
  pG <- subset(df_summary_raw2, variable == "pG")  
  
  # ExtendedFigure 1f # under-over-labeling #######################################
  jnk1 <- readRDS("ExtFigure_1_i_underlabeling_DATA.rds")
  jnk1$underlabeled <- 100- jnk1$pFreq
  jnk1 <- as.data.frame(jnk1[,c(1,6)])
  names(jnk1)[2] <- "pFreq"
  jnk1$Label <- "Under-labeled"
  
  jnk2 <- readRDS("ExtFigure_1_i_overlabeling_DATA.rds")
  jnk2 <- as.data.frame(jnk2[,c(1,5)])
  jnk2$Label <- "Over-labeled"
  
  jnk <- as.data.frame(rbind(jnk1, jnk2))
  jnk <- remove.factors(jnk)
  rm(jnk1)
  rm(jnk2)
  
  jnk$Label <- factor(jnk$Label,
                      levels = unique(jnk$Label[order(jnk$Label, decreasing = T)]))
  
  F1f <- ggplot(jnk, aes(pFreq))+
    geom_density(aes(fill=Label, color=Label, y=..scaled..)) +
    guides(color=FALSE) +
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=0.05) +
    geom_rug(sides="b") +
    xlab("Percentage of evidences")+
    xlim(0,10)+
    ylim(0,1.05)+
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.5,0.98),
          legend.background = element_blank(),
          legend.key.height = unit(0.06, "cm"),
          legend.key.width = unit(0.15, "cm"),
          legend.text = element_text(size=7)) +
    scale_color_manual(values = c("#2166ac", "#b2182b")) +
    scale_fill_manual(values = c("#2166ac", "#b2182b"), 
                        guide = guide_legend(direction = "horizontal", byrow = TRUE,
                                             title = NULL,
                                             label.position = "right")) +
    ylab("Scaled") +
    annotate("text", x=10, y=1, label="n = 469", size=3, hjust=1) 
  
    
  # ExtendedFigure 1g # correlation and intensity with nTimesIdentified of pG ##################
  jnk <- readRDS("ExtFigure_1_j_corelation_DATA.rds")
  
  myR <- round(cor(jnk$ProteinCount, jnk$MeasuredIntensity, method = "spearman"),2)
  
  jnk$color[jnk$color==TRUE] <- "measured in all samples (n = 513)"
  jnk$color[jnk$color==FALSE] <- "measured in subset (n = 2408)"
  
  F1g <- ggplot(jnk, aes(ProteinCount, MeasuredIntensity))+
    geom_point(data=subset(jnk, color == "measured in subset (n = 2408)"), aes(color=color)) +
    geom_point(data=subset(jnk, color == "measured in all samples (n = 513)"), aes(color=color)) +
    theme_classic()+
    xlab("Number of strains identified")+
    ylab("Average measured intensity") +
    xlim(0,(max(jnk$ProteinCount)+10))+
    ylim(10,(max(jnk$MeasuredIntensity)+1))+
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.57,.86),
          legend.background = element_blank(),
          legend.key.size = unit(0.2, "cm"),
          legend.text = element_text(size=7),
          legend.title = element_blank()) +
    # geom_smooth(aes(ProteinCount, MeasuredIntensity), method='lm', color="#67001f", size=1.2) +
    annotate("text", x=350, y=22, label=paste0("rho = ", myR), fontface =2, size=3) +
    scale_color_manual(values=c("#2166ac", "#878787")) +
    guides(guide = guide_legend(direction = "vertical", byrow = TRUE,
                                title = NULL,
                                label.position = "right"))
 
  

  # ExtendedFigure 1h # Normalization - correlation pairs - before normalization ######################################
  df_cor_melt <- readRDS("ExtFigure_1_l_notNorm_corPairs_DATA.rds")
  df_cor_melt$Category[df_cor_melt$Category == "SamePlate"] <- "Same Plate"
  df_cor_melt$Category[df_cor_melt$Category == "SameRun"] <- "Same Run"
  
  jnk <- as.data.frame(table(df_cor_melt$Category))
  
  F1h <- ggplot(df_cor_melt, aes(Category, Pearson_R))+
    geom_violin(aes(fill=Category)) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic()+
    xlab("Groups of pairs")+
    ylab("Pearson R")+
    theme(axis.text=element_text(size=6,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    scale_y_continuous(breaks=c(.4,.6,.8,1), limits=c(0.3,1))+
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=0.36, size=2) +
    scale_fill_manual(values=c("#1a9850", "#2166ac", "#b2182b")) +
    guides(fill=FALSE)

  # ExtendedFigure 1j # Normalization - correlation pairs - after normalization ######################################
  df_cor_melt <- readRDS("ExtFigure_1_m_Norm_corPairs_DATA.rds")
  df_cor_melt$Category[df_cor_melt$Category == "SamePlate"] <- "Same Plate"
  df_cor_melt$Category[df_cor_melt$Category == "SameRun"] <- "Same Run"
  
  jnk <- as.data.frame(table(df_cor_melt$Category))
  
  F1j <- ggplot(df_cor_melt, aes(Category, Pearson_R))+
    geom_violin(aes(fill=Category)) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic()+
    xlab("Groups of pairs")+
    ylab("Pearson R")+
    theme(axis.text=element_text(size=6,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    scale_y_continuous(breaks=c(.4,.6,.8,1), limits=c(0.3,1))+
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=0.36, size=2) +
    scale_fill_manual(values=c("#1a9850", "#2166ac", "#b2182b")) +
    guides(fill=FALSE)

  # ExtendedFigure 1i # normalization methods summary plot ######################################
  mydf <- readRDS("ExtFigure_1_n_BIASplot_DATA.rds")
  mydf$lastMethod2 <- mydf$lastMethod
  mydf$lastMethod2 <- gsub("bapred", "", mydf$lastMethod2)
  
  mydf$lastMethod2 <- gsub("wtTech", "WT\ntechnical", mydf$lastMethod2)
  mydf$lastMethod2 <- gsub("svaCombatParametric", "Combat(P)", mydf$lastMethod2)
  mydf$lastMethod2 <- gsub("svaCombatNonParametric", "Combat(NP)", mydf$lastMethod2)

  mydf$lastMethod2 <- gsub("NotNormalized", "Original", mydf$lastMethod2)
  mydf$lastMethod2 <- gsub("medProt", "Adj.median", mydf$lastMethod2)
  
  mydf$LabelSize <- 3
  mydf$LabelSize[mydf$Color == "ALL"] <- 2
  
  mydf$LabelColor <- "gray"
  mydf$LabelColor[mydf$lastMethod2 == "Original"] <- "black"
  mydf$LabelColor[mydf$lastMethod2 == "Adj.median"] <- "red"
  

  F1i <- ggplot(mydf, aes(BiasCoeff_ordered, Median_Cor2OriginalData_Pearson)) +
    theme_classic() +
    geom_segment(aes(x=mydf$BiasCoeff_ordered[mydf$lastMethod == "NotNormalized"], y=-.5 , xend=mydf$BiasCoeff_ordered[mydf$lastMethod == "NotNormalized"], yend=1), 
                 color="#bababa", linetype= "dashed") +
    geom_segment(aes(x=mydf$BiasCoeff_ordered[mydf$lastMethod == "medProt"], y=-.5 , xend=mydf$BiasCoeff_ordered[mydf$lastMethod == "medProt"], yend=1), 
                 color="#bababa", linetype= "dashed") +
    geom_hline(yintercept = 1, color="#bababa", linetype= "dashed") +
    geom_point(data=subset(mydf, Color == "Normalized"), color="red", size=3, shape=15) +
    geom_point(data=subset(mydf, package == "NotNormalized"), color="#1a1a1a", size=3, shape=15) +
    geom_point(data=subset(mydf, Color=="ALL" & package != "NotNormalized"), color= "gray50",size=1.8, alpha=.8) +
    xlab("Bias coefficient") +
    ylab("Median(R to original data)") +
    scale_y_continuous(breaks = c(-.5,0,0.5,1), labels = c(-.5,0,0.5,1), limits = c(-.5,1.2))+
    xlim(-0.04, 0.6) +
    # scale_color_manual(values=c("dimgray", "dimgray", "#b2182b", "black", "#b2182b")) +
    # scale_shape_manual(values=c(18, 17, 15, 15, 17)) +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.88,0.8),
          legend.key.size = unit(0.05, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_blank()) +
    geom_text_repel(aes(label=lastMethod2, size=as.factor(LabelSize), color=LabelColor), min.segment.length = 0, segment.size = .2,
                    force = 50, max.iter = 10000) +
    guides(color=FALSE, size=FALSE) +
    scale_color_manual(values=c("black", "gray30","red")) +
    scale_size_manual(values = c(2,3))

  # ExtendedFigure 1 # put together ################################################
  p <- ggplot() +
    theme_blank()
  F1 <- ggarrange(ggarrange(F1a, F1b, F1c, nrow = 1, ncol = 3, labels = c("a", "b", "c")),
                  ggarrange(F1d, F1e, F1f, nrow = 1, ncol = 3, labels = c("d", "e", "f")), 
                  ggarrange(p, F1g, nrow = 1, ncol = 2, labels = c("g", ""), widths = c(.04,1)),
                  ggarrange(F1h, F1i, F1j, nrow = 1, ncol = 3, labels = c("h", "i", "j"), widths = c(1,1.2,1)),
                  nrow = 4)
  
  F1ann <- annotate_figure(F1, bottom = text_grob("�zt�rk et al, Extended Figure 1    ", hjust=1, x=1, size=10))
  
  ggsave("ExtendedFigure_1.pdf", F1ann, dpi = 300, units = "cm", width = 18.3, height = 20)
  #######################################################################################
}

if(figure2){
  # Figure 2 # The most different strains # became simpler now ####################################################
  # Figure 2 a # Number of proteins changing old EF2b #############################################################
  df_melt <- readRDS("ExtFigure_2_bc_koNtarget_DATA.rds")
  
  x <- ecdf(df_melt$Regulated_pFDR_05)
  df_melt$Regulated_pFDR_05_ecdf_func <- x(df_melt$Regulated_pFDR_05)
  
  # "#b2182b"
  
  F2a <- ggplot(df_melt, aes(Regulated_pFDR_05))+
    geom_histogram(color="black", bins = 100)+
    geom_point(aes(Regulated_pFDR_05, 800*Regulated_pFDR_05_ecdf_func), color="#cb181d", size=0.9) +
    scale_y_continuous(sec.axis = sec_axis(~./800, name = "Cumulative fraction", breaks = c(0,.25, .5,.75,1))) +
    theme_classic() +
    xlab("Number of altered proteins")+
    ylab(paste("Number of", "\n" , "knockout strains")) +
    theme(axis.text=element_text(size=6),
          axis.title.x=element_text(size=8,face="bold"),
          axis.title.y.left=element_text(size=8,face="bold"),
          axis.title.y.right = element_text(size=8,face="bold", color="#b2182b"), 
          axis.line.y.right = element_line(color="#b2182b"),
          axis.ticks.y.right = element_line(color="#b2182b"),
          axis.text.y.right = element_text(color="#b2182b", size=6))
  
  
  # Figure 2 b # Pie chart Number of proteins changing old EF2b #############################################################
  df_melt <- readRDS("ExtFigure_2_bc_koNtarget_DATA.rds")
  quantile(df_melt$Regulated_pFDR_05)
  mycutoffs <- c("0", "1-5", "6-15", "16-50", "51-150", ">150")
  myvalues <- c(sum(df_melt$Regulated_pFDR_05==0),
                sum(df_melt$Regulated_pFDR_05<=5) - sum(df_melt$Regulated_pFDR_05<=0),
                sum(df_melt$Regulated_pFDR_05<=15) - sum(df_melt$Regulated_pFDR_05<=5),
                sum(df_melt$Regulated_pFDR_05<=50) - sum(df_melt$Regulated_pFDR_05<=15),
                sum(df_melt$Regulated_pFDR_05<=150) - sum(df_melt$Regulated_pFDR_05<=50),
                sum(df_melt$Regulated_pFDR_05 > 150))
  
  
  
  
  df <- as.data.frame(cbind(mycutoffs, myvalues))
  df$myvalues <- as.numeric(df$myvalues)
  df$Percent <- round(100*df$myvalues / sum(df$myvalues),1)
  
  df$mycutoffs <- factor(df$mycutoffs, levels = c("0", "1-5", "6-15", "16-50", "51-150", ">150"))
  
  
  blank_theme <- theme_minimal() +
    theme(axis.title.x = element_blank(),
          axis.text.x = element_blank(),
          axis.text.y = element_blank(),
          axis.title.y = element_blank(),
          panel.border = element_blank(),
          panel.grid =  element_blank(),
          axis.ticks =  element_blank())
  
  bp <- ggplot(df, aes(x="",y=myvalues, fill=mycutoffs)) +
    geom_bar(width = 1, stat = "identity") +
#    scale_fill_brewer(palette = "Greys", guide_legend(title = "# Altered proteins")) +
    scale_fill_brewer(palette = "Paired", guide_legend(title = "Number of altered proteins", reverse = FALSE)) +
    blank_theme
  
  
  F2b <- bp+coord_polar("y", start = 0, direction = -1) +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          #legend.position = c(1.15,.7),
          legend.position = "right",
          legend.background = element_blank(),
          legend.box = "horizontal",
          legend.direction = "vertical",
          legend.key.size = unit(0.2, "cm"),
          legend.text = element_text(size=7),
          legend.title = element_text(size=7, face = "bold")) +
    geom_label_repel(aes(y=c(3300,3308-400,3308-1350,3300-2000,3308-2700,50), label=myvalues), fill="white", size=2, vjust=1, min.segment.length = 0.4) 
  
  
  
  # Figure 2 c # new # Number of proteins changing mRNA, rRNA, tRNA processing ######################################################
  gsea_nprot <- readRDS("ExtFigure2_fgsea_rank_ALL_min20.rds")
  jnk <- gsea_nprot[grep("protein", gsea_nprot$pathway),]
  
  
  df_melt <- readRDS("ExtFigure_2_bc_koNtarget_DATA.rds")
  
  pombeBioMartGO <- read.delim("mart_export_Spombe_GO.txt")
  pombeBioMartGO <- subset(pombeBioMartGO, GO.term.accession != "")
  pombeBioMartGO <- pombeBioMartGO[pombeBioMartGO$Gene.stable.ID %in% df_melt$SytemicID,]
  
  myphospho <- pombeBioMartGO[pombeBioMartGO$GO.term.name == "protein phosphorylation",]
  myglyco <- pombeBioMartGO[pombeBioMartGO$GO.term.name == "protein glycosylation",]
  myBP <- pombeBioMartGO[pombeBioMartGO$GO.term.name == "transporter activity",]
  mymRNA <- pombeBioMartGO[pombeBioMartGO$GO.term.name == "mRNA binding",]
  
  df_new <- df_melt[df_melt$SytemicID %in% c(myphospho$Gene.stable.ID, myglyco$Gene.stable.ID, myBP$Gene.stable.ID, mymRNA$Gene.stable.ID),]
  
  df_new$phospho <- 0
  df_new$phospho[df_new$SytemicID %in% myphospho$Gene.stable.ID] <- 1
  
  df_new$glyco <- 0
  df_new$glyco[df_new$SytemicID %in% myglyco$Gene.stable.ID] <- 1
  
  df_new$BP <- 0
  df_new$BP[df_new$SytemicID %in% myBP$Gene.stable.ID] <- 1
  
  df_new$mRNA <- 0
  df_new$mRNA[df_new$SytemicID %in% mymRNA$Gene.stable.ID] <- 1
  
  jnk <- as.data.frame(table(df_new[,c(32,33,34,35)]))
  
  df_new2 <- as.data.frame(df_new[,c(2,6,16,32:35)])
  df_new2 <- melt(df_new2, id=c("SytemicID", "Regulated_pFDR_05", "Score_pFDR_05"))
  
  df_new2 <- df_new2[df_new2$value != 0,]
  df_new3 <- df_melt[,c(2,6,16)]
  df_new3$variable <- "All (n=3,308)"
  df_new3$value <- 1
  
  df_new2 <- as.data.frame(remove.factors(rbind(df_new2, df_new3)))
  
  df_new2$ecdf_RNA_all <- NA
  
  x <- ecdf(df_new2$Regulated_pFDR_05[df_new2$variable == "phospho"])
  df_new2$ecdf_RNA_all[df_new2$variable == "phospho"] <- x(df_new2$Regulated_pFDR_05[df_new2$variable == "phospho"])
  
  y <- ecdf(df_new2$Regulated_pFDR_05[df_new2$variable == "glyco"])
  df_new2$ecdf_RNA_all[df_new2$variable == "glyco"] <- y(df_new2$Regulated_pFDR_05[df_new2$variable == "glyco"])
  
  z <- ecdf(df_new2$Regulated_pFDR_05[df_new2$variable == "BP"])
  df_new2$ecdf_RNA_all[df_new2$variable == "BP"] <- z(df_new2$Regulated_pFDR_05[df_new2$variable == "BP"])
  
  z2 <- ecdf(df_new2$Regulated_pFDR_05[df_new2$variable == "All (n=3,308)"])
  df_new2$ecdf_RNA_all[df_new2$variable == "All (n=3,308)"] <- z2(df_new2$Regulated_pFDR_05[df_new2$variable == "All (n=3,308)"])
  
  z3 <- ecdf(df_new2$Regulated_pFDR_05[df_new2$variable == "mRNA"])
  df_new2$ecdf_RNA_all[df_new2$variable == "mRNA"] <- z3(df_new2$Regulated_pFDR_05[df_new2$variable == "mRNA"])
  
  
  df_new2 <- remove.factors(df_new2)
  df_new2$variable[df_new2$variable == "phospho"] <- "protein phosphorylation (n=90)"
  df_new2$variable[df_new2$variable == "glyco"] <- "protein glycosylation (n=21)"
  df_new2$variable[df_new2$variable == "BP"] <- "transporter activity (n=21)"
  df_new2$variable[df_new2$variable == "mRNA"] <- "mRNA binding (n=29)"
  
  
  df_new2$variable <- factor(df_new2$variable, levels = c("transporter activity (n=21)", "protein phosphorylation (n=90)", 
                                                          "All (n=3,308)", "protein glycosylation (n=21)", "mRNA binding (n=29)"))
  
  F2c <- ggplot(df_new2, aes(Regulated_pFDR_05, ecdf_RNA_all))+
    geom_point(aes(color=variable), alpha=.6, size=1.3) +
    geom_line(aes(color=variable), size=1.1) +
    theme_classic() +
    xlab("Number of altered proteins")+
    ylab("Cumulative fraction") +
    scale_y_continuous(breaks = c(0,.5,1), labels = c(0,.5,1)) +
    scale_x_continuous(breaks = c(0,100,200,300), limits = c(-1,300)) +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.65,0.3),
          legend.background = element_blank(),
          legend.direction = "vertical",
          legend.key.height = unit(0.2, "cm"),
          legend.key.width = unit(0.3, "cm"),
          legend.text = element_text(size=7),
          legend.spacing.y = unit(0.01, "cm"),
          legend.spacing.x = unit(0.05, "cm"),
          legend.title = element_blank()) +
#    scale_color_manual(values = c("black", "dimgray", "gray60"))
    scale_color_brewer(palette = "Set2")
  # Figure 2 d # Violin plots for growth top 100, 200, 300, 400,500,600 # from initial culture ############################
  df_melt <- readRDS("ExtFigure_2_bc_koNtarget_DATA.rds")
  
  df_melt$new <- 33
  df_melt$Xlabel <- ">3200"
  for (i in 32:1) {
    df_melt$new[df_melt$Score_pFDR_05 <= i*100] <- i
    df_melt$Xlabel[df_melt$Score_pFDR_05 <= i*100] <- paste(((i-1)*100)+1, "-", i*100, sep="")
  }
  
  df_melt <- df_melt %>%
    group_by(new) %>%
    dplyr::mutate(minpG = min(Regulated_pFDR_05),
                  maxpG = max(Regulated_pFDR_05),
                  meanZscore_fc = mean(Zscore_fc)) %>%
    as.data.frame()
  
  df_melt <- df_melt[df_melt$new <= 10,]
  df_melt$Xlabel <- factor(df_melt$Xlabel,
                           levels = unique(df_melt$Xlabel[order(df_melt$new, decreasing = F)]))
  
  df_melt2 <- as.data.frame(unique(remove.factors(df_melt[,c(32:36)])))
  df_melt2$pGLabel <- paste(df_melt2$minpG, "-", df_melt2$maxpG, sep="")
  
  F2d <- ggplot(df_melt, aes(Xlabel, Zscore_ic)) +
    geom_hline(yintercept = 0, color="#878787") +
    geom_boxplot(width=.8,outlier.shape = NA, aes(fill=Xlabel)) +
    theme_classic()+
    xlab("Knockout strains binned by number of altered proteins") +
    ylab("Z-score(Growth)  ") +
    scale_y_continuous(breaks = c(-6,-4,-2,0,2), labels=c(-6,-4,-2,0,2), limits = c(-7,2.1)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=7,face="bold", angle = 90, vjust=0.5),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=df_melt2, aes(x= Xlabel, label=pGLabel), y=-7, size=2, hjust=0.5, vjust=0, color="#a50026") +
    guides(fill=FALSE) +
    scale_fill_manual(values = c("#084081", "#0868ac", "#2b8cbe", "#4eb3d3", "#7bccc4", "#a8ddb5", "#ccebc5", "#e0f3db", "#f7fcf0", "white"))
  
  
  
  
  # Figure 2 e # GSEA # ranked by #proteins regulated based on wt ############################
  gsea_nprot <- readRDS("ExtFigure2_fgsea_rank_ALL_min20.rds")
  gsea_nprot <- gsea_nprot[gsea_nprot$NES>0 & gsea_nprot$pval <= 0.05,]
  gsea_nprot$GO.term.name <- gsub("(GO\\:[0-9]+)\\_\\.\\_(.*)", "\\2", gsea_nprot$pathway)
  gsea_nprot$GO.term.name <- gsub("_", " ", gsea_nprot$GO.term.name)
  
  pombeBioMartGO <- read.delim("E:/Merve/mart_export_Spombe_GO.txt")
  pombeBioMartGO <- subset(pombeBioMartGO, GO.term.accession != "")
  pombeBioMartGO <- as.data.frame(unique(pombeBioMartGO[,c(3,5)]))
  
  gsea_nprot <- merge(gsea_nprot, pombeBioMartGO, by.x="GO.term.name", by.y="GO.term.name", all=F)
  
  GOselectterms <- c("chromatin organization", "mRNA binding", "nucleic acid binding",
                     "protein N-linked glycosylation", "ribosome", 
                     "transcription, DNA-templated", "translation")
  
  gsea_nprot <- gsea_nprot[gsea_nprot$GO.term.name %in% GOselectterms]
  mybreaks <- c(0,1)
  gsea_nprot$FDRcheck <- formatC(gsea_nprot$pval, format = "e", digits = 1)
  gsea_nprot$addLabel <- ""
  gsea_nprot$addLabel[gsea_nprot$padj <=0.05] <- "*"
  
  
  #gsea_nprot$GO.term.name[31] <- "*RNA polymerase II proximal promoter sequence-specific DNA binding"
  # gsea_nprot$GO.term.name <- factor(gsea_nprot$GO.term.name, 
  #                                 levels = gsea_nprot$GO.term.name[order(gsea_nprot$GO.domain, gsea_nprot$NES, decreasing = F)])
  
  
  gsea_nprot$GO.term.name <- factor(gsea_nprot$GO.term.name, 
                                    levels = c("protein N-linked glycosylation",
                                               "ribosome", 
                                               "translation",
                                               "mRNA binding",
                                               "nucleic acid binding",
                                               "transcription, DNA-templated",
                                               "chromatin organization"))
  
  gsea_nprot$GO.term.name <- factor(gsea_nprot$GO.term.name,
                           levels = unique(gsea_nprot$GO.term.name[order(gsea_nprot$NES, decreasing = F)]))
  
  F2e <- ggplot(gsea_nprot, aes(GO.term.name, as.numeric(NES))) +
    geom_hline(yintercept = mybreaks, alpha=0.6) +
    geom_bar(stat = "identity", width=0.7, size=1.2, aes(fill=GO.domain))+
    geom_text(aes(x= GO.term.name, label=FDRcheck), y=1.55, size=2, hjust=0)+
    # geom_text(aes(x= GO.term.name, label=addLabel), y=1.52, size=4, hjust=0)+
    coord_flip() +
    theme_classic()+
    theme(legend.position="bottom") +
    xlab(NULL) +
    ylab("Normalized enrichment score") +
    scale_y_continuous(breaks=mybreaks, limits = c(0,1.65)) +
    theme(axis.text = element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          title = element_text(size=8), 
#          legend.position = c(.9,.97),
          legend.position = "right",
          legend.background = element_blank(),
          legend.key.height = unit(0.2, "cm"),
          legend.key.width = unit(0.2, "cm"),
          legend.text = element_text(size=6),
          legend.spacing.y = unit(0.1, "cm"),
          legend.spacing.x = unit(0.05, "cm"),
          legend.title = element_blank())
  
  # put it together ###############################################################
  F2 <- ggarrange(ggarrange(F2a, F2b, nrow = 1, ncol = 2, labels = c("a", "b"), widths = c(1.6,1), vjust = .95),
                  ggarrange(F2c, F2d, nrow = 1, ncol = 2, labels = c("c", "d"), widths = c(1.1,2), vjust = .8),
                  ggarrange(F2e, nrow = 1, ncol = 1, labels = c("e"), vjust = .9),
                  nrow = 3, heights = c(1.6,1.6,1)) 
  
  F2ann <- annotate_figure(F2, bottom = text_grob("�zt�rk et al, Figure 2   ", hjust=1, x=1, size=10))
  
  
  ggsave("Figure_2.pdf", F2ann, dpi = 300, units = "cm", width = 18, height = 12)
  
}
if(Extendedfigure2){
  # Figure 2 # The most different strains # became simpler now ####################################################
  # Figure 2 f # Violin plots for growth top 100, 200, 300, 400 # from initial culture ############################
  df_melt <- readRDS("ExtFigure_2_bc_koNtarget_DATA.rds")
  
  df_melt$new <- 33
  df_melt$Xlabel <- ">3200"
  for (i in 32:1) {
    df_melt$new[df_melt$Score_pFDR_05 <= i*100] <- i
    df_melt$Xlabel[df_melt$Score_pFDR_05 <= i*100] <- paste(((i-1)*100)+1, "-", i*100, sep="")
  }
  
  df_melt <- df_melt %>%
    group_by(new) %>%
    dplyr::mutate(minpG = min(Regulated_pFDR_05),
                  maxpG = max(Regulated_pFDR_05),
                  meanZscore_fc = mean(Zscore_fc)) %>%
    as.data.frame()
  
  
  df_melt$Xlabel <- factor(df_melt$Xlabel,
                           levels = unique(df_melt$Xlabel[order(df_melt$new, decreasing = F)]))
  
  df_melt2 <- as.data.frame(unique(remove.factors(df_melt[,c(32:36)])))
  df_melt2$pGLabel <- paste(df_melt2$minpG, "-", df_melt2$maxpG, sep="")
  
  F2f <- ggplot(df_melt, aes(Xlabel, Zscore_ic)) +
    geom_hline(yintercept = 0, color="#878787") +
    #geom_violin(aes(fill=new), width=1) +
    geom_boxplot(width=.8,outlier.shape = NA) +
    #geom_point(data=df_melt2, aes(Xlabel, y=meanZscore_fc), color= "#b2182b", size=2) + #######red 
    stat_compare_means(label.x = 2, label.y=2, size = 2) +
    theme_classic()+
    xlab("Knockout strains binned by number of altered proteins") +
    ylab("Z-score (Growth)") +
    scale_y_continuous(breaks = c(-6,-4,-2,0,2), labels=c(-6,-4,-2,0,2), limits = c(-8,2.1)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=7,face="bold", angle = 90),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=df_melt2, aes(x= Xlabel, label=pGLabel), y=-8, size=2, angle=90, hjust=0, color="#a50026") +
    guides(fill=FALSE) 
  
  # Figure 2 d # Gene ontology of essential genes #############################################################
  pombeBioMartGO <- read.delim("mart_export_Spombe_GO.txt")
  pombeBioMartGO <- subset(pombeBioMartGO, GO.term.accession != "")
  pombeBioMartGO <- as.data.frame(unique(pombeBioMartGO[,1:5]))
  
  pombefypo <- read.delim("FYPOviability.tsv", header = F)
  mygenelist <- pombefypo$V1[pombefypo$V2 == "inviable"]
  
  
  myGOanalysisFUNCTION <- function(pombeBioMartGO, mygenelist){
    
    pombeBioMartGO_summary <- as.data.frame(unique(pombeBioMartGO[,2:5]))
    
    myGOterms <- unique(pombeBioMartGO$GO.term.accession)
    myBGgenes <- unique(pombeBioMartGO$Gene.stable.ID)
    
    pombeBioMartGO_mygenes <- pombeBioMartGO[pombeBioMartGO$Gene.stable.ID %in% mygenelist,]
    
    myContingencyTable <- as.data.frame(table(pombeBioMartGO$GO.term.accession))
    names(myContingencyTable) <- c("Term", "BGcount")
    myContingencyTable$BGcount_NOT <- length(myBGgenes) - myContingencyTable$BGcount
    
    
    myContingencyTable_jnk <- as.data.frame(table(pombeBioMartGO_mygenes$GO.term.accession))
    names(myContingencyTable_jnk) <- c("Term", "ENRcount")
    myContingencyTable_jnk$ENRcount_NOT <- length(mygenelist) - myContingencyTable_jnk$ENRcount
    
    
    myContingencyTable <- merge(myContingencyTable, myContingencyTable_jnk, by=1, all.x=TRUE)
    myContingencyTable[is.na(myContingencyTable)] <- 0
    
    myContingencyTable$Expected <- length(mygenelist) * (myContingencyTable$BGcount/ length(myBGgenes))
    myContingencyTable$FoldEnrichment <- myContingencyTable$ENRcount / myContingencyTable$Expected
    
    myContingencyTable$pValue <- NA
    myContingencyTable <- remove.factors(myContingencyTable)
    
    for (i in 1:dim(myContingencyTable)[1]) {
      jnk <- as.data.frame(rbind(c(myContingencyTable[i,2], myContingencyTable[i,4]),
                                 c(myContingencyTable[i,3], myContingencyTable[i,5])))
      
      myContingencyTable$pValue[i] <- fisher.test(jnk)$p.value
    }
    
    myContingencyTable$FDR <- p.adjust(myContingencyTable$pValue, "fdr", n=length(myContingencyTable$pValue))
    
    myContingencyTable <- merge(myContingencyTable, pombeBioMartGO_summary, by.x="Term", by.y="GO.term.accession")
    myContingencyTable$log2_FoldEnrichment <- log2(myContingencyTable$FoldEnrichment)
    return(myContingencyTable)
  }
  
  essentialGO <- myGOanalysisFUNCTION(pombeBioMartGO, mygenelist)
  
  essentialGO_significant <- essentialGO[essentialGO$log2_FoldEnrichment>0 & essentialGO$FDR <= 0.05,]
  
  
  mybreaks <- c(0,1,2,3,4)
  essentialGO_significant$FDRcheck <- formatC(essentialGO_significant$FDR, format = "e", digits = 1)
  
  essentialGO_significant$GO.term.name <- gsub("\\(SSU\\-rRNA\\, 5.8S rRNA\\, LSU\\-rRNA\\)", "*", essentialGO_significant$GO.term.name)
  essentialGO_significant$GO.term.name <- factor(essentialGO_significant$GO.term.name, 
                                                 levels = essentialGO_significant$GO.term.name[order(essentialGO_significant$GO.domain, essentialGO_significant$log2_FoldEnrichment, decreasing = F)])
  
  F2d <- ggplot(essentialGO_significant, aes(GO.term.name, as.numeric(FoldEnrichment))) +
    geom_hline(yintercept = mybreaks, alpha=0.6) +
    geom_bar(stat = "identity", width=0.7, size=1.2, aes(fill=GO.domain))+
    geom_text(aes(x= GO.term.name, label=FDRcheck), y=4.5, size=2)+
    coord_flip() +
    theme_classic()+
    theme(legend.position="bottom") +
    xlab(NULL) +
    ylab("Fold enrichment") +
    scale_y_continuous(breaks=mybreaks, limits = c(0,6)) +
    theme(axis.text = element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          title = element_text(size=8), 
          legend.position = c(.9,.97),
          legend.background = element_blank(),
          legend.key.height = unit(0.2, "cm"),
          legend.key.width = unit(0.2, "cm"),
          legend.text = element_text(size=6),
          legend.spacing.y = unit(0.01, "cm"),
          legend.spacing.x = unit(0.05, "cm"),
          legend.title = element_blank())
  
  # put it together ###############################################################
  F2 <- ggarrange(F2f, F2d, nrow = 2, ncol = 1, labels = c("a", "b"), heights = c(1.7,3)) 
  
  F2ann <- annotate_figure(F2, bottom = text_grob("�zt�rk et al, Extended Figure 2   ", hjust=1, x=1, size=10))
  
  ggsave("ExtendedFigure_2.pdf", F2ann, dpi = 300, units = "cm", width = 18, height = 20)
  
}

if(figure3){
  # Figure 3 # protein clusters 144 ... ####################################################
  # Figure 3 a # pca for all 1444 protein groups clustered #################################
  # clusters to color 141, 136, 110, 142
  jnk <- readRDS("Figure_3_a_PCA_DATA.rds")
  
  get_density <- function(x, y, ...) {
    dens <- MASS::kde2d(x, y, ...)
    ix <- findInterval(x, dens$x)
    iy <- findInterval(y, dens$y)
    ii <- cbind(ix, iy)
    return(dens$z[ii])
  }
  
  jnk$density <- get_density(jnk$PC1, jnk$PC2, n = 80)
  # jnk <- jnk[jnk$Keep == "Keep", ]
  names(jnk)[6] <- "Cluster"
  
  F3a <- ggplot(data=subset(jnk, Cluster == 0), aes(PC1, PC2))+
    geom_point(color="#878787", alpha=.3) +
    geom_point(data=subset(jnk, Cluster != 0), aes(color=Cluster)) +
    theme_classic() +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.125,0.2),
          legend.background = element_blank(),
          legend.key.size = unit(0.3, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_text(size=7)) +
    guides(shape=FALSE) +
    scale_color_brewer(type = "div", palette = "RdBu") +
    # scale_color_manual(values = c("#ca0020", "#0571b2", "#fdae61", "#5aae61")) +
    # scale_shape_manual(values = c(17,16)) +
    annotate("text", x=40, y= 40, label="n = 1,444", size=3)
  rm(jnk)
  # Figure 3 b # tiny networks of the colored clusters #################################
  df_string <- readRDS("Figure_3_b_stringNet_DATA.rds")
  jnk <- readRDS("Figure_3_b_stringNet_DATA2.rds")
  pombe_gn <- read.delim("20200701_Spombe_genename.txt")
  sum(pombe_gn$Gene.name == "")
  
  pombe_gn$Order <- 0
  pombe_gn$Order[pombe_gn$Gene.name == ""] <- 1
  pombe_gn$Gene.name[pombe_gn$Gene.name == ""] <- pombe_gn$Gene.stable.ID[pombe_gn$Gene.name == ""]
  
  
  df_R <- readRDS("20201111_Spombe_ProteinClusters_info.rds")
  df_R <- df_R[df_R$Cluster_number %in% df_string$cluster1,]
  
  df_R <- as.data.frame(unique(df_R[,c(3,2,4)]))
  df_R$MergeID <- paste(df_R$Gene1, df_R$Gene2, sep="_")
  
  df_string$MergeID <- paste(df_string$protein1, df_string$protein2, sep="_")
  
  df_string <- merge(df_string, df_R, by.x="MergeID", by.y="MergeID", all=T)
  # df_string$Score <- "new"
  # df_string$Score[!is.na(df_string$combined_score)] <- "STRINGdb"
  min(df_string$combined_score, na.rm = T)
  df_string$combined_score[is.na(df_string$combined_score)] <- 0
  pombe_gn <- as.data.frame(unique(pombe_gn[,1:2]))
  
  df_string <- merge(df_string, pombe_gn, by.x="Gene1", by.y="Gene.stable.ID", all.x=T)
  names(df_string)[11] <- "GeneName1"
  df_string <- merge(df_string, pombe_gn, by.x="Gene2", by.y="Gene.stable.ID", all.x=T)
  names(df_string)[12] <- "GeneName2"
  
  jnk <- as.data.frame(unique(df_string[,c(11,10)]))
  names(jnk) <- c("pG", "cluster")
  
  # 110
  df_110 <- df_string[df_string$Cluster_number == 110, c(11,12,6)]
  
  nodes <- as.data.frame(unique(jnk$pG[jnk$cluster == 110]))
  nodes$id <- rownames(nodes)
  nodes <- nodes[,2:1]
  names(nodes)[2] <- "label"
  edges <- df_110
  edges <- as.data.frame(edges)
  edges <- remove.factors(edges)
  if(length(setdiff(nodes$label, c(edges$protein1, edges$protein2))) > 0){
    toadd <- setdiff(nodes$label, c(edges$protein1, edges$protein2))
    toadd <- as.data.frame(cbind(toadd, toadd))
    toadd$combined_score <- 10
    names(toadd) <- names(edges)
    edges <- as.data.frame(rbind(edges, toadd))
  }
  names(edges) <- c("source", "destination", "weight")
  my_network <- network(edges, vertex.attr = nodes, 
                        matrix.type = "edgelist", 
                        directed=FALSE, ignore.eval = FALSE, layout="circle")
  
  df110_genes <- unique(c(df_110$GeneName1, df_110$Gene2))
  df110_genes <- pombe_gn[pombe_gn$Gene.name %in% df110_genes,]
 
  p110 <- ggplot(my_network, aes(x = x, y = y, xend = xend, yend = yend)) +
    #    geom_edges(size=.2, color="#ca0020") +
    geom_edges(size=.2, aes(color=weight != 0)) +
    geom_nodes(color="#ca0020") +
    geom_nodetext(aes(label=vertex.names), size=2, hjust = "outward", vjust = "outward", check_overlap = TRUE) +
    #    geom_nodelabel(aes(label=vertex.names), size=2) +
    theme_blank() +
    guides(color=FALSE) +
    ggtitle("Cluster 110") +
    theme(title = element_text(size=7)) +
    scale_color_manual(values = c("#878787", "#ca0020")) +
    annotate("text", x=.5, y= -.21, label="Carbohydrate metabolism", size=2) +
    xlim(-.2,1.2) +
    ylim(-.25,1.1)   
  
  rm(df_110)
  
  # 136
  df_136 <- df_string[df_string$Cluster_number == 136, c(11,12,6)]
  nodes <- as.data.frame(unique(jnk$pG[jnk$cluster == 136]))
  nodes$id <- rownames(nodes)
  nodes <- nodes[,2:1]
  names(nodes)[2] <- "label"
  
  edges <- df_136
  edges <- as.data.frame(edges)
  edges <- remove.factors(edges)
  if(length(setdiff(nodes$label, c(edges$protein1, edges$protein2))) > 0){
    toadd <- setdiff(nodes$label, c(edges$protein1, edges$protein2))
    toadd <- as.data.frame(cbind(toadd, toadd))
    toadd$combined_score <- 10
    names(toadd) <- names(edges)
    edges <- as.data.frame(rbind(edges, toadd))
  }
  names(edges) <- c("source", "destination", "weight")
  my_network <- network(edges, vertex.attr = nodes, 
                        matrix.type = "edgelist", 
                        directed=FALSE, ignore.eval = FALSE, layout="circle")
  
  
  df136_genes <- unique(c(df_136$GeneName1, df_136$GeneName2))
  df136_genes <- pombe_gn[pombe_gn$Gene.name %in% df136_genes,]
  
  
  p136 <- ggplot(my_network, aes(x = x, y = y, xend = xend, yend = yend)) +
    geom_edges(size=.2, aes(color=weight != 0)) +
    geom_nodes(color="#f4a582") +
    geom_nodetext(aes(label=vertex.names), size=2, hjust = "outward", vjust = "outward", check_overlap = TRUE) +
    theme_blank() +
    guides(color=FALSE) +
    ggtitle("Cluster 136") +
    theme(title = element_text(size=7)) +
    annotate("text", x=.5, y= -.31, label="Mitochondrion", size=2) +
    xlim(-.2,1.2) +
    ylim(-.35,1.15) +
    scale_color_manual(values = c("#878787", "#f4a582")) 
  
  rm(df_136)
  
  # 141
  df_141 <- df_string[df_string$Cluster_number == 141, c(11,12,6)]
  nodes <- as.data.frame(unique(jnk$pG[jnk$cluster == 141]))
  nodes$id <- rownames(nodes)
  nodes <- nodes[,2:1]
  names(nodes)[2] <- "label"
  edges <- df_141
  edges <- as.data.frame(edges)
  edges <- remove.factors(edges)
  if(length(setdiff(nodes$label, c(edges$protein1, edges$protein2))) > 0){
    toadd <- setdiff(nodes$label, c(edges$protein1, edges$protein2))
    toadd <- as.data.frame(cbind(toadd, toadd))
    toadd$combined_score <- 10
    names(toadd) <- names(edges)
    edges <- as.data.frame(rbind(edges, toadd))
  }
  names(edges) <- c("source", "destination", "weight")
  my_network <- network(edges, vertex.attr = nodes, 
                        matrix.type = "edgelist", 
                        directed=FALSE, ignore.eval = FALSE, layout="circle")
  
  
  df141_genes <- unique(c(df_141$GeneName1, df_141$GeneName2))
  df141_genes <- pombe_gn[pombe_gn$Gene.name %in% df141_genes,]
  
  
  p141 <- ggplot(my_network, aes(x = x, y = y, xend = xend, yend = yend)) +
    geom_edges(size=.2, aes(color=weight != 0)) +
    geom_nodes(color="#92c5de") +
    geom_nodetext(aes(label=vertex.names), size=2, hjust = "outward", vjust = "outward", check_overlap = TRUE) +
    theme_blank() +
    guides(color=FALSE) +
    ggtitle("Cluster 141") +
    theme(title = element_text(size=7)) +
    annotate("text", x=.5, y= -.31, label="Cytoplasmic translation", size=2)+
    xlim(-.1,1.2) +
    ylim(-.45,1.1) +
    scale_color_manual(values = c("#878787", "#92c5de")) 
  
  
  rm(df_141)
  
  # 142
  df_142 <- df_string[df_string$Cluster_number == 142, c(11,12,6)]
  nodes <- as.data.frame(unique(jnk$pG[jnk$cluster == 142]))
  nodes$id <- rownames(nodes)
  nodes <- nodes[,2:1]
  names(nodes)[2] <- "label"
  edges <- df_142
  edges <- as.data.frame(edges)
  edges <- remove.factors(edges)
  if(length(setdiff(nodes$label, c(edges$protein1, edges$protein2))) > 0){
    toadd <- setdiff(nodes$label, c(edges$protein1, edges$protein2))
    toadd <- as.data.frame(cbind(toadd, toadd))
    toadd$combined_score <- 150
    names(toadd) <- names(edges)
    edges <- as.data.frame(rbind(edges, toadd))
  }
  names(edges) <- c("source", "destination", "weight")
  my_network <- network(edges, vertex.attr = nodes, 
                        matrix.type = "edgelist", 
                        directed=FALSE, ignore.eval = FALSE, layout="circle")
  
  df142_genes <- unique(c(df_142$GeneName1, df_142$GeneName2))
  df142_genes <- pombe_gn[pombe_gn$Gene.name %in% df142_genes,]
  
  
  p142 <- ggplot(my_network, aes(x = x, y = y, xend = xend, yend = yend)) +
    geom_edges(size=.2, aes(color=weight != 0)) +
    geom_nodes(color="#0571b0") +
    geom_nodetext(aes(label=vertex.names), size=2, hjust = "outward", vjust = "outward", check_overlap = TRUE) +
    theme_blank() +
    guides(color=FALSE) +
    ggtitle("Cluster 142") +
    theme(title = element_text(size=7)) +
    annotate("text", x=.5, y= -.31, label="Co-expressed", size=2)+
    xlim(-.1,1.1) +
    ylim(-.45,1.1) +
    scale_color_manual(values = c("#878787", "#0571b0")) 
  
  rm(df_142)
  # done
  rm(df_string)
  rm(edges)
  rm(jnk)
  rm(my_network)
  rm(nodes)
  rm(toadd)
  # Figure 3 b2 # expression profile # tiny networks of the colored clusters #################################
  df_melt <- readRDS("6_5_1_2019-07-16_meltAllInfo.rds")
  
  df_melt$StrainType <- "Knockout"
  df_melt$StrainType[grep("WT", df_melt$Strain)] <- "Wildtype"
  
  # group the genes 
  df110_genes$Cluster <- "c110"
  df136_genes$Cluster <- "c136"
  df141_genes$Cluster <- "c141"
  df142_genes$Cluster <- "c142"
  df_genes <- as.data.frame(rbind(df110_genes, df136_genes, df141_genes, df142_genes))
  df_genes <- df_genes[,c(1,3)]
  
  df_melt$Proteins <- gsub("([^;])\\;.*", "\\1", df_melt$Proteins)
  length(unique(setdiff(df_melt$Proteins, df_genes$Gene.stable.ID)))
  length(unique(setdiff(df_genes$Gene.stable.ID, df_melt$Proteins)))
  #  df_melt <- df_melt[df_melt$Proteins %in% df110_genes$Gene.stable.ID,]
  df_melt <- df_melt[df_melt$Proteins %in% df_genes$Gene.stable.ID,]
  df_melt <- df_melt[df_melt$StrainType == "Knockout",]
  length(unique(setdiff(df_melt$Proteins, df_genes$Gene.stable.ID)))
  length(unique(setdiff(df_genes$Gene.stable.ID, df_melt$Proteins)))
  # 
  df_melt <- df_melt %>%
    group_by(Strain) %>%
    dplyr::mutate(meanZscore = mean(Zscore, na.rm=T)) %>%
    as.data.frame()
  
  df_melt <- merge(df_melt, df_genes, by.x="Proteins", by.y="Gene.stable.ID", all=T)
  
  df_melt <- df_melt[with(df_melt, order(meanZscore, decreasing = T)), ]
  
  df_jnk <- as.data.frame(unique(df_melt[,c(2,9)]))
  df_jnk$Rank <- 1:3308
  
  df_melt <- merge(df_melt[,c(1:8,10)], df_jnk, by.x="Strain", by.y="Strain")
  
  
  F3b2 <- ggplot(df_melt, aes(Rank, Zscore))+
    geom_smooth(aes(color=Cluster), size=1.1) +
    scale_color_manual(values = c("#ca0020", "#f4a582", "#92c5de", "#0571b0")) +
    guides(color=FALSE) +
    theme_classic() +
    xlab("Knockout strains") +
    ylab("Normalized expression") +
    theme(axis.text.y=element_text(size=6),
          axis.text.x=element_blank(),
          axis.ticks.x = element_blank(),  
          axis.title=element_text(size=8,face="bold"))
  
  
  
  # Figure 3 # put together ################################################
  p_p <- ggarrange(p110, p136, p141, p142, nrow = 2, ncol = 2, labels = c("c", "d", "e", "f"), hjust = .9, widths = c(1.1,1))

  
  F3 <- ggarrange(ggarrange(F3a, F3b2, nrow = 2, ncol = 1, labels = c("a","b"), vjust = .9),
                  p_p, ncol=2, widths = c(2,4))
  
  F3ann <- annotate_figure(F3, bottom = text_grob("�zt�rk et al, Figure 3  ", hjust=1, x=1, size=10))
  
  ggsave("Figure_3.pdf", F3ann, dpi = 300, units = "cm", width = 18, height = 10)
  rm(F2a)
  rm(F2b)
  rm(F2c)
  rm(F2)
  
  
}

if(Extendedfigure3){
  # ExtendedFigure 3a2 # correlation of expression vs. in string db or not #########################################
  df_2plot <- readRDS("ExtFigure_3_a_corString_DATA.rds")
  df_2plot$group <- !is.na(df_2plot$combined_score)
  df_2plot$group[df_2plot$group== TRUE] <- "STRINGdb"
  df_2plot$group[df_2plot$group==FALSE] <- "Not STRINGdb"
  jnk <- as.data.frame(table(df_2plot$group))
  
  df_2plot$group <- factor(df_2plot$group,
                           levels = c("STRINGdb", "Not STRINGdb"))
  
  F3a2 <- ggplot(df_2plot, aes(group, cor)) +
    geom_hline(yintercept = 0, color="#878787") +
    geom_violin(aes(fill=group), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    stat_compare_means(label.x = 1.15, label.y=1.1, size = 2) +
    theme_classic() +
    xlab(NULL) +
    ylab("Pearson R") +
    scale_y_continuous(breaks = c(-1,0,1), labels=c(-1,0,1), limits = c(-1.1,1.1)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-1.1, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  rm(df_2plot)
  rm(jnk)
  # ExtendedFigure 3b_new # titration of the cor vs. stringdb percentage #########################################
  df_count <- readRDS("EF3b_new_20201210_stringTitration_DATA.rds")
  
  names(df_count) <- c("cutOff", "myCount", "Score_150", "Score_400",
                       "Score_600", "Score_800")
  
  df_jnk <- melt(df_count, id=c("cutOff", "myCount"))
  
  df_jnk$variable <- gsub("Score_", ">=", df_jnk$variable)
  df_jnk$value[df_jnk$value == "NaN"] <- 0
  names(df_jnk)[3] <- "Score"
  
  df_jnk <- df_jnk[df_jnk$Score != ">=150",]
  df_jnk$cutOff2 <- paste(">= ", round(df_jnk$cutOff,2), sep="") 
  myCutOffs <- unique(df_jnk$cutOff)
  
  df_jnk <- as.data.frame(remove.factors(df_jnk))
  
  df_jnk$myCount <- as.numeric(df_jnk$myCount)
  
  F3b_new <- ggplot(df_jnk, aes(cutOff, value)) +
    geom_col(aes(y=(myCount/4000000)), color="#bababa",fill="#bababa") +
    geom_point(aes(color=Score)) +
    geom_line(aes(color=Score)) +
    theme_classic() +
    scale_x_continuous(breaks = myCutOffs, labels = paste(">= ", round(myCutOffs,2), sep="")) + 
    scale_y_continuous(breaks = c(0,2,4), labels = c(0,2,4), limits = c(0,4.6),
                       sec.axis = sec_axis(~.*4000000, name = "Number of pairs")) + 
    theme(axis.text.x = element_text(size=7, angle=90, hjust=0),
          axis.text.y = element_text(size=7),
          axis.title = element_text(size=8, face="bold"),
          legend.position = c(.5,.9),
          legend.background = element_blank(),
          legend.key.width = unit(0.4, "cm"),
          legend.key.height = unit(0.2, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_text(size = 7, face="bold"),
          legend.direction = "horizontal") +
    xlab("Pearson R cut-off") +
    ylab(("% in STRINGdb")) +
    scale_color_brewer(palette = "Set1")
  
  
  # ExtendedFigure 3c,f # cor ecdf, same cluster or not # before any filtering ########################################
  df_cor <- readRDS("ExtFigure_3_c_CorCluster_DATA.rds")
  df_cor$SameCluster[df_cor$SameCluster == "Same Cluster"] <- paste("Same", "\n","cluster")
  df_cor$SameCluster[df_cor$SameCluster == "Different Clusters"] <- paste("Different", "\n","clusters")
  
  df_cor$Keep[df_cor$Keep=="Discard"] <- "Discarded"
  df_cor$Keep[df_cor$Keep=="Keep"] <- "Kept"
  
  jnk <- as.data.frame(table(df_cor$SameCluster))
  
  F3c <- ggplot(df_cor, aes(SameCluster, cor)) +
    geom_hline(yintercept = 0, color="#878787") +
    geom_violin(aes(fill=SameCluster), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    stat_compare_means(label.x = 1.1, label.y=1.1, size = 2) +
    theme_classic() +
    xlab(NULL) +
    ylab("Pearson R") +
    scale_y_continuous(breaks = c(-1,0,1), labels=c(-1,0,1), limits = c(-1.1,1.1)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-1.1, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  jnk <- as.data.frame(table(df_cor$Keep[df_cor$SameCluster == "Same \n cluster"]))
  
  F3f <- ggplot(data=subset(df_cor, SameCluster == "Same \n cluster"), aes(Keep, cor)) +
    geom_hline(yintercept = 0, color="#878787") +
    geom_violin(aes(fill=Keep), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    stat_compare_means(label.x = 1.1, label.y=1.1, size = 2) +
    theme_classic() +
    xlab(NULL) +
    ylab("Pearson R") +
    scale_y_continuous(breaks = c(-1,0,1), labels=c(-1,0,1), limits = c(-1.1,1.1)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-1.1, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  rm(jnk)
  rm(df_cor) 
  # ExtendedFigure 3d,e # filtering of the clusters ########################################
  df_class_distance <- readRDS("ExtFigure_3_d_filtering_DATA.rds")
  names(df_class_distance)[2] <- "cluster"
  df_jnk <- unique(df_class_distance[,c(2,4,6)])
  
  df_jnk$Keep[df_jnk$Keep=="Discard"] <- "Discarded"
  df_jnk$Keep[df_jnk$Keep=="Keep"] <- "Kept"
  
  
  jnk <- as.data.frame(table(df_jnk$Keep))
  q42line <- quantile(df_class_distance$Distance2cluster)[[4]]
  
  F3d <- ggplot(df_jnk, aes(Keep, mean_Distance2cluster)) +
    geom_violin(aes(fill=Keep), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    geom_hline(yintercept = q42line, color="#878787", linetype="dashed") +
    theme_classic() +
    xlab(NULL) +
    ylab("Mean (distance)") +
    stat_compare_means(label.x = 1.3, label.y=1500, size = 2) +
    scale_y_continuous(breaks = c(500,1000,1500), labels=c(500,1000,1500), limits = c(300,1500)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=300, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  df_class_distance$Keep[df_class_distance$Keep=="Discard"] <- "Discarded"
  df_class_distance$Keep[df_class_distance$Keep=="Keep"] <- "Kept"
  
  jnk <- as.data.frame(table(df_class_distance$Keep))
  F3e <- ggplot(df_class_distance, aes(Keep, Distance2cluster)) +
    geom_violin(aes(fill=Keep), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    geom_hline(yintercept = q42line, color="#878787", linetype="dashed") +
    theme_classic() +
    xlab(NULL) +
    ylab("Distance") +
    stat_compare_means(label.x = 1.3, label.y=3500, size = 2) +
    ylim(0,3500) +
    # scale_y_continuous(breaks = c(500,1000,1500), labels=c(500,1000,1500), limits = c(300,1500)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=0, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  rm(df_class_distance)
  rm(df_jnk)
  rm(jnk)
  # ExtendedFigure 3g # example ########################################
  nodes <- as.data.frame(c("A", "B", "C", "D"))
  nodes$id <- rownames(nodes)
  nodes <- nodes[,2:1]
  names(nodes)[2] <- "label"
  
  edges <- combn(c("A", "B", "C", "D"),2)
  edges <- as.data.frame(t(edges))
  edges <- remove.factors(edges)
  #edges <- edges[-grep("D", edges$V2),]
  #edges <- as.data.frame(rbind(edges, c("D", "D")))
  edges$V3 <- 10
  names(edges) <- c("source", "destination", "weight")
  edges$weight[edges$destination == "D"] <- 0
  
  my_network <- network(edges, vertex.attr = nodes, 
                        matrix.type = "edgelist", 
                        directed=FALSE, ignore.eval = FALSE)
  
  p_exmpl <- ggplot(my_network, aes(x = x, y = y, xend = xend, yend = yend)) +
    geom_nodes(color="#b2182b", size=2) +
    geom_edges(size=.2, aes(color=weight!=0)) +
    geom_nodetext_repel(aes(label=vertex.names)) +
    theme_blank() +
    scale_color_manual(values=c("#878787", "#b2182b")) +
    guides(color=FALSE) +
    xlim(-4,1)
  
  F3g <- p_exmpl +
    annotate("text", x=-4, y= .5, label="# node = 4", size=3, hjust=0) +
    annotate("text", x=-4, y= .35, label="# edge = 3", size=3, hjust=0) +
    annotate("text", x=-4, y= .2, label="# possible edge = 6", size=3, hjust=0) +
    annotate("text", x=-4, y= 1, label="Connectivity score = 0.5", size=2.8, hjust=0) +
    ylim(0,1.3) +
    annotate("text", x=-1.5, y= 1.3, label="Connectivity example", size=3.5, fontface=2)
  rm(df)
  rm(edges)
  rm(nodes)
  rm(jnk)
  rm(my_network)
  #rm(p_exmpl)
  
  
  # ExtendedFigure 3h # sampling ########################################
  df <- readRDS("ExtFigure_3_g_sampling_DATA.rds")
  df$group[df$group == "clusters"] <- "Clusters"
  df$group[df$group == "sampling"] <- paste("Random", "\n","sampling")
  
  jnk <- as.data.frame(table(df$group))
  df$PercentNoInteract <- df$n_noInteraction / df$n_size_cluster
  
  F3h <- ggplot(df, aes(group,connectscore)) +
    geom_violin(aes(fill=group), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() +
    xlab(NULL) +
    ylab("Connectivity score") +
    stat_compare_means(label.x = 1.3, label.y=1.1, size = 2) +
    scale_y_continuous(breaks = c(0,.5,1), labels=c(0,.5,1), limits = c(-0.1,1.1)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-0.1, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  # EF3_addON # Y2H venn and Ryan GI violinplot #####################################
  # Ryan column comparison to clusters ##############################################
  df_protein <- read.delim("20200723_SupplementaryTable_1_DATA.txt")
  df_protein <- df_protein[df_protein$Filtered == "Kept",]
  
  df_protein$Systematic_ID <- gsub("([^;]+)\\;.*", "\\1", df_protein$Systematic_ID)
  df_protein <- as.data.frame(df_protein[,1:2])
  df_protein$Systematic_ID_upper <- toupper(df_protein$Systematic_ID)
  
  ryan <- readRDS("E:/Merve/PaperFigures/Ryan_matrix.rds")
  rownames(ryan) <- toupper(rownames(ryan))
  colnames(ryan) <- toupper(colnames(ryan))
  
  ryan_cor <- as.data.frame(cor(ryan, use = 'pairwise.complete.obs'))
  ryan_cor$Protein1 <- rownames(ryan_cor)
  ryan_cor <- melt(ryan_cor, "Protein1")
  names(ryan_cor) <- c("Protein1", "Protein2", "Ryan_cor")
  
  ryan_cor <- merge(ryan_cor, df_protein, by.x="Protein1", by.y="Systematic_ID_upper", all=FALSE)  
  names(ryan_cor)[5] <- "C_protein1"
  ryan_cor <- merge(ryan_cor, df_protein, by.x="Protein2", by.y="Systematic_ID_upper", all=FALSE)  
  names(ryan_cor)[7] <- "C_protein2"
  
  ryan_cor <- ryan_cor[ryan_cor$Protein1 != ryan_cor$Protein2, ]
  
  ryan_cor$SameCluster <- ryan_cor$C_protein1 == ryan_cor$C_protein2
  ryan_cor$SameCluster[ryan_cor$SameCluster == TRUE] <- "Same\ncluster"
  ryan_cor$SameCluster[ryan_cor$SameCluster == FALSE] <- "Different\nclusters"
  
  
  jnk <- as.data.frame(table(ryan_cor$SameCluster))
  jnk <- jnk[jnk$Freq != 0,]
  names(jnk)[1] <- "SameCluster"
  
  p_ryan_box_cor <- ggplot(ryan_cor, aes(x=SameCluster, y=Ryan_cor))+
    geom_hline(yintercept = 0, color="#878787")+
    geom_violin(aes(fill = SameCluster)) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() +
    stat_compare_means(label.x = 1.1, label.y = .75, size = 2) +
    xlab(NULL) +
    ylab("Pearson R, Ryan GI") +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8, face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(label=paste("n = ",Freq)), y=-.55, size=2) +
    scale_fill_manual(values=c("#2166ac", "#b2182b")) +
    guides(fill=FALSE) +
    scale_y_continuous(breaks = c(-1,-.5,0,.5,1), labels = c(-1,-.5,0,.5,1), limits = c(-.6,.75))
  
  # not a lot of interactions Y2H ##############################################
  library(eulerr)
  d_y2h <- read.delim("Y2H_pairs.txt", sep=" ")
  d_y2h$strain1 <- toupper(d_y2h$strain1)
  d_y2h$strain2 <- toupper(d_y2h$strain2)
  
  # y2h heterodimers
  d_y2h_hetero <- d_y2h[d_y2h$strain1 != d_y2h$strain2,]
  # proteins clustered
  df_cor <- readRDS("ExtFigure_3_c_CorCluster_DATA.rds")
  df_cor <- df_cor[df_cor$Protein1 != df_cor$Protein2,]
  #df_cor <- df_cor[df_cor$SameCluster == "Same Cluster",]
  df_cor <- df_cor[df_cor$Keep == "Keep",]
  df_cor <- remove.factors(df_cor)
  
  df_cor_proteins <- unique(toupper(unique(c(df_cor$Protein1, df_cor$Protein2))))
  
  #length(unique(setdiff(df_cor$Protein2, df_cor$Protein1)))
  # y2h proteome
  d_y2h_proteome <- d_y2h[d_y2h$strain1 %in% df_cor_proteins,]
  d_y2h_proteome <- d_y2h_proteome[d_y2h_proteome$strain2 %in% df_cor_proteins,]
  # y2h hetero proteome
  d_y2h_proteome_h <- d_y2h_hetero[d_y2h_hetero$strain1 %in% df_cor_proteins,]
  d_y2h_proteome_h <- d_y2h_proteome_h[d_y2h_proteome_h$strain2 %in% df_cor_proteins,]
  
  
  py2h <- c("Y2H"= dim(d_y2h_hetero)[1] - dim(d_y2h_proteome_h)[1], 
            "Proteome"= dim(df_cor)[1] - dim(d_y2h_proteome_h)[1],
            "Y2H&Proteome"= dim(d_y2h_proteome_h)[1])
  
  
  fit1 <- euler(py2h)
  
  p1 <- plot(fit1, quantities=list(fontsize=7), labels=list(fontsize=7))
  
  pdf("EF3_y2h_Venn_euler.pdf", height = 4, width = 4)
  print(p1)
  dev.off()
  
  px <- ggplot()+
    theme_blank()
  # ExtendedFigure 3 # put together ################################################
  px <- ggplot() +
    theme_blank()
  
  F3 <- ggarrange(ggarrange(F3a2, F3b_new, nrow = 1, ncol = 2, labels = c("a", "b"), widths = c(1,2)),
                    ggarrange(F3c, F3d, F3e, F3f, nrow = 1, ncol = 4, labels = c("c","d", "e", "f")),
                    ggarrange(px, p_ryan_box_cor, F3g, F3h, nrow = 1, ncol = 4, labels = c("g", "h", "i", "j")), 
                    nrow = 3)
  
  F3ann <- annotate_figure(F3, bottom = text_grob("�zt�rk et al, Extended Figure 3  ", hjust=1, x=1, size=10))
  
  ggsave("ExtendedFigure_3.pdf", F3ann, dpi = 300, units = "cm", width = 20, height = 15)
  
  
  rm(F3a)
  rm(F3b)
  rm(F3c)
  rm(F3d)
  rm(F3e)
  rm(F3f)
  rm(F3g)
  rm(F3h)
  rm(F3i)
  rm(F3j)
  rm(F3k)
  rm(F3l)
  rm(F3)
  
}

if(Extendedfigure4){
  # ExtendedFigure 4 # strain clustering  #########################################
  # ExtendedFigure 4a # strain corelations with Zscore and Normalized #############
  df <- readRDS("ExtFigure_4_a_corelation_DATA.rds")
  jnk <- as.data.frame(table(df$variable))
  
  F4a <- ggplot(df, aes(variable, value)) +
    geom_hline(yintercept = 0, color="#878787") +
    geom_violin(aes(fill=variable), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    stat_compare_means(label.x = 1.2, label.y=1.1, size = 2) +
    theme_classic() +
    xlab(NULL) +
    ylab("Pearson R") +
    scale_y_continuous(breaks = c(-1,0,1), labels=c(-1,0,1), limits = c(-1.1,1.1)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=7,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-1.1, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  rm(df)
  rm(jnk)
  # ExtendedFigure 4b # correlations of same cluster or not #############
  df_cor <- readRDS("ExtFigure_4_b_CorCluster_DATA.rds")
  
  df_cor$SameCluster[df_cor$SameCluster == TRUE] <- paste("Same", "\n" ,"cluster")
  df_cor$SameCluster[df_cor$SameCluster == FALSE] <- paste("Different", "\n" ,"clusters")
  
  jnk <- as.data.frame(table(df_cor$SameCluster))
  
  F4b <- ggplot(df_cor, aes(SameCluster, cor_Z1444)) +
    geom_hline(yintercept = 0, color="#878787") +
    geom_violin(aes(fill=SameCluster), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    stat_compare_means(label.x = 1.2, label.y=1.1, size = 2) +
    theme_classic() +
    xlab(NULL) +
    ylab("Pearson R") +
    scale_y_continuous(breaks = c(-1,0,1), labels=c(-1,0,1), limits = c(-1.1,1.1)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-1.1, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  
  mygenes <- unique(df_cor$Strain1)
  mygenes <- gsub("Sp.*\\-(.*)", "\\1", mygenes)
  
  GO <- read.delim("gene_association.pombase.gz", skip=42, header=FALSE)
  GO_my <- subset(GO, V2 %in% mygenes)
  length(unique(GO_my$V2))
  
  GO_my <- GO_my[GO_my$V9 == "P",]
  length(unique(GO_my$V2))
  
  length(unique(GO$V2))
  
  rm(df_cor)
  rm(jnk)
  # ExtendedFigure 4c # wt percentage ###############################################
  df_class_distance_jnk2 <- readRDS("ExtFigure_4_c_wtPercentage_DATA.rds")
  df_class_distance_jnk2$color[df_class_distance_jnk2$color == "Discard"] <- "Wt containing clusters (40)"
  df_class_distance_jnk2$color[df_class_distance_jnk2$color == "Keep"] <- "Knockout strain clusters (81)"
  
  
  F4c <- ggplot(df_class_distance_jnk2, aes(WT_percentage, SizeCluster))+
    geom_point(aes(color=color, alpha=Freq), size=2) +
    theme_classic()+
    xlab("Wt percentage") +
    ylab("Number of strains") +
    scale_color_manual(values=c("#ca0020", "#000000"),
                       guide = guide_legend(direction = "vertical", byrow = FALSE,
                                            title = NULL, keyheight = .8)) +
    theme(axis.text.y=element_text(size=6),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.55,0.85),
          legend.background = element_blank(),
          legend.key.size = unit(0.1, "cm"),
          legend.text = element_text(size=7),
          legend.box = "horizontal") +
    guides(alpha=FALSE)
  
  rm(df_class_distance_jnk2)
  
  # ExtendedFigure 4de # distance filtering ###############################################
  df_class_distance <- readRDS("ExtFigure_4_d_classDistance_DATA.rds")
  df_jnk <- as.data.frame(unique(df_class_distance[,c(2,4,5,7,8,9,10,11)]))
  
  q42line <- quantile(df_class_distance$Distance)[[4]]
  
  df_jnk <- df_jnk[df_jnk$Keep %in% c("Keep", "distance"),]
  df_jnk$Keep[df_jnk$Keep == "Keep"] <- "Kept"
  df_jnk$Keep[df_jnk$Keep == "distance"] <- "Discarded"
  df_jnk <- remove.factors(df_jnk)
  
  df_class_distance <- df_class_distance[df_class_distance$Keep %in% c("Keep", "distance"),]
  df_class_distance$Keep[df_class_distance$Keep == "Keep"] <- "Kept"
  df_class_distance$Keep[df_class_distance$Keep == "distance"] <- "Discarded"
  df_class_distance <- remove.factors(df_class_distance)
  jnk <- as.data.frame(table(df_jnk$Keep))
  
  F4d <- ggplot(df_jnk, aes(Keep, averageDistance)) +
    geom_violin(aes(fill=Keep), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    geom_hline(yintercept = q42line, color="#878787", linetype="dashed") +
    theme_classic() +
    xlab(NULL) +
    ylab("Mean (distance)") +
    stat_compare_means(label.x = 1.3, label.y=2700, size = 2) +
    scale_y_continuous(breaks = c(0,1000,2000), labels=c(0,1000,2000), limits = c(0,2770)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=0, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  
  jnk <- as.data.frame(table(df_class_distance$Keep))
  F4e <- ggplot(df_class_distance, aes(Keep, Distance)) +
    geom_violin(aes(fill=Keep), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    geom_hline(yintercept = q42line, color="#878787", linetype="dashed") +
    theme_classic() +
    xlab(NULL) +
    ylab("Distance") +
    stat_compare_means(label.x = 1.3, label.y=4700, size = 2) +
    scale_y_continuous(breaks = c(0,1000,2000, 3000, 4000), labels=c(0,1000,2000, 3000, 4000), limits = c(-80,4700)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-80, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  rm(df_class_distance)
  rm(df_jnk)
  rm(jnk)
  # ExtendedFigure 4f # keep cor ###############################################
  df_cor <- readRDS("ExtFigure_4_f_SameClusterCor_DATA.rds")
  df_cor <- df_cor[df_cor$Keep %in% c("Keep", "distance"),]
  df_cor$Keep[df_cor$Keep == "Keep"] <- "Kept"
  df_cor$Keep[df_cor$Keep == "distance"] <- "Discarded"
  df_cor <- remove.factors(df_cor)
  
  jnk <- as.data.frame(table(df_cor$Keep))
  
  F4f <- ggplot(df_cor, aes(Keep, cor_Z1444)) +
    geom_violin(aes(fill=Keep), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() +
    xlab(NULL) +
    ylab("Pearson R") +
    scale_y_continuous(breaks = c(-1,0,1), labels=c(-1,0,1), limits = c(-.1,1.1)) +
    stat_compare_means(label.x = 1.3, label.y=1.1, size = 2) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-.08, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  # ExtendedFigure 4gi # to remove the main figure without our data and include it here  #######################################
  pombeann <- readRDS("ExtFigure_4_gi_annotation_DATA.rds")
  
  pombeann$viability[pombeann$viability == "viable"] <- "Non-essential"
  pombeann$viability[pombeann$viability == "inviable"] <- "Essential"
  
  jnk <- as.data.frame(table(pombeann[!is.na(pombeann$ReactomeReactions),2]))
  F4g <- ggplot(pombeann, aes(viability, ReactomeReactions)) +
    geom_violin(aes(fill=viability), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    stat_compare_means(label.x = 1.2, label.y=70, size = 2) +
    theme_classic() +
    ggtitle("Reactome reactions") +
    ylab("Number of associations") +
    xlab(NULL) +
    scale_y_continuous(breaks = c(0,20,40,60), labels=c(0,20,40,60), limits = c(-5,72)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold"),
          title = element_text(size=7,face="bold", hjust = .5)) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-4, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  
  jnk <- as.data.frame(table(pombeann[!is.na(pombeann$ReactomePathwaysALL),2]))
  F4h <- ggplot(pombeann, aes(viability, ReactomePathwaysALL)) +
    geom_violin(aes(fill=viability), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    stat_compare_means(label.x = 1.2, label.y=70, size = 2) +
    theme_classic() +
    ggtitle("Reactome pathways") +
    ylab("Number of associations") +
    xlab(NULL) +
    scale_y_continuous(breaks = c(0,20,40,60), labels=c(0,20,40,60), limits = c(-5,72)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold"),
          title = element_text(size=7,face="bold", hjust = .5)) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-4, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  
  
  jnk <- as.data.frame(table(pombeann[!is.na(pombeann$String),2]))
  F4i <- ggplot(pombeann, aes(viability, String)) +
    geom_violin(aes(fill=viability), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    stat_compare_means(label.x = 1.2, label.y=2000, size = 2) +
    theme_classic() +
    ggtitle("STRING database") +
    ylab("Number of associations") +
    xlab(NULL) +
    scale_y_continuous(breaks = c(0,1000,2000), labels=c(0,1000,2000), limits = c(-100,2000)) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold"),
          title = element_text(size=7,face="bold", hjust = .5)) +
    geom_text(data=jnk, aes(x= Var1, label=paste("n = ",Freq)), y=-100, size=2) +
    guides(fill=FALSE) +
    scale_fill_manual(values=c("#b2182b", "#2166ac"))
  rm(jnk)
  rm(pombeann)
  # ExtendedFigure 4j # volcanoplot for all the targets from 48 clusters ########################################### TO DO############
  library(viridis)
  df_melt <- readRDS("ExtFigure_4_j_volcanoplot_DATA.rds")
  df_melt$pplot <- -log10(df_melt$pvalue)
  df_melt <- df_melt[!is.na(df_melt$pplot),]
  
  df_melt$shape <- 1
  df_melt$shape[df_melt$pplot >=40 | abs(df_melt$FC) >=1] <- 2
  df_melt$pplot2 <- df_melt$pplot
  df_melt$pplot2[df_melt$pplot2 >= 40] <- 40
  df_melt$FC2 <- df_melt$FC
  df_melt$FC2[df_melt$FC >=1] <- 1
  df_melt$FC2[df_melt$FC <= -1] <- -1
  
  df_melt$color <- "NOT"
  df_melt$color[df_melt$pvalue <= 0.05 & df_melt$FC > 0] <- "UP"
  df_melt$color[df_melt$pvalue <= 0.05 & df_melt$FC < 0] <- "down"
  
  
  F4j <- ggplot(df_melt, aes(FC2, pplot2))+
    theme_classic() +
    xlab("log2(fold change)")+
    ylab("-log10(p-value)")+
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.5,0.96),
          legend.title = element_blank(),
          legend.background = element_blank(),
          legend.key.width = unit(0.6, "cm"),
          legend.key.height = unit(0.2, "cm"),
          legend.text = element_text(size=6),
          legend.direction = "horizontal",
          legend.spacing.y = unit(0.01, "cm")) +
    # geom_rect(xmin=-1.02, xmax=1.02,
    #           ymin=0, ymax=-log10(0.05),
    #           color="#1a1a1a", fill=NA) +
    # geom_rect(xmin=-1.02, xmax=-0.02,
    #           ymin=-log10(0.05), ymax=48,
    #           color="#2166ac", fill=NA) +
    # geom_rect(xmin=0.02, xmax=1.02,
    #           ymin=-log10(0.05), ymax=48,
    #           color="#b2182b", fill=NA) +
    geom_bin2d(bins=35) +
    geom_hline(yintercept = -log10(0.05), color="#878787", linetype="dashed") +
    geom_vline(xintercept = 0, color="#878787", linetype="dashed") +
    scale_fill_viridis() +
    ylim(-.9,44) 
  
  
  rm(df_melt)
  # ExtendedFigure 4k # number of targets per cluster #######################################################
  df <- readRDS("ExtFigure_4_k_ntarget_DATA.rds")
  jnk <- as.data.frame(table(df$variable))
  
  df <- dcast(df, Var1 ~ variable)
  
  F4k <- ggplot(df, aes(Up, Down)) +
    geom_point(size=2, alpha=.7) +
    theme_classic() +
    xlab("# Upregulated proteins") +
    ylab("# Downregulated proteins") +
    scale_x_continuous(limits = c(0,680)) +
    scale_y_continuous(limits = c(0,680)) +
    theme(axis.text=element_text(size=7),
          axis.title=element_text(size=7,face="bold")) +
    guides(color=FALSE) 
  rm(df)
  rm(jnk)
  # ExtendedFigure 4l # number of targets GO categories enriched - scatterplot ################################################
  df_merged <- readRDS("ExtFigure_4_l_GO_DATA.rds")
  df_merged$IDcluster <- as.numeric(df_merged$IDcluster)
  df_merged <- df_merged[,c(1,2,4,5)]
  
  names(df_merged) <- c("IDcluster", "Strains", "Downregulated", "Upregulated")
  
  df_merged <- melt(df_merged, "IDcluster")
  df_merged$value[is.na(df_merged$value)] <- 0
  
  df_merged <- df_merged[df_merged$variable != "Strains",]
  
  F4l <- ggplot(df_merged, aes(x=IDcluster, value))+
    geom_point(aes(color = variable, shape=variable), size=1.5, alpha=.7) +
    geom_line(aes(color = variable)) +
    theme_classic() +
    ylim(0,150) + 
    xlab("Cluster")+
    ylab("# Enriched GO terms") +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.45,0.95),
          legend.background = element_blank(),
          legend.key.size = unit(0.3, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_blank(),
          legend.direction = "horizontal") +
    # guides(shape=FALSE, color=FALSE) +
    scale_color_manual(values = c("#2166ac","#b2182b")) +
    scale_x_continuous(breaks = 1:121, labels = NULL)
  rm(df_merged)
  # ExtendedFigure 4 # put together ################################################
  px <- ggplot()+
    theme_blank()
  
  F4 <- ggarrange(ggarrange(F4g,F4h,F4i, nrow = 1, ncol = 3, labels = c("a","b","c")),
                  ggarrange(F4c,F4b,F4d, nrow = 1, ncol = 3, labels = c("d","e", "f")),
                  ggarrange(F4e,F4f,px, nrow = 1, ncol = 3, labels = c("g", "h", "i")),
                  nrow = 3)
  F4ann <- annotate_figure(F4, bottom = text_grob("�zt�rk et al, Extended Figure 4  ", hjust=1, x=1, size=10))
  
  
  ggsave("ExtendedFigure_4.pdf", F4ann, dpi = 300, units = "cm", width = 18, height = 18)
  
  rm(F4a)
  rm(F4b)
  rm(F4c)
  rm(F4d)
  rm(F4e)
  rm(F4f)
  rm(F4g)
  rm(F4h)
  rm(F4i)
  rm(F4j)
  rm(F4k)
  rm(F4l)
  rm(F4)
  
}


if(figure4){
  # Figure 4 # a# proteome 94 heatmap of averages of normalized values per strain with all measured proteins and ones measured in all #####
  df_mymat <- readRDS("20210209_Figure4a_protein_Data.rds")
  
  F4a <- ggplot(df_mymat, aes(SystemicIDko, ProteinIDs)) +
    geom_tile(aes(fill=`log2(intensity)`)) +
    theme_classic() +
    theme(axis.title.y = element_text(size=7, face = "bold"),
          axis.title.x = element_blank(),
          axis.text = element_blank(),
          axis.ticks = element_blank(),
          axis.line = element_blank(), 
          legend.key.size = unit(0.3, "cm"),
          strip.text = element_text(size=7, vjust = 0),
          legend.title = element_text(size=7),
          legend.text = element_text(size=7),
          legend.position = "bottom",
          # legend.box = "horizontal",
          legend.background = element_blank(),
          strip.background = element_blank()) +
    scale_fill_gradient(low="black", high="yellow") +
    facet_grid(. ~ Type, scales ="free_x", space = "free_x") +
    ylab("Proteome") +
    guides(fill=FALSE)
    
  
  # Figure 4 # b# transcriptome 94 heatmap of averages of normalized values per strain with all measured proteins and ones measured in all #####
  df_mymat <- readRDS("20210209_Figure4a_RNA_Data.rds")
  
  F4b <- ggplot(df_mymat, aes(SystemicIDko, geneID)) +
    geom_tile(aes(fill=`log2(CPM)`)) +
    theme_classic() +
    theme(axis.title.y = element_text(size=7, face = "bold"),
          axis.title.x = element_blank(),
          axis.text = element_blank(),
          axis.ticks = element_blank(),
          axis.line = element_blank(), 
          legend.key.size = unit(0.3, "cm"),
          strip.text = element_blank(),
          legend.title = element_text(size=7),
          legend.text = element_text(size=7),
          legend.position = "bottom",
          # legend.box = "horizontal",
          legend.background = element_blank(),
          strip.background = element_blank()) +
    scale_fill_gradient(low="black", high="#6baed6") +
    facet_grid(. ~ Type, scales ="free_x", space = "free_x") +
    ylab("Transcriptome") + 
    guides(fill=FALSE)
  
  # p_guides <- ggarrange(F4a, F4b)
  # ggsave("FiguresModified_20210207/Figure_4_annotation_20210207.pdf", p_guides, dpi = 300, units = "cm", width = 12, height = 3)
  
  # Figure 4 # d# transcriptome-proteome  correlation heatmap 94 from averages of normalized values, with clustering based on proteome numbered #####
  get_density <- function(x, y, ...) {
    dens <- MASS::kde2d(x, y, ...)
    ix <- findInterval(x, dens$x)
    iy <- findInterval(y, dens$y)
    ii <- cbind(ix, iy)
    return(dens$z[ii])
  }
  library(viridis)
  
  df_cor_merged <- readRDS("20210209_Figure4b_Data.rds")
  jnk <- round(cor(df_cor_merged$RNA_R, df_cor_merged$proteome_R),2)[[1]]
  df_cor_merged$density <- get_density(df_cor_merged$RNA_R, df_cor_merged$proteome_R, n = 80)
  
  F4d <- ggplot(df_cor_merged, aes(RNA_R, proteome_R)) +
    geom_hline(yintercept = 0, size=.8, color="#878787") +
    geom_segment(aes(x=0, y=-.355 , xend=0, yend=.85), color="#878787", size=.8) +
    geom_point(aes(color = density)) +
    scale_x_continuous(breaks = seq(-.25,1,.25), labels = seq(-.25,1,.25), limits = c(-.355,1)) +
    scale_y_continuous(breaks = seq(-.25,1,.25), labels = seq(-.25,1,.25), limits = c(-.355,1)) +
    xlab("Pearson R, mRNA") +
    ylab("Pearson R, protein") +
    theme_classic() +
    annotate("text", x=-.35, y=1, label=paste("R= ", jnk), hjust=0, size=2)+
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.9,0.2),
          legend.key.size = unit(0.15, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_text(size=7, face ="bold")) +
    scale_color_viridis()
  

  # F4e shall be the EF7c so remake here ###########################################
  experiments_meta <- readRDS("ExtFigure_7_b_meta_DATA.rds")
  
  experiments_meta$Label <- FALSE
  experiments_meta$Label[experiments_meta$genesRegulated_protein_overlap > 450] <- TRUE  
  
  pombeGN <- read.delim("20200701_Spombe_genename.txt")
  
  experiments_meta <- merge(experiments_meta, pombeGN, by=1, all.x=T)
  
  
  F4e <- ggplot(experiments_meta, aes(genesRegulated_RNA_overlep, genesRegulated_protein_overlap))+
    theme_classic()+
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.key.width = unit(0.2, "cm"),
          legend.key.height = unit(0.35, "cm"),
          legend.text = element_text(size=6, vjust = 1),
          legend.title = element_text(size=7, vjust = 0, hjust = 0, face="bold"),
          legend.position = c(0.9,0.4),
          legend.box = "horizontal",
          legend.background = element_blank()) +
    geom_point(aes(color=FC_cor), size=1.5) +
    xlab("Number of\naltered mRNA") +
    ylab("Number of\naltered protein") +
    xlim(0,600) +
    scale_color_gradient2(high= "#cb181d", mid= "#fed976", low = "#238b45", midpoint = 0.0, guide_legend(title = "Pearson R"),
                          breaks = c(-.2,0,.2,.4,.6), limits = c(-.3,.6)) +
    geom_text_repel(data=subset(experiments_meta, Label == TRUE), aes(label=Gene.name), size=2, min.segment.length = 0)
  
  # Figure 4 put together ###########################################################################################
  p <- ggplot() +
    theme_blank()
  F4a_combined <- ggarrange(F4a, F4b, nrow = 2, ncol = 1)
  
  # F4 <- ggarrange(ggarrange(F4a_combined, labels = "a"),
  #                 ggarrange(F4d, F4e, nrow = 2, ncol = 1, labels = c("b", "c")),
  #                 ncol = 2)
  # 
  F4 <- ggarrange(p, F4d, F4e, ncol=3, labels = c("a","b", "c"))
  
  
  F4ann <- annotate_figure(F4, bottom = text_grob("�zt�rk et al, Figure 4  ", hjust=1, x=1, size=10))
  
  ggsave("Figure_4.pdf", F4ann, dpi = 300, units = "cm", width = 18, height = 6)
  ggsave("Figure_4a.png", F4a_combined, dpi = 300, units = "cm", width = 6, height = 6)
}

if(ExtendedFigure5){
  # EF5 a # which strains based on their number of proteins regulated in the screen ###############################
  my94genes <- read.delim("E:/Merve/20190424_FinalDatasets/94_strains_replicates.txt", header = F)
  my94genes <- my94genes$V1
  
  df_melt <- readRDS("ExtFigure_2_bc_koNtarget_DATA.rds")
  
  df_melt$new <- 33
  df_melt$Xlabel <- ">3200"
  for (i in 32:1) {
    df_melt$new[df_melt$Score_pFDR_05 <= i*100] <- i
    df_melt$Xlabel[df_melt$Score_pFDR_05 <= i*100] <- paste(((i-1)*100)+1, "-", i*100, sep="")
  }
  
  df_melt <- df_melt %>%
    group_by(new) %>%
    dplyr::mutate(minpG = min(Regulated_pFDR_05),
                  maxpG = max(Regulated_pFDR_05),
                  meanZscore_fc = mean(Zscore_fc)) %>%
    as.data.frame()
  
  
  df_melt$Xlabel <- factor(df_melt$Xlabel,
                           levels = unique(df_melt$Xlabel[order(df_melt$new, decreasing = F)]))
  
  df_melt2 <- as.data.frame(unique(remove.factors(df_melt[,c(32:36)])))
  df_melt2$pGLabel <- paste(df_melt2$minpG, "-", df_melt2$maxpG, sep="")
  
  df_melt3 <- df_melt
  df_melt3$Picked <- FALSE
  df_melt3$Picked[df_melt$SytemicID %in% my94genes] <- TRUE
  
  
  df_melt3 <- remove.factors(df_melt3)
  df_melt3$Xlabel[df_melt3$Xlabel != "1-100" & df_melt3$Xlabel != "101-200" & df_melt3$Xlabel != "201-300" & df_melt3$Xlabel != "301-400"] <- ">400"
  
  df_melt3$Xlabel <- factor(df_melt3$Xlabel, levels = c("1-100", "101-200", "201-300", "301-400", ">400"))
  
  df_melt4 <- as.data.frame(table(df_melt3$Xlabel[df_melt3$Picked == TRUE]))
  names(df_melt4) <- c("Xlabel", "n")
  df_melt4 <- df_melt4[df_melt4$n !=0, ]
  
  df_melt3$Regulated_pFDR_05 <- as.numeric(df_melt3$Regulated_pFDR_05)
  
  EF5a <- ggplot(df_melt3, aes(Xlabel, Regulated_pFDR_05)) +
    geom_boxplot(width=.8,outlier.shape = NA) +
#    geom_jitter(data=subset(df_melt3, Picked ==FALSE), size=.8, shape=1) +
    geom_jitter(data=subset(df_melt3, Picked ==TRUE), size=.9, shape=1, color="#cb181d") +
    theme_classic()+
    xlab("Knockout strains (binned)") +
    ylab("Number of\naltered proteins") +
    ylim(-1,700) +
    theme(axis.text.y=element_text(size=7),
          axis.text.x=element_text(size=7,face="bold", angle = 90),
          axis.title=element_text(size=8,face="bold")) +
    geom_text(data=df_melt4, aes(x= Xlabel, label=paste("n=", n)), y=660, size=3, hjust=0.5) +
    guides(fill=FALSE) 

  # EF5 b # which strains based on their GO ###############################
  jnkjnk <- readRDS("20210209_ExtendedFigure5b_Data.rds")
  
  EF5b <- ggplot(jnkjnk, aes(GO.term.name, Freq)) +
    geom_bar(stat = "identity", width=0.7, size=1.2, aes(fill=GO.term.name))+
    coord_flip() +
    theme_classic()+
    theme(legend.position="bottom") +
    xlab(NULL) +
    ylab("Number of knockout strains") +
    theme(axis.text = element_text(size=7),
          axis.title=element_text(size=8,face="bold")) +
    guides(fill=FALSE)+
    ylim(-.1,26) +
    geom_text(aes(label=paste("n=", Freq)), y=22, size=3, hjust=0)

  # EF5 c # replicates cor to screen ###############################
  cor_unique <- readRDS("EF5c_new_DATA_20201211.rds")
  meanR2plot <- round(mean(cor_unique$Replicate_normMean),2)
  
  EF5c <- ggplot(cor_unique, aes(Replicate_normMean))+
    geom_histogram(color="#000000", fill="#f0f0f0", bins = 50) +
    guides(color=FALSE) +
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=0.05) +
    geom_rug(sides="b") +
    xlab("Pearson R, screen - replicates") +
    ylab("Count") +
    theme(axis.text=element_text(size=7),
          axis.title=element_text(size=8,face="bold")) +
    scale_x_continuous(breaks = c(0,.25,.5,.75,1), labels = c(0,.25,.5,.75,1), limits = c(0,1)) +
    annotate("text", x=0, y=21, label="n = 94", hjust=0, size=2) +
    geom_vline(xintercept = meanR2plot, color="#b2182b") +
    annotate("text", x=0.8, y=21, label="mean = 0.84", hjust=1, size=2, color="#b2182b")

      
  # EF5 d # heatmap from F4c yesterday more colored and squared ###############################
  df_cor_protein_cor_lower <- readRDS("20210209_ExtendedFigure5d_proteinLower_Data.rds")
  df_cor_RNA_cor_upper <- readRDS("20210209_ExtendedFigure5d_RNAupper_Data.rds")
  
  EF5d <- ggplot(df_cor_protein_cor_lower, aes(Var1, Var2)) +
    geom_tile(color="gray", aes(fill=value)) +
    geom_tile(data=df_cor_RNA_cor_upper, color="white", aes(fill=value)) +
    scale_fill_gradient2(low = "#084594", mid = "white", high="#b10026", midpoint = 0, limit=c(-1,1), name="Pearson R") +
    scale_color_gradient2(low = "#084594", mid = "white", high="#b10026", midpoint = 0, limit=c(-1,1), name="Pearson R") +
    theme_blank() +
    theme(axis.title = element_blank(), 
          axis.text.x = element_text(size=5, angle = 90, hjust=0),
          axis.text.y = element_text(size=5, hjust=0),
          axis.ticks = element_blank(),
          axis.line = element_blank(), 
          legend.key.width = unit(0.6, "cm"),
          legend.key.height = unit(0.2, "cm"),
          strip.text = element_text(size=7, vjust = 0),
          legend.title = element_text(size=7),
          legend.text = element_text(size=7),
          legend.position = "bottom",
          # legend.box = "horizontal",
          legend.background = element_blank(),
          strip.background = element_blank()) +
    scale_y_discrete(position = "left", expand = expand_scale(mult = c(0, .04))) +
    scale_x_discrete(expand = expand_scale(mult = c(0, .04))) +
    geom_segment(aes(x=0.5, y=94.5 , xend=94.2, yend=94.5), color="black") +
    geom_segment(aes(x=94.5, y=0.5 , xend=94.5, yend=94.2), color="black") +
    annotate("text", x=96, y=47, label="Proteome", size=3, angle=270) +
    annotate("text", x=47, y=96, label="Transcriptome", size=3)
  
  # EF 5ef # old EF7ab ########################################################
  # ExtendedFigure 7a # distribution of cors ################################################################
  experiments_meta <- readRDS("ExtFigure_7_b_meta_DATA.rds")
  
  EF5e <- ggplot(experiments_meta, aes(FC_cor))+
    geom_histogram(color="#000000", fill="#f0f0f0", bins = 20) +
    guides(color=FALSE) +
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=0.5) +
    geom_rug(sides="b") +
    xlab("Pearson R, fold change") +
    ylab("Number of strains") +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold")) +
    annotate("text", x=-.2, y=11, label="n = 94", hjust=0, size=3) +
    scale_y_continuous(breaks = c(0,5,10), labels = c(0,5,10))
  
  rm(experiments_meta)
  # ExtendedFigure 7b # good cor vs. bad cor ################################################################
  df_melt <- readRDS("ExtFigure_7_a_cor_DATA.rds")
  
  df_melt$example[df_melt$example == "bad correlation"] <- "Low correlation, SPAC22F8.11"
  df_melt$example[df_melt$example == "good correlation"] <- "High correlation, SPBC2F12.12c"
  
  df_good_cor <- round(cor(df_melt$FC_RNA[df_melt$example == "High correlation, SPBC2F12.12c"], 
                           df_melt$FC_protein[df_melt$example == "High correlation, SPBC2F12.12c"]),3)
  df_bad_cor <- round(cor(df_melt$FC_RNA[df_melt$example == "Low correlation, SPAC22F8.11"], 
                          df_melt$FC_protein[df_melt$example == "Low correlation, SPAC22F8.11"]),3)
#  df_melt$FC_RNA[df_melt$FC_RNA >= 1.95] <- 1.95
  
  df_cor <- as.data.frame(rbind(c("Low correlation, SPAC22F8.11", df_bad_cor), c("High correlation, SPBC2F12.12c", df_good_cor)))
  names(df_cor) <- c("example", "coR")
  df_cor$FC_RNA <- -1.9
  df_cor$FC_protein <- 1.5
  
  
  EF5f <- ggplot(df_melt, aes(FC_RNA, FC_protein)) +
    geom_hline(yintercept = 0, size=.9) +
    geom_vline(xintercept = 0, size=.9) +
    geom_point(alpha=.7) +
    facet_grid(. ~ example) +
    scale_x_continuous(breaks = c(-2,0,2), labels = c(-2,0,2)) +
    scale_y_continuous(breaks = c(-1,0,1), labels = c(-1,0,1)) +
    xlab("log2 (fold change), mRNA") +
    ylab("log2 (fold change), protein") +
    geom_smooth(method="lm") +
    theme_classic() +
    geom_text(data=df_cor, hjust=0, aes(label=paste0("R = ", coR)), size=3) +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          strip.text = element_text(size=8, face="bold", vjust = 1),
          strip.background = element_blank())
  # put together new EF5 ###############################################################
  EF5 <- ggarrange(ggarrange(EF5a, EF5b, EF5c, nrow = 1, ncol = 3, labels = c("a", "b", "c"), widths = c(1,1.2,1)),
                   ggarrange(EF5d, nrow = 1, ncol = 1, labels = "d", vjust = .85),
                   ggarrange(EF5e, EF5f, nrow=1, ncol = 2, labels = c("e","f"), widths = c(1,2)),
                   nrow = 3, heights=c(1,3,1))
  
  EF5ann <- annotate_figure(EF5, bottom = text_grob("�zt�rk et al, Extended Figure 5  ", hjust=1, x=1, size=10))
  
  ggsave("ExtendedFigure_5.pdf", EF5ann, dpi = 300, units = "cm", width = 24, height = 40)
}

if(Extendedfigure6){
  # ExtendedFigure 6 # replicates transcriptome #########################################
  # ExtendedFigure 6a # 3'end seq percentage read mapping and protein coding ############
  df <- readRDS("ExtFigure_6_a_mapped_DATA.rds")
  df1 <- df[df$IS_Assigned %in% c("Assigned", "Unassigned"),]
  df2 <- df[df$IS_Assigned %in% c("protein_coding", "rRNA", "OTHER"),]
  
  F6a1 <- ggplot(df1, aes(Percentage))+
    geom_density(aes(fill=IS_Assigned, color=IS_Assigned, y=..scaled..), alpha=.6) +
    guides(color=FALSE) +
    theme_classic() +
    geom_hline(yintercept=0, colour="white", size=0.05) +
    geom_rug(sides="b", aes(color=IS_Assigned)) +
    xlab("Percentage of reads")+
    ylab("Scaled") +
    scale_y_continuous(breaks = c(0,.5,1), labels = c(0,.5,1)) +
    scale_x_continuous(breaks = c(0,25,50,75,100), limits = c(0,100)) +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.5,0.8),
          legend.background = element_blank(),
          legend.key.height = unit(0.2, "cm"),
          legend.key.width = unit(0.2, "cm"),
          legend.text = element_text(size=6),
          legend.spacing.y = unit(0.01, "cm"),
          legend.spacing.x = unit(0.05, "cm")) +
    scale_color_manual(values = c("#a50026", "#4575b4")) +
    scale_fill_manual(values = c("#a50026", "#4575b4"),
                      guide = guide_legend(direction = "vertical", byrow = TRUE,
                                           title = NULL, label.position = "right")) 
  F6a2 <- ggplot(df2, aes(Percentage))+
    geom_density(aes(fill=IS_Assigned, color=IS_Assigned, y=..scaled..), alpha=.6) +
    guides(color=FALSE) +
    theme_classic() +
    geom_hline(yintercept=0, colour="white", size=0.05) +
    geom_rug(sides="b", aes(color=IS_Assigned)) +
    xlab("Percentage of reads")+
    ylab("Scaled") +
    scale_y_continuous(breaks = c(0,.5,1), labels = c(0,.5,1)) +
    scale_x_continuous(breaks = c(0,25,50,75,100), limits = c(0,100)) +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.5,0.8),
          legend.background = element_blank(),
          legend.key.height = unit(0.2, "cm"),
          legend.key.width = unit(0.2, "cm"),
          legend.text = element_text(size=6),
          legend.spacing.y = unit(0.01, "cm"),
          legend.spacing.x = unit(0.05, "cm")) +
    scale_color_manual(values = c("#a6d96a", "#f46d43", "#313695")) +
    scale_fill_manual(values = c("#a6d96a", "#f46d43", "#313695"),
                      guide = guide_legend(direction = "vertical", byrow = TRUE,
                                           title = NULL, label.position = "right")) 
  rm(df)
  # ExtendedFigure 6c # filtering low abundance #########################################
  df_melt <- readRDS("ExtFigure_6_b_filtered_DATA.rds")
  
  F6c <- ggplot(df_melt, aes(value))+
    geom_density(aes(color=position, y=..scaled..), alpha=.6) +
    guides(color=FALSE) +
    theme_classic() +
    geom_hline(yintercept=0, colour="white", size=0.05) +
    geom_vline(xintercept = quantile(df_melt$value, 0.25)[[1]], color="#878787", linetype="dashed") +
    # geom_rug(sides="b", aes(color=position)) +
    xlab("log2 (CPM)")+
    ylab("Scaled") +
    scale_y_continuous(breaks = c(0,.5,1), labels = c(0,.5,1)) +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"))
  rm(df_melt)
  # ExtendedFigure 6d # correlation, protein coding genes, replicate-plate ##############
  df_cor <- readRDS("ExtFigure_6_c_cor_DATA.rds")
  df_cor_melt <- df_cor[,c(3,8,9)]
  df_cor_melt <- melt(df_cor_melt, "value")
  names(df_cor_melt) <- c("cor", "comparison", "category")
  df_cor_melt <- remove.factors(df_cor_melt)
  
  df_cor_melt$category_2 <- df_cor_melt$category
  
  df_cor_melt$category[df_cor_melt$comparison == "Plate" & df_cor_melt$category == FALSE] <- "Different\nPlate"
  df_cor_melt$category[df_cor_melt$comparison == "Plate" & df_cor_melt$category == TRUE] <- "Same\nPlate"
  
  df_cor_melt$category[df_cor_melt$comparison == "Replicate" & df_cor_melt$category == FALSE] <- "Not\nReplicates"
  df_cor_melt$category[df_cor_melt$comparison == "Replicate" & df_cor_melt$category == TRUE] <- "Replicates"
  
  jnk <- as.data.frame(table(df_cor_melt[,2:4]))
  jnk <- jnk[jnk$Freq != 0,]
  
  df_cor_melt$category <- factor(df_cor_melt$category, 
                                 levels = c("Different\nPlate", "Same\nPlate",
                                            "Not\nReplicates", "Replicates"))
  
  my_comparisons <- list(c("Different\nPlate", "Same\nPlate"),
                         c("Not\nReplicates", "Replicates"))
  
  F6d <- ggplot(df_cor_melt, aes(x=category, y=cor))+
    geom_violin(aes(fill = category_2)) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() +
    stat_compare_means(comparisons = my_comparisons,label.x = 1, label.y = 1, size = 2) +
    xlab(NULL) +
    ylab("Pearson R") +
    theme(axis.text.y=element_text(size=7,face="bold"),
          axis.text.x=element_text(size=8,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    ylim(0.85,1.01) +
    geom_text(data=jnk, aes(label=paste("n = ",Freq)), y=0.85, size=2) +
    scale_fill_manual(values=c("#2166ac", "#b2182b")) +
    guides(fill=FALSE) +
    annotate("text", x=2.12, y=1.01, label="Wilcoxon", hjust=0, size=2)
    
  
  rm(df_cor)
  rm(df_cor_melt)
  rm(jnk)
  # ExtendedFigure 6e # counts after filtering for protein coding genes #################
  ko_count <- readRDS("ExtFigure_6_d_count_DATA.rds")
  
  jnk <- as.data.frame(table(ko_count$Replicate_measured_count))
  
  F6e <- ggplot(ko_count, aes(as.factor(Replicate_measured_count), pG_count))+
#    geom_hline(yintercept = median(ko_count$pG_count[ko_count$Replicate_measured_count == 4]), color="#878787", linetype="dashed") + # 4694
    geom_violin(aes(fill = as.factor(Replicate_measured_count))) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() +
    xlab(paste("Number of", "\n", "replicates (n = 94)")) +
    ylab(paste("Number of","\n" , "transcripts")) +
    theme(axis.text=element_text(size=6,face="bold"),
          axis.title=element_text(size=8,face="bold"),
          strip.text = element_blank(),
          strip.background = element_blank()) +
    scale_fill_brewer(type = "div", palette = "RdBu") +
    guides(fill=FALSE)
  
  rm(jnk)
  rm(ko_count)
  
  # ExtendedFigure 6f # FC p-value tile #################################################
  my_comparisons <- readRDS("ExtFigure_6_e_FDR_DATA.rds")
  my_comparisons$FDR_4_8 <- my_comparisons$FDR_4_8 / 100
  
  F6f <- ggplot(my_comparisons, aes(FC, p))+
    geom_tile(aes(fill=FDR_4_8)) +
    geom_tile(data=subset(my_comparisons, candidateCutOff == TRUE),aes(fill=FDR_4_8),color="black") +
    geom_text(data=subset(my_comparisons, candidateCutOff == TRUE), label= "X", size=4)+
    theme_classic() +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          # legend.position = "bottom",
          legend.position = "right",
          legend.background = element_blank(),
          legend.key.width = unit(0.15, "cm"),
          legend.key.height = unit(0.5, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_text(size = 7, face="bold"),
          legend.direction = "vertical") +
    scale_fill_gradient(low = "gray90", high = "gray40" ,guide_legend(title = "FDR")) +
    xlab("|log2 (fold change)|") +
    ylab("p-value") +
    scale_x_discrete(breaks=c(0,.6,1,1.5,2))

  rm(my_comparisons)
  # ExtendedFigure 6gi # heatmap for the RNA targets ####################################
  df <- readRDS("ExtFigure_6_f_cluster_DATA.rds")
  df$ColumnOrder <- as.numeric(df$ColumnOrder)
  
  jnk2 <- as.data.frame(unique(df[,c(2,5)]))
  jnk2 <- jnk2[order(jnk2$ColumnOrder),]
  
  df <- df %>%
    group_by(clusterNumber) %>%
    dplyr::mutate(mean_cluster=mean(value)) %>%
    as.data.frame()
  
  jnk3 <- as.data.frame(unique(df[,c(1,7)]))
  jnk3 <- jnk3[order(jnk3$mean_cluster),]
  jnk3$NewClusterNumber <- 10:1
  jnk3$NewRow <- 1:10
  
  df <- merge(df, jnk3, by=1)
  
  jnk <- as.data.frame(unique(df[,c(1,4,9,10)]))
  jnk2 <- as.data.frame(unique(df[,c(2,5)]))
  jnk3 <- as.data.frame(unique(df[,c(10,7)]))
  names(jnk3)[2] <- "mean_value"
  jnk2 <- remove.factors(jnk2)
  
  F6g <-  ggplot(df, aes(ColumnOrder, NewRow)) +
    geom_tile(aes(fill=value)) +
    geom_tile(data=jnk3, aes(x=96, fill=mean_value, y= NewRow)) +
    theme_blank() +
    scale_fill_gradient2(low="#2b83ba", mid="#ffffbf",high="#bd0026", midpoint = 0, guide_legend(title = "Score")) +
    geom_text(data=jnk, x=-1.5, aes(y=NewRow, label=NewClusterNumber), hjust=0, size=2.5)+
    annotate("text", x=-1.2, y=10.6, label="Cluster", hjust=0, size=2.5, angle=90)+
    annotate("text", x=98, y=10.6, label="Size", hjust=0, size=2.5, angle=90)+
    annotate("text", x=96, y=10.6, label="Mean (score)", hjust=0, size=2.5, angle=90)+
    geom_text(data=jnk, x=97.5, aes(y=NewRow, label=Size), hjust=0, size=2.5)+
    geom_text(data=jnk2, y=10.6, aes(x=ColumnOrder, label=variable), hjust=0, size=1.6, angle=90)+
    ylim(0,15) +
    xlim(-1.5,98) +
    theme(axis.title = element_blank(), 
          axis.text = element_blank(),
          axis.ticks = element_blank(),
          legend.key.width = unit(0.4, "cm"),
          legend.key.height = unit(0.2, "cm"),
          legend.text = element_text(size=6, vjust = 1),
          legend.title = element_text(size=7, hjust = 1),
          legend.position = c(0.8,0.018),
          legend.box = "horizontal",
          legend.background = element_blank(),
          legend.direction = "horizontal",
          strip.text = element_text(size=3.5, vjust = 0),
          strip.background = element_blank()) 
  rm(df)
  rm(jnk)
  rm(jnk2)

  # ExtendedFigure 6h # Gene ontology up cluster #2 &10    ###########################
  GOfiles_jnk <- readRDS("ExtFigure_6_g_Top20BPMFtermsGO_DATA.rds")
  GOfiles_jnk$Term <- factor(GOfiles_jnk$Term, 
                             levels = GOfiles_jnk$Term[order(GOfiles_jnk$GOcategory, GOfiles_jnk$fold.Enrichment., decreasing = T)])
  GOfiles_jnk <- GOfiles_jnk[with(GOfiles_jnk, order(fold.Enrichment., decreasing = F)), ]
  GOfiles_jnk$FDRcheck <- formatC(GOfiles_jnk$FDR., format = "e", digits = 1)
  GOfiles_jnk <- remove.factors(GOfiles_jnk)
  
  GOfiles_jnk$Term[16] <- "response to pheromone triggering conjugation ...*"
  GOfiles_jnk$Term[19] <- "signal transduction involved in ...**"
  GOfiles_jnk$Term[20] <- "pheromone-dependent signal transduction ...***"
  
  GOfiles_jnk$l2FC <- log2(GOfiles_jnk$fold.Enrichment.)
  mybreaks <- c(-2,0,2,4)
  
  GOfiles_jnk$Term <- factor(GOfiles_jnk$Term, 
                             levels = GOfiles_jnk$Term[order(GOfiles_jnk$fold.Enrichment., decreasing = F)])
  
  
  F6h <- ggplot(GOfiles_jnk, aes(Term, as.numeric(l2FC))) +
    geom_hline(yintercept = mybreaks, color="#878787") +
    geom_bar(stat = "identity", fill="#a50026", width=0.7, size=1.2)+
    geom_text(aes(x= Term, label=FDRcheck), y=4.3, hjust=0, size=2)+
    coord_flip() +
    theme_classic()+
    theme(legend.position="bottom") +
    xlab(NULL) +
    ylab("log2 (fold enrichment), Cluster: 1 & 2") +
    labs(fill = "FDR corrected p-value")+
    scale_y_continuous(breaks=mybreaks, limits = c(-2.5,6.2))+
    guides(fill=FALSE) +
    theme(axis.text = element_text(size = 6),
          axis.title=element_text(size=6,face="bold")) 
  
  # ExtendedFigure 6i # Gene ontology down cluster #6 & 7 ##########################
  GOfiles_jnk <- readRDS("ExtFigure_6_h_Top20BPMFtermsGO_DATA.rds")
  
  GOfiles_jnk$Term <- factor(GOfiles_jnk$Term, 
                             levels = GOfiles_jnk$Term[order(GOfiles_jnk$GOcategory, GOfiles_jnk$fold.Enrichment., decreasing = T)])
  GOfiles_jnk <- GOfiles_jnk[with(GOfiles_jnk, order(fold.Enrichment., decreasing = F)), ]
  GOfiles_jnk$FDRcheck <- formatC(GOfiles_jnk$FDR., format = "e", digits = 1)
  GOfiles_jnk$Term <- gsub("process$", "p.", GOfiles_jnk$Term)
  
  GOfiles_jnk$l2FC <- log2(GOfiles_jnk$fold.Enrichment.)
  
  mybreaks <- c(-6,-3,0,3)
  
  GOfiles_jnk$Term <- factor(GOfiles_jnk$Term, 
                             levels = GOfiles_jnk$Term[order(GOfiles_jnk$fold.Enrichment., decreasing = F)])
  
  
  F6i <- ggplot(GOfiles_jnk, aes(Term, as.numeric(l2FC))) +
    geom_hline(yintercept = mybreaks, color="#878787") +
    geom_bar(stat = "identity", fill="#4575b4", width=0.7, size=1.2)+
    geom_text(aes(x= Term, label=FDRcheck), y=5.2, hjust=0, size=2)+
    coord_flip() +
    theme_classic()+
    theme(legend.position="bottom") +
    xlab(NULL) +
    ylab("log2 (fold enrichment), Cluster: 9 & 10") +
    labs(fill = "FDR corrected p-value")+
    scale_y_continuous(breaks=mybreaks, limits = c(-6.7,7.6))+
    guides(fill=FALSE) +
    theme(axis.text = element_text(size = 6),
          axis.title=element_text(size=6,face="bold")) 
  rm(GOfiles_jnk)
  rm(jnk3)
  # ExtendedFigure 6 # put together ################################################
  F6 <- ggarrange(ggarrange(F6a1, F6a2, F6c, F6d, nrow = 1, ncol = 4, labels = c("a", "b", "c", "d"),widths = c(1,1,1,1.6)),
                  ggarrange(F6e, F6f, nrow=1, ncol = 2, labels = c("e","f"), widths = c(2,5)),
                  ggarrange(F6g, nrow = 1, labels = c("g")),
                  ggarrange(F6h,F6i, nrow = 1, ncol = 2, labels = c("h","i")),
                  nrow = 4, heights = c(1,1,1.3,1.1))
  
  F6ann <- annotate_figure(F6, bottom = text_grob("�zt�rk et al, Extended Figure 6   ", hjust=1, x=1, size=10))
  
  
  ggsave("ExtendedFigure_6.pdf", F6ann, dpi = 300, units = "cm", width = 18, height = 22)
}

if(Extendedfigure7){
  # ExtendedFigure 5 # replicates proteome #########################################
  # ExtendedFigure 5ab # normalization effect for the proteome replicates ##########################
  # ExtendedFigure 5a # cor before normalization ##########################
  df_cor <- readRDS("ExtFigure_5_a_cor_DATA.rds")
  df_cor <- remove.factors(df_cor)
  df_cor_melt <- df_cor[,c(3,12:15)]
  df_cor_melt <- melt(df_cor_melt, "value")
  names(df_cor_melt) <- c("cor", "comparison", "category")
  df_cor_melt <- remove.factors(df_cor_melt)
  # df_cor_melt$category[df_cor_melt$category == TRUE] <- "Same"
  # df_cor_melt$category[df_cor_melt$category == FALSE] <- "Not"
  df_cor_melt$comparison[df_cor_melt$comparison == "MS_run"] <- "MS run"
  df_cor_melt$comparison[df_cor_melt$comparison == "TMT_label"] <- "TMT label"
  
  df_cor_melt$category_2 <- df_cor_melt$category
  # change the labels for plot
  df_cor_melt$category[df_cor_melt$comparison == "MS run" & df_cor_melt$category == FALSE] <- "Different\nMS run"
  df_cor_melt$category[df_cor_melt$comparison == "MS run" & df_cor_melt$category == TRUE] <- "Same\nMS run"
  
  df_cor_melt$category[df_cor_melt$comparison == "Plate" & df_cor_melt$category == FALSE] <- "Different\nplate"
  df_cor_melt$category[df_cor_melt$comparison == "Plate" & df_cor_melt$category == TRUE] <- "Same\nplate"
  
  df_cor_melt$category[df_cor_melt$comparison == "Replicate" & df_cor_melt$category == FALSE] <- "Not\nreplicates"
  df_cor_melt$category[df_cor_melt$comparison == "Replicate" & df_cor_melt$category == TRUE] <- "Replicates"
  
  df_cor_melt$category[df_cor_melt$comparison == "TMT label" & df_cor_melt$category == FALSE] <- "Different\nTMT label"
  df_cor_melt$category[df_cor_melt$comparison == "TMT label" & df_cor_melt$category == TRUE] <- "Same\nTMT label"
  
  df_cor_melt <- remove.factors(df_cor_melt)
  names(df_cor_melt)[1] <- "my_cor"
  df_cor_melt$my_cor <- as.numeric(df_cor_melt$my_cor)
  jnk <- as.data.frame(table(df_cor_melt[,2:4]))
  jnk <- jnk[jnk$Freq != 0,]
  

  df_cor_melt$category <- factor(df_cor_melt$category, 
                                 levels = c("Different\nplate", "Same\nplate",
                                            "Different\nMS run", "Same\nMS run",
                                            "Different\nTMT label", "Same\nTMT label",
                                            "Not\nreplicates", "Replicates"))
                                   
  my_comparisons <- list(c("Different\nMS run", "Same\nMS run"),
                         c("Different\nplate", "Same\nplate"),
                         c("Not\nreplicates", "Replicates"),
                         c("Different\nTMT label", "Same\nTMT label"))
  
  F5a <- ggplot(df_cor_melt, aes(x=category, y=my_cor))+
    geom_violin(aes(fill = category_2)) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() +
    stat_compare_means(comparisons = my_comparisons,label.x = 1, label.y = 1.02, size = 2) +
    xlab("Before normalization") +
    ylab("Pearson R") +
    theme(axis.text=element_text(size=7,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    scale_y_continuous(breaks = c(.6,.7,.8,.9,1), limits = c(0.55,1.08)) +
    geom_text(data=jnk, aes(label=paste("n = ",Freq)), y=0.55, size=2) +
    scale_fill_manual(values=c("#2166ac", "#b2182b")) +
    guides(fill=FALSE) +
    annotate("text", x=c(1.25,3.25,5.25,7.25), y=1.08, label="Wilcoxon", hjust=0, size=2)
  
  # ExtendedFigure 5b # cor after normalization ##########################
  df_cor <- readRDS("ExtFigure_5_b_cor_DATA.rds")
  df_cor <- remove.factors(df_cor)
  df_cor_melt <- df_cor[,c(3,12:15)]
  df_cor_melt <- melt(df_cor_melt, "value")
  names(df_cor_melt) <- c("cor", "comparison", "category")
  df_cor_melt <- remove.factors(df_cor_melt)
  # df_cor_melt$category[df_cor_melt$category == TRUE] <- "Same"
  # df_cor_melt$category[df_cor_melt$category == FALSE] <- "Not"
  df_cor_melt$comparison[df_cor_melt$comparison == "MS_run"] <- "MS run"
  df_cor_melt$comparison[df_cor_melt$comparison == "TMT_label"] <- "TMT label"
  
  df_cor_melt$category_2 <- df_cor_melt$category
  # change the labels for plot
  df_cor_melt$category[df_cor_melt$comparison == "MS run" & df_cor_melt$category == FALSE] <- "Different\nMS run"
  df_cor_melt$category[df_cor_melt$comparison == "MS run" & df_cor_melt$category == TRUE] <- "Same\nMS run"
  
  df_cor_melt$category[df_cor_melt$comparison == "Plate" & df_cor_melt$category == FALSE] <- "Different\nplate"
  df_cor_melt$category[df_cor_melt$comparison == "Plate" & df_cor_melt$category == TRUE] <- "Same\nplate"
  
  df_cor_melt$category[df_cor_melt$comparison == "Replicate" & df_cor_melt$category == FALSE] <- "Not\nreplicates"
  df_cor_melt$category[df_cor_melt$comparison == "Replicate" & df_cor_melt$category == TRUE] <- "Replicates"
  
  df_cor_melt$category[df_cor_melt$comparison == "TMT label" & df_cor_melt$category == FALSE] <- "Different\nTMT label"
  df_cor_melt$category[df_cor_melt$comparison == "TMT label" & df_cor_melt$category == TRUE] <- "Same\nTMT label"
  
  df_cor_melt <- remove.factors(df_cor_melt)
  names(df_cor_melt)[1] <- "my_cor"
  df_cor_melt$my_cor <- as.numeric(df_cor_melt$my_cor)
  jnk <- as.data.frame(table(df_cor_melt[,2:4]))
  jnk <- jnk[jnk$Freq != 0,]
  
  
  df_cor_melt$category <- factor(df_cor_melt$category, 
                                 levels = c("Different\nplate", "Same\nplate",
                                            "Different\nMS run", "Same\nMS run",
                                            "Different\nTMT label", "Same\nTMT label",
                                            "Not\nreplicates", "Replicates"))
  
  my_comparisons <- list(c("Different\nMS run", "Same\nMS run"),
                         c("Different\nplate", "Same\nplate"),
                         c("Not\nreplicates", "Replicates"),
                         c("Different\nTMT label", "Same\nTMT label"))
  
  F5b <- ggplot(df_cor_melt, aes(x=category, y=my_cor))+
    geom_violin(aes(fill = category_2)) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() +
    stat_compare_means(comparisons = my_comparisons,label.x = 1, label.y = 1, size = 2) +
    xlab("After normalization") +
    ylab("Pearson R") +
    theme(axis.text=element_text(size=7,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    ylim(0.82,1.03) +
    geom_text(data=jnk, aes(label=paste("n = ",Freq)), y=0.82, size=2) +
    scale_fill_manual(values=c("#2166ac", "#b2182b")) +
    guides(fill=FALSE) +
    annotate("text", x=c(1.25,3.25,5.25,7.25), y=1.025, label="Wilcoxon", hjust=0, size=2)
  

  rm(df_cor)
  rm(df_cor_melt)
  rm(jnk)
  # ExtendedFigure 5c # how many protein groups in how many replicates ##########################
  ko_count <- readRDS("ExtFigure_5_c_countMeasured_DATA.rds")
  
  jnk <- as.data.frame(table(ko_count$Replicate_Count))
  my_yintecept <- c(median(ko_count$Measured[ko_count$Replicate_Count == 0]),
                    median(ko_count$Measured[ko_count$Replicate_Count == 3]),
                    median(ko_count$Measured[ko_count$Replicate_Count == 4]))
  
  F5c <- ggplot(ko_count, aes(Replicate_Count, Measured))+
    geom_hline(yintercept = median(ko_count$Measured[ko_count$Replicate_Count == 4]), color="#878787", linetype="dashed") +
    geom_violin(aes(fill = Replicate_Count)) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() +
    xlab("# Replicates (n = 94)") +
    ylab("# Proteins") +
    theme(axis.text=element_text(size=6,face="bold"),
          axis.title=element_text(size=8,face="bold")) +
    # geom_text(data = jnk, aes(x=Var1, label=paste("n = ",94)), y=230, size=2) +
    scale_fill_brewer(type = "div", palette = "RdBu") +
    guides(fill=FALSE)
  rm(jnk)
  rm(ko_count)
  # ExtendedFigure 5d # FC p-value tile ##########################
  my_comparisons <- readRDS("ExtFigure_5_d_FDR_DATA.rds")
  my_comparisons$FDR_4_8 <- my_comparisons$FDR_4_8 / 100
  F5d <- ggplot(my_comparisons, aes(FC, p))+
    geom_tile(aes(fill=FDR_4_8)) +
    geom_tile(data=subset(my_comparisons, candidateCutOff == TRUE),aes(fill=FDR_4_8),color="black") +
    geom_text(data=subset(my_comparisons, candidateCutOff == TRUE), label= "X", size=4)+
    theme_classic() +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          # legend.position = "bottom",
          legend.position = "right",
          legend.background = element_blank(),
          legend.key.width = unit(0.15, "cm"),
          legend.key.height = unit(0.5, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_text(size = 7, face="bold"),
          legend.direction = "vertical") +
    scale_fill_gradient(low = "gray90", high = "gray40" ,guide_legend(title = "FDR")) +
    xlab("|log2 (fold change)|") +
    ylab("p-value") +
    scale_x_discrete(breaks=c(0,.1,.2,.3,.4,.5,.6,.7,.8,.9,1))
  rm(my_comparisons)
  # ExtendedFigure 5e # heatmap for the protein targets ##########################
  df <- readRDS("ExtFigure_5_e_cluster_DATA.rds")
  new_names <- read.delim("20200701_Spombe_genename.txt")
  new_names <- new_names[new_names$Gene.stable.ID %in% df$variable,] # 13 out of 94 does not have a name
  
  df$ColumnOrder <- as.numeric(df$ColumnOrder)

  jnk2 <- as.data.frame(unique(df[,c(2,5)]))
  jnk2 <- jnk2[order(jnk2$ColumnOrder),]
  
  df <- df %>%
    group_by(clusterNumber) %>%
    dplyr::mutate(mean_cluster=mean(value)) %>%
    as.data.frame()
  
  jnk3 <- as.data.frame(unique(df[,c(1,7)]))
  jnk3 <- jnk3[order(jnk3$mean_cluster),]
  jnk3$NewClusterNumber <- 10:1
  jnk3$NewRow <- 1:10
  
  df <- merge(df, jnk3, by=1)
  
  jnk <- as.data.frame(unique(df[,c(1,4,9,10)]))
  jnk2 <- as.data.frame(unique(df[,c(2,5)]))
  jnk3 <- as.data.frame(unique(df[,c(10,7)]))
  names(jnk3)[2] <- "mean_value"
  jnk2 <- remove.factors(jnk2)
  F5e <- ggplot(df, aes(ColumnOrder, NewRow)) +
    geom_tile(aes(fill=value)) +
    geom_tile(data=jnk3, aes(x=96, fill=mean_value, y= NewRow)) +
    theme_blank() +
    scale_fill_gradient2(low="#2b83ba", mid="#ffffbf",high="#bd0026", midpoint = 0, guide_legend(title = "Score")) +
    geom_text(data=jnk, x=-1.5, aes(y=NewRow, label=NewClusterNumber), hjust=0, size=2.5)+
    annotate("text", x=-1.2, y=10.6, label="Cluster", hjust=0, size=2.5, angle=90)+
    annotate("text", x=98, y=10.6, label="Size", hjust=0, size=2.5, angle=90)+
    annotate("text", x=96, y=10.6, label="Mean (score)", hjust=0, size=2.5, angle=90)+
    geom_text(data=jnk, x=97.5, aes(y=NewRow, label=Size), hjust=0, size=2.5)+
    geom_text(data=jnk2, y=10.6, aes(x=ColumnOrder, label=variable), hjust=0, size=1.6, angle=90)+
    ylim(0,15) +
    xlim(-1.5,98) +
    theme(axis.title = element_blank(), 
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        legend.key.width = unit(0.4, "cm"),
        legend.key.height = unit(0.2, "cm"),
        legend.text = element_text(size=6, vjust = 1),
        legend.title = element_text(size=7, hjust = 1),
        legend.position = c(0.8,0.02),
        legend.box = "horizontal",
        legend.background = element_blank(),
        legend.direction = "horizontal",
        strip.text = element_text(size=3.5, vjust = 0),
        strip.background = element_blank()) 

  rm(df)
  rm(jnk)
  rm(jnk2)
  # ExtendedFigure 5f # Gene ontology up cluster #4     ###########################
  GOfiles_jnk <- readRDS("ExtFigure_5_f_Top20BPMFtermsGO_DATA.rds")
  
  mybreaks <- c(0,1,2,3)
  GOfiles_jnk$Term <- factor(GOfiles_jnk$Term, 
                             levels = GOfiles_jnk$Term[order(GOfiles_jnk$GOcategory, GOfiles_jnk$fold.Enrichment., decreasing = T)])
  GOfiles_jnk <- GOfiles_jnk[with(GOfiles_jnk, order(fold.Enrichment., decreasing = F)), ]
  GOfiles_jnk$FDRcheck <- formatC(GOfiles_jnk$FDR., format = "e", digits = 1)
  GOfiles_jnk$Term <- gsub("process$", "p.", GOfiles_jnk$Term)
  GOfiles_jnk$Term[16] <- "oxidoreductase activity, ..."
  
  GOfiles_jnk$Term <- factor(GOfiles_jnk$Term, 
                             levels = GOfiles_jnk$Term[order(GOfiles_jnk$fold.Enrichment., decreasing = F)])
  
  F5f <- ggplot(GOfiles_jnk, aes(Term, log2(as.numeric(fold.Enrichment.)))) +
    geom_hline(yintercept = mybreaks, color="#878787") +
    geom_bar(stat = "identity", fill="#a50026", width=0.7, size=1.2)+
    geom_text(aes(x= Term, label=FDRcheck), y=4, hjust=0, size=2)+
    coord_flip() +
    theme_classic()+
    theme(legend.position="bottom") +
    xlab(NULL) +
    ylab("log2 (fold enrichment), Cluster: 1") +
    labs(fill = "FDR corrected p-value") +
    scale_y_continuous(breaks=mybreaks, limits = c(0,5))+
    guides(fill=FALSE) +
    theme(axis.text = element_text(size = 6),
          axis.title=element_text(size=8,face="bold")) 

  # ExtendedFigure 5g # Gene ontology down cluster #1   ############################
  GOfiles_jnk <- readRDS("ExtFigure_5_g_Top20BPMFtermsGO_DATA.rds")
  
  mybreaks <- c(0,-1,-2)
  GOfiles_jnk$Term <- factor(GOfiles_jnk$Term, 
                             levels = GOfiles_jnk$Term[order(GOfiles_jnk$GOcategory, GOfiles_jnk$fold.Enrichment., decreasing = T)])
  GOfiles_jnk <- GOfiles_jnk[with(GOfiles_jnk, order(fold.Enrichment., decreasing = F)), ]
  GOfiles_jnk$FDRcheck <- formatC(GOfiles_jnk$FDR., format = "e", digits = 1)
  GOfiles_jnk$Term <- gsub("process$", "p.", GOfiles_jnk$Term)
  GOfiles_jnk$Term <- factor(GOfiles_jnk$Term, 
                             levels = GOfiles_jnk$Term[order(GOfiles_jnk$fold.Enrichment., decreasing = F)])
  F5g <- ggplot(GOfiles_jnk, aes(Term, log2(as.numeric(fold.Enrichment.)))) +
    geom_hline(yintercept = mybreaks, color="#878787") +
    geom_bar(stat = "identity", fill="#4575b4", width=0.7, size=1.2)+
    geom_text(aes(x= Term, label=FDRcheck), y=0.1, size=2, hjust=0)+
    coord_flip() +
    theme_classic()+
    theme(legend.position="bottom") +
    xlab(NULL) +
    ylab("log2 (fold enrichment), Cluster: 10") +
    labs(fill = "FDR corrected p-value")+
    scale_y_continuous(breaks=mybreaks, limits = c(-2.6,1))+
    guides(fill=FALSE) +
    theme(axis.text = element_text(size = 6),
          axis.title=element_text(size=8,face="bold")) 
  rm(GOfiles_jnk)
  rm(jnk3)
  # ExtendedFigure 5 # put together ################################################
  F5 <- ggarrange(ggarrange(F5a, nrow = 1, labels = c("a")),
                  ggarrange(F5b, nrow = 1, labels = c("b")),
                  ggarrange(F5c,F5d, nrow = 1, ncol = 2, labels = c("c","d"), widths = c(2,5)),
                  ggarrange(F5e, nrow = 1, labels = c("e")),
                  ggarrange(F5f,F5g, nrow = 1, ncol = 2, labels = c("f","g")),
                  nrow = 5, heights = c(1,1,1,1.3,1.1))

  F5ann <- annotate_figure(F5, bottom = text_grob("�zt�rk et al, Extended Figure 7   ", hjust=1, x=1, size=10))
  
  ggsave("ExtendedFigure_7.pdf", F5ann, dpi = 300, units = "cm", width = 18, height = 26)
  }

if(Extendedfigure8){
  # ExtendedFigure 8 # replicates transcriptome proteome comparison #########################################
  # EF8 # calculate pairwise transcriptome proteome correlation for the genes measured #####################
  df_jnk <- read.delim("SupplementaryTableX_EF8ab.txt")
  # EF 8 ab examples for good and badd correlating genes ############################
  # ExtendedFigure 8a # distribution of cors ################################################################
  EF8a <- ggplot(df_jnk, aes(RNA_protein_cor))+
    geom_histogram(color="#000000", fill="#f0f0f0", bins = 80) +
    guides(color=FALSE) +
    theme_classic()+
    geom_hline(yintercept=0, colour="white", size=0.5) +
    geom_rug(sides="b") +
    xlab("Pearson R, mRNA vs. protein") +
    ylab("Number of genes") +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold")) +
    annotate("text", x=-1, y=60, label="n = 1,706", hjust=0, size=3) +
    xlim(-1,1)
  
  # ExtendedFigure 8b # volcano plot for significance ################################################################
  EF8b <- ggplot(df_jnk, aes(RNA_protein_cor, -log10(RNA_protein_cor_pvalue)))+
    geom_hline(yintercept = -log10(0.05), color="#878787", linetype="dashed") +
    geom_segment(aes(x=0, y=0 , xend=0, yend=36), color="#878787") +
    geom_point(aes(color=type)) +
    guides(color=FALSE) +
    theme_classic()+
    xlab("Pearson R, mRNA vs. protein") +
    ylab("-log10(p-value)") +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold")) +
    xlim(-1,1) +
    annotate("text", x = 0, y=40, size=2, label="Total = 1,706", hjust=0.5) +
    annotate("text", x = -.8, y=35, size=2, label="Negative = 90", hjust=0) +
    annotate("text", x = .8, y=35, size=2, label="Positive = 750", hjust=1) +
    scale_color_manual(values=c("#2166ac", "gray50", "#b2182b"))
  # ExtendedFigure 8cd # Gene ontology for negative ones ################################################################
  pombeBioMartGO <- read.delim("mart_export_Spombe_GO.txt")
  pombeBioMartGO <- subset(pombeBioMartGO, GO.term.accession != "")
  pombeBioMartGO <- as.data.frame(unique(pombeBioMartGO[,1:5]))
  pombeBioMartGO <- pombeBioMartGO[pombeBioMartGO$Gene.stable.ID %in% df_jnk$Gene_Of_Interest,]
  
  mygenelist_pos <- df_jnk$Gene_Of_Interest[df_jnk$type == "Positive cor"]
  mygenelist_neg <- df_jnk$Gene_Of_Interest[df_jnk$type == "Negative cor"]
  mygenelist_not <- df_jnk$Gene_Of_Interest[df_jnk$type == "Not significant"]
  
  myGOanalysisFUNCTION <- function(pombeBioMartGO, mygenelist){
    
    pombeBioMartGO_summary <- as.data.frame(unique(pombeBioMartGO[,2:5]))
    
    myGOterms <- unique(pombeBioMartGO$GO.term.accession)
    myBGgenes <- unique(pombeBioMartGO$Gene.stable.ID)
    
    pombeBioMartGO_mygenes <- pombeBioMartGO[pombeBioMartGO$Gene.stable.ID %in% mygenelist,]
    
    myContingencyTable <- as.data.frame(table(pombeBioMartGO$GO.term.accession))
    names(myContingencyTable) <- c("Term", "BGcount")
    myContingencyTable$BGcount_NOT <- length(myBGgenes) - myContingencyTable$BGcount
    
    
    myContingencyTable_jnk <- as.data.frame(table(pombeBioMartGO_mygenes$GO.term.accession))
    names(myContingencyTable_jnk) <- c("Term", "ENRcount")
    myContingencyTable_jnk$ENRcount_NOT <- length(mygenelist) - myContingencyTable_jnk$ENRcount
    
    
    myContingencyTable <- merge(myContingencyTable, myContingencyTable_jnk, by=1, all.x=TRUE)
    myContingencyTable[is.na(myContingencyTable)] <- 0
    
    myContingencyTable$Expected <- length(mygenelist) * (myContingencyTable$BGcount/ length(myBGgenes))
    myContingencyTable$FoldEnrichment <- myContingencyTable$ENRcount / myContingencyTable$Expected
    
    myContingencyTable$pValue <- NA
    myContingencyTable <- remove.factors(myContingencyTable)
    
    for (i in 1:dim(myContingencyTable)[1]) {
      jnk <- as.data.frame(rbind(c(myContingencyTable[i,2], myContingencyTable[i,4]),
                                 c(myContingencyTable[i,3], myContingencyTable[i,5])))
      
      myContingencyTable$pValue[i] <- fisher.test(jnk)$p.value
    }
    
    myContingencyTable$FDR <- p.adjust(myContingencyTable$pValue, "fdr", n=length(myContingencyTable$pValue))
    
    myContingencyTable <- merge(myContingencyTable, pombeBioMartGO_summary, by.x="Term", by.y="GO.term.accession")
    myContingencyTable$log2_FoldEnrichment <- log2(myContingencyTable$FoldEnrichment)
    return(myContingencyTable)
  }
  
  GO_pos <- myGOanalysisFUNCTION(pombeBioMartGO, mygenelist_pos)
  GO_pos$Category <- "Positive"
  GO_neg <- myGOanalysisFUNCTION(pombeBioMartGO, mygenelist_neg)
  GO_neg$Category <- "Negative"
  GO_not <- myGOanalysisFUNCTION(pombeBioMartGO, mygenelist_not)
  GO_not$Category <- "NotSignificant"
  
  # 8c #GO_significant <- as.data.frame(rbind(GO_pos, GO_neg, GO_not)) ###########################
  GO_significant <- as.data.frame(GO_neg)
  GO_significant <- GO_significant[GO_significant$pValue <= 0.05,]
  GO_significant <- GO_significant[GO_significant$log2_FoldEnrichment >0,]
 
  GO_significant$GO.term.name <- gsub("SSU-rRNA, 5.8S rRNA, LSU-rRNA", "*", GO_significant$GO.term.name)
   
  mybreaks <- c(0,2,4)
  GO_significant$Pcheck <- formatC(GO_significant$pValue, format = "e", digits = 1)
  
  GO_significant$GO.term.name <- factor(GO_significant$GO.term.name, 
                                        levels = unique(GO_significant$GO.term.name[order(GO_significant$Category, GO_significant$GO.domain, 
                                                                                          GO_significant$log2_FoldEnrichment, decreasing = F)]))
  
  EF8c <- ggplot(GO_significant, aes(GO.term.name, as.numeric(log2_FoldEnrichment))) +
    geom_hline(yintercept = mybreaks, color="#878787") +
    geom_bar(stat = "identity", width=0.7, size=1.2, aes(fill=GO.domain))+
    geom_text(aes(x= GO.term.name, label=Pcheck), y=4.5, size=2, hjust=0)+
    coord_flip() +
    theme_classic()+
    theme(legend.position="bottom") +
    xlab(NULL) +
    ylab("log2 (fold enrichment)") +
    facet_grid(Category ~ ., scales = "free", space = "free") +
    scale_y_continuous(breaks=mybreaks, limits = c(0,5)) +
    theme(axis.text = element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          title = element_text(size=8), 
          # legend.position = c(.15,.97),
          legend.position = "top",
          #          legend.background = element_blank(),
          legend.key.height = unit(0.2, "cm"),
          legend.key.width = unit(0.2, "cm"),
          legend.text = element_text(size=6),
          legend.spacing.y = unit(0.01, "cm"),
          legend.spacing.x = unit(0.05, "cm"),
          legend.title = element_blank(),
          strip.background = element_rect(fill = "#92c5de"))
  # 8d #GO_significant <- as.data.frame(rbind(GO_pos, GO_neg, GO_not)) #############################
  GO_significant <- as.data.frame(GO_pos)
  GO_significant <- GO_significant[GO_significant$pValue <= 0.05,]
  GO_significant <- GO_significant[GO_significant$log2_FoldEnrichment >0,]
  
  GO_significant$GO.term.name <- gsub("SSU-rRNA, 5.8S rRNA, LSU-rRNA", "*", GO_significant$GO.term.name)
  
  mybreaks <- c(0,2,4)
  GO_significant$Pcheck <- formatC(GO_significant$pValue, format = "e", digits = 1)
  
  GO_significant$GO.term.name <- factor(GO_significant$GO.term.name, 
                                        levels = unique(GO_significant$GO.term.name[order(GO_significant$Category, GO_significant$GO.domain, 
                                                                                          GO_significant$log2_FoldEnrichment, decreasing = F)]))
  
  EF8d <- ggplot(GO_significant, aes(GO.term.name, as.numeric(log2_FoldEnrichment))) +
    geom_hline(yintercept = mybreaks, color="#878787") +
    geom_bar(stat = "identity", width=0.7, size=1.2, aes(fill=GO.domain))+
    geom_text(aes(x= GO.term.name, label=Pcheck), y=4.5, size=2, hjust=0)+
    coord_flip() +
    theme_classic()+
    theme(legend.position="bottom") +
    xlab(NULL) +
    ylab("log2 (fold enrichment)") +
    facet_grid(Category ~ ., scales = "free", space = "free") +
    scale_y_continuous(breaks=mybreaks, limits = c(0,5)) +
    theme(axis.text = element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          title = element_text(size=8), 
          # legend.position = c(.15,.97),
          legend.position = "top",
          #          legend.background = element_blank(),
          legend.key.height = unit(0.2, "cm"),
          legend.key.width = unit(0.2, "cm"),
          legend.text = element_text(size=6),
          legend.spacing.y = unit(0.01, "cm"),
          legend.spacing.x = unit(0.05, "cm"),
          legend.title = element_blank(),
          strip.background = element_rect(fill = "#fc9272"))
  # ExtendedFigure 8 # put together ################################################
  p <- ggplot() +
    theme_blank()
  
  F8 <- ggarrange(ggarrange(EF8a, EF8b, nrow = 1, ncol = 2, labels = c("a", "b")),
                  ggarrange(EF8c, labels = c("c")),
                  ggarrange(p, EF8d, labels = c("d"), widths = c(1,2)),
                  nrow = 3, heights = c(1.5,4,1.2))
  
  F8ann <- annotate_figure(F8, bottom = text_grob("�zt�rk et al, Extended Figure 8   ", hjust=1, x=1, size=10))
  
  
  ggsave("ExtendedFigure_8.pdf", F8ann, 
         dpi = 300, units = "cm", width = 18, height = 22)
  
  
}

if(Extendedfigure9){
  # ExtendedFigure 9a # PCA for the clusters protein level and not at RNA level ##############
  df_melt <- readRDS("ExtFigure_7_d_PCA_DATA.rds")
  df_cluster <- read.delim("8_pamk_clusters_769.txt")
  names(df_cluster)[1] <- "UP1down2"
  
  df_pca <- as.data.frame(df_melt)
  df_pca[is.na(df_pca)] <- 0
  df.pca <- prcomp(df_pca, center = FALSE, scale. = FALSE) 
  
  jnk <- as.data.frame(df.pca$sdev)
  
  jnk <- as.data.frame(df.pca$x)
  jnk <- jnk[,1:2]
  jnk$pG <- rownames(jnk)
  
  jnk <- merge(jnk, df_cluster, by.x="pG", by.y="pG", all=FALSE)
  # jnk$UP1down2[jnk$UP1down2 == 1] <- "Upregulated"
  # jnk$UP1down2[jnk$UP1down2 == 2] <- "Downregulated"

  jnk$UP1down2[jnk$UP1down2 == 1] <- "Cluster 1"
  jnk$UP1down2[jnk$UP1down2 == 2] <- "Cluster 2"
  
  
  F9a<- ggplot(jnk, aes(PC1, PC2))+
    geom_point(aes(color=as.factor(UP1down2))) +
    stat_ellipse(aes(color=as.factor(UP1down2))) +
    theme_classic() +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.5,0.97),
          legend.background = element_blank(),
          legend.key.size = unit(0.3, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_blank(),
          legend.direction = "horizontal") +
    scale_color_manual(values=c("#b2182b", "#2166ac")) +
    ylim(-14,17) +
    annotate("text", x = -15, y=15, size=2, label="n = 769", hjust=1)
    
    
  rm(df_cluster)
  rm(df_melt)
  rm(df_pca)

  # ExtendedFigure 9b# now boxplot # heatmap of the targets regulated at protein level and not at RNA level ##############
  df_melt <- readRDS("ExtFigure_7_d_cluster_DATA.rds")
  df_melt$variable <- factor(df_melt$variable, 
                                 levels = unique(df_melt$variable[order(df_melt$difference, decreasing = T)]))
  df_melt$pamkluster[df_melt$pamkluster == "Up"] <- "Cluster 1 - Upregulated"
  df_melt$pamkluster[df_melt$pamkluster == "Down"] <- "Cluster 2 - Downregulated"
  
  df_jnk <- df_melt[,1:3]
  df_jnk <- dcast(df_jnk, variable ~ pamkluster)
  df_jnk$`Cluster 2 - Downregulated` <- df_jnk$`Cluster 2 - Downregulated` < 0
  df_jnk$`Cluster 1 - Upregulated` <- df_jnk$`Cluster 1 - Upregulated` > 0
  jnk <- as.data.frame(table(df_jnk[,2:3]))

  
  F9b <- ggplot(df_melt, aes(pamkluster, Av_cluster_strain))+
    geom_hline(yintercept = 0, color="#878787") +
    geom_violin(aes(fill=pamkluster), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() +
    xlab("Clusters") +
    ylab("Mean (score)") +
    theme(axis.text.x=element_text(size=7),
          axis.text.y = element_text(size=6),
          axis.title.x=element_blank(),
          axis.title.y=element_text(size=7,face="bold")) +
    guides(fill=F) +
    scale_fill_manual(values=c("#b2182b", "#2166ac")) +
    ylim(-3.5,4) +
    stat_compare_means(label.x = 1.4, label.y=3.5, size = 2) +
    annotate("text", x = .8, y=3.6, size=2, label="n = 94", hjust=1)
  
    
  rm(df_melt)
  
  # ExtendedFigure 9c # GO of the targets regulated at protein level and not at RNA level ###################
  GOfiles_jnk <- readRDS("ExtFigure_7_e_GO_DATA.rds")
  GOfiles_jnk$FDRcheck <- formatC(GOfiles_jnk$FDR., format = "e", digits = 1)
  GOfiles_jnk$l2FC <- as.numeric(log2(GOfiles_jnk$fold.Enrichment.))
  GOfiles_jnk$myhjust <- 1.49
  GOfiles_jnk$myhjust[sign(GOfiles_jnk$l2FC) == -1] <- -2.27
  
  GOfiles_jnk <- GOfiles_jnk %>%
    group_by(Term) %>%
    dplyr::mutate(TermOrderColumn = sum(abs(l2FC))) %>%
    as.data.frame()
  
  GOfiles_jnk$Term <- factor(GOfiles_jnk$Term, 
                             levels = unique(GOfiles_jnk$Term[order(GOfiles_jnk$TermOrderColumn, decreasing = F)]))
  
  mybreaks <- c(-2,-1,0,1)
  
  F9c <- ggplot(GOfiles_jnk, aes(Term, l2FC)) +
    geom_hline(yintercept = c(-2,-1,0,1), color="#878787") +
    geom_bar(stat = "identity", aes(fill=GOcategory), width=0.7, size=1.2)+
    coord_flip() +
    theme_classic()+
    theme(axis.text = element_text(size = 6),
          axis.title=element_text(size=6,face="bold"),
          legend.position = c(.58,.99),
          legend.background = element_rect(size=0),
          legend.key.height = unit(0.1, "cm"),
          legend.key.width = unit(0.2, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_blank(),
          legend.direction = "horizontal") +
    xlab(NULL) +
    ylab("log2 (fold enrichment)") +
    scale_y_continuous(breaks=mybreaks, limits = c(-2.31,1.55)) +
    geom_text(aes(x=Term, y=myhjust, label=FDRcheck), size=2) +
    scale_fill_manual(values=c("#2166ac", "#b2182b")) +
    guides(fill =FALSE)
  
  rm(GOfiles_jnk)
  # ExtendedFigure 8gh # codon figure ############################################
  # 9d # PCA ############################################################################
  only_RNA_not <- readRDS("ExtFigure_7_f_codonPCA_DATA.rds")
  
  res.pca <- prcomp(t(only_RNA_not), scale = F)

  df.pca <- prcomp(t(only_RNA_not), scale = F) 
  
  jnk <- as.data.frame(df.pca$sdev)
  
  jnk <- as.data.frame(df.pca$x)
  jnk <- jnk[,1:2]
  jnk$pG <- rownames(jnk)
  
  jnk$pG[grep("UP", jnk$pG)] <- "Upregulated"
  jnk$pG[grep("DOWN", jnk$pG)] <- "Downregulated"
  
  
  F9d<- ggplot(jnk, aes(PC1, PC2))+
    geom_point(aes(color=as.factor(pG)), size=2, alpha=.9) +
    stat_ellipse(aes(color=as.factor(pG))) +
    theme_classic() +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.5,0.97),
          legend.background = element_blank(),
          legend.key.size = unit(0.3, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_blank()) +
    scale_color_manual(values=c("#2166ac", "#b2182b"))
  # 9e # volcano ############################################################################
  ttest_results <- readRDS("ExtFigure_7_g_ttest_DATA.rds")
  ttest_results$aa.middle[is.na(ttest_results$aa.middle)] <- "*"
  ttest_results$mycolor <- ttest_results$FC > 1
  
  ttest_plot <- ggplot(ttest_results, aes(x=log2(FC),y=-log10(p.value))) +
    geom_hline(yintercept = 0, color="#878787")+
    geom_segment(aes(x=0, y=0 , xend=0, yend=38), color="#878787") +
    # geom_hline(yintercept = -log10(0.01), size=0.5, linetype = "dashed")+
    geom_point(aes(color=mycolor), size=3, alpha=0.9) +
    xlab("log2 (fold change)") +
    ylab("-log10 (p-value)") +
    theme_classic() +
    theme(axis.text=element_text(size=6),
          axis.title=element_text(size=8,face="bold"),
          legend.position = c(0.5,0.97),
          legend.background = element_blank(),
          legend.key.size = unit(0.3, "cm"),
          legend.text = element_text(size=6),
          legend.title = element_blank(),
          legend.direction = "horizontal") +
    scale_color_manual(values=c("#2166ac", "#b2182b"),name = "Regulation", labels = c("Downregulated", "Upregulated")) +
    geom_text_repel(data=subset(ttest_results, -log10(p.value)>=15),aes(color=mycolor, label=paste0(Var1,"\n",aa.middle)), size = 2) +
    xlim(-1.05,1) +
    ylim(-.5,40)
    
  
   
  
 RNA_not_spread <- readRDS("ExtFigure_7_g_volcano_DATA.rds")
  # TCT plot
  aa <- as.data.frame(RNA_not_spread[56,])
  temp <- unnest(aa, cols=c(DOWN,UP),names_repair = 'minimal')
  colnames(temp) <- c("codon","UP","Upregulated", "DOWN","Downregulated")
  
  vioplot_TCT <- melt(temp) %>% ggplot(aes(x=variable,y=value)) + 
    geom_violin(aes(fill=variable)) + 
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() + 
    labs(#title=unique(temp$codon), 
      x="",y="TCT %") + 
    theme(axis.text.x =element_blank(),
          axis.text.y = element_text(size=6),
          axis.title=element_text(size=8,face="bold")) +
    scale_fill_manual(values=c("#b2182b", "#2166ac")) +
    guides(fill=FALSE)
  
  # ATT plot
  aa <- as.data.frame(RNA_not_spread[16,])
  temp <- unnest(aa, cols=c(DOWN,UP),names_repair = 'minimal')
  colnames(temp) <- c("codon","UP","Upregulated", "DOWN","Downregulated")
  
  vioplot_ATT <- melt(temp) %>% ggplot(aes(x=variable,y=value)) + 
    geom_violin(aes(fill=variable)) + 
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() + 
    labs(#title=unique(temp$codon), 
      x="",y="ATT %") + 
    theme(axis.text.x =element_blank(),
          axis.text.y = element_text(size=6),
          axis.title=element_text(size=8,face="bold")) +
    scale_fill_manual(values=c("#b2182b", "#2166ac")) +
    guides(fill=FALSE)
  
  # Combine t-test and individual codon plots
  F9e <- ttest_plot + 
    annotation_custom(ggplotGrob(vioplot_TCT), xmin = -1.15, xmax = -0.67, ymin = 16, ymax = 41) + 
    annotation_custom(ggplotGrob(vioplot_ATT), xmin = .57, xmax = 1.05, ymin = 16, ymax = 41)
  # 9f # boxplots ############################################################################
  adjusted_table_for_stats <- readRDS("FiguresModified_20210116/20210116_ML/codon_boxplot_data.rds")
  adjusted_table_for_stats <- adjusted_table_for_stats[adjusted_table_for_stats$V2 == "optimal codons",]
  
  F9f <- ggplot(adjusted_table_for_stats, aes(Reason, value))+
    geom_hline(yintercept = 0, color="#878787") +
    geom_violin(aes(fill=Reason), width=1) +
    geom_boxplot(width=0.1,outlier.shape = NA) +
    theme_classic() +
    xlab("Clusters") +
    ggtitle("optimal codons") +
    ylab("Codon percentage \n (up - downregulated)") +
    theme(axis.text.x=element_text(size=8,face="bold"),
          axis.text.y = element_text(size=6),
          axis.title.x=element_blank(),
          axis.title.y=element_text(size=8,face="bold"),
          title = element_text(size=7)) +
    guides(fill=F) +
    scale_fill_manual(values=c("#fdae61", "#abdda4")) +
    stat_compare_means(label.x = 1.3, label.y=2, size = 2)
  # ExtendedFigure 9 # put together ################################################
  F9 <- ggarrange(ggarrange(F9a, F9b, nrow = 1, ncol = 2, labels = c("a","b")),
                  ggarrange(F9c, nrow=1, ncol = 1, labels = c("c")),
                  ggarrange(F9d, F9f, nrow = 1, labels = c("d","f")),
                  ggarrange(F9e, nrow=1, ncol = 1, labels = c("e")),
                  nrow = 4)
  
  F9ann <- annotate_figure(F9, bottom = text_grob("�zt�rk et al, Extended Figure 9   ", hjust=1, x=1, size=10))
  
  ggsave("ExtendedFigure_9.pdf", F9ann, 
         dpi = 300, units = "cm", width = 18, height = 24)
  
}
###############################################################################################