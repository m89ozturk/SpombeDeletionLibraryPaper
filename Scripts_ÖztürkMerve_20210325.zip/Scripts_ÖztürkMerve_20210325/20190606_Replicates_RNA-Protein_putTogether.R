options(stringsAsFactors=FALSE) #
.libPaths(c(.libPaths(), "U:/Merve/Rpackages")) 

# setwd("U:/Merve/AllinAll_Mrv_IMB/Project/R_Projects/2017_TMT_SpDelLib/20190424_FinalDatasets")
setwd("E:/Merve/20190424_FinalDatasets")
source("myFunctions.R")
source("extra_fun_LFQ.R")

out_dir <- "ReplicateRNAprotein/"
# 1 # load the libraries #######################################################################################
library(dplyr)
library(plotly)
library(tidyr)
library(knitr)
library(plyr)
library(reshape2)
library(ggplot2)
library(RColorBrewer)
library(parallel)
library(pcaMethods)
library(fBasics)
library(stats)
library(pvclust)
library(ggrepel)
library(cluster)
library(factoextra)
library(psych)
library(gridExtra)
library("ape")
library(ggpubr)
library(ggfortify)
library(broom)
library(data.table)
library(WGCNA)
library(e1071)
library(ggsignif)
library(corrplot)
library(GGally)
library(network)
library(sna)
library(igraph)
library(ggnetwork)
library(VennDiagram)
library(quantmod)
library(threejs)
library(crosstalk)
library(htmltools)
library(GOfuncR)
library(corrplot)
library(PerformanceAnalytics)
library(matrixTests)
library(stringr)
library(pheatmap)
library(taRifx)
library(Biostrings)
# 2 # decide on the targets at RNA and protein level #####################################################
myfile <- list.files(path = "ReplicateProteome/1U_MBR/", pattern = "meltALL_imputed_Keep")
df_protein <- readRDS(file.path("ReplicateProteome/1U_MBR/", myfile))
myfile <- list.files(path = "ReplicateTranscriptome/", pattern = "imputed_Keep.rds")
df_RNA <- readRDS(file.path("ReplicateTranscriptome/", myfile))
# 2.1 # decide from replicates which strains is targeting what with which p-fc ######
# proteins
df_imp <- df_protein[,c(3,5,18)]
df_imp <- dcast(df_imp, ProteinIDs ~ ReplicateID)
rownames(df_imp) <- df_imp$ProteinIDs
df_imp <- df_imp[,-1]

experiments <- unique(gsub(".*\\_(.*)\\_[0-9]", "\\1", names(df_imp)))
experiments <- experiments[-c(grep("wt", experiments))]
experiments <- c(experiments, "wt")
myconditions <- experiments

my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
rows2keep <- my_comparisons$V2 == "wt"
my_comparisons <- my_comparisons[rows2keep,]
my_comparisons$ComparisonSize <- NA

myPvalueCutOFF <- 0.03
myFCCutOFF <- 0.2
mydf_diffreg <- data.frame(KOstrain=character(),
                           pG=character(),
                           log2FC_Strain_wt=numeric(),
                           pvalue=numeric())

for (i in 1:dim(my_comparisons)[1]) {
  print(i)
  group1 <- my_comparisons$V1[i]
  group2 <- my_comparisons$V2[i]
  
  if(group1 %in% c("wt1","wt2")){
    group2Cols <- grep(group2, names(df_imp))
    
    df_group <- df_imp[,group2Cols]
    df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
    my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
    
    # original 
    group1Cols <- grep(group1, names(df_group))
    
    myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group, alternative = "two.sided", mu = 0, conf.level = 0.95)
    myPvalue <- myPvalue[,c(6,13)]
    myPvalue$pG <- rownames(myPvalue)
    myPvalue$KOstrain <- group1
    myPvalue <- myPvalue[,c(4,3,1,2)]
    names(myPvalue) <- names(mydf_diffreg)
    mydf_diffreg <- rbind(mydf_diffreg, myPvalue)
    rownames(mydf_diffreg) <- NULL
  } else {
    group1Cols <- grep(group1, names(df_imp))
    group2Cols <- grep(group2, names(df_imp))
    
    df_group <- df_imp[,c(group1Cols, group2Cols)]
    df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
    my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
    
    # original 
    group1Cols <- grep(group1, names(df_group))
    group2Cols <- grep(group2, names(df_group))
    
    myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
    myPvalue <- myPvalue[,c(6,13)]
    myPvalue$pG <- rownames(myPvalue)
    myPvalue$KOstrain <- group1
    myPvalue <- myPvalue[,c(4,3,1,2)]
    names(myPvalue) <- names(mydf_diffreg)
    mydf_diffreg <- rbind(mydf_diffreg, myPvalue)
    rownames(mydf_diffreg) <- NULL
  }
}

saveRDS(mydf_diffreg, file.path(out_dir, paste0("2_1_1_", Sys.Date(), "_replicateProteome_FC_pvalue.rds")))

rm(df_group)
rm(df_imp)
rm(df_protein)
rm(myPvalue)
rm(my_comparisons)
rm(mydf_diffreg)
# RNA
df_imp <- df_RNA[,c(1,3,16)]
df_imp <- dcast(df_imp, geneID ~ sample)
rownames(df_imp) <- df_imp$geneID
df_imp <- df_imp[,-1]

experiments <- unique(gsub(".*\\-(.*)\\_[0-9]", "\\1", names(df_imp)))
experiments <- experiments[-c(grep("wt", experiments))]
experiments <- c(experiments, "wt")
myconditions <- experiments

my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
rows2keep <- my_comparisons$V2 == "wt"
my_comparisons <- my_comparisons[rows2keep,]
my_comparisons$ComparisonSize <- NA

myPvalueCutOFF <- 0.005
myFCCutOFF <- 0.6
mydf_diffreg <- data.frame(KOstrain=character(),
                           pG=character(),
                           log2FC_Strain_wt=numeric(),
                           pvalue=numeric())

for (i in 1:dim(my_comparisons)[1]) {
  print(i)
  group1 <- my_comparisons$V1[i]
  group2 <- my_comparisons$V2[i]
  
  if(group1 %in% c("wt1","wt2")){
    group2Cols <- grep(group2, names(df_imp))
    
    df_group <- df_imp[,group2Cols]
    df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
    my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
    
    # original 
    group1Cols <- grep(group1, names(df_group))
    
    myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group, alternative = "two.sided", mu = 0, conf.level = 0.95)
    myPvalue <- myPvalue[,c(6,13)]
    myPvalue$pG <- rownames(myPvalue)
    myPvalue$KOstrain <- group1
    myPvalue <- myPvalue[,c(4,3,1,2)]
    names(myPvalue) <- names(mydf_diffreg)
    mydf_diffreg <- rbind(mydf_diffreg, myPvalue)
    rownames(mydf_diffreg) <- NULL
  } else {
    group1Cols <- grep(group1, names(df_imp))
    group2Cols <- grep(group2, names(df_imp))
    
    df_group <- df_imp[,c(group1Cols, group2Cols)]
    df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
    my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
    
    # original 
    group1Cols <- grep(group1, names(df_group))
    group2Cols <- grep(group2, names(df_group))
    
    myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
    myPvalue <- myPvalue[,c(6,13)]
    myPvalue$pG <- rownames(myPvalue)
    myPvalue$KOstrain <- group1
    myPvalue <- myPvalue[,c(4,3,1,2)]
    names(myPvalue) <- names(mydf_diffreg)
    mydf_diffreg <- rbind(mydf_diffreg, myPvalue)
    rownames(mydf_diffreg) <- NULL
  }
}

saveRDS(mydf_diffreg, file.path(out_dir, paste0("2_1_2_", Sys.Date(), "_replicateTranscriptome_FC_pvalue.rds")))

rm(df_group)
rm(df_imp)
rm(df_RNA)
rm(myPvalue)
rm(my_comparisons)
rm(mydf_diffreg)
# 2.2 # correlate the fold changes of RNA and protein per strain #########################
myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_protein <- readRDS(file.path(out_dir, myfile))
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))

experiments <- unique(df_RNA$KOstrain)

experiments_meta <- as.data.frame(experiments)
experiments_numbers <- as.data.frame(experiments)

experiments_meta$geneCount_RNA <- NA
experiments_meta$geneCount_protein <- NA
experiments_meta$geneCount_protein_split <- NA
experiments_meta$geneCount_overlap <- NA

experiments_meta$FC_cor <- NA

experiments_meta$genesRegulated_RNA <- NA
experiments_meta$genesRegulated_protein <- NA

experiments_meta$genesRegulated_RNA_overlep <- NA
experiments_meta$genesRegulated_protein_overlap <- NA

experiments_meta$genesRegulated_overlap <- NA
experiments_meta$genesRegulated_overlap_2 <- NA

experiments_meta$genesRegulated_overlap_sameDirection <- NA

# # check number of targets ####################################################################################
# mydf_prepare <- function(df_original, df_target, mypvalue=0.005, myfoldchange=0.6){
#   jnk <- as.data.frame(table(df_target$KOstrain))
#   names(jnk)[2] <- "GeneCount"
#   df_original <- merge(df_original, jnk, by.x="experiments", by.y="Var1")
#   df_target_jnk <- subset(df_target, abs(log2FC_Strain_wt)>=myfoldchange & pvalue<=mypvalue)
#   jnk <- as.data.frame(table(df_target_jnk$KOstrain))
#   names(jnk)[2] <- "TargetCount"
#   df_original <- merge(df_original, jnk, by.x="experiments", by.y="Var1")
#   df_target_jnk <- subset(df_target, log2FC_Strain_wt>=myfoldchange & pvalue<=mypvalue)
#   jnk <- as.data.frame(table(df_target_jnk$KOstrain))
#   names(jnk)[2] <- "TargetCount-UP"
#   df_original <- merge(df_original, jnk, by.x="experiments", by.y="Var1")
#   
#   df_target_jnk <- subset(df_target, log2FC_Strain_wt<= -myfoldchange & pvalue<=mypvalue)
#   jnk <- as.data.frame(table(df_target_jnk$KOstrain))
#   names(jnk)[2] <- "TargetCount-DOWN"
#   df_original <- merge(df_original, jnk, by.x="experiments", by.y="Var1")
#   
#   return(df_original)
# }
# 
# experiments_numbers_RNA <- mydf_prepare(experiments_numbers, df_RNA, mypvalue=0.005, myfoldchange=0.6)
# experiments_numbers_protein <- mydf_prepare(experiments_numbers, df_protein, mypvalue=0.03, myfoldchange=0.2)
# 
# names(experiments_numbers_RNA) <- paste(names(experiments_numbers_RNA), "_RNA", sep="")
# names(experiments_numbers_protein) <- paste(names(experiments_numbers_protein), "_protein", sep="")
# experiments_numbers <- merge(experiments_numbers_protein, experiments_numbers_RNA, by=1)
# names(experiments_numbers)[1] <- "KOstrain"
# rm(experiments_numbers_protein)
# rm(experiments_numbers_RNA)
# names(experiments_numbers) <- gsub("-", "_", names(experiments_numbers))
# 
# experiments_numbers$TargetPercent_UP_protein <- round(100*(experiments_numbers$TargetCount_UP_protein/experiments_numbers$TargetCount_protein),0)
# experiments_numbers$TargetPercent_DOWN_protein <- round(100*(experiments_numbers$TargetCount_DOWN_protein/experiments_numbers$TargetCount_protein),0)
# experiments_numbers$TargetPercent_UP_RNA <- round(100*(experiments_numbers$TargetCount_UP_RNA/experiments_numbers$TargetCount_RNA),0)
# experiments_numbers$TargetPercent_DOWN_RNA <- round(100*(experiments_numbers$TargetCount_DOWN_RNA/experiments_numbers$TargetCount_RNA),0)
# 
# p <- ggplot(experiments_numbers, aes(TargetPercent_UP_protein, TargetPercent_UP_RNA)) +
#   geom_point()+
#   geom_vline(xintercept = 50)+
#   geom_hline(yintercept = 50) +
#   geom_vline(xintercept = c(45,55), linetype="dashed")+
#   geom_hline(yintercept = c(45,55), linetype="dashed") +
#   geom_text_repel(aes(label=KOstrain))
# 
# ggplotly(p)
# 
# experiments_numbers$RNA_quarter <- NA
# experiments_numbers$protein_quarter <- NA
# save plots ##############################################################################################################
pdf(file.path(out_dir, paste0("2_2_1_", Sys.Date(), "_plots_eachStrain.pdf")), height = 6, width = 6)
for (i in 1:length(experiments)) {
  print(i)
  mystrain <- experiments[i]
  df_RNA_strain <- subset(df_RNA, KOstrain == mystrain)
  df_RNA_strain <- df_RNA_strain[,2:4]
  names(df_RNA_strain) <- c("gene", "FC_RNA", "P_RNA")
  df_protein_strain <- subset(df_protein, KOstrain == mystrain)
  df_protein_strain <- df_protein_strain[,2:4]
  names(df_protein_strain) <- c("gene", "FC_protein", "P_protein")
  
  experiments_meta$geneCount_RNA[i] <- dim(df_RNA_strain)[1]
  experiments_meta$geneCount_protein[i] <- dim(df_protein_strain)[1]
  
  df_protein_strain$pG <- df_protein_strain$gene
  df_protein_strain <- splitColumnBySep(df_protein_strain, "gene")
  df_protein_strain <- df_protein_strain[-c(grep("REV|CON",df_protein_strain$gene)),]
  
  experiments_meta$geneCount_protein_split[i] <- dim(df_protein_strain)[1]
  
  experiments_meta$geneCount_overlap[i] <- length(intersect(df_protein_strain$gene, df_RNA_strain$gene))
  
  df_strain <- merge(df_RNA_strain, df_protein_strain, by.x="gene", by.y="gene", all=TRUE)
  
  experiments_meta$FC_cor[i] <- cor(df_strain$FC_RNA, df_strain$FC_protein, use = 'pairwise.complete.obs')[1]

  experiments_meta$genesRegulated_RNA[i] <- dim(subset(df_strain, P_RNA<=0.005 & abs(FC_RNA)>=0.6))[1]
  experiments_meta$genesRegulated_protein[i] <- dim(subset(df_strain, P_protein<=0.03 & abs(FC_protein)>=0.2))[1]

  df_strain_2 <- merge(df_RNA_strain, df_protein_strain, by.x="gene", by.y="gene", all=FALSE)
  
  experiments_meta$genesRegulated_RNA_overlep[i] <- dim(subset(df_strain_2, P_RNA<=0.005 & abs(FC_RNA)>=0.6))[1]
  experiments_meta$genesRegulated_protein_overlap[i] <- dim(subset(df_strain_2, P_protein<=0.03 & abs(FC_protein)>=0.2))[1]
  
  experiments_meta$genesRegulated_overlap[i] <- dim(subset(df_strain, P_protein<=0.03 & abs(FC_protein)>=0.2 & P_RNA<=0.005 & abs(FC_RNA)>=0.6))[1]
  experiments_meta$genesRegulated_overlap_2[i] <- dim(subset(df_strain_2, P_protein<=0.03 & abs(FC_protein)>=0.2 & P_RNA<=0.005 & abs(FC_RNA)>=0.6))[1]
  
  jnk <- subset(df_strain, P_protein<=0.03 & abs(FC_protein)>=0.2 & P_RNA<=0.005 & abs(FC_RNA)>=0.6)
  jnk$Direction <- sign(jnk$FC_RNA * jnk$FC_protein)
  experiments_meta$genesRegulated_overlap_sameDirection[i] <- sum(jnk$Direction == 1)

 
  p <- ggplot(df_strain, aes(FC_protein, FC_RNA)) +
    geom_point() +
    geom_hline(yintercept = c(-0.6,0.6), linetype="dashed") +
    geom_vline(xintercept = c(-0.2,0.2), linetype="dashed") +
    geom_hline(yintercept = 0) +
    geom_vline(xintercept = 0) +
    scale_x_continuous(breaks = c(-1,-0.2,0,0.2,1)) +
    scale_y_continuous(breaks = c(-1,-0.6,0,0.6,1)) +
    xlab("Enrichment_Protein") +
    ylab("Enrichment_RNA") +
    ggtitle(paste(mystrain, ", cor: ", round(experiments_meta$FC_cor[i],2), sep="")) +
    geom_smooth(method="lm")+
    geom_abline(slope=1, intercept = 0, na.rm = TRUE, color="darkgreen", size=1) +
    theme_bw()
  print(p)
}
dev.off()
experiments_meta <- experiments_meta[,-12]
experiments_meta$genesRegulated_overlap_Percentage <- round(100*(experiments_meta$genesRegulated_overlap / (experiments_meta$genesRegulated_RNA_overlep + experiments_meta$genesRegulated_protein_overlap - experiments_meta$genesRegulated_overlap)),0)
experiments_meta$genesRegulated_overlap_sameDirection_Percentage <- round(100*(experiments_meta$genesRegulated_overlap_sameDirection / experiments_meta$genesRegulated_overlap),0)


saveRDS(experiments_meta, file.path(out_dir, paste0("2_2_2_", Sys.Date(), "_experiments_meta_data.rds")))
write.table(experiments_meta, file.path(out_dir,paste0("2_2_3_", Sys.Date(), "_experiments_meta_data.txt")),
            quote = F, row.names = F, sep="\t")
rm(df_protein_strain)
rm(df_RNA_strain)
rm(df_strain)
rm(df_strain_2)
rm(jnk)
rm(p)

# 2.2.2 # group based on the number of targets at protein or RNA level #########################
myfile <- list.files(out_dir, "^2_2_2.*rds")
experiments_meta <- readRDS(file.path(out_dir, myfile))
experiments_meta$genesRegulated_overlap_sameDirection_Percentage[is.nan(experiments_meta$genesRegulated_overlap_sameDirection_Percentage)] <- 0

p1 <- ggplot(experiments_meta, aes(genesRegulated_RNA, genesRegulated_protein))+
  geom_point(aes(color=FC_cor), size=8, alpha=0.6) +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("Number of targets (RNA)") +
  ylab("Number of targets (protein)")

p1_2 <- ggplot(experiments_meta, aes(genesRegulated_RNA_overlep, genesRegulated_protein_overlap))+
  geom_point(aes(color=FC_cor), size=8, shape=1) +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("Number of targets (RNA), overlap") +
  ylab("Number of targets (protein), overlap") +
  scale_color_gradient(low="#deebf7", high="#08306b")

p2 <- ggplot(experiments_meta, aes(FC_cor, genesRegulated_overlap_sameDirection_Percentage))+
  geom_point(size=8, alpha=0.6) +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("Pearson's R, fold change") +
  ylab("Percentage of targets (same direction)")
pdf(file.path(out_dir, paste0("2_2_2_", Sys.Date(), "_plots_targets_cor.pdf")), height = 6, width = 6)
print(p1)
print(p1_2)
print(p2)
dev.off()

# 20191030 # additional plots ############################
p1 <- ggplot(experiments_meta, aes(FC_cor))+
  geom_histogram(bins = 50) +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("Pearson's R, fold change") 
ggsave(file.path(out_dir, paste0("2_2_2_1_", Sys.Date(), "_foldChange_cor_distribution_histogram.pdf")),
       p1, width = 4, height = 4)

p2 <- ggplot(experiments_meta, aes(FC_cor))+
  geom_density(size=1.2) +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("Pearson's R, fold change") +
  xlim(-1,1) +
  geom_hline(yintercept = 0, size=1.3, color="white")
ggsave(file.path(out_dir, paste0("2_2_2_3_", Sys.Date(), "_foldChange_cor_distribution_density.pdf")),
       p2, width = 4, height = 4)

p2 <- ggplot(experiments_meta, aes(genesRegulated_RNA, genesRegulated_protein))+
  geom_point() +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("# targets, RNA") +
  ylab("# targets protein")



# 20191104 # additional plots ##########################################
out_dir <- "ReplicateRNAprotein/20191104/"
myfile <- list.files(out_dir, "^2_2_2.*rds")
experiments_meta <- readRDS(file.path(out_dir, myfile))
experiments_meta$genesRegulated_overlap_sameDirection_Percentage[is.nan(experiments_meta$genesRegulated_overlap_sameDirection_Percentage)] <- 0

p1 <- ggplot(experiments_meta, aes(FC_cor, genesRegulated_RNA))+
  geom_point() +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("R, FC cor") +
  ylab("# targets, RNA")

p2 <- ggplot(experiments_meta, aes(FC_cor, genesRegulated_protein))+
  geom_point() +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("R, FC cor") +
  ylab("# targets, protein")


p3 <- ggplot(experiments_meta, aes(FC_cor, genesRegulated_RNA_overlep))+
  geom_point() +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("R, FC cor") +
  ylab("# targets, overlap, RNA")

p4 <- ggplot(experiments_meta, aes(FC_cor, genesRegulated_protein_overlap))+
  geom_point() +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("R, FC cor") +
  ylab("# targets, overlap, protein")

df_heatmap <- experiments_meta[,c(6:12)]
rownames(df_heatmap) <- experiments_meta$experiments
for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

# df_heatmap$FC_cor <- 100*df_heatmap$FC_cor

mymat <- as.matrix(df_heatmap)
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)


paletteLength <- 100
my.breaks <- c(seq(-1, -0.01, length.out=10),
               seq(0.01, 1, length.out=10),
               seq(1.1, max(df_heatmap, na.rm=TRUE), 
                   length.out=80))
my.colors <- c(colorRampPalette(c("#b2182b", "white", "#1a9850"))(20),
               colorRampPalette(c("#abd9e9", "#053061"))(80))


pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
         main = "info",
         annotation_legend = FALSE, border_color=NA, fontsize = 6, fontface="bold",
         color = my.colors, breaks= my.breaks,
         file=file.path(out_dir, "20191104_1_heatmap.pdf"),
         width = 4, height = 10)


# version 2  heatmap
df_heatmap <- experiments_meta[,c(7:12)]
rownames(df_heatmap) <- experiments_meta$experiments
for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

# df_heatmap$FC_cor <- 100*df_heatmap$FC_cor

mymat <- as.matrix(df_heatmap)
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)


paletteLength <- 100
my.breaks <- c(seq(0, max(df_heatmap, na.rm=TRUE), 
                   length.out=100))
my.colors <- colorRampPalette(c("white", "#053061"))(100)

mydf <- as.data.frame(experiments_meta$FC_cor)
names(mydf) <- "cor_FC"
rownames(mydf) <- experiments_meta$experiments

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
         main = "info", annotation_row = mydf,
         annotation_legend = TRUE, border_color=NA, fontsize = 4, fontface="bold",
#         color = my.colors, breaks= my.breaks,
         file=file.path(out_dir, "20191104_2_heatmap.pdf"),
         width = 4, height = 6)

# 20191108 # additional plots #############################################
myfile <- list.files(out_dir, "^2_2_2.*rds")
experiments_meta <- readRDS(file.path(out_dir, myfile))
experiments_meta$genesRegulated_overlap_sameDirection_Percentage[is.nan(experiments_meta$genesRegulated_overlap_sameDirection_Percentage)] <- 0

out_dir <- "ReplicateRNAprotein/"
myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_protein <- readRDS(file.path(out_dir, myfile))
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))

experiments <- unique(df_RNA$KOstrain)
experiments <- c("SPAC22F8.11", "SPBC2F12.12c")

# bad cor 
df_RNA_bad <- df_RNA[df_RNA$KOstrain == experiments[1],]
df_protein_bad <- df_protein[df_protein$KOstrain == experiments[1],]
names(df_RNA_bad) <- c("strain","gene", "FC_RNA", "P_RNA")
names(df_protein_bad) <- c("strain","gene", "FC_protein", "P_protein")
df_protein_bad$gene_split <- df_protein_bad$gene
df_protein_bad <- splitColumnBySep(df_protein_bad, "gene_split")

df_bad <- merge(df_RNA_bad, df_protein_bad, by.x="gene", by.y="gene_split", all=FALSE)
df_bad_cor <- round(cor(df_bad$FC_RNA, df_bad$FC_protein),3)
df_bad$FC_RNA[df_bad$FC_RNA>2] <- 1.9
p_bad_1 <- ggplot(df_bad, aes(FC_RNA, FC_protein)) +
  geom_point() +
  # geom_hline(yintercept = c(-0.2,0.2), linetype="dashed") +
  # geom_vline(xintercept = c(-0.6,0.6), linetype="dashed") +
  geom_hline(yintercept = 0) +
  geom_vline(xintercept = 0) +
  scale_x_continuous(breaks = c(-2,0,2), labels = c(-2,0,2), limits = c(-2,2)) +
  scale_y_continuous(breaks = c(-2,0,2), labels = c(-2,0,2), limits = c(-2,2)) +
  xlab("fold change, RNA") +
  ylab("fold change, Protein") +
  ggtitle("bad correlation") +
  geom_smooth(method="lm")+
  theme_classic() +
  annotate("text", x=-1.3, y=2, label=paste0("R = ", df_bad_cor), size=5) +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))
p_bad_2 <- ggplot(df_bad, aes(y=FC_RNA, x=FC_protein)) +
  geom_point() +
  # geom_vline(xintercept = c(-0.2,0.2), linetype="dashed") +
  # geom_hline(yintercept = c(-0.6,0.6), linetype="dashed") +
  geom_hline(yintercept = 0) +
  geom_vline(xintercept = 0) +
  scale_x_continuous(breaks = c(-2,0,2), labels = c(-2,0,2), limits = c(-2,2)) +
  scale_y_continuous(breaks = c(-2,0,2), labels = c(-2,0,2), limits = c(-2,2)) +
  ylab("fold change, RNA") +
  xlab("fold change, Protein") +
  ggtitle("bad correlation") +
  geom_smooth(method="lm")+
  theme_classic() +
  annotate("text", x=-1.3, y=2, label=paste0("R = ", df_bad_cor), size=5) +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))


# good cor 
df_RNA_good <- df_RNA[df_RNA$KOstrain == experiments[2],]
df_protein_good <- df_protein[df_protein$KOstrain == experiments[2],]
names(df_RNA_good) <- c("strain","gene", "FC_RNA", "P_RNA")
names(df_protein_good) <- c("strain","gene", "FC_protein", "P_protein")
df_protein_good$gene_split <- df_protein_good$gene
df_protein_good <- splitColumnBySep(df_protein_good, "gene_split")

df_good <- merge(df_RNA_good, df_protein_good, by.x="gene", by.y="gene_split", all=FALSE)
df_good_cor <- round(cor(df_good$FC_RNA, df_good$FC_protein),3)
df_good$FC_RNA[df_good$FC_RNA>2] <- 1.9

p_good_1 <- ggplot(df_good, aes(FC_RNA, FC_protein)) +
  geom_point() +
  # geom_hline(yintercept = c(-0.2,0.2), linetype="dashed") +
  # geom_vline(xintercept = c(-0.6,0.6), linetype="dashed") +
  geom_hline(yintercept = 0) +
  geom_vline(xintercept = 0) +
  scale_x_continuous(breaks = c(-2,0,2), labels = c(-2,0,2), limits = c(-2,2)) +
  scale_y_continuous(breaks = c(-2,0,2), labels = c(-2,0,2), limits = c(-2,2)) +
  xlab("fold change, RNA") +
  ylab("fold change, Protein") +
  ggtitle("good correlation") +
  geom_smooth(method="lm")+
  theme_classic() +
  annotate("text", x=-1.3, y=2, label=paste0("R = ", df_good_cor), size=5) +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))
p_good_2 <- ggplot(df_good, aes(y=FC_RNA, x=FC_protein)) +
  geom_point() +
  # geom_vline(xintercept = c(-0.2,0.2), linetype="dashed") +
  # geom_hline(yintercept = c(-0.6,0.6), linetype="dashed") +
  geom_hline(yintercept = 0) +
  geom_vline(xintercept = 0) +
  scale_x_continuous(breaks = c(-2,0,2), labels = c(-2,0,2), limits = c(-2,2)) +
  scale_y_continuous(breaks = c(-2,0,2), labels = c(-2,0,2), limits = c(-2,2)) +
  ylab("fold change, RNA") +
  xlab("fold change, Protein") +
  ggtitle("good correlation") +
  geom_smooth(method="lm")+
  theme_classic() +
  annotate("text", x=-1.3, y=2, label=paste0("R = ", df_good_cor), size=5) +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))


save_dir <- "E:/Merve/PaperFigures/20191108/"
ggsave(file.path(save_dir,"Figure5_bad_cor_plot1_v20191108.pdf"), p_bad_1, height = 3, width = 3)
ggsave(file.path(save_dir,"Figure5_bad_cor_plot2_v20191108.pdf"), p_bad_2, height = 3, width = 3)
ggsave(file.path(save_dir,"Figure5_good_cor_plot1_v20191108.pdf"), p_good_1, height = 3, width = 3)
ggsave(file.path(save_dir,"Figure5_good_cor_plot2_v20191108.pdf"), p_good_2, height = 3, width = 3)

p_histogram <- ggplot(experiments_meta, aes(FC_cor))+
  geom_histogram(bins = 20) +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  scale_y_continuous(breaks = c(0,5,10), labels = c(0,5,10)) +
  xlab("Pearson's R, fold change") +
  ggtitle("Distribution of the correlations")

ggsave(file.path(save_dir,"Figure5_cor_distribution_v20191108.pdf"), p_histogram, height = 3, width = 3)

# ggsave(file.path(out_dir, paste0("2_2_2_1_", Sys.Date(), "_foldChange_cor_distribution_histogram.pdf")),
#        p1, width = 4, height = 4)
# 2.2 # correlate the fold changes of RNA and protein per strain #########################
out_dir <- "ReplicateRNAprotein/"
myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_protein <- readRDS(file.path(out_dir, myfile))
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))

experiments <- unique(df_RNA$KOstrain)

experiments_meta <- as.data.frame(experiments)
experiments_numbers <- as.data.frame(experiments)

experiments_meta$geneCount_RNA <- NA
experiments_meta$geneCount_protein <- NA
experiments_meta$geneCount_protein_split <- NA
experiments_meta$geneCount_overlap <- NA

experiments_meta$FC_cor <- NA
experiments_meta$FC_cor_changing <- NA
experiments_meta$FC_cor_changing_spearman <- NA

experiments_meta$genesRegulated_RNA <- NA
experiments_meta$genesRegulated_protein <- NA

experiments_meta$genesRegulated_RNA_overlep <- NA
experiments_meta$genesRegulated_protein_overlap <- NA

experiments_meta$genesRegulated_overlap <- NA
experiments_meta$genesRegulated_overlap_2 <- NA

experiments_meta$genesRegulated_overlap_sameDirection <- NA

out_dir <- "ReplicateRNAprotein/20191104/"
pdf(file.path(out_dir, paste0("2_2_1_", Sys.Date(), "_plots_eachStrain.pdf")), height = 6, width = 6)
for (i in 1:length(experiments)) {
  print(i)
  mystrain <- experiments[i]
  df_RNA_strain <- subset(df_RNA, KOstrain == mystrain)
  df_RNA_strain <- df_RNA_strain[,2:4]
  names(df_RNA_strain) <- c("gene", "FC_RNA", "P_RNA")
  df_protein_strain <- subset(df_protein, KOstrain == mystrain)
  df_protein_strain <- df_protein_strain[,2:4]
  names(df_protein_strain) <- c("gene", "FC_protein", "P_protein")
  
  experiments_meta$geneCount_RNA[i] <- dim(df_RNA_strain)[1]
  experiments_meta$geneCount_protein[i] <- dim(df_protein_strain)[1]
  
  df_protein_strain$pG <- df_protein_strain$gene
  df_protein_strain <- splitColumnBySep(df_protein_strain, "gene")
  df_protein_strain <- df_protein_strain[-c(grep("REV|CON",df_protein_strain$gene)),]
  
  experiments_meta$geneCount_protein_split[i] <- dim(df_protein_strain)[1]
  
  experiments_meta$geneCount_overlap[i] <- length(intersect(df_protein_strain$gene, df_RNA_strain$gene))
  
  df_strain <- merge(df_RNA_strain, df_protein_strain, by.x="gene", by.y="gene", all=TRUE)
  df_strain$RNA_significant <- FALSE
  df_strain$RNA_significant[df_strain$P_RNA <=0.005 & abs(df_strain$FC_RNA)>=0.6] <- TRUE
  
  df_strain$Protein_significant <- FALSE
  df_strain$Protein_significant[df_strain$P_protein <=0.03 & abs(df_strain$FC_protein)>=0.2] <- TRUE
  
  experiments_meta$FC_cor[i] <- cor(df_strain$FC_RNA, df_strain$FC_protein, use = 'pairwise.complete.obs')[1]
  
  experiments_meta$FC_cor_changing[i] <- cor(df_strain$FC_RNA[df_strain$RNA_significant==TRUE | 
                                                                df_strain$Protein_significant==TRUE], 
                                             df_strain$FC_protein[df_strain$RNA_significant==TRUE | 
                                                                    df_strain$Protein_significant==TRUE], 
                                             use = 'pairwise.complete.obs')[1]
  experiments_meta$FC_cor_changing_spearman[i] <- cor(df_strain$FC_RNA[df_strain$RNA_significant==TRUE | 
                                                                df_strain$Protein_significant==TRUE], 
                                             df_strain$FC_protein[df_strain$RNA_significant==TRUE | 
                                                                    df_strain$Protein_significant==TRUE], 
                                             use = 'pairwise.complete.obs', method="spearman")[1]
  
  
  experiments_meta$genesRegulated_RNA[i] <- dim(subset(df_strain, P_RNA<=0.005 & abs(FC_RNA)>=0.6))[1]
  experiments_meta$genesRegulated_protein[i] <- dim(subset(df_strain, P_protein<=0.03 & abs(FC_protein)>=0.2))[1]
  
  df_strain_2 <- merge(df_RNA_strain, df_protein_strain, by.x="gene", by.y="gene", all=FALSE)
  
  experiments_meta$genesRegulated_RNA_overlep[i] <- dim(subset(df_strain_2, P_RNA<=0.005 & abs(FC_RNA)>=0.6))[1]
  experiments_meta$genesRegulated_protein_overlap[i] <- dim(subset(df_strain_2, P_protein<=0.03 & abs(FC_protein)>=0.2))[1]
  
  experiments_meta$genesRegulated_overlap[i] <- dim(subset(df_strain, P_protein<=0.03 & abs(FC_protein)>=0.2 & P_RNA<=0.005 & abs(FC_RNA)>=0.6))[1]
  experiments_meta$genesRegulated_overlap_2[i] <- dim(subset(df_strain_2, P_protein<=0.03 & abs(FC_protein)>=0.2 & P_RNA<=0.005 & abs(FC_RNA)>=0.6))[1]
  
  jnk <- subset(df_strain, P_protein<=0.03 & abs(FC_protein)>=0.2 & P_RNA<=0.005 & abs(FC_RNA)>=0.6)
  jnk$Direction <- sign(jnk$FC_RNA * jnk$FC_protein)
  experiments_meta$genesRegulated_overlap_sameDirection[i] <- sum(jnk$Direction == 1)
  
  
  p <- ggplot(df_strain, aes(FC_RNA, FC_protein)) +
    geom_point() +
    geom_hline(yintercept = c(-0.2,0.2), linetype="dashed") +
    geom_vline(xintercept = c(-0.6,0.6), linetype="dashed") +
    geom_hline(yintercept = 0) +
    geom_vline(xintercept = 0) +
    scale_x_continuous(breaks = c(-2,-0.6,0,0.6,2), limits = c(-8,8)) +
    scale_y_continuous(breaks = c(-2,-0.2,0,0.2,2), limits = c(-3,3)) +
    xlab("Enrichment_RNA") +
    ylab("Enrichment_Protein") +
    ggtitle(paste(mystrain, ", cor: ", round(experiments_meta$FC_cor[i],2), sep="")) +
    geom_smooth(method="lm")+
    geom_abline(slope=1, intercept = 0, na.rm = TRUE, color="darkgreen", size=1) +
    theme_classic()
  print(p)
}
dev.off()
experiments_meta <- experiments_meta[,-12]
experiments_meta$genesRegulated_overlap_Percentage <- round(100*(experiments_meta$genesRegulated_overlap / (experiments_meta$genesRegulated_RNA_overlep + experiments_meta$genesRegulated_protein_overlap - experiments_meta$genesRegulated_overlap)),0)
experiments_meta$genesRegulated_overlap_sameDirection_Percentage <- round(100*(experiments_meta$genesRegulated_overlap_sameDirection / experiments_meta$genesRegulated_overlap),0)


saveRDS(experiments_meta, file.path(out_dir, paste0("2_2_2_", Sys.Date(), "_experiments_meta_data.rds")))
write.table(experiments_meta, file.path(out_dir,paste0("2_2_3_", Sys.Date(), "_experiments_meta_data.txt")),
            quote = F, row.names = F, sep="\t")
rm(df_protein_strain)
rm(df_RNA_strain)
rm(df_strain)
rm(df_strain_2)
rm(jnk)
rm(p)




if(replicateKO){
# 2.3 # knockout detection replicates #########################
myfile <- list.files(path = out_dir, pattern = "2_1_1_")
df_protein <- readRDS(file.path(out_dir, myfile))
df_protein$protein_count <- str_count(df_protein$pG, ";") +1
df_protein <- splitColumnBySep(df_protein, "pG")
myfile <- list.files(path = out_dir, pattern = "2_1_2_")
df_RNA <- readRDS(file.path(out_dir, myfile))

df_RNA <- subset(df_RNA, pG == KOstrain)
df_protein <- subset(df_protein, pG == KOstrain)

df_RNA <- df_RNA[,c(1,3)]
names(df_RNA)[2] <- "RNA_FC"
df_protein <- df_protein[,c(1,2,4)]
names(df_protein)[2] <- "Protein_FC"
df_merge <- merge(df_RNA, df_protein, by=1, all=TRUE)
df_merge$protein_missing <- is.na(df_merge$Protein_FC)
df_merge$Protein_FC[is.na(df_merge$Protein_FC)] <- 0
df_merge$protein_count[is.na(df_merge$protein_count)] <- "NA"
df_merge$protein_count <- as.factor(df_merge$protein_count)

p1 <- ggplot(df_merge, aes(Protein_FC, RNA_FC))+
  geom_vline(xintercept = 0) +
  geom_hline(yintercept = 0) +
  geom_point(aes(color=protein_count, shape=protein_missing), size=8, alpha=0.6) +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("Fold change (protein)") +
  ylab("Fold change (RNA)") +
  xlim(-1.5,1.5) +
  ylim(-8,8) +
  scale_color_manual(values=c("#08306b", "#b2182b", "#878787"))

p2 <- ggplot(df_merge, aes(Protein_FC, RNA_FC))+
  geom_vline(xintercept = 0) +
  geom_hline(yintercept = 0) +
  geom_hex() +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("Fold change (protein)") +
  ylab("Fold change (RNA)") +
  xlim(-1.5,1.5) +
  ylim(-8,8) +
  scale_color_gradient(breaks=c(1,5,10,15), labels=c(1,5,10,15))

pdf(file.path(out_dir, paste0("2_3_", Sys.Date(), "_Knockout_Transcript_Protein.pdf")), height = 6, width = 6)
print(p1)
print(p2)
dev.off()

saveRDS(df_merge, file.path(out_dir, paste0("2_3_1_", Sys.Date(), "_KO_df_merge.rds")))
# 2.3.2 # knockout detection replicates # LATER ########################
myfile <- list.files(path = out_dir, pattern = "2_1_1_")
df_protein <- readRDS(file.path(out_dir, myfile))
df_protein$protein_count <- str_count(df_protein$pG, ";") +1
df_protein <- splitColumnBySep(df_protein, "pG")
myfile <- list.files(path = out_dir, pattern = "2_1_2_")
df_RNA <- readRDS(file.path(out_dir, myfile))
myKOgenes <- unique(df_protein$KOstrain)

myfile <- list.files(path = out_dir, pattern = "2_3_1_")
df_merge <- readRDS(file.path(out_dir, myfile))
screen <- list.files("ScreenProteome/", "6_12_1.*rds")
screen <- readRDS(file.path("ScreenProteome/", screen))
screen <- remove.factors(screen)
screen$Strain_SysID <- gsub("Sp.*\\-(.*)", "\\1", screen$Strain)
screen <- screen[screen$Strain_SysID %in% myKOgenes,]
screen$protein_count <- str_count(screen$Proteins, ";") +1
screen$pG <- screen$Proteins
screen <- splitColumnBySep(screen, "pG")
screen <- subset(screen, pG == Strain_SysID)
screen <- screen[,c(17,8,16)]
names(screen)[2] <- "Screen_FC"
names(screen)[3] <- "Screen_protein_count"
screen <- screen[!is.na(screen$Screen_FC),]
df_merge <- merge(df_merge, screen, by.x="KOstrain", by.y="pG", all=TRUE)
df_merge[df_merge==0] <- NA
df_merge$protein_missing[is.na(df_merge$protein_missing)] <- FALSE

ggplot(df_merge, aes(Protein_FC, Screen_FC))+
  geom_vline(xintercept = 0) +
  geom_hline(yintercept = 0) +
  geom_point(aes(color=protein_count, shape=as.factor(Screen_protein_count)), size=8, alpha=0.6) +
  theme_classic()+
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold")) +
  xlab("Fold change (protein)") +
  ylab("Fold change (screen)") 
  xlim(-1.5,1.5) +
  ylim(-8,8) +
  scale_color_manual(values=c("#08306b", "#b2182b", "#878787"))

}
if(ribosomalproteins){  
# 2.4 # Ribosomal proteins # 19 not 21, 2 duplicated ##################################################################
myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_protein <- readRDS(file.path(out_dir, myfile))
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))

write.table(as.data.frame(unique(df_RNA$pG)), file.path(out_dir,paste0("2_4_0_1_", Sys.Date(), "_RNA_bg.txt")),
            quote = F, row.names = F, sep="\t")

write.table(as.data.frame(unique(df_protein$pG)), file.path(out_dir,paste0("2_4_0_2_", Sys.Date(), "_protein_bg.txt")),
            quote = F, row.names = F, sep="\t")

# filter for the significant changes and ribosomal strains
ribogenes <- read.delim("21_ribosomal_proteins_from94_replicates.txt", header = F)
# ribogenes$genename <- gsub("SCHPO\\|PomBase\\=(.*)\\|UniProtKB.*", "\\1", ribogenes$V2)
# ribogenes <- ribogenes[,c(1,2,7,3:6)]
df_protein <- df_protein[df_protein$KOstrain %in% ribogenes$V2,]
# length(unique(df_protein$KOstrain))
df_RNA <- df_RNA[df_RNA$KOstrain %in% ribogenes$V2,]
# length(unique(df_RNA$KOstrain))

# regulation at RNA level
RNA_genes <- unique(df_RNA$pG[abs(df_RNA$log2FC_Strain_wt)>=0.6 & df_RNA$pvalue <= 0.005])
protein_genes <- unique(df_protein$pG[abs(df_protein$log2FC_Strain_wt)>=0.2 & df_protein$pvalue <= 0.03])
all_genes <- unique(c(RNA_genes, protein_genes))

df_protein <- df_protein[df_protein$pG %in% all_genes,]
df_RNA <- df_RNA[df_RNA$pG %in% all_genes,]

# 2.4.1 # at RNA level ###############################################################################################
df_RNA_RNA <- df_RNA[df_RNA$pG %in% RNA_genes,]
df_RNA_RNA$regulated <- FALSE
df_RNA_RNA$regulated[abs(df_RNA_RNA$log2FC_Strain_wt)>=0.6 & df_RNA_RNA$pvalue <= 0.005] <- TRUE

jnk <- as.data.frame(table(df_RNA_RNA[,c(2,5)]))
jnk <- jnk[jnk$regulated == TRUE,]
jnk <- jnk[jnk$Freq >1,]

df_RNA_RNA <- df_RNA_RNA[df_RNA_RNA$pG %in% jnk$pG, 1:3]
df_RNA_RNA <- dcast(df_RNA_RNA, pG ~ KOstrain, value.var="log2FC_Strain_wt")
rownames(df_RNA_RNA) <- df_RNA_RNA$pG
df_heatmap <- df_RNA_RNA
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

RNA_ribogenes <- ribogenes[,2:3]
RNA_ribogenes$V3 <- gsub("([0-9]*S)\\ .*", "\\1", RNA_ribogenes$V3)
RNA_ribogenes <- unique(RNA_ribogenes)

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- RNA_ribogenes
rownames(mydf) <- mydf$V2
mydf <- mydf[,c(2,1)]
mydf$V3 <- paste("Ribosomal_", mydf$V3, sep="")

ann_colors = list(V3 = c(Ribosomal_60S = "#e31a1c", Ribosomal_40S = "#33a02c"))

paletteLength <- 50
my.breaks <- c(seq(min(df_heatmap, na.rm=TRUE), 0, length.out=ceiling(paletteLength/2) + 1), 
              seq(max(df_heatmap, na.rm=TRUE)/paletteLength, max(df_heatmap, na.rm=TRUE), 
                  length.out=floor(paletteLength/2)))
my.colors <- colorRampPalette(c("#023858", "white", "#a50f15"))(paletteLength)



pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=F, 
         annotation_col = mydf, breaks = my.breaks, color = my.colors,
         annotation_colors =ann_colors, 
         border_color=NA, fontsize = 4,
         main = "Ribosomal proteins regulated genes at RNA level",
         file=file.path(out_dir, paste0("2_4_1_1_", Sys.Date(), "_RibosomalProteinregulatedGenes_atRNAlevel.pdf")),
         width = 6, height = 10)

df_RNA_RNA$UPcount <- rowSums(df_RNA_RNA[,2:20] > 0.6, na.rm = T)
df_RNA_RNA$DOWNcount <- rowSums(df_RNA_RNA[,2:20] < -0.6, na.rm = T)

df_RNA_RNA$mainlyUP <- df_RNA_RNA$UPcount > df_RNA_RNA$DOWNcount

write.table(df_RNA_RNA, file.path(out_dir,paste0("2_4_1_2_", Sys.Date(), "_dfRNARNA_up_down.txt")),
            quote = F, row.names = F, sep="\t")

# 2.4.2 # at protein level ###############################################################################################
df_protein_protein <- df_protein[df_protein$pG %in% protein_genes,]
df_protein_protein$regulated <- FALSE
df_protein_protein$regulated[abs(df_protein_protein$log2FC_Strain_wt)>=0.2 & df_protein_protein$pvalue <= 0.03] <- TRUE

jnk <- as.data.frame(table(df_protein_protein[,c(2,5)]))
jnk <- jnk[jnk$regulated == TRUE,]
jnk <- jnk[jnk$Freq >1,]

df_protein_protein <- df_protein_protein[df_protein_protein$pG %in% jnk$pG, 1:3]
df_protein_protein <- dcast(df_protein_protein, pG ~ KOstrain, value.var="log2FC_Strain_wt")
rownames(df_protein_protein) <- df_protein_protein$pG
df_heatmap <- df_protein_protein
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

protein_ribogenes <- ribogenes[,2:3]
protein_ribogenes$V3 <- gsub("([0-9]*S)\\ .*", "\\1", protein_ribogenes$V3)
protein_ribogenes <- unique(protein_ribogenes)

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- protein_ribogenes
rownames(mydf) <- mydf$V2
mydf <- mydf[,c(2,1)]
mydf$V3 <- paste("Ribosomal_", mydf$V3, sep="")

ann_colors = list(V3 = c(Ribosomal_60S = "#e31a1c", Ribosomal_40S = "#33a02c"))

paletteLength <- 50
my.breaks <- c(seq(min(df_heatmap, na.rm=TRUE), 0, length.out=ceiling(paletteLength/2) + 1), 
               seq(max(df_heatmap, na.rm=TRUE)/paletteLength, max(df_heatmap, na.rm=TRUE), 
                   length.out=floor(paletteLength/2)))
my.colors <- colorRampPalette(c("#023858", "white", "#a50f15"))(paletteLength)

mymat[is.na(mymat)] <- 0

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=F, 
         annotation_col = mydf, breaks = my.breaks, color = my.colors,
         annotation_colors =ann_colors, 
         border_color=NA, fontsize = 4,
         main = "Ribosomal proteins regulated genes at protein level",
         file=file.path(out_dir, paste0("2_4_2_1_", Sys.Date(), "_RibosomalProteinregulatedGenes_atproteinlevel.pdf")),
         width = 6, height = 10)

df_protein_protein$UPcount <- rowSums(df_protein_protein[,2:20] > 0.2, na.rm = T)
df_protein_protein$DOWNcount <- rowSums(df_protein_protein[,2:20] < -0.2, na.rm = T)

df_protein_protein$mainlyUP <- df_protein_protein$UPcount > df_protein_protein$DOWNcount

write.table(df_protein_protein, file.path(out_dir,paste0("2_4_2_2_", Sys.Date(), "_dfproteinprotein_up_down.txt")),
            quote = F, row.names = F, sep="\t")
# 2.4.3 # at RNA and protein level ###############################################################################################
myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_protein <- readRDS(file.path(out_dir, myfile))
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))

# filter for the significant changes and ribosomal strains
ribogenes <- read.delim("21_ribosomal_proteins_from94_replicates.txt", header = F)
# ribogenes$genename <- gsub("SCHPO\\|PomBase\\=(.*)\\|UniProtKB.*", "\\1", ribogenes$V2)
# ribogenes <- ribogenes[,c(1,2,7,3:6)]
df_protein <- df_protein[df_protein$KOstrain %in% ribogenes$V2,]
# length(unique(df_protein$KOstrain))
df_RNA <- df_RNA[df_RNA$KOstrain %in% ribogenes$V2,]
# length(unique(df_RNA$KOstrain))

# regulation at RNA level
RNA_genes <- unique(df_RNA$pG[abs(df_RNA$log2FC_Strain_wt)>=0.6 & df_RNA$pvalue <= 0.005])
protein_genes <- unique(df_protein$pG[abs(df_protein$log2FC_Strain_wt)>=0.2 & df_protein$pvalue <= 0.03])
all_genes <- unique(intersect(RNA_genes, protein_genes))

df_protein <- df_protein[df_protein$pG %in% all_genes,]
df_RNA <- df_RNA[df_RNA$pG %in% all_genes,]


df_protein$regulated <- FALSE
df_protein$regulated[abs(df_protein$log2FC_Strain_wt)>=0.2 & df_protein$pvalue <= 0.03] <- TRUE

df_RNA$regulated <- FALSE
df_RNA$regulated[abs(df_RNA$log2FC_Strain_wt)>=0.6 & df_RNA$pvalue <= 0.005] <- TRUE

jnk <- as.data.frame(table(df_protein[,c(2,5)]))
jnk <- jnk[jnk$regulated == TRUE,]
names(jnk)[3] <- "F_protein"
jnk2 <- jnk

jnk <- as.data.frame(table(df_RNA[,c(2,5)]))
jnk <- jnk[jnk$regulated == TRUE,]
names(jnk)[3] <- "F_RNA"

jnk <- jnk[,c(1,3)]
jnk2 <- jnk2[,c(1,3)]
jnk <- merge(jnk, jnk2, by=1, all=FALSE)
rm(jnk2)
jnk$Freq <- jnk$F_RNA + jnk$F_protein

jnk <- jnk[jnk$Freq >2,]

df_protein_protein <- df_protein[df_protein$pG %in% jnk$pG, 1:3]
df_protein_protein <- dcast(df_protein_protein, pG ~ KOstrain, value.var="log2FC_Strain_wt")

df_RNA_RNA <- df_RNA[df_RNA$pG %in% jnk$pG, 1:3]
df_RNA_RNA <- dcast(df_RNA_RNA, pG ~ KOstrain, value.var="log2FC_Strain_wt")

names(df_RNA_RNA) <- paste("RNA", names(df_RNA_RNA), sep="_")
names(df_protein_protein) <- paste("protein", names(df_protein_protein), sep="_")

df_heatmap <- merge(df_protein_protein, df_RNA_RNA, by=1, all=FALSE)
rownames(df_heatmap) <- df_heatmap$protein_pG
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

protein_ribogenes <- ribogenes[,2:3]
protein_ribogenes$V3 <- gsub("([0-9]*S)\\ .*", "\\1", protein_ribogenes$V3)
protein_ribogenes <- unique(protein_ribogenes)

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- protein_ribogenes
jnk <- as.data.frame(names(df_heatmap))
jnk$gene <- gsub(".*\\_(.*)", "\\1", jnk$`names(df_heatmap)`)
names(jnk)[1] <- "colID"
mydf <- merge(jnk, mydf, by.x="gene", by.y="V2", all=FALSE)
rownames(mydf) <- mydf$colID
mydf$Type <- gsub("(.*)\\_.*", "\\1", mydf$colID)
  
mydf <- mydf[,c(4,3,1)]
mydf$V3 <- paste("Ribosomal_", mydf$V3, sep="")
rm(jnk)
ann_colors = list(V3 = c(Ribosomal_60S = "#e31a1c", Ribosomal_40S = "#33a02c"),
                  Type = c(RNA = "#3288bd", protein = "#f46d43"))

paletteLength <- 50
my.breaks <- c(seq(min(df_heatmap, na.rm=TRUE), 0, length.out=ceiling(paletteLength/2) + 1), 
               seq(max(df_heatmap, na.rm=TRUE)/paletteLength, max(df_heatmap, na.rm=TRUE), 
                   length.out=floor(paletteLength/2)))
my.colors <- colorRampPalette(c("#023858", "white", "#a50f15"))(paletteLength)

mymat[is.na(mymat)] <- 0

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=F, 
         annotation_col = mydf, breaks = my.breaks, color = my.colors,
         annotation_colors =ann_colors, 
         border_color=NA, fontsize = 4,
         main = "Ribosomal proteins regulated genes",
         file=file.path(out_dir, paste0("2_4_3_1_", Sys.Date(), "_RibosomalProteinregulatedGenes.pdf")),
         width = 6, height = 10)

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
         annotation_col = mydf, breaks = my.breaks, color = my.colors,
         annotation_colors =ann_colors, 
         border_color=NA, fontsize = 4,
         main = "Ribosomal proteins regulated genes", fontsize_row = 2,
         file=file.path(out_dir, paste0("2_4_3_2_", Sys.Date(), "_RibosomalProteinregulatedGenes.pdf")),
         width = 6, height = 15)
# 2.5 # all the replicates clutering as in 2.4 for ribosomal proteins ######################################
myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_protein <- readRDS(file.path(out_dir, myfile))
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))

# regulation at RNA level
RNA_genes <- unique(df_RNA$pG[abs(df_RNA$log2FC_Strain_wt)>=0.6 & df_RNA$pvalue <= 0.005])
protein_genes <- unique(df_protein$pG[abs(df_protein$log2FC_Strain_wt)>=0.2 & df_protein$pvalue <= 0.03])
all_genes <- unique(intersect(RNA_genes, protein_genes))

# 2.5.1 # at RNA level ###############################################################################################
df_RNA_RNA <- df_RNA[df_RNA$pG %in% RNA_genes,]
df_RNA_RNA$regulated <- FALSE
df_RNA_RNA$regulated[abs(df_RNA_RNA$log2FC_Strain_wt)>=0.6 & df_RNA_RNA$pvalue <= 0.005] <- TRUE

jnk <- as.data.frame(table(df_RNA_RNA[,c(2,5)]))
jnk <- jnk[jnk$regulated == TRUE,]
jnk <- jnk[jnk$Freq >1,]

df_RNA_RNA <- df_RNA_RNA[df_RNA_RNA$pG %in% jnk$pG, 1:3]
df_RNA_RNA <- dcast(df_RNA_RNA, pG ~ KOstrain, value.var="log2FC_Strain_wt")
rownames(df_RNA_RNA) <- df_RNA_RNA$pG
df_heatmap <- df_RNA_RNA
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

paletteLength <- 50
my.breaks <- c(seq(min(df_heatmap, na.rm=TRUE), 0, length.out=ceiling(paletteLength/2) + 1), 
               seq(max(df_heatmap, na.rm=TRUE)/paletteLength, max(df_heatmap, na.rm=TRUE), 
                   length.out=floor(paletteLength/2)))
my.colors <- colorRampPalette(c("#023858", "white", "#a50f15"))(paletteLength)

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=F, 
         breaks = my.breaks, color = my.colors,
         border_color=NA, fontsize = 4,
         main = "regulated genes at RNA level",
         file=file.path(out_dir, paste0("2_5_1_1_", Sys.Date(), "_RegulatedGenes_atRNAlevel.pdf")),
         width = 6, height = 10)

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
         breaks = my.breaks, color = my.colors,
         border_color=NA, fontsize = 4, fontsize_row = 1,
         main = "regulated genes at RNA level",
         file=file.path(out_dir, paste0("2_5_1_2_", Sys.Date(), "_RegulatedGenes_atRNAlevel.pdf")),
         width = 6, height = 15)

# 2.5.2 # at protein level ###############################################################################################
df_protein_protein <- df_protein[df_protein$pG %in% protein_genes,]
df_protein_protein$regulated <- FALSE
df_protein_protein$regulated[abs(df_protein_protein$log2FC_Strain_wt)>=0.2 & df_protein_protein$pvalue <= 0.03] <- TRUE

jnk <- as.data.frame(table(df_protein_protein[,c(2,5)]))
jnk <- jnk[jnk$regulated == TRUE,]
jnk <- jnk[jnk$Freq >1,]

df_protein_protein <- df_protein_protein[df_protein_protein$pG %in% jnk$pG, 1:3]
df_protein_protein <- dcast(df_protein_protein, pG ~ KOstrain, value.var="log2FC_Strain_wt")
rownames(df_protein_protein) <- df_protein_protein$pG
df_heatmap <- df_protein_protein
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)
mymat[is.na(mymat)] <- 0

paletteLength <- 50
my.breaks <- c(seq(min(df_heatmap, na.rm=TRUE), 0, length.out=ceiling(paletteLength/2) + 1), 
               seq(max(df_heatmap, na.rm=TRUE)/paletteLength, max(df_heatmap, na.rm=TRUE), 
                   length.out=floor(paletteLength/2)))
my.colors <- colorRampPalette(c("#023858", "white", "#a50f15"))(paletteLength)

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=F, 
         breaks = my.breaks, color = my.colors,
         border_color=NA, fontsize = 4,
         main = "regulated genes at protein level",
         file=file.path(out_dir, paste0("2_5_2_1_", Sys.Date(), "_RegulatedGenes_atProteinlevel.pdf")),
         width = 6, height = 10)

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
         breaks = my.breaks, color = my.colors,
         border_color=NA, fontsize = 4, fontsize_row = 1,
         main = "regulated genes at protein level",
         file=file.path(out_dir, paste0("2_5_2_2_", Sys.Date(), "_RegulatedGenes_atProteinlevel.pdf")),
         width = 6, height = 20)

# 2.5.3 # at RNA and protein level ###############################################################################################
myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_protein <- readRDS(file.path(out_dir, myfile))
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))

# filter for the significant changes and ribosomal strains
ribogenes <- read.delim("21_ribosomal_proteins_from94_replicates.txt", header = F)
# ribogenes$genename <- gsub("SCHPO\\|PomBase\\=(.*)\\|UniProtKB.*", "\\1", ribogenes$V2)
# ribogenes <- ribogenes[,c(1,2,7,3:6)]
df_protein <- df_protein[df_protein$KOstrain %in% ribogenes$V2,]
# length(unique(df_protein$KOstrain))
df_RNA <- df_RNA[df_RNA$KOstrain %in% ribogenes$V2,]
# length(unique(df_RNA$KOstrain))

# regulation at RNA level
RNA_genes <- unique(df_RNA$pG[abs(df_RNA$log2FC_Strain_wt)>=0.6 & df_RNA$pvalue <= 0.005])
protein_genes <- unique(df_protein$pG[abs(df_protein$log2FC_Strain_wt)>=0.2 & df_protein$pvalue <= 0.03])
all_genes <- unique(intersect(RNA_genes, protein_genes))

df_protein <- df_protein[df_protein$pG %in% all_genes,]
df_RNA <- df_RNA[df_RNA$pG %in% all_genes,]


df_protein$regulated <- FALSE
df_protein$regulated[abs(df_protein$log2FC_Strain_wt)>=0.2 & df_protein$pvalue <= 0.03] <- TRUE

df_RNA$regulated <- FALSE
df_RNA$regulated[abs(df_RNA$log2FC_Strain_wt)>=0.6 & df_RNA$pvalue <= 0.005] <- TRUE

jnk <- as.data.frame(table(df_protein[,c(2,5)]))
jnk <- jnk[jnk$regulated == TRUE,]
names(jnk)[3] <- "F_protein"
jnk2 <- jnk

jnk <- as.data.frame(table(df_RNA[,c(2,5)]))
jnk <- jnk[jnk$regulated == TRUE,]
names(jnk)[3] <- "F_RNA"

jnk <- jnk[,c(1,3)]
jnk2 <- jnk2[,c(1,3)]
jnk <- merge(jnk, jnk2, by=1, all=FALSE)
rm(jnk2)
jnk$Freq <- jnk$F_RNA + jnk$F_protein

jnk <- jnk[jnk$Freq >2,]

df_protein_protein <- df_protein[df_protein$pG %in% jnk$pG, 1:3]
df_protein_protein <- dcast(df_protein_protein, pG ~ KOstrain, value.var="log2FC_Strain_wt")

df_RNA_RNA <- df_RNA[df_RNA$pG %in% jnk$pG, 1:3]
df_RNA_RNA <- dcast(df_RNA_RNA, pG ~ KOstrain, value.var="log2FC_Strain_wt")

names(df_RNA_RNA) <- paste("RNA", names(df_RNA_RNA), sep="_")
names(df_protein_protein) <- paste("protein", names(df_protein_protein), sep="_")

df_heatmap <- merge(df_protein_protein, df_RNA_RNA, by=1, all=FALSE)
rownames(df_heatmap) <- df_heatmap$protein_pG
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

protein_ribogenes <- ribogenes[,2:3]
protein_ribogenes$V3 <- gsub("([0-9]*S)\\ .*", "\\1", protein_ribogenes$V3)
protein_ribogenes <- unique(protein_ribogenes)

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- protein_ribogenes
jnk <- as.data.frame(names(df_heatmap))
jnk$gene <- gsub(".*\\_(.*)", "\\1", jnk$`names(df_heatmap)`)
names(jnk)[1] <- "colID"
mydf <- merge(jnk, mydf, by.x="gene", by.y="V2", all=FALSE)
rownames(mydf) <- mydf$colID
mydf$Type <- gsub("(.*)\\_.*", "\\1", mydf$colID)

mydf <- mydf[,c(4,3,1)]
mydf$V3 <- paste("Ribosomal_", mydf$V3, sep="")
rm(jnk)
ann_colors = list(V3 = c(Ribosomal_60S = "#e31a1c", Ribosomal_40S = "#33a02c"),
                  Type = c(RNA = "#3288bd", protein = "#f46d43"))

paletteLength <- 50
my.breaks <- c(seq(min(df_heatmap, na.rm=TRUE), 0, length.out=ceiling(paletteLength/2) + 1), 
               seq(max(df_heatmap, na.rm=TRUE)/paletteLength, max(df_heatmap, na.rm=TRUE), 
                   length.out=floor(paletteLength/2)))
my.colors <- colorRampPalette(c("#023858", "white", "#a50f15"))(paletteLength)

mymat[is.na(mymat)] <- 0

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=F, 
         annotation_col = mydf, breaks = my.breaks, color = my.colors,
         annotation_colors =ann_colors, 
         border_color=NA, fontsize = 4,
         main = "Ribosomal proteins regulated genes",
         file=file.path(out_dir, paste0("2_4_3_1_", Sys.Date(), "_RibosomalProteinregulatedGenes.pdf")),
         width = 6, height = 10)

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
         annotation_col = mydf, breaks = my.breaks, color = my.colors,
         annotation_colors =ann_colors, 
         border_color=NA, fontsize = 4,
         main = "Ribosomal proteins regulated genes", fontsize_row = 2,
         file=file.path(out_dir, paste0("2_4_3_2_", Sys.Date(), "_RibosomalProteinregulatedGenes.pdf")),
         width = 6, height = 15)

df_protein_protein$UPcount <- rowSums(df_protein_protein[,2:20] > 0.2, na.rm = T)
df_protein_protein$DOWNcount <- rowSums(df_protein_protein[,2:20] < -0.2, na.rm = T)

df_protein_protein$mainlyUP <- df_protein_protein$UPcount > df_protein_protein$DOWNcount

write.table(df_protein_protein, file.path(out_dir,paste0("2_4_2_2_", Sys.Date(), "_dfproteinprotein_up_down.txt")),
            quote = F, row.names = F, sep="\t")





# 2.5.4 # protein FC / RNA FC # 20191024 test ### cont later ##################
myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_protein <- readRDS(file.path(out_dir, myfile))
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))

# regulation at RNA level
RNA_genes <- unique(df_RNA$pG[abs(df_RNA$log2FC_Strain_wt)>=0.6 & df_RNA$pvalue <= 0.005])
protein_genes <- unique(df_protein$pG[abs(df_protein$log2FC_Strain_wt)>=0.2 & df_protein$pvalue <= 0.03])
all_genes <- unique(intersect(RNA_genes, protein_genes))

df_protein <- df_protein[df_protein$pG %in% all_genes,]
df_RNA <- df_RNA[df_RNA$pG %in% all_genes,]


df_protein$regulated_protein <- FALSE
df_protein$regulated_protein[abs(df_protein$log2FC_Strain_wt)>=0.2 & df_protein$pvalue <= 0.03] <- TRUE
df_protein$ID <- paste(df_protein$KOstrain, df_protein$pG)
names(df_protein)[3] <- "log2FC_protein" 
names(df_protein)[4] <- "pvalue_protein" 
df_protein <- df_protein[,c(3:6)]
df_RNA$regulated_RNA <- FALSE
df_RNA$regulated_RNA[abs(df_RNA$log2FC_Strain_wt)>=0.6 & df_RNA$pvalue <= 0.005] <- TRUE
df_RNA$ID <- paste(df_RNA$KOstrain, df_RNA$pG)
names(df_RNA)[3] <- "log2FC_RNA" 
names(df_RNA)[4] <- "pvalue_RNA" 
df_reg <- merge(df_RNA, df_protein, by.x="ID", by.y="ID", all=FALSE)
jnk <- rowSums(df_reg[,c(6,9)])
df_reg <- df_reg[jnk>0,]
df_reg$Ratio <- df_reg$log2FC_protein - df_reg$log2FC_RNA

df_heatmap <- df_reg[,c(2,3,10)]
df_heatmap <- dcast(df_heatmap, pG ~ KOstrain, value.var="Ratio")
rownames(df_heatmap) <- df_heatmap$pG
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

paletteLength <- 50
my.breaks <- c(seq(min(df_heatmap, na.rm=TRUE), 0, length.out=ceiling(paletteLength/2) + 1), 
               seq(max(df_heatmap, na.rm=TRUE)/paletteLength, max(df_heatmap, na.rm=TRUE), 
                   length.out=floor(paletteLength/2)))
my.colors <- c(colorRampPalette(rev(brewer.pal(n = 7, name = "Reds")))(25),
              "#ffffff",
              colorRampPalette(brewer.pal(n = 7, name = "Blues"))(25))

mymat[is.na(mymat)] <- 0
pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=F, 
         breaks = my.breaks, color = my.colors,
         border_color=NA, fontsize = 4,
         main = "regulated genes abs(Ratio)",
         file=file.path(out_dir, paste0("2_5_4_1_", Sys.Date(), "_RegulatedGenes_Ratio.pdf")),
         width = 6, height = 4)

table(df_reg[,c(6,9)])
jnk <- as.data.frame(table(df_reg$KOstrain))
library(mixtools)
wait = jnk$Freq
mixmdl = normalmixEM(wait, k=3)
plot(mixmdl,which=2, 100)
lines(density(wait), lty=2, lwd=2)
jnk <- as.data.frame(cbind(jnk, mixmdl$posterior))
jnk$mymin <- apply(jnk[,c(3:5)], 1, min)
jnk$category <- NA
for (i in 1:dim(jnk)[1]) {
  if(jnk$mymin[i] == jnk$comp.1[i]){
    jnk$category[i] <- "1"
  } else if (jnk$mymin[i] == jnk$comp.2[i]) {
    jnk$category[i] <- "2"
  } else if (jnk$mymin[i] == jnk$comp.3[i]) {
    jnk$category[i] <- "3"
  }
}
write.table(jnk, file.path(out_dir, paste0("2_5_4_2_", Sys.Date(), "_howManyRegulated.txt")),
            quote = F, sep="\t", row.names = F)




# 2.6 # overlap with RBP's based on correlation ################################################################
myfile <- list.files(out_dir, "^2_2_2.*rds")
experiments_meta <- readRDS(file.path(out_dir, myfile))
experiments_meta$genesRegulated_overlap_sameDirection_Percentage[is.nan(experiments_meta$genesRegulated_overlap_sameDirection_Percentage)] <- 0

RBPtag <- read.delim("ReplicateRNAprotein/RBPtag_4_1_counts_merged.txt")
RBPtag$pG <- RBPtag$Var1
RBPtag <- splitColumnBySep(RBPtag, "pG")
names(RBPtag)[1] <- "RBPtag"
polyA <- read.delim("ReplicateRNAprotein/Spombe_oligoDT_volcano_enriched_reduced_UV_vs_C.txt")
polyA <- polyA[polyA$difference_UV_C >0 , ]
polyA$pG <- polyA$Protein.IDs
polyA <- splitColumnBySep(polyA, "pG")
polyA <- polyA[,2:5]

experiments_meta <- merge(experiments_meta, RBPtag, by.x="experiments", by.y="pG", all.x=TRUE)
experiments_meta <- merge(experiments_meta, polyA, by.x="experiments", by.y="pG", all.x=TRUE)
experiments_meta$P_R_difference <- experiments_meta$genesRegulated_protein - experiments_meta$genesRegulated_RNA


}
##########################################################################
if(codonbias){
# 3 # codon bias for genes targeted at proteome but transcriptome ####################################
# cds_gff <- readRDS("ReplicateRNAprotein/MotifSearch_20190911/1_1_P_gff3_CDS.rds")
# all_gff <- readRDS("ReplicateRNAprotein/MotifSearch_20190911/2019-09-23_Spombe_gff3_withSequence.rds")
# cds_gff$Length <- nchar(cds_gff$DNAsequence)
# cds_gff$Length_3 <- cds_gff$Length %% 3
fastaFile <- readDNAStringSet("20191014_Spombe_ASM294v2_CodingSequence_mart_export.txt")
seq_name = names(fastaFile)
sequence = paste(fastaFile)
codingSeq <- data.frame(seq_name, sequence)
codingSeq <- codingSeq[grep("^SP", codingSeq$seq_name),]
codingSeq <- codingSeq[-grep("^SNCNAVAAB", codingSeq$sequence),]
codingSeq$Length <- nchar(codingSeq$sequence)
codingSeq$Length_3 <- codingSeq$Length %% 3
rm(fastaFile)

myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_protein <- readRDS(file.path(out_dir, myfile))
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))
names(df_RNA) <- c("KOstrain", "target", "log2FC_RNA", "pvalue_RNA")
names(df_protein) <- c("KOstrain", "target", "log2FC_protein", "pvalue_protein")

df_RNA$mergeID <- paste(df_RNA$KOstrain, df_RNA$target, sep="_")
df_protein$mergeID <- paste(df_protein$KOstrain, df_protein$target, sep="_")
df_protein <- df_protein[,3:5]
df_merged <- merge(df_RNA, df_protein, by.x="mergeID", by.y="mergeID", all=FALSE)

df_merged$reg_RNA <- "NOT"
df_merged$reg_protein <- "NOT"

df_merged$reg_RNA[df_merged$log2FC_RNA >= 0.6 & df_merged$pvalue_RNA <= 0.005] <- "UP"
df_merged$reg_protein[df_merged$log2FC_protein >= 0.2 & df_merged$pvalue_protein <= 0.03] <- "UP"

df_merged$reg_RNA[df_merged$log2FC_RNA <= -0.6 & df_merged$pvalue_RNA <= 0.005] <- "DOWN"
df_merged$reg_protein[df_merged$log2FC_protein <= -0.2 & df_merged$pvalue_protein <= 0.03] <- "DOWN"
saveRDS(df_merged, file.path(out_dir, paste0("3_0_0_", Sys.Date(), "_df_RNA_protein_merged.rds")))
# 3.1 # create the background file for the aminoacid cododn representation #################################
my_measured_genes <- unique(df_merged$target)

my_codingSeq <- codingSeq[codingSeq$seq_name %in% my_measured_genes,]

myAAcomposition <- data.frame(AAtriplet=character(), Frequency=numeric(), GeneID=character())

for (i in 1:dim(codingSeq)[1]) {
  print(i)
  jnk <- substring(codingSeq$sequence[i], seq(1, nchar(codingSeq$sequence[i])-1, 3), seq(3, nchar(codingSeq$sequence[i]), 3))
  jnk <- as.data.frame(table(jnk))
  jnk$GeneID <- codingSeq$seq_name[i]
  names(jnk) <- names(myAAcomposition)
  myAAcomposition <- as.data.frame(rbind(myAAcomposition, jnk))
  rm(jnk)
}

myAAcomposition <- myAAcomposition %>%
  group_by(GeneID) %>%
  dplyr::mutate(Frequency_AA_inGene = round(100*Frequency/sum(Frequency),2)) %>%
  as.data.frame()


saveRDS(myAAcomposition, file.path(out_dir, paste0("3_1_1_", Sys.Date(), "_AAcomposition_allgenes.rds")))
saveRDS(df_merged, file.path(out_dir, paste0("3_1_2_", Sys.Date(), "_replicates_RNA_protein_df_merged.rds")))

based_AA <- myAAcomposition[,1:2]
based_AA <- based_AA %>%
  group_by(AAtriplet) %>%
  dplyr::mutate(Total_freq=sum(Frequency)) %>%
  as.data.frame()
based_AA <- as.data.frame(unique(based_AA[,c(1,3)]))
based_AA <- based_AA %>%
  dplyr::mutate(Total_Percentage=round(100*Total_freq/sum(Total_freq),2)) %>%
  as.data.frame()
based_AA_all <- based_AA

myAAcomposition <- myAAcomposition[myAAcomposition$GeneID %in% my_measured_genes,]
based_AA <- myAAcomposition[,1:2]
based_AA <- based_AA %>%
  group_by(AAtriplet) %>%
  dplyr::mutate(All_measured_freq=sum(Frequency)) %>%
  as.data.frame()
based_AA <- as.data.frame(unique(based_AA[,c(1,3)]))
based_AA <- based_AA %>%
  dplyr::mutate(All_measured_Percentage=round(100*All_measured_freq/sum(All_measured_freq),2)) %>%
  as.data.frame()

based_AA_all <- merge(based_AA_all, based_AA, by=1, all=TRUE)
rm(based_AA)

myKOgenes <- unique(df_merged$KOstrain)

for (i in 1:length(myKOgenes)) {
  print(i)
  kogene <- myKOgenes[i]
  df_merged_jnk <- df_merged[df_merged$KOstrain == kogene,]
  # all pG
  myAAcomposition_jnk <- myAAcomposition[myAAcomposition$GeneID %in% df_merged_jnk$target,]
  based_jnk <- myAAcomposition_jnk[,1:2]
  based_jnk <- based_jnk %>%
    group_by(AAtriplet) %>%
    dplyr::mutate(All_pG_freq=sum(Frequency)) %>%
    as.data.frame()
  
  based_jnk <- as.data.frame(unique(based_jnk[,c(1,3)]))
  based_jnk <- based_jnk %>%
    dplyr::mutate(All_pG_Percentage=round(100*All_pG_freq/sum(All_pG_freq),2)) %>%
    as.data.frame()
  based_1 <- based_jnk
  # RNA not reg
  myAAcomposition_jnk2 <- myAAcomposition_jnk[myAAcomposition_jnk$GeneID %in% df_merged_jnk$target[df_merged_jnk$reg_RNA=="NOT"],]
  based_jnk <- myAAcomposition_jnk2[,1:2]
  based_jnk <- based_jnk %>%
    group_by(AAtriplet) %>%
    dplyr::mutate(RNA_NOT_freq=sum(Frequency)) %>%
    as.data.frame()
  
  based_jnk <- as.data.frame(unique(based_jnk[,c(1,3)]))
  based_jnk <- based_jnk %>%
    dplyr::mutate(RNA_NOT_Percentage=round(100*RNA_NOT_freq/sum(RNA_NOT_freq),2)) %>%
    as.data.frame()
  based_2 <- based_jnk
  # RNA not reg protein UP
  myAAcomposition_jnk3 <- myAAcomposition_jnk2[myAAcomposition_jnk2$GeneID %in% df_merged_jnk$target[df_merged_jnk$reg_RNA=="NOT" & df_merged_jnk$reg_protein == "UP"],]
  based_jnk <- myAAcomposition_jnk3[,1:2]
  based_jnk <- based_jnk %>%
    group_by(AAtriplet) %>%
    dplyr::mutate(RNA_NOT_protein_UP_freq=sum(Frequency)) %>%
    as.data.frame()
  
  based_jnk <- as.data.frame(unique(based_jnk[,c(1,3)]))
  based_jnk <- based_jnk %>%
    dplyr::mutate(RNA_NOT_protein_UP_Percentage=round(100*RNA_NOT_protein_UP_freq/sum(RNA_NOT_protein_UP_freq),2)) %>%
    as.data.frame()
  based_3 <- based_jnk
  # RNA not reg protein DOWN
  myAAcomposition_jnk3 <- myAAcomposition_jnk2[myAAcomposition_jnk2$GeneID %in% df_merged_jnk$target[df_merged_jnk$reg_RNA=="NOT" & df_merged_jnk$reg_protein == "DOWN"],]
  based_jnk <- myAAcomposition_jnk3[,1:2]
  based_jnk <- based_jnk %>%
    group_by(AAtriplet) %>%
    dplyr::mutate(RNA_NOT_protein_DOWN_freq=sum(Frequency)) %>%
    as.data.frame()
  
  based_jnk <- as.data.frame(unique(based_jnk[,c(1,3)]))
  based_jnk <- based_jnk %>%
    dplyr::mutate(RNA_NOT_protein_DOWN_Percentage=round(100*RNA_NOT_protein_DOWN_freq/sum(RNA_NOT_protein_DOWN_freq),2)) %>%
    as.data.frame()
  based_4 <- based_jnk
  
  based_1 <- based_1[,c(1,3)]
  based_2 <- based_2[,c(1,3)]
  based_3 <- based_3[,c(1,3)]
  based_4 <- based_4[,c(1,3)]
  based_1 <- merge(based_1, based_2, by=1, all=TRUE)
  based_1 <- merge(based_1, based_3, by=1, all=TRUE)
  based_1 <- merge(based_1, based_4, by=1, all=TRUE)
  rm(based_2)
  rm(based_3)
  rm(based_4)
  rm(myAAcomposition_jnk)
  rm(myAAcomposition_jnk2)
  rm(myAAcomposition_jnk3)
  rm(based_jnk)
  names(based_1) <- paste(names(based_1), kogene, sep="_")
  
  saveRDS(based_1, file.path(out_dir, paste0("3_1_3_", Sys.Date(), "_", kogene, "AAcomposition.rds")))
  based_AA_all <- merge(based_AA_all, based_1, by=1, all=TRUE)
  rm(based_1)
}
based_AA_all <- based_AA_all[,-c(2,4)]
saveRDS(based_AA_all, file.path(out_dir, paste0("3_1_3_", Sys.Date(), "_ALL_reg_AAcomposition.rds")))

based_AA_all <- melt(based_AA_all, "AAtriplet")
based_AA_all <- remove.factors(based_AA_all)
myAAcodon <- unique(based_AA_all$AAtriplet)

pdf(file.path(out_dir, paste0("3_1_4_", Sys.Date(), "_plots_eachAA.pdf")), height = 6, width = 6)
for (i in 1:length(myAAcodon)) {
  print(i)
  based_AA_all_jnk <- based_AA_all[based_AA_all$AAtriplet == myAAcodon[i],]
  p <- ggplot(based_AA_all_jnk, aes(value)) +
    geom_histogram(bins=50) +
    theme_classic() +
    xlab("Percentage") +
    ggtitle(myAAcodon[i])
  print(p)
}
dev.off()
rm(based_AA_all_jnk)
rm(df_merged_jnk)
rm(df_protein)
rm(df_RNA)
rm(codingSeq)
rm(my_codingSeq)
rm(p)
# 3.2 # do the testing with each protein belonging to the category instead of the average ####################
my.t.test.p.value <- function(x,y) {
  obj<-try(t.test(x,y), silent=TRUE)
  if (is(obj, "try-error")) return(NA) else return(obj$p.value)
}
based_AA_all$p_value <- NA

for (i in 1:length(myKOgenes)) {
  print(i)
  kogene <- myKOgenes[i]
  df_merged_jnk <- df_merged[df_merged$KOstrain == kogene,]
  # all pG
  myAAcomposition_jnk <- myAAcomposition[myAAcomposition$GeneID %in% df_merged_jnk$target,]
  # RNA not reg
  myAAcomposition_jnk2 <- myAAcomposition_jnk[myAAcomposition_jnk$GeneID %in% df_merged_jnk$target[df_merged_jnk$reg_RNA=="NOT"],]
  # RNA not reg protein UP
  myAAcomposition_jnk3 <- myAAcomposition_jnk2[myAAcomposition_jnk2$GeneID %in% df_merged_jnk$target[df_merged_jnk$reg_RNA=="NOT" & df_merged_jnk$reg_protein == "UP"],]
  # RNA not reg protein DOWN
  myAAcomposition_jnk4 <- myAAcomposition_jnk2[myAAcomposition_jnk2$GeneID %in% df_merged_jnk$target[df_merged_jnk$reg_RNA=="NOT" & df_merged_jnk$reg_protein == "DOWN"],]
  
  my_AA <- as.data.frame(myAAcodon)
  for (j in 1:dim(my_AA)[1]) {
    myAAcomposition_jnk2_j <- myAAcomposition_jnk2[myAAcomposition_jnk2$AAtriplet == my_AA$myAAcodon[j],]
    myAAcomposition_jnk3_j <- myAAcomposition_jnk3[myAAcomposition_jnk3$AAtriplet == my_AA$myAAcodon[j],]
    myAAcomposition_jnk4_j <- myAAcomposition_jnk4[myAAcomposition_jnk4$AAtriplet == my_AA$myAAcodon[j],]
    
    x <- my.t.test.p.value(myAAcomposition_jnk2_j$Frequency_AA_inGene, myAAcomposition_jnk3_j$Frequency_AA_inGene)
    y <- my.t.test.p.value(myAAcomposition_jnk2_j$Frequency_AA_inGene, myAAcomposition_jnk4_j$Frequency_AA_inGene)
    
    based_AA_all$p_value[based_AA_all$AAtriplet == my_AA$myAAcodon[j] & based_AA_all$variable == paste("RNA_NOT_protein_UP_Percentage_",
                                                                                                       kogene, sep="")] <- x
    based_AA_all$p_value[based_AA_all$AAtriplet == my_AA$myAAcodon[j] & based_AA_all$variable == paste("RNA_NOT_protein_DOWN_Percentage_",
                                                                                                       kogene, sep="")] <- y
  }
}
saveRDS(based_AA_all, file.path(out_dir, paste0("3_2_1_", Sys.Date(), "_AAcomposition_p_values.rds")))
based_AA_all$p_value <- as.numeric(based_AA_all$p_value)
based_AA_all$p_FDR <- p.adjust(based_AA_all$p_value, method = "fdr", n = length(based_AA_all$p_value))
based_AA_all$Different <- FALSE
based_AA_all$Different[based_AA_all$p_value <= 0.05] <- TRUE

based_AA_all$RNA_NOT_bg <- NA
for (i in 1:length(myKOgenes)) {
  print(i)
  kogene <- myKOgenes[i]
  df_merged_jnk <- df_merged[df_merged$KOstrain == kogene,]
  # all pG
  myAAcomposition_jnk <- myAAcomposition[myAAcomposition$GeneID %in% df_merged_jnk$target,]
  # RNA not reg
  myAAcomposition_jnk2 <- myAAcomposition_jnk[myAAcomposition_jnk$GeneID %in% df_merged_jnk$target[df_merged_jnk$reg_RNA=="NOT"],]
  
  my_AA <- as.data.frame(myAAcodon)
  for (j in 1:dim(my_AA)[1]) {
    myAAcomposition_jnk2_j <- myAAcomposition_jnk2[myAAcomposition_jnk2$AAtriplet == my_AA$myAAcodon[j],]

    based_AA_all$RNA_NOT_bg[based_AA_all$AAtriplet == my_AA$myAAcodon[j] & based_AA_all$variable == paste("RNA_NOT_protein_UP_Percentage_",
                                                                                                       kogene, sep="")] <- mean(myAAcomposition_jnk2_j$Frequency_AA_inGene)
    based_AA_all$RNA_NOT_bg[based_AA_all$AAtriplet == my_AA$myAAcodon[j] & based_AA_all$variable == paste("RNA_NOT_protein_DOWN_Percentage_",
                                                                                                       kogene, sep="")] <- mean(myAAcomposition_jnk2_j$Frequency_AA_inGene)
  }
}
saveRDS(based_AA_all, file.path(out_dir, paste0("3_2_1_", Sys.Date(), "_AAcomposition_p_values_mean_bg.rds")))
rm(df_merged_jnk)
rm(my_AA)
rm(myAAcomposition_jnk)
rm(myAAcomposition_jnk2)
rm(myAAcomposition_jnk3)
rm(myAAcomposition_jnk4)
rm(myAAcomposition_jnk2_j)
rm(myAAcomposition_jnk3_j)
rm(myAAcomposition_jnk4_j)
based_AA_all$FC <- based_AA_all$value - based_AA_all$RNA_NOT_bg
based_AA_all$log2FC <- log2(based_AA_all$value) - log2(based_AA_all$RNA_NOT_bg)

based_AA_all$Different <- FALSE
based_AA_all$Different[based_AA_all$p_value <= 0.05 & abs(based_AA_all$FC) >= 0.5] <- TRUE
based_AA_all$KOgene <- gsub(".*\\_(SP.*)$", "\\1" ,based_AA_all$variable)
saveRDS(based_AA_all, file.path(out_dir, paste0("3_2_1_", Sys.Date(), "_AAcomposition_p_values_mean_bg.rds")))

ggplot(based_AA_all, aes(FC, -log10(p_value))) +
  geom_point(data=subset(based_AA_all, Different == FALSE))+
  geom_point(data=subset(based_AA_all, Different == TRUE), aes(color=AAtriplet))+
  theme_classic()

pdf(file.path(out_dir, paste0("3_2_2_", Sys.Date(), "_volcanoplots_eachAA.pdf")), height = 6, width = 6)
for (i in 1:length(myAAcodon)) {
  print(i)
  based_AA_all_jnk <- based_AA_all[based_AA_all$AAtriplet == myAAcodon[i],]
  p <- ggplot(based_AA_all_jnk, aes(FC, -log10(p_value))) +
    geom_point(aes(color=Different))+
    geom_text_repel(data=subset(based_AA_all_jnk, Different == TRUE), aes(label=KOgene)) +
    theme_classic()+
    ggtitle(myAAcodon[i])
  print(p)
}
dev.off()
rm(p)
rm(based_AA_all_jnk)

AA_table <- as.data.frame(table(based_AA_all[,c(1,6)]))
AA_table <- AA_table[AA_table$Freq > 0,]
AA_table <- AA_table[AA_table$Different == TRUE,]

KO_table <- as.data.frame(table(based_AA_all[,c(10,6)]))
KO_table <- KO_table[KO_table$Freq > 0,]
KO_table <- KO_table[KO_table$Different == TRUE,]

based_AA_all$Score <- based_AA_all$FC * (-log10(based_AA_all$p_value))
based_AA_all$UPdown <- "UP"
based_AA_all$UPdown[grep("DOWN", based_AA_all$variable)] <- "DOWN"

newTable <- based_AA_all[,c(1,10,11,12)]
newTable <- newTable[!is.na(newTable$Score),]
saveRDS(newTable, file.path(out_dir, paste0("3_2_3_", Sys.Date(), "_score_table_KOgene_AA.rds")))
newTable$KOgene <- paste(newTable$KOgene, newTable$UPdown, sep="_")
newTable <- newTable[,1:3]
newTable <- dcast(newTable, KOgene ~ AAtriplet)
saveRDS(newTable, file.path(out_dir, paste0("3_2_3_", Sys.Date(), "_score_table_KOgene_AA.rds")))

# heatmap AA ko gene
df_heatmap <- newTable
rownames(df_heatmap) <- df_heatmap$KOgene
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}
df_heatmap <- as.data.frame(t(df_heatmap))

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(colnames(df_heatmap))
mydf$regulated <- gsub(".*\\_(.*)", "\\1", mydf$`colnames(df_heatmap)`)
mydf$KOgene <- gsub("(.*)\\_(.*)", "\\1", mydf$`colnames(df_heatmap)`)
names(mydf)[1] <- "GeneName"
jnk <- mydf$GeneName
mydf <- as.data.frame(mydf[,2])
rownames(mydf) <- jnk
names(mydf) <- "regulated"
mymat <- as.matrix(t(mymat))

mydf2 <- read.delim("DNA2AA.txt")
jnk <- mydf2$DNA
mydf2 <- as.data.frame(mydf2[,2])
rownames(mydf2) <- jnk
names(mydf2) <- "AA"
ann_colors = list(regulated = c(UP = "#e31a1c", DOWN = "#33a02c"))

pheatmap(mymat, cluster_cols = T, cluster_rows = F, show_colnames=T, show_rownames=F, 
         annotation_row = mydf, annotation_col = mydf2,
         main = "codon score for regulated genes at protein level (not RNA)", annotation_colors = ann_colors,
         annotation_names_row = FALSE, border_color=NA,
         file=file.path(out_dir, paste0("3_2_4_", Sys.Date(), "_heatmap_allAA_allKO.pdf")),
         width = 10, height = 10)

rm(ann_colors)
rm(df_heatmap)
rm(mydf)
rm(mydf2)
rm(mymat)
# filter for the ones not significant at all ########
newTable <- based_AA_all
newTable <- newTable[!is.na(newTable$Score),]
newTable <- newTable[newTable$p_FDR <= 0.05,]

jnk <- as.data.frame(table(newTable[,c(1,10)]))
jnk <- jnk[jnk$Freq >1,]

newTable <- newTable[newTable$AAtriplet %in% jnk$AAtriplet,]
newTable <- newTable[newTable$KOgene %in% jnk$KOgene,]
newTable <- newTable[,c(1,10,11,12)]
newTable$KOgene <- paste(newTable$KOgene, newTable$UPdown, sep="_")
newTable <- newTable[,1:3]
newTable <- dcast(newTable, KOgene ~ AAtriplet)

# heatmap AA ko gene
df_heatmap <- newTable
rownames(df_heatmap) <- df_heatmap$KOgene
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}
df_heatmap <- as.data.frame(t(df_heatmap))

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(colnames(df_heatmap))
mydf$regulated <- gsub(".*\\_(.*)", "\\1", mydf$`colnames(df_heatmap)`)
mydf$KOgene <- gsub("(.*)\\_(.*)", "\\1", mydf$`colnames(df_heatmap)`)
names(mydf)[1] <- "GeneName"
jnk <- mydf$GeneName
mydf <- as.data.frame(mydf[,2])
rownames(mydf) <- jnk
names(mydf) <- "regulated"
mymat <- as.matrix(t(mymat))

mydf2 <- read.delim("DNA2AA.txt")
jnk <- mydf2$DNA
mydf2 <- as.data.frame(mydf2[,2])
rownames(mydf2) <- jnk
names(mydf2) <- "AA"
ann_colors = list(regulated = c(UP = "#e31a1c", DOWN = "#33a02c"))
mymat[is.na(mymat)] <- 0
pheatmap(mymat, cluster_cols = T, cluster_rows = F, show_colnames=T, show_rownames=F, 
         annotation_row = mydf, annotation_col = mydf2,
         main = "codon score for regulated genes at protein level (not RNA)", annotation_colors = ann_colors,
         annotation_names_row = FALSE, border_color=NA,
         file=file.path(out_dir, paste0("3_2_5_", Sys.Date(), "_heatmap_allAA_allKO_atleast1_2.pdf")),
         width = 10, height = 10)

rm(ann_colors)
rm(df_heatmap)
rm(mydf)
rm(mydf2)
rm(mymat)
# filter for the ones up/down different ratios ########
newTable <- based_AA_all
newTable <- newTable[!is.na(newTable$Score),]
newTable <- newTable[newTable$p_FDR <= 0.05,]

jnk <- as.data.frame(table(newTable[,c(1,10)]))
jnk <- jnk[jnk$Freq >1,]
jnk$mergeID <- paste(jnk$AAtriplet, jnk$KOgene, sep="_")
newTable$mergeID <- paste(newTable$AAtriplet, newTable$KOgene, sep="_")
newTable <- newTable[newTable$mergeID %in% jnk$mergeID,]

newTable <- dcast(newTable, mergeID ~ UPdown, value.var="FC")
newTable$FCscore <- newTable$DOWN * newTable$UP
newTable <- newTable[newTable$FCscore <0,]
hist(newTable$FCscore)
newTable$AA <- gsub("(.*)\\_.*", "\\1", newTable$mergeID)
newTable$KO <- gsub("(.*)\\_(.*)", "\\2", newTable$mergeID)

# heatmap AA ko gene # not ordered ####################
df_heatmap <- newTable[,1:4]
rownames(df_heatmap) <- df_heatmap$mergeID
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(rownames(df_heatmap))
mydf$KOgene <- gsub("(.*)\\_(.*)", "\\2", mydf$`rownames(df_heatmap)`)
mydf$AA <- gsub("(.*)\\_(.*)", "\\1", mydf$`rownames(df_heatmap)`)

names(mydf)[1] <- "GeneName"
jnk <- mydf$GeneName
mydf <- as.data.frame(mydf[,2:3])
rownames(mydf) <- jnk

mydf2 <- read.delim("DNA2AA.txt")
mydf2 <- mydf2[,c(1,3)]
mydf <- merge(mydf2, mydf, by.y="AA", by.x="DNA", all.y=TRUE)
rownames(mydf) <- jnk
mydf <- mydf[,2:3]

mymat[is.na(mymat)] <- 0
pheatmap(mymat, cluster_cols = T, cluster_rows = F, show_colnames=T, show_rownames=F, 
         annotation_row = mydf,
         main = "codon score for regulated genes at protein level (not RNA)",
         border_color=NA,
         file=file.path(out_dir, paste0("3_2_6_", Sys.Date(), "_heatmap_only_both_UP_down.pdf")),
         width = 10, height = 10)

rm(df_heatmap)
rm(mydf)
rm(mydf2)
rm(mymat)
# heatmap AA ko gene # AA ordered ####################
newTable <- newTable[with(newTable, order(AA)),]

df_heatmap <- newTable[,1:4]
rownames(df_heatmap) <- df_heatmap$mergeID
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(rownames(df_heatmap))
mydf$KOgene <- gsub("(.*)\\_(.*)", "\\2", mydf$`rownames(df_heatmap)`)
mydf$AA <- gsub("(.*)\\_(.*)", "\\1", mydf$`rownames(df_heatmap)`)

names(mydf)[1] <- "GeneName"
jnk <- mydf$GeneName
mydf <- as.data.frame(mydf[,2:3])
rownames(mydf) <- jnk

mydf2 <- read.delim("DNA2AA.txt")
mydf2 <- mydf2[,c(1,3)]
mydf <- merge(mydf2, mydf, by.y="AA", by.x="DNA", all.y=TRUE)
rownames(mydf) <- jnk
mydf <- mydf[,2:3]

mymat[is.na(mymat)] <- 0
pheatmap(mymat, cluster_cols = T, cluster_rows = F, show_colnames=T, show_rownames=T, 
         annotation_row = mydf,
         main = "codon score for regulated genes at protein level (not RNA)",
         border_color=NA,
         file=file.path(out_dir, paste0("3_2_7_", Sys.Date(), "_heatmap_only_both_UP_down_AAsort.pdf")),
         width = 10, height = 20)

rm(df_heatmap)
rm(mydf)
rm(mydf2)
rm(mymat)
# heatmap AA ko gene # strain ordered ####################
newTable <- newTable[with(newTable, order(KO)),]

df_heatmap <- newTable[,1:4]
rownames(df_heatmap) <- df_heatmap$mergeID
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(rownames(df_heatmap))
mydf$KOgene <- gsub("(.*)\\_(.*)", "\\2", mydf$`rownames(df_heatmap)`)
mydf$AA <- gsub("(.*)\\_(.*)", "\\1", mydf$`rownames(df_heatmap)`)

names(mydf)[1] <- "GeneName"
jnk <- mydf$GeneName
mydf <- as.data.frame(mydf[,2:3])
rownames(mydf) <- jnk

mydf2 <- read.delim("DNA2AA.txt")
mydf2 <- mydf2[,c(1,3)]
mydf <- merge(mydf2, mydf, by.y="AA", by.x="DNA", all.y=TRUE)
rownames(mydf) <- jnk
mydf <- mydf[,2:3]

mymat[is.na(mymat)] <- 0
pheatmap(mymat, cluster_cols = F, cluster_rows = F, show_colnames=T, show_rownames=T, 
         annotation_row = mydf,
         main = "codon score for regulated genes at protein level (not RNA)",
         border_color=NA,
         file=file.path(out_dir, paste0("3_2_8_", Sys.Date(), "_heatmap_only_both_UP_down_KOsort.pdf")),
         width = 10, height = 20)

rm(df_heatmap)
rm(mydf)
rm(mydf2)
rm(mymat)
# heatmap AA ko gene # only FCscore ####################
df_heatmap <- newTable[,4:6]
df_heatmap <- dcast(df_heatmap, KO ~ AA, value.var="FCscore")

rownames(df_heatmap) <- df_heatmap$KO
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(colnames(df_heatmap))
names(mydf)[1] <- "GeneName"
mydf2 <- read.delim("DNA2AA.txt")
mydf2 <- mydf2[,c(1,3)]
mydf <- merge(mydf2, mydf, by.y="GeneName", by.x="DNA", all.y=TRUE)
jnk <- mydf$DNA
mydf <- as.data.frame(mydf$AA)
rownames(mydf) <- jnk
names(mydf) <- "AA"

mymat[is.na(mymat)] <- 0

my.colors <- rev(colorRampPalette(brewer.pal(4, "Blues"))(25))

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
         annotation_col = mydf, color = my.colors, 
         main = "codon score for regulated genes at protein level (not RNA)",
         border_color=NA,
         file=file.path(out_dir, paste0("3_2_9_", Sys.Date(), "_heatmap_only_both_UP_down_KO_AA.pdf")),
         width = 10, height = 10)

rm(df_heatmap)
rm(mydf)
rm(mydf2)
rm(mymat)
# heatmap AA ko gene # only UP ####################
df_heatmap <- newTable[,c(3,5,6)]
df_heatmap <- dcast(df_heatmap, KO ~ AA, value.var="UP")

rownames(df_heatmap) <- df_heatmap$KO
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(colnames(df_heatmap))
names(mydf)[1] <- "GeneName"
mydf2 <- read.delim("DNA2AA.txt")
mydf2 <- mydf2[,c(1,3)]
mydf <- merge(mydf2, mydf, by.y="GeneName", by.x="DNA", all.y=TRUE)
jnk <- mydf$DNA
mydf <- as.data.frame(mydf$AA)
rownames(mydf) <- jnk
names(mydf) <- "AA"

mymat[is.na(mymat)] <- 0

my.colors <- colorRampPalette(brewer.pal(4, "OrRd"))(25)

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
         annotation_col = mydf,
         main = "codon score for regulated genes at protein level (not RNA)",
         border_color=NA,
         file=file.path(out_dir, paste0("3_2_10_", Sys.Date(), "_heatmap_only_both_UP_down_KO_AA_upFC.pdf")),
         width = 10, height = 10)

rm(df_heatmap)
rm(mydf)
rm(mydf2)
rm(mymat)

# heatmap AA ko gene # only UP # add annotation to the strains ###################
df_heatmap <- newTable[,c(3,5,6)]
df_heatmap <- dcast(df_heatmap, KO ~ AA, value.var="UP")

rownames(df_heatmap) <- df_heatmap$KO
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(colnames(df_heatmap))
names(mydf)[1] <- "GeneName"
mydf2 <- read.delim("DNA2AA.txt")
mydf2 <- mydf2[,c(1,3)]
mydf <- merge(mydf2, mydf, by.y="GeneName", by.x="DNA", all.y=TRUE)
jnk <- mydf$DNA
mydf <- as.data.frame(mydf$AA)
rownames(mydf) <- jnk
names(mydf) <- "AA"

mymat[is.na(mymat)] <- 0

mydf2 <- as.data.frame(rownames(df_heatmap))
names(mydf2) <- "KOgene"

df_x <- df_merged[abs(df_merged$log2FC_RNA)>=0.6 & df_merged$pvalue_RNA<=0.005,]
jnk <- as.data.frame(table(df_x$KOstrain))
mydf2 <- merge(mydf2, jnk, by.x="KOgene", by.y="Var1", all.x=TRUE)
names(mydf2)[2] <- "N_RNA_target"

df_x <- df_merged[abs(df_merged$log2FC_protein)>=0.2 & df_merged$pvalue_protein<=0.03,]
jnk <- as.data.frame(table(df_x$KOstrain))
mydf2 <- merge(mydf2, jnk, by.x="KOgene", by.y="Var1", all.x=TRUE)
names(mydf2)[3] <- "N_protein_target"


df_x <- read.delim("ReplicateRNAprotein/RBPtag_4_1_counts_merged.txt")
df_x <- splitColumnBySep(df_x, "Var1")
mydf2 <- merge(mydf2, df_x, by.x="KOgene", by.y="Var1", all.x=TRUE)
mydf2[is.na(mydf2)] <- 0
rownames(mydf2) <- mydf2$KOgene
mydf2 <- mydf2[,-1]

my.colors <- colorRampPalette(brewer.pal(4, "OrRd"))(25)

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
         annotation_col = mydf,
         annotation_row = mydf2,
         main = "codon score for regulated genes at protein level (not RNA)",
         border_color=NA,
         file=file.path(out_dir, paste0("3_2_11_", Sys.Date(), "_heatmap_only_both_UP_down_KO_AA_upFC_geneInfo.pdf")),
         width = 10, height = 10)

rm(df_heatmap)
rm(mydf)
rm(mydf2)
rm(mymat)

# heatmap AA ko gene # only UP # add annotation to the strains # yes/no##################
df_heatmap <- newTable[,c(3,5,6)]
df_heatmap <- dcast(df_heatmap, KO ~ AA, value.var="UP")

rownames(df_heatmap) <- df_heatmap$KO
df_heatmap <- df_heatmap[,-1]

for (i in 1:dim(df_heatmap)[2]) {
  df_heatmap[,i] <- as.numeric(df_heatmap[,i])
}

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(colnames(df_heatmap))
names(mydf)[1] <- "GeneName"
mydf2 <- read.delim("DNA2AA.txt")
mydf2 <- mydf2[,c(1,3)]
mydf <- merge(mydf2, mydf, by.y="GeneName", by.x="DNA", all.y=TRUE)
jnk <- mydf$DNA
mydf <- as.data.frame(mydf$AA)
rownames(mydf) <- jnk
names(mydf) <- "AA"

mymat[is.na(mymat)] <- 0

mydf2 <- as.data.frame(rownames(df_heatmap))
names(mydf2) <- "KOgene"

df_x <- df_merged[abs(df_merged$log2FC_RNA)>=0.6 & df_merged$pvalue_RNA<=0.005,]
jnk <- as.data.frame(table(df_x$KOstrain))
mydf2 <- merge(mydf2, jnk, by.x="KOgene", by.y="Var1", all.x=TRUE)
names(mydf2)[2] <- "N_RNA_target"

df_x <- df_merged[abs(df_merged$log2FC_protein)>=0.2 & df_merged$pvalue_protein<=0.03,]
jnk <- as.data.frame(table(df_x$KOstrain))
mydf2 <- merge(mydf2, jnk, by.x="KOgene", by.y="Var1", all.x=TRUE)
names(mydf2)[3] <- "N_protein_target"


df_x <- read.delim("ReplicateRNAprotein/RBPtag_4_1_counts_merged.txt")
df_x <- splitColumnBySep(df_x, "Var1")
mydf2 <- merge(mydf2, df_x, by.x="KOgene", by.y="Var1", all.x=TRUE)
mydf2[is.na(mydf2)] <- 0
rownames(mydf2) <- mydf2$KOgene
mydf2 <- mydf2[,-1]
mydf2$PPI_count[mydf2$PPI_count != 0] <- 1
mydf2$RNA_count[mydf2$RNA_count != 0] <- 1


my.colors <- colorRampPalette(brewer.pal(4, "OrRd"))(25)

pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
         annotation_col = mydf,
         annotation_row = mydf2,
         main = "codon score for regulated genes at protein level (not RNA)",
         border_color=NA,
         file=file.path(out_dir, paste0("3_2_12_", Sys.Date(), "_heatmap_only_both_UP_down_KO_AA_upFC_geneInfo.pdf")),
         width = 10, height = 10)

rm(df_heatmap)
rm(mydf)
rm(mydf2)
rm(mymat)
rm(jnk)
rm(newTable)
rm(AA_table)
rm(based_AA_all)
rm(df_x)
rm(KO_table)
rm(myAAcomposition)


}
##############################################################################
if(chromosomeamplification){
# 4 # chromosome amplification # test based on transcriptome ###########################################
# 4.1 # plots to see ###################################################################################
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))
names(df_RNA) <- c("KOstrain", "target", "log2FC_RNA", "pvalue_RNA")

chr_pombe <- readRDS("ReplicateRNAprotein/MotifSearch_20190911/2019-09-23_Spombe_gff3_withSequence.rds")
chr_pombe <- chr_pombe[chr_pombe$type=="gene", ]

chr_pombe <- chr_pombe[,c(1,4,5,7,9)]
chr_pombe$GeneID <- gsub(".*\\:(.*)", "\\1", chr_pombe$ID)

my_chr_counts <- as.data.frame(table(chr_pombe$seqid))
names(my_chr_counts) <- c("Chr", "Total_Gene")

myKOgenes <- unique(df_RNA$KOstrain)

for (i in 1:length(myKOgenes)) {
  print(i)
  df_RNA_jnk <- df_RNA[df_RNA$KOstrain == myKOgenes[i],]
  chr_pombe_jnk <- chr_pombe[chr_pombe$GeneID %in% df_RNA_jnk$target,]
  jnk <- as.data.frame(table(chr_pombe_jnk$seqid))
  names(jnk) <- c("Chr", paste0("All_", myKOgenes[i]))
  
  my_chr_counts <- merge(my_chr_counts, jnk, by=1, all.x=TRUE)
  
  df_RNA_jnk <- df_RNA_jnk[df_RNA_jnk$pvalue_RNA <= 0.005,]
  
  df_RNA_jnk_UP <- df_RNA_jnk[df_RNA_jnk$log2FC_RNA >= 0.6,]
  df_RNA_jnk_DOWN <- df_RNA_jnk[df_RNA_jnk$log2FC_RNA <= -0.6,]
  
  chr_pombe_jnk <- chr_pombe[chr_pombe$GeneID %in% df_RNA_jnk_UP$target,]
  jnk <- as.data.frame(table(chr_pombe_jnk$seqid))
  names(jnk) <- c("Chr", paste0("UP_", myKOgenes[i]))
  my_chr_counts <- merge(my_chr_counts, jnk, by=1, all.x=TRUE)

  chr_pombe_jnk <- chr_pombe[chr_pombe$GeneID %in% df_RNA_jnk_DOWN$target,]
  jnk <- as.data.frame(table(chr_pombe_jnk$seqid))
  names(jnk) <- c("Chr", paste0("DOWN_", myKOgenes[i]))
  my_chr_counts <- merge(my_chr_counts, jnk, by=1, all.x=TRUE)
  
}

rownames(my_chr_counts) <- my_chr_counts$Chr
my_chr_counts <- my_chr_counts[,-1]
my_chr_counts <- as.data.frame(t(my_chr_counts))

my_chr_Percentages <- my_chr_counts
my_chr_Percentages <- 100*my_chr_Percentages/rowSums(my_chr_Percentages)

pdf(file.path(out_dir, paste0("4_1_1_", Sys.Date(), "_plots_eachCHR.pdf")), height = 6, width = 6)
for (i in 1:dim(my_chr_Percentages)[2]) {
  print(i)
  my_chr_Percentages_jnk <- my_chr_Percentages
  names(my_chr_Percentages_jnk)[i] <- "myCol"
  
  p <- ggplot(my_chr_Percentages_jnk, aes(myCol)) +
    geom_histogram(bins=50) +
    theme_classic() +
    xlab("Percentage") +
    ggtitle(names(my_chr_Percentages)[i])
  print(p)
}
dev.off()


pdf(file.path(out_dir, paste0("4_1_2_", Sys.Date(), "_plots_eachStrain_CHR.pdf")), height = 6, width = 6)
for (i in 1:length(myKOgenes)) {
  print(i)
  df_RNA_jnk <- df_RNA[df_RNA$KOstrain == myKOgenes[i],]
  chr_pombe_jnk <- chr_pombe[chr_pombe$GeneID %in% df_RNA_jnk$target,]
  chr_pombe_jnk <- merge(chr_pombe_jnk, df_RNA_jnk, by.x="GeneID", by.y="target")
  chr_pombe_jnk$regulated <- FALSE
  chr_pombe_jnk$regulated[chr_pombe_jnk$pvalue_RNA <= 0.005 & abs(chr_pombe_jnk$log2FC_RNA)>=0.6] <- TRUE
  
  p <- ggplot(chr_pombe_jnk, aes(start, log2FC_RNA)) +
    geom_point(aes(color=regulated)) +
    theme_classic() +
    xlab("gene start") +
    ggtitle(paste("Strain:", myKOgenes[i]))+
    facet_grid(seqid ~ .) +
    geom_hline(yintercept = 0)
  print(p)
  chr_pombe_jnk <- chr_pombe_jnk %>%
    group_by(seqid) %>%
    dplyr::mutate(Position=round(100*start/max(start),2)) %>%
    as.data.frame()
  
  p <- ggplot(chr_pombe_jnk, aes(Position, log2FC_RNA)) +
    geom_point(aes(color=regulated)) +
    theme_classic() +
    xlab("gene start in chr, %") +
    ggtitle(paste("Strain:", myKOgenes[i]))+
    facet_grid(seqid ~ .) +
    geom_hline(yintercept = 0)
  print(p)
}
dev.off()


pdf(file.path(out_dir, paste0("4_1_3_", Sys.Date(), "_plots_eachStrain_CHR_only_percentage.pdf")), height = 6, width = 6)
for (i in 1:length(myKOgenes)) {
  print(i)
  df_RNA_jnk <- df_RNA[df_RNA$KOstrain == myKOgenes[i],]
  chr_pombe_jnk <- chr_pombe[chr_pombe$GeneID %in% df_RNA_jnk$target,]
  chr_pombe_jnk <- merge(chr_pombe_jnk, df_RNA_jnk, by.x="GeneID", by.y="target")
  chr_pombe_jnk$regulated <- FALSE
  chr_pombe_jnk$regulated[chr_pombe_jnk$pvalue_RNA <= 0.005 & abs(chr_pombe_jnk$log2FC_RNA)>=0.6] <- TRUE

  chr_pombe_jnk <- chr_pombe_jnk %>%
    group_by(seqid) %>%
    dplyr::mutate(Position=round(100*start/max(start),2)) %>%
    as.data.frame()
  
  p <- ggplot(chr_pombe_jnk, aes(Position, log2FC_RNA)) +
    geom_point(aes(color=regulated)) +
    theme_classic() +
    xlab("gene start in chr, %") +
    ggtitle(paste("Strain:", myKOgenes[i]))+
    facet_grid(seqid ~ .) +
    geom_hline(yintercept = 0)
  print(p)
}
dev.off()

# only proteins
myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_RNA <- readRDS(file.path(out_dir, myfile))
names(df_RNA) <- c("KOstrain", "target", "log2FC_RNA", "pvalue_RNA")

chr_pombe <- readRDS("ReplicateRNAprotein/MotifSearch_20190911/2019-09-23_Spombe_gff3_withSequence.rds")
chr_pombe <- chr_pombe[chr_pombe$type=="gene", ]

chr_pombe <- chr_pombe[,c(1,4,5,7,9)]
chr_pombe$GeneID <- gsub(".*\\:(.*)", "\\1", chr_pombe$ID)

my_chr_counts <- as.data.frame(table(chr_pombe$seqid))
names(my_chr_counts) <- c("Chr", "Total_Gene")

myKOgenes <- unique(df_merged$KOstrain)


pdf(file.path(out_dir, paste0("4_1_3_", Sys.Date(), "_plots_eachStrain_CHR_only_percentage_proteins.pdf")), height = 6, width = 6)
for (i in 1:length(myKOgenes)) {
  print(i)
  df_RNA_jnk <- df_RNA[df_RNA$KOstrain == myKOgenes[i],]
  chr_pombe_jnk <- chr_pombe[chr_pombe$GeneID %in% df_RNA_jnk$target,]
  chr_pombe_jnk <- merge(chr_pombe_jnk, df_RNA_jnk, by.x="GeneID", by.y="target")
  chr_pombe_jnk$regulated <- FALSE
  chr_pombe_jnk$regulated[chr_pombe_jnk$pvalue_RNA <= 0.03 & abs(chr_pombe_jnk$log2FC_RNA)>=0.2] <- TRUE
  
  chr_pombe_jnk <- chr_pombe_jnk %>%
    group_by(seqid) %>%
    dplyr::mutate(Position=round(100*start/max(start),2)) %>%
    as.data.frame()
  
  p <- ggplot(chr_pombe_jnk, aes(Position, log2FC_RNA)) +
    geom_point(aes(color=regulated)) +
    theme_classic() +
    xlab("gene start in chr, %") +
    ggtitle(paste("Strain:", myKOgenes[i]))+
    facet_grid(seqid ~ .) +
    geom_hline(yintercept = 0)
  print(p)
}
dev.off()

# 4.2 # scoring by bins #######################################################
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))
names(df_RNA) <- c("KOstrain", "target", "log2FC_RNA", "pvalue_RNA")
df_RNA$Significant <- "NOT"
df_RNA$Significant[df_RNA$log2FC_RNA >= 0.6 & df_RNA$pvalue_RNA <= 0.005] <- "UP"
df_RNA$Significant[df_RNA$log2FC_RNA <= -0.6 & df_RNA$pvalue_RNA <= 0.005] <- "DOWN"

chr_pombe <- readRDS("ReplicateRNAprotein/MotifSearch_20190911/2019-09-23_Spombe_gff3_withSequence.rds")
chr_pombe <- chr_pombe[chr_pombe$type=="gene", ]
chr_pombe$mid <- rowMeans(chr_pombe[,4:5])

chr_pombe <- chr_pombe[,c(1,27,9)]
chr_pombe$GeneID <- gsub(".*\\:(.*)", "\\1", chr_pombe$ID)
chr_pombe <- chr_pombe %>%
  group_by(seqid) %>%
  dplyr::mutate(Position=round(100*mid/max(mid),2)) %>%
  as.data.frame()

df_test <- merge(df_RNA, chr_pombe, by.x= "target", by.y="GeneID", all.x=TRUE)
df_test <- remove.factors(df_test)
df_test$binNumber <- ceiling(df_test$Position)
df_test$binID <- paste(df_test$seqid, df_test$binNumber, sep="_")


myKOgenes <- unique(df_test$KOstrain)
my_df <- data.frame(KOstrain=character(), binID=character(), bin_number=numeric(),
                    up_number=numeric(), down_number=numeric(), reg_number=numeric(),
                    up_pvalue=numeric(), down_pvalue=numeric(), reg_pvalue=numeric(),
                    population = numeric(), regulated=numeric(), regulated_up=numeric(), regulated_down=numeric())

for (i in 1:length(myKOgenes)) {
  print(i)
  df_test_jnk <- df_test[df_test$KOstrain == myKOgenes[i],]
  p_size <- dim(df_test_jnk)[1]
  reg_size <- sum(df_test_jnk$Significant != "NOT")
  reg_size_up <- sum(df_test_jnk$Significant == "UP")
  reg_size_down <- sum(df_test_jnk$Significant == "DOWN")
  
  df_test_jnk <- df_test_jnk %>%
    group_by(binID) %>%
    dplyr::mutate(bin_number = length(target),
                  up_number = sum(Significant == "UP"),
                  down_number = sum(Significant == "DOWN"),
                  reg_number = sum(Significant != "NOT")) %>%
    as.data.frame()
  
  df_test_jnk <- as.data.frame(unique(df_test_jnk[,c(2,10:15)]))
  df_test_jnk <- remove.factors(df_test_jnk)
  df_test_jnk$up_pvalue <- NA
  df_test_jnk$down_pvalue <- NA
  df_test_jnk$reg_pvalue <- NA
  df_test_jnk$population <- p_size
  df_test_jnk$regulated <- reg_size
  df_test_jnk$regulated_up <- reg_size_up
  df_test_jnk$regulated_down <- reg_size_down
  for (j in 1:dim(df_test_jnk)[1]) {
    df_test_jnk$up_pvalue[j] <- phyper(df_test_jnk$up_number[j]-1, df_test_jnk$bin_number[j], 
                                       p_size-df_test_jnk$bin_number[j], reg_size_up, lower.tail=FALSE)
    
    df_test_jnk$down_pvalue[j] <- phyper(df_test_jnk$down_number[j]-1, df_test_jnk$bin_number[j], 
                                       p_size-df_test_jnk$bin_number[j], reg_size_down, lower.tail=FALSE)
    df_test_jnk$reg_pvalue[j] <- phyper(df_test_jnk$reg_number[j]-1, df_test_jnk$bin_number[j], 
                                         p_size-df_test_jnk$bin_number[j], reg_size, lower.tail=FALSE)
  }
  my_df <- as.data.frame(rbind(my_df, df_test_jnk))
  
}

my_df$up_pvalue_FDR <- p.adjust(my_df$up_pvalue, method = "fdr", n = length(my_df$up_pvalue))
my_df$down_pvalue_FDR <- p.adjust(my_df$down_pvalue, method = "fdr", n = length(my_df$down_pvalue))
my_df$reg_pvalue_FDR <- p.adjust(my_df$reg_pvalue, method = "fdr", n = length(my_df$reg_pvalue))

saveRDS(my_df, file.path(out_dir, paste0("4_2_1_", Sys.Date(), "_mydf_pvalue_region.rds")))
rm(df_test_jnk)

# regulated #####################################################################################
my_df$pvalue_selection <- my_df$reg_pvalue
my_df$pvalue_selection_log10 <- -log10(my_df$pvalue_selection)
#my_df$pvalue_selection_log10_sign <- my_df$pvalue_selection_log10
#my_df$pvalue_selection_log10_sign[my_df$pvalue_selection == my_df$down_pvalue_FDR] <- -my_df$pvalue_selection_log10_sign[my_df$pvalue_selection == my_df$down_pvalue_FDR]

df_heatmap <- my_df[,c(1,3,19)]
df_heatmap <- dcast(df_heatmap, KOstrain ~ binID, value.var="pvalue_selection_log10")
sum(is.na(df_heatmap))
df_heatmap[is.na(df_heatmap)] <- 0

rownames(df_heatmap) <- df_heatmap$KOstrain
df_heatmap <- df_heatmap[,-1]

jnk <- as.data.frame(names(df_heatmap))
jnk$order <- 1:dim(jnk)[1]
names(jnk)[1] <- "cnames"
jnk$binID <- gsub("(.*)\\_.*", "\\1", jnk$cnames)
jnk$binnumber <- gsub(".*\\_(.*)", "\\1", jnk$cnames)
jnk$binnumber <- as.numeric(jnk$binnumber)

jnk <- jnk[with(jnk, order(binID, binnumber)),]

df_heatmap <- df_heatmap[,jnk$order]

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(names(df_heatmap))
mydf$chr <- gsub("(.*)\\_.*", "\\1", mydf$`names(df_heatmap)`)
mydf$bin <- gsub("(.*)\\_(.*)", "\\2", mydf$`names(df_heatmap)`)
rownames(mydf) <- mydf$`names(df_heatmap)`
mydf <- mydf[,-1]

ann_colors = list(chr = c(I = "#3288bd", II = "#f46d43", 
                          III="#66bd63", MT="#d53e4f"))

mymat[mymat < -log10(0.05)] <- 0
mymat[mymat >= -log10(0.05)] <- 1

mycolors <- c("#ffffff", "#b2182b")
mybreaks <- c(-0.1,0.1, 1.1)


pheatmap(mymat, cluster_cols = F, cluster_rows = T, show_colnames=F, show_rownames=T, 
         annotation_col = mydf, 
         color = mycolors, clustering_distance_rows = "binary", 
         breaks = mybreaks, main = "regulated genes, -log10(p-value)", 
         annotation_colors = ann_colors,
         annotation_legend = FALSE, fontsize = 4,
         file=file.path(out_dir, paste0("4_2_2_", Sys.Date(), "_regulated_chr_pvalue_heatmap.pdf")),
         width = 4, height = 6)
# up_regulated #####################################################################################
my_df$pvalue_selection <- my_df$up_pvalue
my_df$pvalue_selection_log10 <- -log10(my_df$pvalue_selection)
#my_df$pvalue_selection_log10_sign <- my_df$pvalue_selection_log10
#my_df$pvalue_selection_log10_sign[my_df$pvalue_selection == my_df$down_pvalue_FDR] <- -my_df$pvalue_selection_log10_sign[my_df$pvalue_selection == my_df$down_pvalue_FDR]

df_heatmap <- my_df[,c(1,3,19)]
df_heatmap <- dcast(df_heatmap, KOstrain ~ binID, value.var="pvalue_selection_log10")
sum(is.na(df_heatmap))
df_heatmap[is.na(df_heatmap)] <- 0

rownames(df_heatmap) <- df_heatmap$KOstrain
df_heatmap <- df_heatmap[,-1]

jnk <- as.data.frame(names(df_heatmap))
jnk$order <- 1:dim(jnk)[1]
names(jnk)[1] <- "cnames"
jnk$binID <- gsub("(.*)\\_.*", "\\1", jnk$cnames)
jnk$binnumber <- gsub(".*\\_(.*)", "\\1", jnk$cnames)
jnk$binnumber <- as.numeric(jnk$binnumber)

jnk <- jnk[with(jnk, order(binID, binnumber)),]

df_heatmap <- df_heatmap[,jnk$order]

mymat <- matrix(as.numeric(as.matrix(df_heatmap)), nrow = dim(df_heatmap)[1], ncol=dim(df_heatmap)[2])
rownames(mymat) <- rownames(df_heatmap)
colnames(mymat) <- colnames(df_heatmap)

mydf <- as.data.frame(names(df_heatmap))
mydf$chr <- gsub("(.*)\\_.*", "\\1", mydf$`names(df_heatmap)`)
mydf$bin <- gsub("(.*)\\_(.*)", "\\2", mydf$`names(df_heatmap)`)
rownames(mydf) <- mydf$`names(df_heatmap)`
mydf <- mydf[,-1]

ann_colors = list(chr = c(I = "#3288bd", II = "#f46d43", 
                          III="#66bd63", MT="#d53e4f"))

mymat[mymat < -log10(0.05)] <- 0
mymat[mymat >= -log10(0.05)] <- 1

mycolors <- c("#ffffff", "#b2182b")
mybreaks <- c(-0.1,0.1, 1.1)


pheatmap(mymat, cluster_cols = F, cluster_rows = T, show_colnames=F, show_rownames=T, 
         annotation_col = mydf, 
         color = mycolors,
         breaks = mybreaks, main = "up regulated genes, -log10(p-value)", 
         annotation_colors = ann_colors, clustering_distance_rows = "binary", 
         annotation_legend = FALSE, fontsize = 6, fontface="bold",
         file=file.path(out_dir, paste0("4_2_2_", Sys.Date(), "_up_regulated_chr_pvalue_heatmap.pdf")))




}
##################################################################################################################
########## 20191025 # Happy tests :) ################################################
# 5 # Based on transcriptome ########################################################
myfile <- list.files(path=out_dir, pattern = "^2_1_2")
df_RNA <- readRDS(file.path(out_dir, myfile))
names(df_RNA) <- c("KOstrain", "target", "log2FC_RNA", "pvalue_RNA")
df_RNA$regulated <- "NOT"
df_RNA$regulated[df_RNA$log2FC_RNA >=0.6 & df_RNA$pvalue_RNA <= 0.005] <- "UP"
df_RNA$regulated[df_RNA$log2FC_RNA <= -0.6 & df_RNA$pvalue_RNA <= 0.005] <- "DOWN"

df_jnk <- df_RNA %>%
  group_by(KOstrain) %>%
  dplyr::mutate(notreg = sum(regulated=="NOT"),
                yesreg = sum(regulated!="NOT")) %>%
  as.data.frame()

ggplot(df_RNA, aes(log2FC_RNA)) +
  geom_density(aes(color=KOstrain)) +
  guides(color=FALSE) +
  theme_classic()


df_RNA_test <- df_RNA
df_RNA_test <- df_RNA_test %>%
  group_by(KOstrain) %>%
  dplyr::mutate(FC_mean=mean(log2FC_RNA),
                FC_sd=sd(log2FC_RNA),
                FC_median=median(log2FC_RNA),
                FC_Q1=quantile(log2FC_RNA)[[2]],
                FC_Q3=quantile(log2FC_RNA)[[4]]) %>%
  as.data.frame()
df_RNA_test <- as.data.frame(unique(df_RNA_test[,c(1,6:10)]))
df_RNA_test$IQR <- df_RNA_test$FC_Q3 - df_RNA_test$FC_Q1


my_counts <- as.data.frame(table(df_RNA[,c(1,5)]))
my_counts <- my_counts %>%
  group_by(KOstrain) %>%
  dplyr::mutate(Percentage=round(100*Freq/sum(Freq),2)) %>%
  as.data.frame()
my_counts <- dcast(my_counts, KOstrain~regulated, value.var="Percentage")

df_RNA_test <- merge(df_RNA_test, my_counts, by=1)
rm(my_counts)

motif_file <- readRDS(file.path("E:/Merve/20190424_FinalDatasets/ReplicateRNAprotein/MotifSearch_20190911/", "2_20191010_ALL_motifs_combined.rds"))
motif_file <- motif_file[motif_file$TypeOfData == "Only_Transcriptome" | motif_file$TypeOfData == "Promoter_Only_Transcriptome",]
motif_file_promoter_count <- as.data.frame(table(motif_file[,c(7,10)]))
motif_file_promoter_count <- dcast(motif_file_promoter_count, KOgene~Category_site, value.var="Freq")

df_RNA_test <- merge(df_RNA_test, motif_file_promoter_count, by=1, all.x=TRUE)
df_RNA_test[is.na(df_RNA_test)] <- 0

df_RNA_test_cor <- cor(df_RNA_test[,2:14])
df_RNA_test$Promoter_CDS <- paste(df_RNA_test$promoter !=0, df_RNA_test$CDS !=0)

ggplot(df_RNA_test, aes(Promoter_CDS, IQR)) +
  geom_boxplot()


names(motif_file)
motif_counts <- as.data.frame(table(motif_file[,c(1,10)]))
motif_counts <- motif_counts[motif_counts$Freq>0,]

jnk <- motif_file[motif_file$Word == "CAAGGCYG",]
# add protein changing info
myfile <- list.files(path=out_dir, pattern = "^2_1_1")
df_protein <- readRDS(file.path(out_dir, myfile))
names(df_protein) <- c("KOstrain", "target", "log2FC_protein", "pvalue_protein")
df_protein$regulated <- "NOT"
df_protein$regulated[df_protein$log2FC_protein >=0.2 & df_protein$pvalue_protein <= 0.03] <- "UP"
df_protein$regulated[df_protein$log2FC_protein <= -0.2 & df_protein$pvalue_protein <= 0.03] <- "DOWN"


ggplot(df_protein, aes(log2FC_protein)) +
  geom_density(aes(color=KOstrain)) +
  guides(color=FALSE) +
  theme_classic()


df_protein_test <- df_protein
df_protein_test <- df_protein_test %>%
  group_by(KOstrain) %>%
  dplyr::mutate(FC_mean=mean(log2FC_protein),
                FC_sd=sd(log2FC_protein),
                FC_median=median(log2FC_protein),
                FC_Q1=quantile(log2FC_protein)[[2]],
                FC_Q3=quantile(log2FC_protein)[[4]]) %>%
  as.data.frame()
df_protein_test <- as.data.frame(unique(df_protein_test[,c(1,6:10)]))
df_protein_test$IQR <- df_protein_test$FC_Q3 - df_protein_test$FC_Q1


my_counts <- as.data.frame(table(df_protein[,c(1,5)]))
my_counts <- my_counts %>%
  group_by(KOstrain) %>%
  dplyr::mutate(Percentage=round(100*Freq/sum(Freq),2)) %>%
  as.data.frame()
my_counts <- dcast(my_counts, KOstrain~regulated, value.var="Percentage")

df_protein_test <- merge(df_protein_test, my_counts, by=1)
rm(my_counts)
######################################################################################
jnk <- read.delim("RBPs_tagged_IPed_grouped.txt")
jnk2 <- readxl::read_xls("Spombe_ORFeome_localization/41587_2006_BFnbt1222_MOESM9_ESM.xls")
jnk2 <- jnk2[jnk2$`Gene Name` %in% jnk$GeneName,]
jnk2 <- jnk2[grep("dots", jnk2$Localization),]
jnk2 <- jnk2[-grep("aggre", jnk2$`Additional Information`),]

jnk <- jnk[jnk$GeneName %in% jnk2$`Gene Name`,]












# 20200122 # trial #########################
myfile <- list.files(path = out_dir, pattern = "^2_2_2.*rds")
experiments_meta <- readRDS(file.path(out_dir, myfile))

ggplot(experiments_meta, aes(FC_cor, genesRegulated_protein))+
  geom_point()

ggplot(experiments_meta, aes(genesRegulated_RNA_overlep, genesRegulated_protein_overlap))+
  geom_point(aes(color=FC_cor), size=4) +
  scale_color_gradient2(midpoint = 0.2)


library(plot3D)
scatter3D(y=experiments_meta$genesRegulated_RNA_overlep, x=experiments_meta$FC_cor, 
          z=experiments_meta$genesRegulated_protein_overlap,
          bty="b2", 
          #bty="b",
          ticktype="detailed", phi=0, theta = 40, 
          #pch=20, 
          pch=1,
          #alpha=0.4,
          cex=2, xlim=c(-0.2,.6),
          ylab="RNA target",
          xlab="correlation",
          colvar = experiments_meta$genesRegulated_protein_overlap,
          zlab="protein target", col=gg.col(100))

scatter3D(y=experiments_meta$genesRegulated_RNA_overlep, x=experiments_meta$FC_cor, 
          z=experiments_meta$genesRegulated_protein_overlap,
          add=TRUE,
          colvar = experiments_meta$genesRegulated_protein_overlap,
          pch=20,
          col=gg.col(100),
          cex=1)

jnk <- c("SPBC1685.01", "SPCC576.12c", "SPAC9E9.09c", "SPBC3E7.05c", "SPAC3A11.07", "SPBC21C3.12c")
jnk <- experiments_meta[experiments_meta$experiments %in% jnk,]

text3D(x=experiments_meta$genesRegulated_RNA_overlep, experiments_meta$FC_cor, 
       experiments_meta$genesRegulated_protein_overlap,
       add=TRUE, colkey = F, cex=0.5, labels=experiments_meta$experiments)


text3D(x=experiments_meta$genesRegulated_RNA_overlep, y=experiments_meta$FC_cor, 
       z=experiments_meta$genesRegulated_protein_overlap,
       cex=0.5, labels=experiments_meta$experiments,
       bty="b2", ticktype="detailed", phi=10, theta = 40, 
       pch=20)


# for the figures # 20200303 #####################################################################################
# Figure 5 # general figures for replicates ######################################
# RNA heatmap ####################################################################
out_dir2 <- "E:/Merve/PaperFigures/20200303_Figure5/"

myfile <- list.files(path = out_dir, pattern = "2_1_2_")
df_RNA_FC <- readRDS(file.path(out_dir, myfile))

myPvalueCutOFF <- 0.005
myFCCutOFF <- 0.6

df_RNA_FC$regulated <- FALSE
df_RNA_FC$regulated[abs(df_RNA_FC$log2FC_Strain_wt) >= myFCCutOFF & 
                      df_RNA_FC$pvalue <= myPvalueCutOFF] <- TRUE

jnk <- as.data.frame(table(df_RNA_FC[,c(2,5)]))
jnk <- subset(jnk, regulated == TRUE)
hist(jnk$Freq, 100)

ggplot(jnk, aes(x="", y=Freq)) +
  geom_violin() +
  theme_classic() +
  geom_hline(yintercept = 3)

quantile(jnk$Freq, 0.9)

jnk <- subset(jnk, Freq >= 6)

df_RNA_FC <- df_RNA_FC[df_RNA_FC$pG %in% jnk$pG,]
df_RNA_FC$p_FC <- sign(df_RNA_FC$log2FC_Strain_wt) * -log10(df_RNA_FC$pvalue)
# df_RNA_FC$p_FC <- df_RNA_FC$log2FC_Strain_wt * -log10(df_RNA_FC$pvalue)


df_RNA_1 <- df_RNA_FC[,1:3]
df_RNA_1 <- dcast(df_RNA_1, pG ~ KOstrain)
rownames(df_RNA_1) <- df_RNA_1$pG
df_RNA_1 <- df_RNA_1[,-1]
df_RNA_1 <- remove.factors(df_RNA_1)


df_RNA_2 <- df_RNA_FC[,c(1,2,6)]
df_RNA_2 <- dcast(df_RNA_2, pG ~ KOstrain)
rownames(df_RNA_2) <- df_RNA_2$pG
df_RNA_2 <- df_RNA_2[,-1]
df_RNA_2 <- remove.factors(df_RNA_2)


##
library(fpc)

mymat <- as.matrix(df_RNA_2)
sum(is.na(mymat))
mymat[is.na(mymat)] <- 0

pamk_best <- pamk(mymat)
pamk_best$nc

plot(pam(mymat, pamk_best$nc))

wss <- (nrow(mymat)-1)*sum(apply(mymat, 2, var))
for (i in 2:20) wss[i] <- sum(kmeans(mymat, centers = i)$withinss)

plot(1:20, wss, type="b")

df_pca <- prcomp(mymat)
autoplot(df_pca)

mymat <- as.matrix(t(mymat))
pamk_best <- pamk(mymat)
pamk_best$nc

plot(pam(mymat, pamk_best$nc))

wss <- (nrow(mymat)-1)*sum(apply(mymat, 2, var))
for (i in 2:93) wss[i] <- sum(kmeans(mymat, centers = i)$withinss)

plot(1:93, wss, type="b")
##
set.seed(1234)

mymat <- as.matrix(df_RNA_2)
mymat[is.na(mymat)] <- 0

mylimit <- max(min(mymat, na.rm=TRUE)*-1,  max(mymat, na.rm = T))

my.breaks <- c(seq(-mylimit-1,  -0.1 , length.out = 15), seq(0.1,  mylimit+1 , length.out = 15))

my.colors <- colorRampPalette(c("#2b83ba", "#ffffbf","#bd0026"))(30)

p1 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=F, show_rownames=F, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               #cutree_rows = 20,
               #kmeans_k = 20,
               main = "all replicates",
               file=file.path(out_dir2, "2_all_replicates_zscore_names.pdf"),
               width = 10, height = 100)


my.breaks <- c(seq(-4, 4, length.out = 30))

p2 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               # clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               clustering_distance_rows = "manhattan", clustering_distance_cols="manhattan",
               cutree_rows = 10,
               cutree_cols = 4,
               kmeans_k = 10,
               main = "all replicates",
               file=file.path(out_dir2, "2_RNA_clusters_manhattan.pdf"),
               width = 20, height = 10)
jnk <- p2$kmeans

jnk <- as.data.frame(jnk$cluster)
jnk$pG <- rownames(jnk)
names(jnk)[1] <- "Kmeans10_cluster"
write.table(jnk, file.path(out_dir2, "2_RNA_clusters_manhattan.txt"),
            quote = F, row.names = F, sep="\t")
saveRDS(p2, file.path(out_dir2, "2_RNA_clusters_manhattan.rds"))


p2 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               # clustering_distance_rows = "manhattan", clustering_distance_cols="manhattan",
               cutree_rows = 10,
               cutree_cols = 4,
               kmeans_k = 10,
               main = "all replicates",
               file=file.path(out_dir2, "2_RNA_clusters_cor.pdf"),
               width = 20, height = 10)
jnk <- p2$kmeans

jnk <- as.data.frame(jnk$cluster)
jnk$pG <- rownames(jnk)
names(jnk)[1] <- "Kmeans10_cluster"
write.table(jnk, file.path(out_dir2, "2_RNA_clusters_cor.txt"),
            quote = F, row.names = F, sep="\t")
saveRDS(p2, file.path(out_dir2, "2_RNA_clusters_cor.rds"))

p2 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               # clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               # clustering_distance_rows = "manhattan", clustering_distance_cols="manhattan",
               cutree_rows = 10,
               cutree_cols = 4,
               kmeans_k = 10,
               main = "all replicates",
               file=file.path(out_dir2, "2_RNA_clusters_euc.pdf"),
               width = 20, height = 10)


dev.off()
jnk <- p2$kmeans

jnk <- as.data.frame(jnk$cluster)
jnk$pG <- rownames(jnk)
names(jnk)[1] <- "Kmeans10_cluster"
write.table(jnk, file.path(out_dir2, "2_RNA_clusters_euc.txt"),
            quote = F, row.names = F, sep="\t")
saveRDS(p2, file.path(out_dir2, "2_RNA_clusters_euc.rds"))
#############################################################################################
# Protein heatmap ######################################
out_dir2 <- "E:/Merve/PaperFigures/20200303_Figure5/"

myfile <- list.files(path = out_dir, pattern = "2_1_1_")
df_RNA_FC <- readRDS(file.path(out_dir, myfile))

myPvalueCutOFF <- 0.03
myFCCutOFF <- 0.2

df_RNA_FC$regulated <- FALSE
df_RNA_FC$regulated[abs(df_RNA_FC$log2FC_Strain_wt) >= myFCCutOFF & 
                      df_RNA_FC$pvalue <= myPvalueCutOFF] <- TRUE

jnk <- as.data.frame(table(df_RNA_FC[,c(2,5)]))
jnk <- jnk %>%
  group_by(pG) %>%
  dplyr::mutate(count_sum=sum(Freq)) %>%
  as.data.frame()

jnk <- subset(jnk, regulated == TRUE)
jnk <- subset(jnk, count_sum >= 64)

hist(jnk$Freq, 100)

ggplot(jnk, aes(x="", y=Freq)) +
  geom_violin() +
  theme_classic() +
  geom_hline(yintercept = 3)

quantile(jnk$Freq)

quantile(jnk$Freq, 0.9)

jnk <- subset(jnk, Freq >= 9)

df_RNA_FC <- df_RNA_FC[df_RNA_FC$pG %in% jnk$pG,]
df_RNA_FC$p_FC <- sign(df_RNA_FC$log2FC_Strain_wt) * -log10(df_RNA_FC$pvalue)
# df_RNA_FC$p_FC <- df_RNA_FC$log2FC_Strain_wt * -log10(df_RNA_FC$pvalue)


df_RNA_1 <- df_RNA_FC[,1:3]
df_RNA_1 <- dcast(df_RNA_1, pG ~ KOstrain)
rownames(df_RNA_1) <- df_RNA_1$pG
df_RNA_1 <- df_RNA_1[,-1]
df_RNA_1 <- remove.factors(df_RNA_1)


df_RNA_2 <- df_RNA_FC[,c(1,2,6)]
df_RNA_2 <- dcast(df_RNA_2, pG ~ KOstrain)
rownames(df_RNA_2) <- df_RNA_2$pG
df_RNA_2 <- df_RNA_2[,-1]
df_RNA_2 <- remove.factors(df_RNA_2)


##
library(fpc)

mymat <- as.matrix(df_RNA_2)
sum(is.na(mymat))
mymat[is.na(mymat)] <- 0

pamk_best <- pamk(mymat)
pamk_best$nc

plot(pam(mymat, pamk_best$nc))

wss <- (nrow(mymat)-1)*sum(apply(mymat, 2, var))
for (i in 2:20) wss[i] <- sum(kmeans(mymat, centers = i)$withinss)

plot(1:20, wss, type="b")

df_pca <- prcomp(mymat)
autoplot(df_pca)

mymat <- as.matrix(t(mymat))
pamk_best <- pamk(mymat)
pamk_best$nc

plot(pam(mymat, pamk_best$nc))

wss <- (nrow(mymat)-1)*sum(apply(mymat, 2, var))
for (i in 2:93) wss[i] <- sum(kmeans(mymat, centers = i)$withinss)

plot(1:93, wss, type="b")
##
set.seed(1234)

mymat <- as.matrix(df_RNA_2)
mymat[is.na(mymat)] <- 0

mylimit <- max(min(mymat, na.rm=TRUE)*-1,  max(mymat, na.rm = T))

my.breaks <- c(seq(-mylimit-1,  -0.1 , length.out = 15), seq(0.1,  mylimit+1 , length.out = 15))

my.colors <- colorRampPalette(c("#2b83ba", "#ffffbf","#bd0026"))(30)

p1 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=F, show_rownames=F, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               #cutree_rows = 20,
               #kmeans_k = 20,
               main = "all replicates",
               file=file.path(out_dir2, "2_proteins.pdf"),
               width = 10, height = 100)
p2 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               # clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               cutree_rows = 10,
               cutree_cols = 4,
               kmeans_k = 10,
               main = "all replicates",
               file=file.path(out_dir2, "2_proteins_clusters.pdf"),
               width = 20, height = 10)
dev.off()
jnk <- p2$kmeans

jnk <- as.data.frame(jnk$cluster)
jnk$pG <- rownames(jnk)
names(jnk)[1] <- "Kmeans10_cluster"
write.table(jnk, file.path(out_dir2, "2_all_replicates_zscore_clusters.txt"),
            quote = F, row.names = F, sep="\t")
saveRDS(p2, file.path(out_dir2, "2_all_replicates_zscore_clusters.rds"))

# RNA-protein heatmap ######################################
out_dir2 <- "E:/Merve/PaperFigures/20200303_Figure5/"

myfile <- list.files(path = out_dir, pattern = "3_0_0")
df <- readRDS(file.path(out_dir, myfile))

jnk <- as.data.frame(table(df[,c(3,8,9)]))
jnk <- jnk[jnk$Freq != 0,]
jnk <- remove.factors(jnk)

jnk$reg_RNA[jnk$reg_RNA != "NOT"] <- "reg"
jnk$reg_protein[jnk$reg_protein != "NOT"] <- "reg"

jnk <- jnk %>%
  group_by(target, reg_RNA, reg_protein) %>%
  dplyr::mutate(Freq=sum(Freq)) %>%
  as.data.frame()
jnk <- remove.factors(as.data.frame(unique(jnk)))

jnk <- jnk %>%
  group_by(target) %>%
  dplyr::mutate(count_sum=sum(Freq)) %>%
  as.data.frame()

jnk2 <- unique(jnk[,c(1,5)])
jnk2 <- jnk2[jnk2$count_sum >= 63,]
jnk <- jnk[jnk$target %in% jnk2$target,]

jnk$remove <- FALSE
jnk$remove[jnk$Freq == 94 & jnk$reg_protein == "NOT" & jnk$reg_RNA == "NOT"] <- TRUE

jnk <- jnk[jnk$remove != TRUE,]
length(unique(jnk$target))

jnk2 <- subset(jnk, reg_protein == "NOT" & reg_RNA == "NOT")
jnk2$interesting4 <- jnk2$count_sum - jnk2$Freq
jnk2 <- jnk2[jnk2$interesting4 >= 6,]

df <- df[df$target %in% jnk2$target,]
df$R_FC <- sign(df$log2FC_RNA) * -log10(df$pvalue_RNA)
df$p_FC <- sign(df$log2FC_protein) * -log10(df$pvalue_protein)

df_R <- df[,c(2,3,10)]
df_p <- df[,c(2,3,11)]

df_R <- dcast(df_R, target ~ KOstrain)
df_p <- dcast(df_p, target ~ KOstrain)
names(df_R) <- paste(names(df_R), "RNA", sep="_")
names(df_p) <- paste(names(df_p), "protein", sep="_")

# df_h <- merge(df_R, df_p, by=1, all=TRUE)
# rownames(df_h) <- df_h$target_RNA
# df_h <- df_h[,-1]

rownames(df_R) <- df_R$target_RNA
rownames(df_p) <- df_p$target_protein
df_R <- df_R[,-1]
df_p <- df_p[,-1]

# df_h <- df_p - df_R
# colnames(df_h) <- gsub("_protein", "", colnames(df_h))

df$h_FC <- df$log2FC_protein - df$log2FC_RNA
df_h <- df[,c(2,3,12)]
df_h <- dcast(df_h, target ~ KOstrain)
rownames(df_h) <- df_h$target
df_h <- df_h[,-1]

df_h <- remove.factors(df_h)

##
library(fpc)

mymat <- as.matrix(df_h)
sum(is.na(mymat))
mymat[is.na(mymat)] <- 0

pamk_best <- pamk(mymat)
pamk_best$nc

plot(pam(mymat, pamk_best$nc))

wss <- (nrow(mymat)-1)*sum(apply(mymat, 2, var))
for (i in 2:20) wss[i] <- sum(kmeans(mymat, centers = i)$withinss)

plot(1:20, wss, type="b")

df_pca <- prcomp(mymat)
autoplot(df_pca)

mymat <- as.matrix(t(mymat))
pamk_best <- pamk(mymat)
pamk_best$nc

plot(pam(mymat, pamk_best$nc))

wss <- (nrow(mymat)-1)*sum(apply(mymat, 2, var))
for (i in 2:93) wss[i] <- sum(kmeans(mymat, centers = i)$withinss)

plot(1:93, wss, type="b")
##
set.seed(1234)

mymat <- as.matrix(df_h)
mymat[is.na(mymat)] <- 0

mylimit <- max(min(mymat, na.rm=TRUE)*-1,  max(mymat, na.rm = T))

my.breaks <- c(seq(-mylimit-1,  -0.1 , length.out = 15), seq(0.1,  mylimit+1 , length.out = 15))

my.colors <- colorRampPalette(c("#2b83ba", "#ffffbf","#bd0026"))(30)

p1 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=F, show_rownames=F, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               #cutree_rows = 20,
               #kmeans_k = 20,
               main = "all replicates",
               file=file.path(out_dir2, "2_RNAproteins_FC.pdf"),
               width = 10, height = 10)
p2 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               # clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               cutree_rows = 10,
               cutree_cols = 4,
               kmeans_k = 10,
               main = "all replicates",
               file=file.path(out_dir2, "2_RNAproteins_FC_clusters.pdf"),
               width = 20, height = 10)
dev.off()
jnk <- p2$kmeans

jnk <- as.data.frame(jnk$cluster)
jnk$pG <- rownames(jnk)
names(jnk)[1] <- "Kmeans10_cluster"
write.table(jnk, file.path(out_dir2, "2_RNAproteins_FC_clusters.txt"),
            quote = F, row.names = F, sep="\t")
saveRDS(p2, file.path(out_dir2, "2_RNAproteins_FC_clusters.rds"))


# Figure 7 # Replicate proteome targeted pSilac changing ????? ###################################
out_dir2 <- "E:/Merve/PaperFigures/20200306_Figure7_pSilac_targets/"

myfile <- list.files(path = out_dir, pattern = "2_1_1_")
df_target <- readRDS(file.path(out_dir, myfile))

myPvalueCutOFF <- 0.03
myFCCutOFF <- 0.2

df_target$regulated <- FALSE
df_target$regulated[abs(df_target$log2FC_Strain_wt) >= myFCCutOFF & 
                      df_target$pvalue <= myPvalueCutOFF] <- TRUE

strains <- unique(df_target$KOstrain)

df_pS <- readRDS("E:/Merve/20200129_DelLib_pSilac/20200224_pSILAC/20200306_pg_ident_melt_pSILAC.rds")
df_pS$gene2del <- gsub("p([0-9]+)\\_.*", "\\1", df_pS$variable)
genes2tag <- read.delim("E:/Merve/PaperFigures/targets2tag.txt")
genes2tag <- as.data.frame(rbind(genes2tag, c(4, "SPAC1687.22c")))
df_pS <- merge(df_pS, genes2tag, by.x="gene2del", by.y="PrimerNumber", all.x=TRUE)
rm(genes2tag)

df_target$ID <- paste(df_target$KOstrain, df_target$pG, sep="_")

df_pS$ID <- paste(df_pS$Gene2Tag, df_pS$Protein.IDs, sep="_")

df_merged <- merge(df_target, df_pS, by.x="ID", by.y="ID", all=FALSE)

table(df_merged$regulated)

df_merged$regulated[df_merged$regulated == TRUE & df_merged$log2FC_Strain_wt >0] <- "UP"
df_merged$regulated[df_merged$regulated == TRUE & df_merged$log2FC_Strain_wt <0] <- "DOWN"

ggplot(df_merged, aes(regulated, log2HM_centered)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(label ~ Gene2Tag) +
  theme_classic() +
  geom_hline(yintercept = 0)

ggplot(df_merged, aes(regulated, ratioHM_centered)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(label ~ Gene2Tag) +
  theme_classic() +
  geom_hline(yintercept = 0)

df_merged$log2HM_centered_ko_wt <- df_merged$log2HM_centered
df_merged$log2HM_centered_ko_wt[df_merged$label == "M"] <- -df_merged$log2HM_centered_ko_wt[df_merged$label == "M"]

df_merged$ratioHM_centered_ko_wt <- df_merged$ratioHM_centered
df_merged$ratioHM_centered_ko_wt[df_merged$label == "M"] <- -df_merged$ratioHM_centered_ko_wt[df_merged$label == "M"]


ggplot(df_merged, aes(regulated, log2HM_centered_ko_wt)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(label ~ Gene2Tag) +
  theme_classic() +
  geom_hline(yintercept = 0)

ggplot(df_merged, aes(regulated, ratioHM_centered)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(label ~ Gene2Tag) +
  theme_classic() +
  geom_hline(yintercept = 0)

df_merged <- remove.factors(df_merged)

df_merged2 <- df_merged %>%
  group_by(ID) %>%
  dplyr::mutate(log2HM_centered_ko_wt=mean(log2HM_centered_ko_wt, na.rm=TRUE), 
                ratioHM_centered_ko_wt=mean(ratioHM_centered_ko_wt, na.rm=TRUE)) %>%
  as.data.frame()

df_merged2 <- as.data.frame(unique(df_merged2[,c(1:7, 19,20)]))


ggplot(df_merged2, aes(regulated, log2HM_centered_ko_wt)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(. ~ KOstrain) +
  theme_classic() +
  geom_hline(yintercept = 0)

p1 <- ggplot(df_merged2, aes(regulated, ratioHM_centered_ko_wt)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(. ~ KOstrain) +
  theme_classic() +
  geom_hline(yintercept = 0)+
  ylim(-2,2) +
  stat_compare_means(method = "wilcox.test", 
                     ref.group="FALSE",
                     hide.ns = TRUE,
                     label="p.signif",
                     size=12)


p2 <- ggplot(df_merged2, aes(regulated, ratioHM_centered_ko_wt)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(. ~ KOstrain) +
  theme_classic() +
  geom_hline(yintercept = 0)+
  ylim(-2,2) +
  stat_compare_means(method = "wilcox.test", 
                     ref.group="FALSE",
                     hide.ns = TRUE,
                     label="p.format",
                     size=4)

ggsave(file.path(out_dir2, "plot1.pdf"), p1)
ggsave(file.path(out_dir2, "plot2.pdf"), p2)


# ggplot(df_merged2, aes(regulated, ratioHM_centered_ko_wt)) +
#   geom_boxplot(aes(color=regulated)) +
#   facet_grid(. ~ KOstrain) +
#   theme_classic() +
#   geom_hline(yintercept = 0)+
#   ylim(-2,2) +
#   stat_compare_means(method = "t.test", 
#                      ref.group="FALSE",
#                      hide.ns = TRUE,
#                      label="p.signif",
#                      size=12)
# 
# 
# 
# ggplot(df_merged2, aes(regulated, ratioHM_centered_ko_wt)) +
#   geom_boxplot(aes(color=regulated)) +
#   facet_grid(. ~ KOstrain) +
#   theme_classic() +
#   geom_hline(yintercept = 0)+
#   ylim(-2,2) +
#   stat_compare_means(method = "t.test", 
#                      ref.group="FALSE",
#                      hide.ns = TRUE,
#                      label="p.format",
#                      size=4)
# ggplot(df_merged2, aes(log2HM_centered_ko_wt, log2FC_Strain_wt)) +
#   geom_point(aes(color=regulated)) +
#   facet_grid(KOstrain ~ .) +
#   theme_classic() +
#   geom_hline(yintercept = 0)
# 
# ggplot(df_merged2, aes(ratioHM_centered_ko_wt, log2FC_Strain_wt)) +
#   geom_point(aes(color=regulated)) +
#   facet_grid(KOstrain ~ .) +
#   theme_classic() +
#   geom_hline(yintercept = 0)

############## puf3 only ############################################
out_dir2 <- "E:/Merve/PaperFigures/20200306_Figure7_pSilac_targets/"

puf3_target <- read.delim("E:/Merve/PaperFigures/20200306_Figure7_pSilac_targets/puf3_targets.txt", sep="\t",
                          header = T)
puf3_target <- as.data.frame(remove.factors(puf3_target[,1:2]))

orthologs <- read.delim2("E:/Merve/PaperFigures/20200306_Figure7_pSilac_targets/orthologs.txt")

puf3_target$pombe <- NA

for (i in 1:dim(puf3_target)[1]) {
  print(i)
  jnk <- grep(puf3_target$Gene[i], orthologs$cerevisiae.manually.curated.orthologs.V2.23)
  
  if(length(jnk)==1){
  puf3_target$pombe[i] <- orthologs$pombe[jnk]} else if(length(jnk)==0){
    puf3_target$pombe[i] <- "NONE"
  }
}

df_pS <- readRDS("E:/Merve/20200129_DelLib_pSilac/20200224_pSILAC/20200306_pg_ident_melt_pSILAC.rds")
df_pS$gene2del <- gsub("p([0-9]+)\\_.*", "\\1", df_pS$variable)
df_pS <- subset(df_pS, strain == "p4")

df_pS$ID <- paste(df_pS$Gene2Tag, df_pS$Protein.IDs, sep="_")
df_pS <- as.data.frame(df_pS[,c(2:12)])


df_merged <- merge(df_pS, puf3_target, by.x="Protein.IDs", by.y="pombe", all.x=TRUE)
df_merged$Protein.effect[is.na(df_merged$Protein.effect)] <- "FALSE"

table(df_merged$Protein.effect)
df_merged$regulated <- df_merged$Protein.effect

ggplot(df_merged, aes(regulated, log2HM_centered)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(label ~ .) +
  theme_classic() +
  geom_hline(yintercept = 0)

ggplot(df_merged, aes(regulated, ratioHM_centered)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(label ~ .) +
  theme_classic() +
  geom_hline(yintercept = 0)

df_merged$log2HM_centered_ko_wt <- df_merged$log2HM_centered
df_merged$log2HM_centered_ko_wt[df_merged$label == "M"] <- -df_merged$log2HM_centered_ko_wt[df_merged$label == "M"]

df_merged$ratioHM_centered_ko_wt <- df_merged$ratioHM_centered
df_merged$ratioHM_centered_ko_wt[df_merged$label == "M"] <- -df_merged$ratioHM_centered_ko_wt[df_merged$label == "M"]


ggplot(df_merged, aes(regulated, log2HM_centered_ko_wt)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(label ~ .) +
  theme_classic() +
  geom_hline(yintercept = 0)

ggplot(df_merged, aes(regulated, ratioHM_centered)) +
  geom_boxplot(aes(color=regulated)) +
  facet_grid(label ~ .) +
  theme_classic() +
  geom_hline(yintercept = 0)

df_merged <- remove.factors(df_merged)

df_merged2 <- df_merged %>%
  group_by(Protein.IDs) %>%
  dplyr::mutate(log2HM_centered_ko_wt=mean(log2HM_centered_ko_wt, na.rm=TRUE), 
                ratioHM_centered_ko_wt=mean(ratioHM_centered_ko_wt, na.rm=TRUE)) %>%
  as.data.frame()

df_merged2 <- as.data.frame(unique(df_merged2[,c(1, 13:16)]))


ggplot(df_merged2, aes(regulated, log2HM_centered_ko_wt)) +
  geom_boxplot(aes(color=regulated)) +
  theme_classic() +
  geom_hline(yintercept = 0)

p3 <- ggplot(df_merged2, aes(regulated, ratioHM_centered_ko_wt)) +
  geom_boxplot(aes(color=regulated)) +
  theme_classic() +
  geom_hline(yintercept = 0)+
  ylim(-2,2) +
  stat_compare_means(method = "wilcox.test", 
                     ref.group="FALSE",
                     hide.ns = TRUE,
                     label="p.signif",
                     size=12)


p4 <- ggplot(df_merged2, aes(regulated, ratioHM_centered_ko_wt)) +
  geom_boxplot(aes(color=regulated)) +
  theme_classic() +
  geom_hline(yintercept = 0)+
  ylim(-2,2) +
  stat_compare_means(method = "wilcox.test", 
                     ref.group="FALSE",
                     hide.ns = TRUE,
                     label="p.format",
                     size=4)

ggsave(file.path(out_dir2, "puf3_plot1.pdf"), p3)
ggsave(file.path(out_dir2, "puf3_plot2.pdf"), p4)

df_merged2$regulated[df_merged2$regulated != FALSE] <- TRUE

p3 <- ggplot(df_merged2, aes(regulated, ratioHM_centered_ko_wt)) +
  geom_boxplot(aes(color=regulated)) +
  theme_classic() +
  geom_hline(yintercept = 0)+
  ylim(-2,2) +
  stat_compare_means(method = "wilcox.test", 
                     ref.group="FALSE",
                     hide.ns = TRUE,
                     label="p.signif",
                     size=12)


p4 <- ggplot(df_merged2, aes(regulated, ratioHM_centered_ko_wt)) +
  geom_boxplot(aes(color=regulated)) +
  theme_classic() +
  geom_hline(yintercept = 0)+
  ylim(-2,2) +
  stat_compare_means(method = "wilcox.test", 
                     ref.group="FALSE",
                     hide.ns = TRUE,
                     label="p.format",
                     size=4)
ggsave(file.path(out_dir2, "puf3_plot3.pdf"), p4)





















###############################################################################################

# 8 # 20200323 # RNA not protein up/down cluster for codon usage ##################################
myfile <- list.files(path = out_dir, pattern = "df_RNA_protein_merged")
df_merged <- readRDS(file.path(out_dir, myfile))

df_target <- subset(df_merged, reg_protein != "NOT" & reg_RNA == "NOT")

df_target$p_FC <- sign(df_target$log2FC_protein) * -log10(df_target$pvalue_protein)

nTimestarget <- as.data.frame(table(df_target$target))

ggplot(nTimestarget, aes(Freq)) +
  geom_density()
quantile(nTimestarget$Freq)


nTimestarget <- nTimestarget[nTimestarget$Freq > quantile(nTimestarget$Freq, 0.5), ]

df_target_1 <- df_target[df_target$target %in% nTimestarget$Var1, ]
df_target_1 <- df_target_1[,c(2,3,10)]
df_target_1 <- dcast(df_target_1, target ~ KOstrain)
rownames(df_target_1) <- df_target_1$target
df_target_1 <- df_target_1[,-1]
df_target_1 <- remove.factors(df_target_1)

# fpc #####
library(fpc)

mymat <- as.matrix(df_target_1)
sum(is.na(mymat))
mymat[is.na(mymat)] <- 0

pamk_best <- pamk(mymat)
pamk_best$nc

plot(pam(mymat, pamk_best$nc))

wss <- (nrow(mymat)-1)*sum(apply(mymat, 2, var))
for (i in 2:20) wss[i] <- sum(kmeans(mymat, centers = i)$withinss)

plot(1:20, wss, type="b")

df_pca <- prcomp(mymat)
autoplot(df_pca)

# heatmap #######
set.seed(1234)

mymat <- as.matrix(df_target_1)
mymat[is.na(mymat)] <- 0

mylimit <- max(min(mymat, na.rm=TRUE)*-1,  max(mymat, na.rm = T))

my.breaks <- c(seq(-mylimit-1,  -0.1 , length.out = 15), seq(0.1,  mylimit+1 , length.out = 15))

my.colors <- colorRampPalette(c("#2b83ba", "#ffffbf","#bd0026"))(30)

p1 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=F, show_rownames=F, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               #cutree_rows = 20,
               #kmeans_k = 20,
               main = "all replicates",
               file=file.path(out_dir, "8_all_p1_names.pdf"),
               width = 10, height = 10)


my.breaks <- c(seq(-3, 3, length.out = 30))

p2 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               # clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               clustering_distance_rows = "manhattan", clustering_distance_cols="manhattan",
               cutree_rows = 2,
               cutree_cols = 4,
               kmeans_k = 2,
               main = "all replicates",
               file=file.path(out_dir, "8_all_clusters_manhattan.pdf"),
               width = 20, height = 10)
jnk <- p2$kmeans

jnk <- as.data.frame(jnk$cluster)
jnk$pG <- rownames(jnk)
names(jnk)[1] <- "Kmeans10_cluster"
write.table(jnk, file.path(out_dir, "8_all_clusters_manhattan.txt"),
            quote = F, row.names = F, sep="\t")
saveRDS(p2, file.path(out_dir, "8_all_clusters_manhattan.rds"))


p2 <- pheatmap(mymat, cluster_cols = T, cluster_rows = T, show_colnames=T, show_rownames=T, 
               color = my.colors, 
               breaks = my.breaks, border_color=NA, fontsize_row = 8, 
               # clustering_distance_rows = "binary", clustering_distance_cols="binary",
               # clustering_distance_rows = "correlation", clustering_distance_cols="correlation",
               # clustering_distance_rows = "manhattan", clustering_distance_cols="manhattan",
               cutree_rows = 2,
               cutree_cols = 4,
               kmeans_k = 2,
               main = "all replicates",
               file=file.path(out_dir, "8_all_clusters_euc.pdf"),
               width = 20, height = 10)


dev.off()
jnk <- p2$kmeans

jnk <- as.data.frame(jnk$cluster)
jnk$pG <- rownames(jnk)
names(jnk)[1] <- "Kmeans10_cluster"
write.table(jnk, file.path(out_dir, "8_all_clusters_euc.txt"),
            quote = F, row.names = F, sep="\t")
saveRDS(p2, file.path(out_dir, "8_all_clusters_euc.rds"))

# based on pam clusters #####
pamklusters <- as.data.frame(pamk_best$pamobject$clustering)
pamklusters$pG <- rownames(pamklusters)

df_target_1$target <- rownames(df_target_1)
df_target_1 <- merge(df_target_1, pamklusters, by.x="target", by.y="pG")
names(df_target_1)[96] <- "pamkluster"

df_target_2 <- melt(df_target_1, c("target","pamkluster"))
df_target_2 <- df_target_2 %>%
  group_by(pamkluster) %>%
  dplyr::mutate(average=mean(value, na.rm=T)) %>% 
  as.data.frame()

ggplot(df_target_2, aes(value)) +
  geom_density(aes(color=as.factor(pamkluster)), size=1.2) +
  theme_classic()
write.table(pamklusters, file.path(out_dir, "8_pamk_clusters_769.txt"),
            quote = F, row.names = F, sep="\t")


bg <- as.data.frame(unique(df_merged$target))
write.table(bg, file.path(out_dir, "8_pamk_clusters_background_1724.txt"),
            quote = F, row.names = F, sep="\t")

## gene ontology for the up and down regulated genes ######
GOfiles <- list.files(path=out_dir,pattern = "8_PAMK.*769.txt")
GOfiletransform <- function(myfile, mycategory){
  GOfiles_CC <- read.delim(myfile, skip=11)
  GOfiles_CC <- GOfiles_CC[!is.na(GOfiles_CC$upload_1..over.under.),]
  GOfiles_CC$GOcategory <- mycategory
  
  names(GOfiles_CC)[1] <- "GOterm"
  GOfiles_CC$Term <- gsub("(.*)\\s\\([PRG].*", "\\1", GOfiles_CC$GOterm)
  GOfiles_CC$TermID <- gsub(".*\\s\\(([PRG].*)\\)", "\\1", GOfiles_CC$GOterm)
  
  names(GOfiles_CC) <- gsub("upload_1..", "", names(GOfiles_CC))
  
  names(GOfiles_CC)[2] <- "BGcount"
  names(GOfiles_CC)[3] <- "Enrcount"
  
  GOfiles_CC$fold.Enrichment. <- gsub("< ", "", GOfiles_CC$fold.Enrichment.)
  GOfiles_CC$fold.Enrichment. <- gsub("> ", "", GOfiles_CC$fold.Enrichment.)
  GOfiles_CC$fold.Enrichment. <- as.numeric(GOfiles_CC$fold.Enrichment.)
  GOfiles_CC$Term <- factor(GOfiles_CC$Term, 
                            levels = GOfiles_CC$Term[order(GOfiles_CC$FDR.)])
  return(GOfiles_CC)
}

GOfiles_UP <- GOfiletransform(file.path(out_dir, GOfiles[1]), "UP")
GOfiles_down <- GOfiletransform(file.path(out_dir, GOfiles[2]), "DOWN")

GOfiles <- as.data.frame(rbind(GOfiles_UP, GOfiles_down))
rownames(GOfiles) <- NULL

mybreaks <- c(-1,0,1)

jnk <- as.data.frame(table(GOfiles$GOterm))
jnk <- jnk[jnk$Freq == 2,]
GOfiles2 <- GOfiles[GOfiles$GOterm %in% jnk$Var1,]

GOfiles2$mylabel <- "*"
GOfiles2$mylabel[GOfiles2$FDR. <= 0.01] <- "**"
GOfiles2$mylabel[GOfiles2$FDR. <= 0.001] <- "***"

GOfiles2$Term <- gsub("process", "p.", GOfiles2$Term)
#GOfiles2$Term <- gsub("metabolic", "met.", GOfiles2$Term)
#GOfiles2$Term <- gsub("biosynthetic", "bios.", GOfiles2$Term)

p1 <- ggplot(GOfiles2, aes(Term, as.numeric(log2(fold.Enrichment.)))) +
  geom_hline(yintercept = 0) +
  geom_bar(stat = "identity", aes(fill=GOcategory), width=0.7, size=1.2)+
  coord_flip() +
  theme_classic()+
  theme(legend.position="bottom") +
  xlab(NULL) +
  ylab("log2(fold enrichment)") +
  scale_y_continuous(breaks=mybreaks) +
  geom_text(aes(x=Term, y=as.numeric(log2(fold.Enrichment.)), label=mylabel))
ggsave(file.path(out_dir, "8_pamk_clusters_769_common_GO.pdf"),
       p1, width = 6, height = 4)

## heatmap for the up and down regulated genes ######
rownames(df_target_1) <- df_target_1$target
df_target_1 <- df_target_1[,-1]

df_target_1 <- df_target_1 %>%
  group_by(pamkluster) %>%
  dplyr::mutate_all(mean, na.rm=T) %>%
  as.data.frame()
df_target_1 <- unique(df_target_1)
df_target_1 <- melt(df_target_1, "pamkluster")
df_target_1$pamkluster[df_target_1$pamkluster == 1] <- "UP"
df_target_1$pamkluster[df_target_1$pamkluster == 2] <- "DOWN"

df_target_1 <- dcast(df_target_1, variable ~ pamkluster)
df_target_1$difference <- df_target_1$UP - df_target_1$DOWN

df_target_1$variable <- factor(df_target_1$variable, 
                          levels = df_target_1$variable[order(df_target_1$difference, decreasing = T)])

df_target_1 <- melt(df_target_1[,1:3], "variable")
names(df_target_1)[2] <- "pamkluster"

p2 <- ggplot(df_target_1, aes(variable, value)) +
  geom_hline(yintercept = 0)+
  geom_point(aes(color=pamkluster))+
  theme_classic()+
  theme(axis.text.x = element_blank()) +
  ylab("mean(score)") +
  xlab("strains")

ggsave(file.path(out_dir, "8_pamk_clusters_769_common_score.pdf"),
       p2, width = 4, height = 4)
