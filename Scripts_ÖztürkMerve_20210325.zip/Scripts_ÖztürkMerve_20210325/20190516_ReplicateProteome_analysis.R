options(stringsAsFactors=FALSE) #
# .libPaths(c(.libPaths(), "U:/Merve/Rpackages")) 

# setwd("U:/Merve/AllinAll_Mrv_IMB/Project/R_Projects/2017_TMT_SpDelLib/20190424_FinalDatasets")
setwd("E:/Merve/20190424_FinalDatasets/")

source("myFunctions.R")
# source("U:/Merve/AllinAll_Mrv_IMB/R_course/Rtraining_Teresa/201611_teresa_LFQ/extra_fun_LFQ.R")
source("extra_fun_LFQ.R")

out_dir <- "ReplicateProteome/1U_MBR/"
data_dir <- "Y:/Publications/SpombeSystems/MaxQuantOutputs/"
# 1 # load the libraries #######################################################################################
library(dplyr)
library(plotly)
library(tidyr)
library(knitr)
library(plyr)
library(reshape2)
library(ggplot2)
library(RColorBrewer)
library(parallel)
library(pcaMethods)
library(fBasics)
library(stats)
library(pvclust)
library(ggrepel)
library(cluster)
library(factoextra)
library(psych)
library(gridExtra)
library("ape")
library(ggpubr)
library(ggfortify)
library(broom)
library(data.table)
library(WGCNA)
library(e1071)
library(ggsignif)
library(corrplot)
library(GGally)
library(network)
library(sna)
library(igraph)
library(ggnetwork)
library(VennDiagram)
library(quantmod)
library(threejs)
library(crosstalk)
library(htmltools)
library(GOfuncR)
library(corrplot)
library(PerformanceAnalytics)
library(matrixTests)
######################################################################################################
if(newdf){
# 2 # protein groups file and initial QC #############################################################
# 2.0 # read and filter pG ###########################################################################
pG <- read.delim(file.path(data_dir,"Replicates_combined_1U_MBR/txt/proteinGroups.txt"))
pG <- my_pG_filter(pG,1,1)
saveRDS(pG, file.path(out_dir,paste0("2_0_",Sys.Date(),"_proteinGroups_filtered.rds")))

repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG))
pG_rep <- pG[,c(1,repCol)]

pG_rep[pG_rep==0] <- NA
pG_rep[,2:dim(pG_rep)[2]] <- log2(pG_rep[,2:dim(pG_rep)[2]])

# 2.1 # counts of identified proteins per sample ####################################################
jnk <- as.data.frame(colSums(is.na(pG_rep)))
jnk2 <- as.data.frame(colSums(!is.na(pG_rep)))
jnk$sample <- rownames(jnk)
jnk2$sample <- rownames(jnk2)
jnk <- merge(jnk, jnk2, by.x="sample", by.y="sample")
names(jnk) <- c("sample", "NotMeasured", "Measured")
write.table(jnk, file.path(out_dir,paste0("2_1_",Sys.Date(),"_counts.txt")), sep="\t", quote = F)
rm(jnk)
rm(jnk2)
# 2.2 # counts # old 3 from the analysis script ###################################################
pg_ident <- pG

repInt_col <- grep("^Reporter.intensity.corrected.[0-9].", names(pg_ident))
experiments <- unique(gsub("^Reporter.intensity.corrected.[0-9].(.*)$", "\\1",names(pg_ident)[repInt_col]))
strains <- unique(gsub("^Reporter.intensity.corrected.([0-9]).(.*)$", "\\1",names(pg_ident)[repInt_col]))
allsamples_name <- as.vector(sapply(experiments, paste0, '_', strains))

CT_TMT_noMBR <- data.frame(Position=character(), NumberOfProteins=numeric(), NumberOfProteinsIntensity=numeric(),
                           RepIntensityCount=character())
for (i in 1:length(experiments)) {
  print(i)
  pg_flt_x <- pg_ident[,grep(experiments[i], names(pg_ident))]
  colUnique <- names(pg_flt_x)[grep("^Unique.peptides", names(pg_flt_x))]
  colRazor <- names(pg_flt_x)[grep("^Razor", names(pg_flt_x))]
  
  enough_unique <- pg_flt_x[,colUnique] >= 1
  enough_razor_unique <- pg_flt_x[,colRazor] >= 1
  pg_ident_x <- subset(pg_flt_x, enough_razor_unique & enough_unique)
  
  colIntensity <- names(pg_ident_x)[grep("^Intensity.", names(pg_ident_x))]
  pg_ident_y <- subset(pg_ident_x, pg_ident_x[,colIntensity]>0)
  
  RepIntensity <- names(pg_ident_x)[grep("^Reporter.intensity.corrected.", names(pg_ident_x))]
  col4 <- NULL
  for(j in 1:length(RepIntensity)){
    pg_ident_z <- subset(pg_ident_x, pg_ident_x[,RepIntensity[j]]>0)
    col4 <- c(col4, dim(pg_ident_z)[1])
  }
  col4 <- paste0(col4, collapse = ";")
  
  CT_TMT_noMBR <- rbind(CT_TMT_noMBR, cbind(experiments[i], dim(pg_ident_x)[1], dim(pg_ident_y)[1], col4) )
}
names(CT_TMT_noMBR) <- c("Position", "NumberOfProteins", "NumberOfProteinsIntensity", "RepIntensityCount")

write.table(CT_TMT_noMBR, file.path(out_dir,paste0("2_2_",Sys.Date(),"_CountsTable.txt")), quote = F, row.names = F,
            sep="\t")
rm(CT_TMT_noMBR)
rm(pg_flt_x)
rm(pg_ident_x)
rm(pg_ident_y)
rm(pg_ident_z)
# 2.3 # reporter intensity decode ?? # old 4 from analysis script ###############################
plates <- unique(gsub("^rep([0-9]*)C[0-9]*$", "\\1",experiments))
repIntCorr_col <- grep("Reporter.intensity.corrected.[0-9].", names(pg_ident))
repIntCorr_col_names <- names(pg_ident)[repIntCorr_col]

repInt_decode <- data.frame(colNames=repIntCorr_col_names, Plates=NA,
                            Position_X=NA, Position_Y=NA, MedianLog2Intensity=0,
                            MaxLog2Intensity=0, pGident=0)

repInt_decode$Plates <- gsub("Reporter.intensity.corrected.[0-9].rep([0-9]*)C[0-9]*$", "\\1",
                             repInt_decode$colNames)

repInt_decode$Position_X <- gsub("Reporter.intensity.corrected.[0-9].rep[0-9]*C([0-9]*)$", "\\1",
                                 repInt_decode$colNames)

repInt_decode$Position_Y <- gsub("Reporter.intensity.corrected.([0-9]).rep[0-9]*C([0-9]*)$", "\\1",
                                 repInt_decode$colNames)

repInt_decode$Position_Y[repInt_decode$Position_Y==0] <- "A"
repInt_decode$Position_Y[repInt_decode$Position_Y==1] <- "B"
repInt_decode$Position_Y[repInt_decode$Position_Y==2] <- "WT_Tech"
repInt_decode$Position_Y[repInt_decode$Position_Y==3] <- "C"
repInt_decode$Position_Y[repInt_decode$Position_Y==4] <- "D"
repInt_decode$Position_Y[repInt_decode$Position_Y==5] <- "E"
repInt_decode$Position_Y[repInt_decode$Position_Y==6] <- "F"
repInt_decode$Position_Y[repInt_decode$Position_Y==7] <- "WT_Bio_mix"
repInt_decode$Position_Y[repInt_decode$Position_Y==8] <- "G"
repInt_decode$Position_Y[repInt_decode$Position_Y==9] <- "H"

repInt_decode$ReLabel <- paste0("rep", repInt_decode$Plates, repInt_decode$Position_Y,
                                repInt_decode$Position_X)

pg_ident_corrected <- pg_ident
pg_ident_corrected[repIntCorr_col][pg_ident_corrected[repIntCorr_col] ==0] <- NA

for(i in 1:dim(repInt_decode)[1]){
  print(i)
  repInt_decode$MedianLog2Intensity[i] <- median(log2(pg_ident_corrected[,repInt_decode$colNames[i]]), na.rm = T)
  repInt_decode$MaxLog2Intensity[i] <- max(log2(pg_ident_corrected[,repInt_decode$colNames[i]]), na.rm = T)
  repInt_decode$pGident[i] <- sum(!is.na(pg_ident_corrected[,repInt_decode$colNames[i]]))
}
repInt_decode$Plates <- as.character(repInt_decode$Plates)

write.table(repInt_decode, file.path(out_dir,paste0("2_3_",Sys.Date(),"_ReporterIntensityDecode_values.txt")),
            quote = F, row.names = F, sep="\t")
rm(pg_ident_corrected)
# 2.4 # median-max intensity DOTplots are saved # old 5 from analysis script ###############################
pdf(file.path(out_dir, paste0("2_4_",Sys.Date(),"_DOTplots.pdf")), width = 10, height = 8)
for(i in 1:length(plates)){
  repInt_decode_s <- subset(repInt_decode, Plates==plates[i])
  medPlot <- ggplot(repInt_decode_s, aes(x=Position_X, y=Position_Y))+
    geom_point(aes(color=MedianLog2Intensity, size=MedianLog2Intensity)) +
    scale_colour_gradientn(colours = c("#084594","#df65b0","#de2d26"),
                           values=c(0, median(repInt_decode$MedianLog2Intensity)/max(repInt_decode$MedianLog2Intensity), 1)) +
    scale_size_continuous(limits = c(min(repInt_decode$MedianLog2Intensity), max(repInt_decode$MedianLog2Intensity)))+
    xlab(NULL) +
    ylab(NULL)+
    ggtitle(paste0("Median intensity dotplot ", plates[i]))+
    geom_text(aes(label=pGident),size = 4, fontface = "bold", 
              color="#636363", vjust = 0, nudge_y = -0.5) 
  print(medPlot)
}
dev.off()
rm(medPlot)
rm(repInt_decode_s)
# 2.5 # create the table for each raw file and what is in which label # old 6 from analysis script ###########
# 2.5.1 # repInt decode advanced #############################################################################
repInt_decode <- read.delim(file.path(out_dir, paste0("2_3_",Sys.Date(),"_ReporterIntensityDecode_values.txt")))
repInt_decode$RawFileSuffix <- gsub("Reporter.intensity.corrected.[0-9].", "", repInt_decode$colNames)
names(repInt_decode)[1] <- "IntensityColumnNames_used"
repInt_decode$TMT_Label <- NA

repInt_decode$TMT_Label[repInt_decode$Position_Y == "A"] <- "126(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "B"] <- "127N(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "C"] <- "128N(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "D"] <- "128C(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "E"] <- "129N(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "F"] <- "129C(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "G"] <- "130C(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "H"] <- "131(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "WT_Bio_mix"] <- "130N(TM)"
repInt_decode$TMT_Label[repInt_decode$Position_Y == "WT_Tech"] <- "127C(TM)"


repInt_decode <- repInt_decode[,c(1,2,10,9,3,4,8,7)]
names(repInt_decode)[7] <- "Position_MS_Plate" 
names(repInt_decode)[2] <- "MS_Plate_Number" 
names(repInt_decode)[8] <- "NumberOfProteins" 
repInt_decode$StrainType <- "Knock-out"
repInt_decode$StrainType[grep("WT_Tech", repInt_decode$Position_MS_Plate)] <- "Technical_WildType"
repInt_decode$StrainType[grep("WT_Bio_mix", repInt_decode$Position_MS_Plate)] <- "Biological_WildType_mix"

write.table(repInt_decode, file.path(out_dir,paste0("2_5_1_",Sys.Date(),"_ReporterIntensityDecode_toCheckPositions.txt")),
            quote = F, row.names = F, sep="\t")
# 2.5.2 # repInt decode advanced - add replicate information - based on shifting in labeling ########################
repInt_decode <- read.delim(file.path(out_dir, paste0("2_5_1_",Sys.Date(),"_ReporterIntensityDecode_toCheckPositions.txt")))
Decision2Pick <- read.delim("20181110_finalfinalDecision2pick.txt")
colnames(Decision2Pick)[5] <- "Position_Replicate_Growing"
Decision2Pick <- Decision2Pick[,1:5]
Decision2Pick$Position_Replicate_Growing <- gsub("__", "_", Decision2Pick$Position_Replicate_Growing)

Label_Shift <- as.data.frame(readxl::read_xls("20190217_Plate 1-4 Quadruplicates.xls", col_names = F))
Plate1 <- Label_Shift[1:9,]
Plate2 <- Label_Shift[11:19,]
Plate3 <- Label_Shift[21:29,]
Plate4 <- Label_Shift[31:39,]

Plate1$X__14[2:9] <- Plate1$X__1[2:9]

label_readjust_replicates <- function(Plate_df, rep_number){
  Plate_adjust <- as.data.frame(matrix(NA, nrow = 96, ncol = 3))
  names(Plate_adjust) <- c("Position_Replicate_Growing", "Position_MS_Label", "Plate_Number")
  for (i in 1:dim(Plate_adjust)[1]) {
    if (i%%12==0) {
      j <- (i%%12)+12
      Plate_adjust$Position_MS_Label[i] <- paste0(Plate_df$X__1[floor(i/12)+1], "_",Plate_df[1,j+1])
      Plate_adjust$Position_Replicate_Growing[i] <- paste0(Plate_df$X__14[floor(i/12)+1], "_",Plate_df[floor(i/12)+1,j+1])
    } else {
      j <- i%%12
      Plate_adjust$Position_MS_Label[i] <- paste0(Plate_df$X__1[floor(i/12)+2], "_",Plate_df[1,j+1])
      Plate_adjust$Position_Replicate_Growing[i] <- paste0(Plate_df$X__14[floor(i/12)+2], "_",Plate_df[floor(i/12)+2,j+1])}
  }
  Plate_adjust$Plate_Number <- paste0("Replicate_Plate_", rep_number)
  return(Plate_adjust)
}

Plate1_adjust <- label_readjust_replicates(Plate1, 1)
Plate2_adjust <- label_readjust_replicates(Plate2, 2)
Plate3_adjust <- label_readjust_replicates(Plate3, 3)
Plate4_adjust <- label_readjust_replicates(Plate4, 4)
Plates_adjust <- as.data.frame(rbind(Plate1_adjust, Plate2_adjust, Plate3_adjust, Plate4_adjust))
rm(Plate1)
rm(Plate1_adjust)
rm(Plate4)
rm(Plate4_adjust)
rm(Plate3)
rm(Plate3_adjust)
rm(Plate2)
rm(Plate2_adjust)
rm(Label_Shift)

Plates_adjust_decisions <- merge(Decision2Pick, Plates_adjust, by.x="Position_Replicate_Growing", by.y="Position_Replicate_Growing")
Plates_adjust_decisions$Plate_Number <- gsub("Replicate\\_Plate\\_([0-9]+)", "\\1", Plates_adjust_decisions$Plate_Number)


Plates_adjust_decisions$Label_row <- gsub("([A-Z])\\_([0-9]*)", "\\1", Plates_adjust_decisions$Position_MS_Label)
Plates_adjust_decisions$Label_col <- gsub("([A-Z])\\_([0-9]*)", "\\2", Plates_adjust_decisions$Position_MS_Label)

Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==1] <- "01"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==2] <- "02"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==3] <- "03"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==4] <- "04"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==5] <- "05"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==6] <- "06"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==7] <- "07"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==8] <- "08"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==9] <- "09"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==10] <- "10"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==11] <- "11"
Plates_adjust_decisions$Label_col[Plates_adjust_decisions$Label_col==12] <- "12"

Plates_adjust_decisions$Label_Position <- paste("rep", Plates_adjust_decisions$Plate_Number,
                                                Plates_adjust_decisions$Label_row, Plates_adjust_decisions$Label_col,
                                                sep="")
Plates_adjust_decisions <- Plates_adjust_decisions[,c(1:7,10)]


repInt_decode_merged <- merge(repInt_decode, Plates_adjust_decisions, by.x="Position_MS_Plate", by.y="Label_Position", all=TRUE)
write.table(repInt_decode_merged, file.path(out_dir,paste0("2_5_2_",Sys.Date(),"_ReporterIntensityDecode_Extended.txt")),
            quote = F, row.names = F, sep="\t")

repInt_decode_merged2 <- repInt_decode_merged[,c(2,5,10,1,4,9,14,13,12,11,8)]
write.table(repInt_decode_merged2, file.path(out_dir,paste0("2_5_2_",Sys.Date(),"_ReporterIntensityDecode_Extended_Simplified_Final.txt")),
            quote = F, row.names = F, sep="\t")
rm(Decision2Pick)
rm(Plates_adjust)
rm(Plate_adjust)
rm(Plate_df)
rm(Plates_adjust_decisions)
rm(repInt_decode)
rm(repInt_decode_merged)
rm(repInt_decode_merged2)
# 2.5.3 # filter the pg_ident for columns to analyze ################################################################
df_pg2 <- pG_rep
rm(pG)
rm(pG_rep)
rm(pg_ident)

df_pg2_ID <- as.data.frame(cbind(df_pg2$Protein.IDs, df_pg2$Protein.IDs))
df_pg2_ID <- splitColumnBySep(df_pg2_ID, "V2")
df_pg2_ID$geneID <- gsub("(SP.*\\..*)\\.1\\:pep.*","\\1",df_pg2_ID$V2)
df_pg2_ID$geneID_length <- nchar(df_pg2_ID$geneID)

df_pg2_ID <- df_pg2_ID[,c(1,3)]
df_pg2_ID2 <- df_pg2_ID %>%
  group_by(V1) %>%
  dplyr::summarise(text=paste(geneID,collapse=';')) %>%
  as.data.frame()
rm(df_pg2_ID)
df_pg2_2 <- merge(df_pg2, df_pg2_ID2, by.x="Protein.IDs", by.y="V1")
df_pg2 <- df_pg2_2
rm(df_pg2_2)
rm(df_pg2_ID2)

# change intensity names to ms plate position names
rownames(df_pg2) <- df_pg2$text
df_pg2 <- df_pg2[,-c(1,dim(df_pg2)[2])]
df_pg2 <- as.data.frame(t(df_pg2))
df_pg2$Strain <- rownames(df_pg2)

repInt_decode <- read.delim(file.path(out_dir, paste0("2_5_2_",Sys.Date(),"_ReporterIntensityDecode_Extended_Simplified_Final.txt")))
# repInt_decode$Systemic.ID[is.na(repInt_decode$Systemic.ID)] <- repInt_decode$Position_MS_Plate[is.na(repInt_decode$Systemic.ID)]
repInt_decode$Systemic.ID[is.na(repInt_decode$Systemic.ID)] <- ""

repInt_decode$ReplicateID <- paste(repInt_decode$Position_MS_Plate,"_",repInt_decode$Systemic.ID, "_", gsub("rep([0-9]+)C.*","\\1",repInt_decode$RawFileSuffix), sep="")
repInt_tomerge <- repInt_decode[c(1,12)]

df_pg2 <- merge(df_pg2, repInt_tomerge, by.x="Strain", by.y="IntensityColumnNames_used", all=FALSE)
rownames(df_pg2) <- df_pg2$ReplicateID

jnk <- grep("Strain|IntensityColumnNames_used|Position_MS_Plate|ReLabel|ReplicateID", names(df_pg2))
df_pg2 <- df_pg2[,-jnk]
df_pg2 <- as.data.frame(t(df_pg2))

# remove the rows with no values
df_pg2 <- df_pg2[rowSums(is.na(df_pg2)) != dim(df_pg2)[2],]

saveRDS(df_pg2, file.path(out_dir, paste0("2_5_3_", Sys.Date(), "_pg_ident_IntensityColsToBeAnalysed_MSplatePositions.rds")))
rm(df_pg2)
rm(repInt_decode)
rm(repInt_tomerge)
# 3 # Normalization # old 7 from the analysis script ####################################################################
# 3.1 # remove the proteins not identified in wt tech for that run ######################################################
df <- readRDS(file.path(out_dir, paste0("2_5_3_", Sys.Date(), "_pg_ident_IntensityColsToBeAnalysed_MSplatePositions.rds")))
df_norm <- as.data.frame(df)

repInt_col <- grep("rep", names(df_norm))

plates <- unique(gsub("(rep[0-9]*)[^0-9]*([0-9]*)\\_.*", "\\1",names(df_norm)[repInt_col]))
strains <- unique(gsub("^rep[0-9]*([^0-9]*)[0-9]*\\_.*", "\\1",names(df_norm)[repInt_col]))

my_pg_med <- df_norm
rm(df)
rm(df_norm)
my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))

for (plate in plates) {
  print(plate)
  plate_col <- grep(plate, names(my_pg_med))
  my_pg_med_subset <- my_pg_med[,plate_col]
  experiments <- paste(unique(gsub("(rep[0-9]*)[^0-9]*([0-9]*)\\_.*", "\\2",names(my_pg_med_subset))), "_[^0-9]", sep="")
  for(exp in experiments){
    print(exp)
    exp_col <- grep(exp, names(my_pg_med_subset))
    
    my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
    
    norm_col <- grep("WT_Tech", names(my_pg_med_subset2))
    my_pg_med_subset2[is.na(my_pg_med_subset2[,norm_col]),] <- NA
    
    my_pg_med_subset2$Proteins <- rownames(my_pg_med_subset2)
    my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset2, by.x="Proteins", by.y="Proteins")
    
  }
}  
rownames(my_wt_normalized) <- my_wt_normalized$Proteins
my_wt_normalized <- my_wt_normalized[,-1]

saveRDS(my_wt_normalized, file.path(out_dir, paste0("3_1_", Sys.Date(), "_Filtered4Proteins_WTtech.rds")))

rm(my_pg_med)
rm(my_pg_med_subset)
rm(my_pg_med_subset2)
rm(my_wt_normalized)
# 3.2 # wtTech_MEDIAN_MEDIANrunNormalized ##############################################################
# 3.2.1 # wtTech #######################################################################################
df_norm <- readRDS(file.path(out_dir, paste0("3_1_", Sys.Date(), "_Filtered4Proteins_WTtech.rds")))
repInt_col <- grep("rep", names(df_norm))

plates <- unique(gsub("(rep[0-9]*)[^0-9]*([0-9]*)\\_.*", "\\1",names(df_norm)[repInt_col]))
strains <- unique(gsub("^rep[0-9]*([^0-9]*)[0-9]*\\_.*", "\\1",names(df_norm)[repInt_col]))

my_pg_med <- df_norm
for (mycol in 1:dim(my_pg_med)[2]) {
  my_pg_med[,mycol] <- as.numeric(my_pg_med[,mycol])
}

jnk_median_allProteins <- apply(my_pg_med, 1, median,na.rm = TRUE)

my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))

for (plate in plates) {
  print(plate)
  plate_col <- grep(plate, names(my_pg_med))
  my_pg_med_subset <- my_pg_med[,plate_col]
  experiments <- paste(unique(gsub("(rep[0-9]*)[^0-9]*([0-9]*)\\_.*", "\\2",names(my_pg_med_subset))), "_[^0-9]", sep="")

  for(exp in experiments){
    print(exp)
    exp_col <- grep(exp, names(my_pg_med_subset))
    my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
    
    norm_col <- grep("WT_Tech", names(my_pg_med_subset2))
    my_pg_med_subset_wtNorm <- normalize2wtTech(my_pg_med_subset2, norm_col)
    my_pg_med_subset_wtNorm$Proteins <- rownames(my_pg_med_subset_wtNorm)
    my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset_wtNorm, by.x="Proteins", by.y="Proteins")
  }
}  

my_pg_med <- my_wt_normalized

my_pg_med[,2:dim(my_pg_med)[2]] <- my_pg_med[,2:dim(my_pg_med)[2]] + jnk_median_allProteins
rownames(my_pg_med) <- my_pg_med$Proteins
my_pg_med <- my_pg_med[,-1]

saveRDS(my_pg_med, file.path(out_dir, paste0("3_2_1_", Sys.Date(), "_wtTechNORMALIZED.rds")))

rm(df_norm)
rm(my_pg_med_subset)
rm(my_pg_med_subset_wtNorm)
rm(my_pg_med)
rm(my_pg_med_subset2)  
rm(my_wt_normalized)  

# 3.2.2 # MEDIAN ######################################################################################
myfile <- list.files(path=out_dir, pattern = "3_2_1_")
df_norm <- readRDS(file.path(out_dir, myfile))

repInt_col <- grep("rep", names(df_norm))

plates <- unique(gsub("(rep[0-9]*)[^0-9]*([0-9]*)\\_.*", "\\1",names(df_norm)[repInt_col]))
strains <- unique(gsub("^rep[0-9]*([^0-9]*)[0-9]*\\_.*", "\\1",names(df_norm)[repInt_col]))

my_pg_med <- df_norm
rm(df_norm)
for (mycol in 1:dim(my_pg_med)[2]) {
  my_pg_med[,mycol] <- as.numeric(my_pg_med[,mycol])
}
my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))

for (plate in plates) {
  print(plate)
  plate_col <- grep(plate, names(my_pg_med))
  my_pg_med_subset <- my_pg_med[,plate_col]
  experiments <- paste(unique(gsub("(rep[0-9]*)[^0-9]*([0-9]*)\\_.*", "\\2",names(my_pg_med_subset))), "_[^0-9]", sep="")
  
  for(exp in experiments){
    print(exp)
    exp_col <- grep(exp, names(my_pg_med_subset))
    my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
    
    colMedian <- apply(my_pg_med_subset2, 2, median,na.rm = TRUE)
    colMedian <- as.numeric(colMedian)
    myRunMedian <- median(colMedian)
    
    for (mycol in 1:dim(my_pg_med_subset2)[2]) {
      my_pg_med_subset2[,mycol] <- my_pg_med_subset2[,mycol] - colMedian[mycol] + myRunMedian
    }
    
    my_pg_med_subset_wtNorm <- my_pg_med_subset2
    my_pg_med_subset_wtNorm$Proteins <- rownames(my_pg_med_subset_wtNorm)
    my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset_wtNorm, by.x="Proteins", by.y="Proteins")
  }
}  
my_pg_med <- my_wt_normalized
rownames(my_pg_med) <- my_pg_med$Proteins
my_pg_med <- my_pg_med[,-1]

saveRDS(my_pg_med, file.path(out_dir, paste0("3_2_2_", Sys.Date(), "_MEDIANrun.rds")))

rm(my_pg_med_subset)
rm(my_pg_med_subset_wtNorm)
rm(my_pg_med)
rm(my_pg_med_subset2)  
rm(my_wt_normalized)  
rm(colMedian)
# 3.2.3 # MEDIAN of proteins from the run #############################################################
myfile <- list.files(path=out_dir, pattern = "3_2_2_")
df_norm <- readRDS(file.path(out_dir, myfile))

repInt_col <- grep("rep", names(df_norm))

plates <- unique(gsub("(rep[0-9]*)[^0-9]*([0-9]*)\\_.*", "\\1",names(df_norm)[repInt_col]))
strains <- unique(gsub("^rep[0-9]*([^0-9]*)[0-9]*\\_.*", "\\1",names(df_norm)[repInt_col]))

my_pg_med <- df_norm
jnk_median_allProteins <- apply(my_pg_med, 1, median,na.rm = TRUE)

my_wt_normalized <- data.frame(Proteins=rownames(my_pg_med))

for (plate in plates) {
  print(plate)
  plate_col <- grep(plate, names(my_pg_med))
  my_pg_med_subset <- my_pg_med[,plate_col]
  experiments <- paste(unique(gsub("(rep[0-9]*)[^0-9]*([0-9]*)\\_.*", "\\2",names(my_pg_med_subset))), "_[^0-9]", sep="")
  for(exp in experiments){
    print(exp)
    exp_col <- grep(exp, names(my_pg_med_subset))
    my_pg_med_subset2 <- my_pg_med_subset[,exp_col]
    
    norm_col <- apply(my_pg_med_subset2, 1, median, na.rm=TRUE)
    
    my_pg_med_subset_wtNorm <- my_pg_med_subset2- norm_col
    
    my_pg_med_subset_wtNorm$Proteins <- rownames(my_pg_med_subset_wtNorm)
    my_wt_normalized <- merge(my_wt_normalized, my_pg_med_subset_wtNorm, by.x="Proteins", by.y="Proteins")
  }
}  

my_pg_med <- my_wt_normalized

my_pg_med[,2:dim(my_pg_med)[2]] <- my_pg_med[,2:dim(my_pg_med)[2]] + jnk_median_allProteins
rownames(my_pg_med) <- my_pg_med$Proteins
my_pg_med <- my_pg_med[,-1]

saveRDS(my_pg_med, file.path(out_dir, paste0("3_2_3_", Sys.Date(), "_MEDIANproteinsRUN.rds")))

rm(df_norm)
rm(my_pg_med)
rm(my_pg_med_subset)
rm(my_pg_med_subset2)
rm(my_pg_med_subset_wtNorm)
rm(my_wt_normalized)
########################################################################################################################
# 4 # Check if normalizaton is working for the replicates for final checks ######################################
# 4.1 # Correlation - pairs #####################################################################################
myfile <- list.files(path=out_dir, pattern = "3_2_3_")
df <- readRDS(file.path(out_dir, myfile))

df_cor <- corAndPvalue(df, use = "pairwise.complete.obs", method="pearson")
df_cor <- as.data.frame(df_cor[1])

df_cor$sample1 <- rownames(df_cor)

df_cor <- melt(df_cor, id="sample1")
names(df_cor)[2] <- "sample2"
df_cor$sample2 <- gsub("cor\\.","",df_cor$sample2)

df_cor$experiment1 <- gsub("rep[0-9][A-Z][0-9]*\\_(.*)\\_[0-9]", "\\1", df_cor$sample1)
df_cor$experiment1 <- gsub("wt1", "wt", df_cor$experiment1)
df_cor$experiment1 <- gsub("wt2", "wt", df_cor$experiment1)
df_cor$experiment1[grep("WT_Tech", df_cor$experiment1)] <- "WT_Tech"
df_cor$experiment1[grep("WT_Bio_mix", df_cor$experiment1)] <- "WT_Bio_mix"

df_cor$experiment2 <- gsub("rep[0-9][A-Z][0-9]*\\_(.*)\\_[0-9]", "\\1", df_cor$sample2)
df_cor$experiment2 <- gsub("wt1", "wt", df_cor$experiment2)
df_cor$experiment2 <- gsub("wt2", "wt", df_cor$experiment2)
df_cor$experiment2[grep("WT_Tech", df_cor$experiment2)] <- "WT_Tech"
df_cor$experiment2[grep("WT_Bio_mix", df_cor$experiment2)] <- "WT_Bio_mix"

df_cor$replicate1 <- gsub("rep([0-9])[A-Z]*[0-9]*\\_(.*)\\_[0-9]", "\\1", df_cor$sample1)
df_cor$replicate2 <- gsub("rep([0-9])[A-Z]*[0-9]*\\_(.*)\\_[0-9]", "\\1", df_cor$sample2)

df_cor$Run1 <- gsub("rep[0-9][A-Z]*([0-9]*)\\_(.*)\\_[0-9]", "\\1", df_cor$sample1)
df_cor$Run1[grep("WT_Tech", df_cor$sample1)] <- gsub("rep[0-9]WT_Tech([0-9]*)\\__(.*)", "\\1", df_cor$sample1[grep("WT_Tech", df_cor$sample1)])
df_cor$Run1[grep("WT_Bio_mix", df_cor$sample1)] <- gsub("rep[0-9]WT_Bio_mix([0-9]*)\\__(.*)", "\\1", df_cor$sample1[grep("WT_Bio_mix", df_cor$sample1)])
df_cor$Run1 <- paste(df_cor$replicate1, "_",df_cor$Run1, sep="")

df_cor$Run2 <- gsub("rep[0-9][A-Z]*([0-9]*)\\_(.*)\\_[0-9]", "\\1", df_cor$sample2)
df_cor$Run2[grep("WT_Tech", df_cor$sample2)] <- gsub("rep[0-9]WT_Tech([0-9]*)\\__(.*)", "\\1", df_cor$sample2[grep("WT_Tech", df_cor$sample2)])
df_cor$Run2[grep("WT_Bio_mix", df_cor$sample2)] <- gsub("rep[0-9]WT_Bio_mix([0-9]*)\\__(.*)", "\\1", df_cor$sample2[grep("WT_Bio_mix", df_cor$sample2)])
df_cor$Run2 <- paste(df_cor$replicate2, "_",df_cor$Run2, sep="")

df_cor$Label1 <- gsub("rep[0-9]([A-Z]*)([0-9]*)\\_(.*)\\_[0-9]", "\\1", df_cor$sample1)
df_cor$Label1[grep("WT_Tech", df_cor$sample1)] <- "WT_Tech"
df_cor$Label1[grep("WT_Bio_mix", df_cor$sample1)] <- "WT_Bio_mix"

df_cor$Label2 <- gsub("rep[0-9]([A-Z]*)([0-9]*)\\_(.*)\\_[0-9]", "\\1", df_cor$sample2)
df_cor$Label2[grep("WT_Tech", df_cor$sample2)] <- "WT_Tech"
df_cor$Label2[grep("WT_Bio_mix", df_cor$sample2)] <- "WT_Bio_mix"

df_cor$same_experiment <- df_cor$experiment1 == df_cor$experiment2
df_cor$same_plate <- df_cor$replicate1 == df_cor$replicate2
df_cor$same_run <- df_cor$Run1 == df_cor$Run2
df_cor$same_label <- df_cor$Label1 == df_cor$Label2

p1 <- ggplot(df_cor, aes(same_experiment, value)) +
  geom_boxplot() +
  ylab("Pearson correlation") +
  scale_y_continuous(breaks=0.965)


p2 <- ggplot(df_cor, aes(same_plate, value)) +
  geom_boxplot() +
  ylab(NULL) +
  scale_y_continuous(breaks=0.964)


p3 <- ggplot(df_cor, aes(same_run, value)) +
  geom_boxplot() +
  ylab(NULL) +
  scale_y_continuous(breaks=0.964)


p4 <- ggplot(df_cor, aes(same_label, value)) +
  geom_boxplot() +
  ylab(NULL) +
  scale_y_continuous(breaks=0.97)

p5 <- ggplot(data=subset(df_cor, Label1 != "WT_Tech" & Label1 != "WT_Bio_mix" & Label2 != "WT_Tech" & Label2 != "WT_Bio_mix"), aes(same_experiment, value)) +
  geom_boxplot() +
  ylab("Pearson correlation") +
  scale_y_continuous(breaks=0.98)


p6 <- ggplot(data=subset(df_cor, Label1 != "WT_Tech" & Label1 != "WT_Bio_mix" & Label2 != "WT_Tech" & Label2 != "WT_Bio_mix"), aes(same_plate, value)) +
  geom_boxplot() +
  ylab(NULL) +
  scale_y_continuous(breaks=0.976)


p7 <- ggplot(data=subset(df_cor, Label1 != "WT_Tech" & Label1 != "WT_Bio_mix" & Label2 != "WT_Tech" & Label2 != "WT_Bio_mix"), aes(same_run, value)) +
  geom_boxplot() +
  ylab(NULL) +
  scale_y_continuous(breaks=0.976)


p8 <- ggplot(data=subset(df_cor, Label1 != "WT_Tech" & Label1 != "WT_Bio_mix" & Label2 != "WT_Tech" & Label2 != "WT_Bio_mix"), aes(same_label, value)) +
  geom_boxplot() +
  ylab(NULL) +
  scale_y_continuous(breaks=0.976)

p1_4 <- ggarrange(p1,p2,p3,p4, nrow = 1, ncol = 4)
p1_4 <- annotate_figure(p1_4, top = text_grob("Additionally normalize for label??", size = 14))

p5_8 <- ggarrange(p5,p6,p7,p8, nrow = 1, ncol = 4)
p5_8 <- annotate_figure(p5_8, top = text_grob("Without WT_Tech or WT_Bio_mix, normalization good:)", size = 14))

pdf(file.path(out_dir, paste0("4_1_", Sys.Date(), "_PairedCorrelations.pdf")))
print(p1_4)
print(p5_8)
dev.off()

rm(df)
rm(df_cor)
rm(p1)
rm(p2)
rm(p3)
rm(p4)
rm(p1_4)
rm(p5)
rm(p6)
rm(p7)
rm(p8)
rm(p5_8)
# 4.2 # Pairwise PCA #####################################################################################
myfile <- list.files(path=out_dir, pattern = "3_2_3_")
df <- readRDS(file.path(out_dir, myfile))

df_notNA <- df[rowSums(is.na(df)) == 0,]

# pca for wt, WT_Tech, and WT_Bio_mix
wt_col <- grep("wt", names(df))
WT_Tech_col <- grep("WT_Tech", names(df))
WT_Bio_mix_col <- grep("WT_Bio_mix", names(df))

df_wts <- df_notNA[, c(wt_col, WT_Tech_col, WT_Bio_mix_col)]
names(df_wts) <- gsub("rep[0-9]", "", names(df_wts))

jnk <- as.data.frame(names(df_wts))
jnk$newNames <- NA
jnk$`names(df_wts)` <- gsub("wt[0-9]", "wt", jnk$`names(df_wts)`)
jnk$newNames[grep("wt", jnk$`names(df_wts)`)] <- gsub("[A-Z][0-9]*\\_(wt[0-9]*\\_[0-9]*)", "\\1", jnk$`names(df_wts)`[grep("wt", jnk$`names(df_wts)`)])

jnk$newNames[grep("WT_Tech", jnk$`names(df_wts)`)] <- gsub("WT_Tech[0-9]+", "WTTech", jnk$`names(df_wts)`[grep("WT_Tech", jnk$`names(df_wts)`)])
jnk$newNames[grep("WT_Bio_mix", jnk$`names(df_wts)`)] <- gsub("WT_Bio_mix[0-9]+", "WTBioMix", jnk$`names(df_wts)`[grep("WT_Bio_mix", jnk$`names(df_wts)`)])
jnk$newNames <- gsub("__", "_", jnk$newNames)

names(df_wts) <- jnk$newNames

df_normalized_forPlots <- t(df_wts)
df.pca <- prcomp(df_normalized_forPlots, center = FALSE, scale. = FALSE) 

p1 <- plotpca2d_ggplot_wt(c(1,2), df.pca, experiment_regex='(.*)\\_(.*)')
p2 <- plotpca2d_ggplot_wt(c(1,3), df.pca, experiment_regex='(.*)\\_(.*)')
p3 <- plotpca2d_ggplot_wt(c(2,3), df.pca, experiment_regex='(.*)\\_(.*)')
p4 <- plotpca2d_ggplot_wt(c(1,4), df.pca, experiment_regex='(.*)\\_(.*)')
p5 <- plotpca2d_ggplot_wt(c(2,4), df.pca, experiment_regex='(.*)\\_(.*)')
p6 <- plotpca2d_ggplot_wt(c(3,4), df.pca, experiment_regex='(.*)\\_(.*)')

p1_6 <- ggarrange(p1,p2,p3,p4,p5,p6, ncol = 2, nrow=3)
p1_6 <- annotate_figure(p1_6, top = text_grob("All the wt's", size = 14, face="bold"))

# pca for ko strains with WT's 
repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
experiments <- unique(repInt_decode$Systemic.ID)
experiments <- experiments[-grep("wt", experiments)]
experiments <- experiments[!is.na(experiments)]
rm(repInt_decode)

pdf(file.path(out_dir, paste0("4_2_", Sys.Date(), "_PCA_4all.pdf")))
print(p1_6)
for (j in 1:length(experiments)) {
  i <- experiments[j]
  print(j)
  ko_col <- grep(i, names(df))
  wt_col <- grep("wt", names(df))
  
  df_ko <- df_notNA[, c(wt_col, ko_col)]
  names(df_ko) <- gsub("rep[0-9][A-Z][0-9]*\\_","",names(df_ko))
  names(df_ko) <- gsub("wt[0-9]", "wt", names(df_ko))
  
  df_normalized_forPlots <- t(df_ko)
  df.pca <- prcomp(df_normalized_forPlots, center = FALSE, scale. = FALSE) 
  
  p1 <- plotpca2d_ggplot_ko(c(1,2), df.pca, experiment_regex='(.*)\\_(.*)')
  p2 <- plotpca2d_ggplot_ko(c(1,3), df.pca, experiment_regex='(.*)\\_(.*)')
  p3 <- plotpca2d_ggplot_ko(c(2,3), df.pca, experiment_regex='(.*)\\_(.*)')
  p4 <- plotpca2d_ggplot_ko(c(1,4), df.pca, experiment_regex='(.*)\\_(.*)')
  p5 <- plotpca2d_ggplot_ko(c(2,4), df.pca, experiment_regex='(.*)\\_(.*)')
  p6 <- plotpca2d_ggplot_ko(c(3,4), df.pca, experiment_regex='(.*)\\_(.*)')
  
  p1_6 <- ggarrange(p1,p2,p3,p4,p5,p6, ncol = 2, nrow=3)
  p1_6 <- annotate_figure(p1_6, top = text_grob(i, size = 14, face="bold"))
  print(p1_6)
  
}
dev.off()
rm(df)
rm(df_ko)
rm(df_normalized_forPlots)
rm(df_notNA)
rm(df_wts)
rm(df.pca)
rm(jnk)
rm(p1)
rm(p2)
rm(p3)
rm(p4)
rm(p5)
rm(p6)
rm(p1_6)
rm(experiments)
rm(ko_col)
rm(wt_col)
rm(WT_Bio_mix_col)
rm(WT_Tech_col)

}
if(imputeCheck){
# 5 # Differential gene regulation per strain ## #11 from analysis script ##########################
myfile <- list.files(path=out_dir, pattern = "3_2_3_")
df <- readRDS(file.path(out_dir, myfile))

repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
repInt_decode$Systemic.ID[is.na(repInt_decode$Systemic.ID)] <- ""
repInt_decode$ReplicateID <- paste(repInt_decode$Position_MS_Plate,"_",repInt_decode$Systemic.ID, "_", gsub("rep([0-9]+)C.*","\\1",repInt_decode$RawFileSuffix), sep="")
repInt_decode <- repInt_decode[,c(7,12)]
repInt_decode$NewColName <- paste(repInt_decode$Wild.type, "-", repInt_decode$ReplicateID, sep="")

repInt_decode$NewColName[grep("wt", repInt_decode$ReplicateID)] <- repInt_decode$ReplicateID[grep("wt", repInt_decode$ReplicateID)]
repInt_decode$NewColName[grep("WT_Tech", repInt_decode$ReplicateID)] <- repInt_decode$ReplicateID[grep("WT_Tech", repInt_decode$ReplicateID)]
repInt_decode$NewColName[grep("WT_Bio_mix", repInt_decode$ReplicateID)] <- repInt_decode$ReplicateID[grep("WT_Bio_mix", repInt_decode$ReplicateID)]

repInt_decode <- repInt_decode[,2:3]

df <- as.data.frame(t(df))
df$Strain <- rownames(df)
df <- merge(df, repInt_decode, by.="Strain", by.y="ReplicateID", all=TRUE)
rownames(df) <- df$NewColName
df <- df[,-c(grep("NewColName|ReplicateID|Strain", colnames(df)))]
df <- as.data.frame(t(df))
saveRDS(df, file.path(out_dir, paste0("5_0_",Sys.Date(),"_Data_Colnames_With_WT.rds")))
rm(repInt_decode)
rm(df)
# 5.1 # all vs. wt and different background separately to see any effect ###########################
myfile <- list.files(path=out_dir, pattern = "5_0_")
df_normalized <- readRDS(file.path(out_dir, myfile))

proteinsIdentified <- dim(df_normalized)[1]
numberOfStrains <- dim(df_normalized)[2]

allCols <- 1:numberOfStrains

wtCols <- grep("wt", colnames(df_normalized))
wttecCols <- grep("WT_Tech", colnames(df_normalized))
wtbiomixCols <- grep("WT_Bio_mix", colnames(df_normalized))

koCols <- setdiff(allCols, c(wtCols,wttecCols, wtbiomixCols))

# calculate the means of the groups and the fold change #
df_normalized$Mean_wt <- apply(df_normalized[,wtCols], 1, mean, na.rm=T)
df_normalized$Mean_ko <- apply(df_normalized[,koCols], 1, mean, na.rm=T)
df_normalized$FoldChange <- df_normalized$Mean_ko - df_normalized$Mean_wt
# calculate the p values #
df_normalized$pValue <- NA

my.t.test.p.value <- function(x,y) {
  obj<-try(t.test(x,y), silent=TRUE)
  if (is(obj, "try-error")) return(NA) else return(obj$p.value)
}
for (i in 1:dim(df_normalized)[1]) {
  print(i)
  jnk <- my.t.test.p.value(df_normalized[i,koCols], df_normalized[i,wtCols])
  df_normalized$pValue[i] <- jnk
}
# correct the p values
df_normalized$p_Holm <- p.adjust(df_normalized$pValue, method = "holm", 
                                 n = length(df_normalized$pValue))
df_normalized$p_Hochberg <- p.adjust(df_normalized$pValue, method = "hochberg", 
                                     n = length(df_normalized$pValue))
df_normalized$p_Hommel <- p.adjust(df_normalized$pValue, method = "hommel", 
                                   n = length(df_normalized$pValue))
df_normalized$p_Bonferroni <- p.adjust(df_normalized$pValue, method = "bonferroni", 
                                       n = length(df_normalized$pValue))
df_normalized$p_BH <- p.adjust(df_normalized$pValue, method = "BH", 
                               n = length(df_normalized$pValue))
df_normalized$p_BY <- p.adjust(df_normalized$pValue, method = "BY", 
                               n = length(df_normalized$pValue))
df_normalized$p_FDR <- p.adjust(df_normalized$pValue, method = "fdr", 
                                n = length(df_normalized$pValue))
# compare different p value correction methods
library(corrplot)
library("PerformanceAnalytics")
pvalue_cols <- grep("^p.*", colnames(df_normalized))
DF_cor<- cor(df_normalized[pvalue_cols], use="pairwise.complete.obs", method="pearson")

pdf(file.path(out_dir, paste0("5_1_1_",Sys.Date(),"_pvalue_correction_comparison_wtKO.pdf")))
corrplot(DF_cor, type = "upper", order = "hclust", 
         tl.col = "black", tl.srt = 45)

chart.Correlation(df_normalized[pvalue_cols], histogram=TRUE, pch=19)
dev.off()
# use p_BH  correction #

# volcano plot with corrected p values and fold changes #
df_normalized$GeneNames <- rownames(df_normalized)

pdf(file.path(out_dir, paste0("5_1_2_",Sys.Date(),"_volcanoPlot_wtKO.pdf")))
ggplot(df_normalized, aes(FoldChange))+
  geom_histogram(bins=50)+
  xlim(-1,1)

ggplot(df_normalized, aes(FoldChange))+
  geom_density(size=1, fill="grey")+
  xlim(-1,1)

ggplot(df_normalized, aes(x=FoldChange, y=-log10(pValue)))+
  geom_point()+
  geom_point(data = subset(df_normalized, 
                           pValue <= 0.01 & FoldChange >= 0.5 | FoldChange <= -0.5), 
             color="red") +
  geom_text_repel(data = subset(df_normalized, 
                                pValue <= 0.01 & FoldChange >= 0.5 | FoldChange <= -0.5), 
                  aes(label=GeneNames)) +
  ggtitle("p value not corrected")


ggplot(df_normalized, aes(x=FoldChange, y=-log10(p_BH)))+
  geom_point()+
  geom_point(data = subset(df_normalized, 
                           p_BH <= 0.01 & FoldChange >= 0.5 | FoldChange <= -0.5), 
             color="red") +
  geom_text_repel(data = subset(df_normalized, 
                                p_BH <= 0.01 & FoldChange >= 0.5 | FoldChange <= -0.5), 
                  aes(label=GeneNames)) +
  ggtitle("Benjamini-Hochberg correction")

ggplot(df_normalized, aes(x=FoldChange, y=-log10(p_Bonferroni)))+
  geom_point()+
  geom_point(data = subset(df_normalized, 
                           p_Bonferroni <= 0.01 & FoldChange >= 0.5 | FoldChange <= -0.5), 
             color="red") +
  geom_text_repel(data = subset(df_normalized, 
                                p_Bonferroni <= 0.01 & FoldChange >= 0.5 | FoldChange <= -0.5), 
                  aes(label=GeneNames)) +
  ggtitle("Bonferroni correction")

dev.off()
df_normalized <- df_normalized[, -pvalue_cols]
# 5.2 # compare the mean distributions in wt-ko-all ###########################
library(corrplot)
library("PerformanceAnalytics")
df_normalized$Mean_all <- apply(df_normalized[,allCols], 1, mean, na.rm=T)
df_normalized$Mean_notTech <- apply(df_normalized[,c(wtCols, koCols)], 1, mean, na.rm=T)

MeanCols <- grep("^Mean.*", colnames(df_normalized))

DF_cor<- cor(df_normalized[MeanCols], use="pairwise.complete.obs", method="pearson")

pdf(file.path(out_dir, paste0("5_2_",Sys.Date(),"_Mean_comparison_wtKOall.pdf")))
corrplot(DF_cor, type = "upper", order = "hclust", 
         tl.col = "black", tl.srt = 45)

chart.Correlation(df_normalized[MeanCols], histogram=TRUE, pch=19)
dev.off()
rm(df_normalized)
rm(DF_cor)
# 5.3 # k/o strains DIFFERENT background vs wild type  same as above #######
myfile <- list.files(path=out_dir, pattern = "5_0_")
df_normalized <- readRDS(file.path(out_dir, myfile))

df_normalized[df_normalized == 0] <- NA
df_normalized_VP <- df_normalized
rm(df_normalized)

proteinsIdentified <- dim(df_normalized_VP)[1]
numberOfStrains <- dim(df_normalized_VP)[2]

allCols <- 1:numberOfStrains
wtCols <- grep("wt", colnames(df_normalized_VP))
wttecCols <- grep("WT_Tech", colnames(df_normalized_VP))
wtbiomixCols <- grep("WT_Bio_mix", colnames(df_normalized_VP))

koCols <- setdiff(allCols, c(wtCols,wttecCols, wtbiomixCols))
koCols_ED666 <- grep("ED666", colnames(df_normalized_VP))
koCols_ED668 <- grep("ED668", colnames(df_normalized_VP))


# calculate the means of the groups and the fold change #
df_normalized_VP$Mean_wt <- apply(df_normalized_VP[,wtCols], 1, mean, na.rm=T)
df_normalized_VP$Mean_ko <- apply(df_normalized_VP[,koCols], 1, mean, na.rm=T)
df_normalized_VP$Mean_ko666 <- apply(df_normalized_VP[,koCols_ED666], 1, mean, na.rm=T)
df_normalized_VP$Mean_ko668 <- apply(df_normalized_VP[,koCols_ED668], 1, mean, na.rm=T)

df_normalized_VP$FoldChange_KOwt <- df_normalized_VP$Mean_ko - df_normalized_VP$Mean_wt
df_normalized_VP$FoldChange_KO666wt <- df_normalized_VP$Mean_ko666 - df_normalized_VP$Mean_wt
df_normalized_VP$FoldChange_KO668wt <- df_normalized_VP$Mean_ko668 - df_normalized_VP$Mean_wt
df_normalized_VP$FoldChange_KO666KO668 <- df_normalized_VP$Mean_ko666 - df_normalized_VP$Mean_ko668


# calculate the p values #
df_normalized_VP$pValue_KOwt <- NA
df_normalized_VP$pValue_KO666wt <- NA
df_normalized_VP$pValue_KO668wt <- NA
df_normalized_VP$pValue_KO666KO668 <- NA

my.t.test.p.value <- function(x,y) {
  obj<-try(t.test(x,y), silent=TRUE)
  if (is(obj, "try-error")) return(NA) else return(obj$p.value)
}

for (i in 1:dim(df_normalized_VP)[1]) {
  print(i)
  df_normalized_VP$pValue_KOwt[i] <- my.t.test.p.value(df_normalized_VP[i,koCols], df_normalized_VP[i,wtCols])
  df_normalized_VP$pValue_KO666wt[i] <- my.t.test.p.value(df_normalized_VP[i,koCols_ED666], df_normalized_VP[i,wtCols])
  df_normalized_VP$pValue_KO668wt[i] <- my.t.test.p.value(df_normalized_VP[i,koCols_ED668], df_normalized_VP[i,wtCols])
  df_normalized_VP$pValue_KO666KO668[i] <- my.t.test.p.value(df_normalized_VP[i,koCols_ED666], df_normalized_VP[i,koCols_ED668])
}
# correct the p values #
df_normalized_VP$pValue_KOwt_B <- p.adjust(df_normalized_VP$pValue_KOwt, method = "bonferroni",
                                           n = length(df_normalized_VP$pValue_KOwt))
df_normalized_VP$pValue_KO666wt_B <- p.adjust(df_normalized_VP$pValue_KO666wt, method = "bonferroni",
                                              n = length(df_normalized_VP$pValue_KO666wt))
df_normalized_VP$pValue_KO668wt_B <- p.adjust(df_normalized_VP$pValue_KO668wt, method = "bonferroni",
                                              n = length(df_normalized_VP$pValue_KO668wt))
df_normalized_VP$pValue_KO666KO668_B <- p.adjust(df_normalized_VP$pValue_KO666KO668, method = "bonferroni",
                                                 n = length(df_normalized_VP$pValue_KO666KO668))

df_normalized_VP$pValue_KOwt_BH <- p.adjust(df_normalized_VP$pValue_KOwt, method = "BH",
                                            n = length(df_normalized_VP$pValue_KOwt))
df_normalized_VP$pValue_KO666wt_BH <- p.adjust(df_normalized_VP$pValue_KO666wt, method = "BH",
                                               n = length(df_normalized_VP$pValue_KO666wt))
df_normalized_VP$pValue_KO668wt_BH <- p.adjust(df_normalized_VP$pValue_KO668wt, method = "BH",
                                               n = length(df_normalized_VP$pValue_KO668wt))
df_normalized_VP$pValue_KO666KO668_BH <- p.adjust(df_normalized_VP$pValue_KO666KO668, method = "BH",
                                                  n = length(df_normalized_VP$pValue_KO666KO668))

# volcano plot with corrected p values and fold changes #
library(ggplot2)
library(ggrepel)
df_normalized_VP$GeneNames <- rownames(df_normalized_VP)


pdf(file.path(out_dir, paste0("5_3_",Sys.Date(),"_volcanoPlot_wtKO_differentWT666_668.pdf")))

# ko-wt #
cor_jnk <- cor(x=df_normalized_VP$Mean_wt, y=df_normalized_VP$Mean_ko, use = "pairwise.complete.obs")
ggplot(df_normalized_VP, aes(x=Mean_wt, y=Mean_ko))+
  geom_point(alpha=0.4)+
  geom_abline(slope=1, color="red") +
  ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))

ggplot(df_normalized_VP, aes(FoldChange_KOwt))+
  geom_density(size=1, fill="grey")+
  ggtitle("FoldChange_KOwt") +
  xlab("mean(KO) - mean(wt)")

ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KOwt))+
  geom_point()+
  ggtitle("FoldChange_KOwt") +
  xlab("mean(KO) - mean(wt)")

ggplot(df_normalized_VP, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KOwt >= 1 | FoldChange_KOwt <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP, 
                                 FoldChange_KOwt >= 1 | FoldChange_KOwt <= -1), 
                   aes(label=GeneNames)) +
  ggtitle("all KO's vs. wt") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO) - mean(wt)")

ggplot(df_normalized_VP, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt_B)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KOwt >= 1 | FoldChange_KOwt <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP,
                                 FoldChange_KOwt >= 1 | FoldChange_KOwt <= -1),
                   aes(label=GeneNames)) +
  ggtitle("all KO's vs. wt (bonferroni corrected)") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO) - mean(wt)")

ggplot(df_normalized_VP, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt_BH)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KOwt >= 1 | FoldChange_KOwt <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP,
                                 FoldChange_KOwt >= 1 | FoldChange_KOwt <= -1),
                   aes(label=GeneNames)) +
  ggtitle("all KO's vs. wt (Benjamini-Hochberg corrected)") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO) - mean(wt)")



# ko666-wt #
cor_jnk <- cor(x=df_normalized_VP$Mean_wt, y=df_normalized_VP$Mean_ko666, use = "pairwise.complete.obs")
ggplot(df_normalized_VP, aes(x=Mean_wt, y=Mean_ko666))+
  geom_point(alpha=0.4)+
  geom_abline(slope=1, color="red") +
  ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))

ggplot(df_normalized_VP, aes(FoldChange_KO666wt))+
  geom_density(size=1, fill="grey")+
  ggtitle("FoldChange_KO666wt") +
  xlab("mean(KO666) - mean(wt)")

ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KO666wt))+
  geom_point()+
  ggtitle("FoldChange_KO666wt") +
  xlab("mean(KO666) - mean(wt)")

ggplot(df_normalized_VP, aes(x=FoldChange_KO666wt, y=-log10(pValue_KO666wt)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KO666wt >= 1 | FoldChange_KO666wt <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP, 
                                 FoldChange_KO666wt >= 1 | FoldChange_KO666wt <= -1), 
                   aes(label=GeneNames)) +
  ggtitle("KO666 vs. wt") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO666) - mean(wt)")

ggplot(df_normalized_VP, aes(x=FoldChange_KO666wt, y=-log10(pValue_KO666wt_B)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KO666wt >= 1 | FoldChange_KO666wt <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP,
                                 FoldChange_KO666wt >= 1 | FoldChange_KO666wt <= -1),
                   aes(label=GeneNames)) +
  ggtitle("KO666 vs. wt (bonferroni corrected)") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO666) - mean(wt)")

ggplot(df_normalized_VP, aes(x=FoldChange_KO666wt, y=-log10(pValue_KO666wt_BH)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KO666wt >= 1 | FoldChange_KO666wt <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP,
                                 FoldChange_KO666wt >= 1 | FoldChange_KO666wt <= -1),
                   aes(label=GeneNames)) +
  ggtitle("KO666 vs. wt (Benjamini-Hochberg corrected)") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO666) - mean(wt)")

# ko668-wt #
cor_jnk <- cor(x=df_normalized_VP$Mean_wt, y=df_normalized_VP$Mean_ko668, use = "pairwise.complete.obs")
ggplot(df_normalized_VP, aes(x=Mean_wt, y=Mean_ko668))+
  geom_point(alpha=0.4)+
  geom_abline(slope=1, color="red") +
  ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))

ggplot(df_normalized_VP, aes(FoldChange_KO668wt))+
  geom_density(size=1, fill="grey")+
  ggtitle("FoldChange_KO668wt") +
  xlab("mean(KO668) - mean(wt)")

ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KO668wt))+
  geom_point()+
  ggtitle("FoldChange_KO668wt") +
  xlab("mean(KO668) - mean(wt)")

ggplot(df_normalized_VP, aes(x=FoldChange_KO668wt, y=-log10(pValue_KO668wt)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KO668wt >= 1 | FoldChange_KO668wt <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP, 
                                 FoldChange_KO668wt >= 1 | FoldChange_KO668wt <= -1), 
                   aes(label=GeneNames)) +
  ggtitle("KO668 vs. wt") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO668) - mean(wt)")

ggplot(df_normalized_VP, aes(x=FoldChange_KO668wt, y=-log10(pValue_KO668wt_B)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KO668wt >= 1 | FoldChange_KO668wt <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP,
                                 FoldChange_KO668wt >= 1 | FoldChange_KO668wt <= -1),
                   aes(label=GeneNames)) +
  ggtitle("KO668 vs. wt (bonferroni corrected)") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO668) - mean(wt)")

ggplot(df_normalized_VP, aes(x=FoldChange_KO668wt, y=-log10(pValue_KO668wt_BH)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KO668wt >= 1 | FoldChange_KO668wt <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP,
                                 FoldChange_KO668wt >= 1 | FoldChange_KO668wt <= -1),
                   aes(label=GeneNames)) +
  ggtitle("KO668 vs. wt (Benjamini-Hochberg corrected)") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO668) - mean(wt)")

# ko666-ko668 #
cor_jnk <- cor(x=df_normalized_VP$Mean_ko666, y=df_normalized_VP$Mean_ko668, use = "pairwise.complete.obs")
ggplot(df_normalized_VP, aes(x=Mean_ko666, y=Mean_ko668))+
  geom_point(alpha=0.4)+
  geom_abline(slope=1, color="red") +
  ggtitle(paste0("Comparison of the abundances, cor: ", round(cor_jnk,2)))

ggplot(df_normalized_VP, aes(FoldChange_KO666KO668))+
  geom_density(size=1, fill="grey")+
  ggtitle("FoldChange_KO666KO668") +
  xlab("mean(KO666) - mean(KO668)")

ggplot(df_normalized_VP, aes(y=Mean_wt,x=FoldChange_KO666KO668))+
  geom_point()+
  ggtitle("FoldChange_KO666KO668") +
  xlab("mean(KO666) - mean(KO668)")

ggplot(df_normalized_VP, aes(x=FoldChange_KO666KO668, y=-log10(pValue_KO666KO668)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KO666KO668 >= 1 | FoldChange_KO666KO668 <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP, 
                                 FoldChange_KO666KO668 >= 1 | FoldChange_KO666KO668 <= -1), 
                   aes(label=GeneNames)) +
  ggtitle("KO666 vs. KO668") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO666) - mean(KO668)")

ggplot(df_normalized_VP, aes(x=FoldChange_KO666KO668, y=-log10(pValue_KO666KO668_B)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KO666KO668 >= 1 | FoldChange_KO666KO668 <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP,
                                 FoldChange_KO666KO668 >= 1 | FoldChange_KO666KO668 <= -1),
                   aes(label=GeneNames)) +
  ggtitle("KO666 vs. KO668 (bonferroni corrected)") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO666) - mean(KO668)")

ggplot(df_normalized_VP, aes(x=FoldChange_KO666KO668, y=-log10(pValue_KO666KO668_BH)))+
  geom_point()+
  geom_point(data = subset(df_normalized_VP, 
                           FoldChange_KO666KO668 >= 1 | FoldChange_KO666KO668 <= -1), 
             color="red") +
  geom_label_repel(data = subset(df_normalized_VP,
                                 FoldChange_KO666KO668 >= 1 | FoldChange_KO666KO668 <= -1),
                   aes(label=GeneNames)) +
  ggtitle("KO666 vs. KO668 (Benjamini-Hochberg corrected)") +
  geom_vline(xintercept = 1, color="red", alpha=0.3) +
  geom_vline(xintercept = -1, color="red", alpha=0.3) +
  geom_hline(yintercept = 2, color="red", alpha=0.3) +
  xlab("mean(KO666) - mean(KO668)")

dev.off()
rm(cor_jnk)
rm(df_normalized_VP)

# 5.4 # each k/o strain vs wild types and their own background population #######
repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
experiments <- unique(repInt_decode$Systemic.ID)
experiments <- experiments[-grep("wt", experiments)]
experiments <- experiments[!is.na(experiments)]
rm(repInt_decode)

myfile <- list.files(path=out_dir, pattern = "5_0_")
df_normalized <- readRDS(file.path(out_dir, myfile))
df_normalized[df_normalized == 0] <- NA
df_normalized_VP <- df_normalized
# rm(df_normalized)

proteinsIdentified <- dim(df_normalized_VP)[1]
numberOfStrains <- dim(df_normalized_VP)[2]
allCols <- 1:numberOfStrains
wtCols <- grep("wt", colnames(df_normalized_VP))
wttecCols <- grep("WT_Tech", colnames(df_normalized_VP))
wtbiomixCols <- grep("WT_Bio_mix", colnames(df_normalized_VP))
koCols <- setdiff(allCols, c(wtCols,wttecCols, wtbiomixCols))
koCols_ED666 <- grep("ED666", colnames(df_normalized_VP))
koCols_ED668 <- grep("ED668", colnames(df_normalized_VP))

pdf(file.path(out_dir, paste0("5_4_1_", Sys.Date(), "_volcanoPlot_eachKO.pdf")))

for (j in 1:length(experiments)) {
  i <- experiments[j]
  print(j)
  ko_col <- grep(i, names(df_normalized_VP))
  wt_col <- grep("wt", names(df_normalized_VP))
  
  bg_wt <- unique(gsub("(ED[0-9]*)\\-.*", "\\1", names(df_normalized_VP)[ko_col]))
  ko_bg_cols <- setdiff(grep(bg_wt, names(df_normalized_VP)), ko_col)
  
  my_new_df <- data.frame(Mean_wt = apply(df_normalized_VP[,wt_col], 1, mean, na.rm=T),
                          Mean_ko = apply(df_normalized_VP[,ko_col], 1, mean, na.rm=T),
                          Mean_kobg = apply(df_normalized_VP[,ko_bg_cols], 1, mean, na.rm=T))
  
  my_new_df$FoldChange_KOwt <- my_new_df$Mean_ko - my_new_df$Mean_wt
  my_new_df$FoldChange_KObg <- my_new_df$Mean_ko - my_new_df$Mean_kobg
  
  # calculate the p values #
  my_new_df$pValue_KOwt <- NA
  my_new_df$pValue_KObg <- NA
  
  
  my.t.test.p.value <- function(x,y) {
    obj<-try(t.test(x,y), silent=TRUE)
    if (is(obj, "try-error")) return(NA) else return(obj$p.value)
  }
  
  for (k in 1:dim(my_new_df)[1]) {
    my_new_df$pValue_KOwt[k] <- my.t.test.p.value(df_normalized_VP[k,ko_col], df_normalized_VP[k,wt_col])
    my_new_df$pValue_KObg[k] <- my.t.test.p.value(df_normalized_VP[k,ko_col], df_normalized_VP[k,ko_bg_cols])
    }

  # volcano plot with corrected p values and fold changes #
  my_new_df$GeneNames <- rownames(my_new_df)
  my_gene_name <- grep(i, my_new_df$GeneNames)
  p1 <- ggplot(my_new_df, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt)))+
    geom_point()+
    geom_point(data = subset(my_new_df, 
                             pValue_KOwt <= 0.05 & FoldChange_KOwt >= 0.5 | pValue_KOwt <= 0.05 & FoldChange_KOwt <= -0.5), 
               color="red") +
    geom_point(data = subset(my_new_df, GeneNames == my_new_df$GeneNames[my_gene_name]), color="blue") +
    # geom_label_repel(data = subset(my_new_df, 
    #                                pValue_KOwt <= 0.05 & FoldChange_KOwt >= 0.5 | pValue_KOwt <= 0.05 & FoldChange_KOwt <= -0.5), 
    #                  aes(label=GeneNames)) +
    geom_vline(xintercept = 0.5, color="red", alpha=0.3) +
    geom_vline(xintercept = -0.5, color="red", alpha=0.3) +
    geom_hline(yintercept = -log10(0.05), color="red", alpha=0.3) +
    xlab(paste0("log2(",i,"-wt)"))+
    ylab("-log10(p-value)")
  p2 <- ggplot(my_new_df, aes(x=FoldChange_KObg, y=-log10(pValue_KObg)))+
    geom_point()+
    geom_point(data = subset(my_new_df, 
                             pValue_KObg <= 0.05 & FoldChange_KObg >= 0.5 | pValue_KObg <= 0.05 & FoldChange_KObg <= -0.5), 
               color="red") +
    geom_point(data = subset(my_new_df, GeneNames == my_new_df$GeneNames[my_gene_name]), color="blue") +
    # geom_label_repel(data = subset(my_new_df, 
    #                                pValue_KObg <= 0.05 & FoldChange_KObg >= 0.5 | pValue_KObg <= 0.05 & FoldChange_KObg <= -0.5), 
    #                  aes(label=GeneNames)) +
    geom_vline(xintercept = 0.5, color="red", alpha=0.3) +
    geom_vline(xintercept = -0.5, color="red", alpha=0.3) +
    geom_hline(yintercept = -log10(0.05), color="red", alpha=0.3) +
    xlab(paste0("log2(",i,"-",bg_wt,")"))+
    ylab(NULL)
  
  p1_2 <- ggarrange(p1,p2,ncol = 2, nrow=1)
  p1_2 <- annotate_figure(p1_2, top = text_grob(i, size = 14, face="bold"))
  print(p1_2)
  names(my_new_df) <- paste(names(my_new_df), "-", i, sep="")
  my_new_df <- my_new_df[,4:7]
  df_normalized <- as.data.frame(cbind(df_normalized, my_new_df))
}
dev.off()

saveRDS(df_normalized,file.path(out_dir, paste0("5_4_2_", Sys.Date(), "_DiffReg_df.rds")))
rm(df_normalized)
rm(df_normalized_VP)
rm(my_new_df)
rm(p1)
rm(p2)
rm(p1_2)
# 5.5 # MBR vs. noMBR ###################################################################################################
# 5.5.0 # comparison identification and values ##########################################################################
pG_mbr <- read.delim(file.path(data_dir,"Replicates_combined_1U_MBR/txt/proteinGroups.txt"))
pG_mbr <- my_pG_filter(pG_mbr,1,1)

pG_NOmbr <- read.delim(file.path(data_dir,"Replicates_combined_1U_noMBR/txt/proteinGroups.txt"))
pG_NOmbr <- my_pG_filter(pG_NOmbr,1,1)


repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG_mbr))
pG_mbr_rep <- pG_mbr[,c(1,repCol)]

pG_mbr_rep[pG_mbr_rep==0] <- NA
pG_mbr_rep[,2:dim(pG_mbr_rep)[2]] <- log2(pG_mbr_rep[,2:dim(pG_mbr_rep)[2]])

repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG_NOmbr))
pG_NOmbr_rep <- pG_NOmbr[,c(1,repCol)]

pG_NOmbr_rep[pG_NOmbr_rep==0] <- NA
pG_NOmbr_rep[,2:dim(pG_NOmbr_rep)[2]] <- log2(pG_NOmbr_rep[,2:dim(pG_NOmbr_rep)[2]])

pG_rep_combined <- merge(pG_mbr_rep, pG_NOmbr_rep, by=1, all=TRUE)
repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG_rep_combined))

experiments <- as.data.frame(unique(gsub("^Reporter.intensity.corrected.([0-9].rep[0-9]C[0-9][0-9]).[x-y]","\\1", names(pG_rep_combined)[repCol])))
experiments$correlation <- NA
names(experiments)[1] <- "experiments"
experiments$PG_mbr <- NA
experiments$PG_NOmbr <- NA
experiments$commonPG <- NA

pdf(file.path(out_dir, paste0("5_5_0_", Sys.Date(), "_correlation_MBR_noMBR.pdf")))
for (i in 1:dim(experiments)[1]) {
  myexp1 <- experiments$experiments[i]
  myexp <- pG_rep_combined[,grep(myexp1, names(pG_rep_combined))]
  myexp <- myexp[rowSums(!is.na(myexp))!=0,]
  experiments$correlation[i] <- cor(myexp[,1], myexp[,2], use = 'pairwise.complete.obs', method = "pearson")[1]
  experiments$PG_mbr[i] <- colSums(!is.na(myexp))[1]
  experiments$PG_NOmbr[i] <- colSums(!is.na(myexp))[2]
  experiments$commonPG[i] <- sum(rowSums(!is.na(myexp))==2)
  plot(myexp[,1], myexp[,2], xlab="MBR", ylab="noMBR", main=myexp1)
}
dev.off()
saveRDS(experiments, file.path(out_dir, paste0("5_5_0_", Sys.Date(), "_experimentsComparison.rds")))
rm(experiments)
rm(myexp)
rm(pG_NOmbr)
rm(pG_NOmbr_rep)
rm(pG_rep_combined)
rm(pG_mbr)
rm(pG_mbr_rep)
# 5.5.1 # work with mbr for imputation tests and the rest ##########################################################################
pG_mbr <- read.delim(file.path(data_dir,"Replicates_combined_1U_MBR/txt/proteinGroups.txt"))
numberOriginal <- dim(pG_mbr)[1]
pG_mbr <- my_pG_filter(pG_mbr,1,1)
numberFiltered <- dim(pG_mbr)[1]

repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG_mbr))
pG_mbr[,repCol][pG_mbr[,repCol]==0] <- NA
pG_mbr[,repCol] <- log2(pG_mbr[,repCol])
pG_mbr <- pG_mbr[rowSums(!is.na(pG_mbr[,repCol])) != 0,]
numberMeasured <- dim(pG_mbr)[1]

IDCol <- grep("Identification.type.", names(pG_mbr))
repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG_mbr))
pG_mbr <- pG_mbr[,c(1, IDCol, repCol)]
# change the id's #
df_pg2_ID <- as.data.frame(cbind(pG_mbr$Protein.IDs, pG_mbr$Protein.IDs))
df_pg2_ID <- splitColumnBySep(df_pg2_ID, "V2")
df_pg2_ID$geneID <- gsub("(SP.*\\..*)\\.1\\:pep.*","\\1",df_pg2_ID$V2)
df_pg2_ID$geneID_length <- nchar(df_pg2_ID$geneID)

df_pg2_ID <- df_pg2_ID[,c(1,3)]
df_pg2_ID2 <- df_pg2_ID %>%
  group_by(V1) %>%
  dplyr::summarise(text=paste(geneID,collapse=';')) %>%
  as.data.frame()
rm(df_pg2_ID)

pG_mbr <- merge(pG_mbr, df_pg2_ID2, by.x="Protein.IDs", by.y="V1")
rm(df_pg2_ID2)

IDCol <- grep("Identification.type.", names(pG_mbr))
repCol <- grep("Reporter.intensity.corrected.[0-9].+", names(pG_mbr))

pG_mbr_REP <- pG_mbr[,c(530,repCol)]
pG_mbr_ID <- pG_mbr[,c(530,IDCol)]


pG_mbr_REP <- as.data.frame(melt(pG_mbr_REP, id="text"))
pG_mbr_ID <- as.data.frame(melt(pG_mbr_ID, id="text"))

pG_mbr_REP$mergeID <- paste(pG_mbr_REP$text, gsub("Reporter.intensity.corrected.[0-9].(.*)","\\1", pG_mbr_REP$variable), sep="=")
pG_mbr_ID$mergeID <- paste(pG_mbr_ID$text, gsub("Identification.type.(.*)","\\1", pG_mbr_ID$variable), sep="=")
pG_mbr_ID <- pG_mbr_ID[,c(4,3)]
names(pG_mbr_ID)[2] <- "IDtype"
names(pG_mbr_REP)[3] <- "log2Intensity"

pG_mbr_melt <- merge(pG_mbr_REP, pG_mbr_ID, by.x="mergeID", by.y="mergeID", all=FALSE)
names(pG_mbr_melt)[2] <- "Protein.IDs"
rm(pG_mbr)
rm(pG_mbr_ID)
rm(pG_mbr_REP)
pG_mbr_melt$variable <- gsub("Reporter.intensity.corrected.(.*)","\\1", pG_mbr_melt$variable)
names(pG_mbr_melt)[3] <- "MSRUN"
pG_mbr_melt$Quantified <- !is.na(pG_mbr_melt$log2Intensity)


repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
repInt_decode$Systemic.ID[is.na(repInt_decode$Systemic.ID)] <- ""

repInt_decode$ReplicateID <- paste(repInt_decode$Position_MS_Plate,"_",repInt_decode$Systemic.ID, "_", gsub("rep([0-9]+)C.*","\\1",repInt_decode$RawFileSuffix), sep="")
repInt_tomerge <- repInt_decode[c(1,10,12)]
repInt_tomerge$IntensityColumnNames_used <- gsub("Reporter.intensity.corrected.(.*)","\\1", repInt_tomerge$IntensityColumnNames_used)

pG_mbr_melt <- merge(pG_mbr_melt, repInt_tomerge, by.x="MSRUN", by.y="IntensityColumnNames_used", all=FALSE)
pG_mbr_melt$mergeID <- paste(pG_mbr_melt$Protein.IDs, pG_mbr_melt$ReplicateID, sep="=")

rm(repInt_decode)
rm(repInt_tomerge)

myfile <- list.files(path=out_dir, pattern="3_2_3")
df_norm <- readRDS(file.path(out_dir, myfile))
df_norm$Protein.IDs <- rownames(df_norm)
df_norm <- melt(df_norm, id="Protein.IDs")
df_norm$mergeID <- paste(df_norm$Protein.IDs, df_norm$variable, sep="=")

pG_mbr_melt <- merge(pG_mbr_melt, df_norm, by.x="mergeID", by.y="mergeID", all=FALSE)
rm(df_norm)
pG_mbr_melt <- pG_mbr_melt[,c(1:3,7,8,6,5,4,11)]
names(pG_mbr_melt)[3] <- "ProteinIDs"
names(pG_mbr_melt)[4] <- "SystemicIDko"
names(pG_mbr_melt)[7:9] <- c("IdentificationType", "log2Measured", "log2Normalized")

pG_mbr_melt$IdentificationType[pG_mbr_melt$IdentificationType==""] <- "NotIdentified"

saveRDS(pG_mbr_melt, file.path(out_dir, paste0("5_5_1_", Sys.Date(), "_pG_mbr_meltALL_4impute.rds")))

df_count <- data.frame(mytype=c("Original", "Filtered", "Measured"),
                       mycounts=c(numberOriginal, numberFiltered, numberMeasured))
df_count$mytype <- factor(df_count$mytype, levels = c("Original", "Filtered", "Measured"))

p1 <- ggplot(df_count, aes(mytype, mycounts)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label=mycounts, y = mycounts + 10), position = position_dodge(0.9), vjust = 0, size=6)+
  xlab(NULL) +
  ylab("Number of Protein Groups") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))
saveRDS(df_count, file.path(out_dir, paste0("5_5_1_", Sys.Date(), "_df_count.rds")))
rm(df_count)

myfile <- list.files(path=out_dir, pattern="5_5_1.*4impute\\.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))

pG_mbr_melt$SystemicIDko[pG_mbr_melt$SystemicIDko==""] <- "tech"

wtTechRow <- grep("tech", pG_mbr_melt$SystemicIDko)
wtBioRow <- grep("wt", pG_mbr_melt$SystemicIDko)
koRow <- setdiff(1:dim(pG_mbr_melt)[1], c(wtTechRow, wtBioRow))


df_count <- data.frame(mytype=c("All-possible","All-with-value","Technical", "Wild-Type", "Knockout"),
                       mycounts=c(dim(pG_mbr_melt)[1],
                                  sum(!is.na(pG_mbr_melt[,"log2Normalized"])), 
                                  sum(!is.na(pG_mbr_melt[wtTechRow,"log2Normalized"])), 
                                  sum(!is.na(pG_mbr_melt[wtBioRow,"log2Normalized"])), 
                                  sum(!is.na(pG_mbr_melt[koRow,"log2Normalized"]))))

df_count$mytype <- factor(df_count$mytype, levels = c("All-possible", "All-with-value", "Knockout", "Wild-Type", "Technical" ))

p1_1 <- ggplot(df_count, aes(mytype, mycounts)) +
  geom_bar(stat = "identity") +
  geom_text(aes(label=mycounts, y = mycounts + 10000), position = position_dodge(0.9), vjust = 0, size=6)+
  xlab(NULL) +
  ylab("Number of Protein Groups") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

# remove the technical wt's for further analysis 
pG_mbr_melt <- subset(pG_mbr_melt, SystemicIDko != "tech")


pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs) %>%
  dplyr::mutate(ProteinIDs_count=sum(!is.na(log2Normalized))) %>%
  as.data.frame()

p2 <- ggplot(pG_mbr_melt, aes(ProteinIDs_count)) +
  geom_density(size=2) +
  xlab("Number of measured") +
  ylab("Density") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs, SystemicIDko) %>%
  dplyr::mutate(Replicate_measured_count=sum(!is.na(log2Normalized))) %>%
  as.data.frame()


p3 <- ggplot(pG_mbr_melt, aes(Replicate_measured_count)) +
  geom_density(size=2) +
  xlab("Number of measured, replicates") +
  ylab("Density") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

p4 <- ggplot(pG_mbr_melt, aes(Replicate_measured_count, log2Measured)) +
  geom_boxplot(aes(group=Replicate_measured_count)) +
  xlab("Number of measured, replicates") +
  ylab("Measured intensity") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))


p5 <- ggplot(pG_mbr_melt, aes(Replicate_measured_count, log2Normalized)) +
  geom_boxplot(aes(group=Replicate_measured_count)) +
  xlab("Number of measured, replicates") +
  ylab("Normalized intensity") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

df_variables <- as.data.frame(table(pG_mbr_melt[,c(6,7,11)]))
df_variables <- subset(df_variables, Freq !=0)
df_variables$Type <- paste(df_variables$IdentificationType, df_variables$Quantified, sep="_")
df_variables$Type <- gsub("By ", "", df_variables$Type)
df_variables$Type <- gsub("matching_FALSE", "matching", df_variables$Type)
df_variables$Type <- gsub("NotIdentified_FALSE", "NotIdentified", df_variables$Type)

df_variables$Type<- factor(df_variables$Type, levels = c("MS/MS_TRUE", "MS/MS_FALSE", "matching", "NotIdentified"))

df_variables$Freq2 <- round(df_variables$Freq*100/sum(df_variables$Freq),1)


p6 <- ggplot(df_variables, aes(x=Type, y=Freq, fill=Replicate_measured_count))+
  geom_bar(stat = "identity") +
  geom_text(aes(label=Freq),size = 3, position = position_stack(vjust = 0.5)) +
  xlab(NULL) +
  ylab("Number") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

p6_1 <- ggplot(df_variables, aes(x=Type, y=Freq, fill=Replicate_measured_count))+
  geom_bar(stat = "identity") +
  geom_text_repel(aes(label=Freq),size = 3, position = position_stack(vjust = 0.5)) +
  xlab(NULL) +
  ylab("Number") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

p7 <- ggplot(df_variables, aes(x=Type, y=Freq2, fill=Replicate_measured_count))+
  geom_bar(stat = "identity") +
  geom_text(aes(label=Freq2),size = 3, position = position_stack(vjust = 0.5)) +
  xlab(NULL) +
  ylab("Percentage") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

p7_1 <- ggplot(df_variables, aes(x=Type, y=Freq2, fill=Replicate_measured_count))+
  geom_bar(stat = "identity") +
  geom_text_repel(aes(label=Freq2),size = 3, position = position_stack(vjust = 0.5)) +
  xlab(NULL) +
  ylab("Percentage") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

# remove the all wt's for further analysis 
pG_mbr_melt <- subset(pG_mbr_melt, SystemicIDko != "tech")
pG_mbr_melt <- subset(pG_mbr_melt, SystemicIDko != "wt1" & SystemicIDko != "wt2")


pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs) %>%
  dplyr::mutate(ProteinIDs_count=sum(!is.na(log2Normalized))) %>%
  as.data.frame()

p2_2 <- ggplot(pG_mbr_melt, aes(ProteinIDs_count)) +
  geom_density(size=2) +
  xlab("Number of measured") +
  ylab("Density") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs, SystemicIDko) %>%
  dplyr::mutate(Replicate_measured_count=sum(!is.na(log2Normalized))) %>%
  as.data.frame()


p3_2 <- ggplot(pG_mbr_melt, aes(Replicate_measured_count)) +
  geom_density(size=2) +
  xlab("Number of measured, replicates") +
  ylab("Density") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

p4_2 <- ggplot(pG_mbr_melt, aes(Replicate_measured_count, log2Measured)) +
  geom_boxplot(aes(group=Replicate_measured_count)) +
  xlab("Number of measured, replicates") +
  ylab("Measured intensity") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))


p5_2 <- ggplot(pG_mbr_melt, aes(Replicate_measured_count, log2Normalized)) +
  geom_boxplot(aes(group=Replicate_measured_count)) +
  xlab("Number of measured, replicates") +
  ylab("Normalized intensity") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

df_variables <- as.data.frame(table(pG_mbr_melt[,c(6,7,11)]))
df_variables <- subset(df_variables, Freq !=0)
df_variables$Type <- paste(df_variables$IdentificationType, df_variables$Quantified, sep="_")
df_variables$Type <- gsub("By ", "", df_variables$Type)
df_variables$Type <- gsub("matching_FALSE", "matching", df_variables$Type)
df_variables$Type <- gsub("NotIdentified_FALSE", "NotIdentified", df_variables$Type)

df_variables$Type<- factor(df_variables$Type, levels = c("MS/MS_TRUE", "MS/MS_FALSE", "matching", "NotIdentified"))

df_variables$Freq2 <- round(df_variables$Freq*100/sum(df_variables$Freq),1)


p6_2 <- ggplot(df_variables, aes(x=Type, y=Freq, fill=Replicate_measured_count))+
  geom_bar(stat = "identity") +
  geom_text(aes(label=Freq),size = 3, position = position_stack(vjust = 0.5)) +
  xlab(NULL) +
  ylab("Number") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

p6_1_2 <- ggplot(df_variables, aes(x=Type, y=Freq, fill=Replicate_measured_count))+
  geom_bar(stat = "identity") +
  geom_text_repel(aes(label=Freq),size = 3, position = position_stack(vjust = 0.5)) +
  xlab(NULL) +
  ylab("Number") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

p7_2 <- ggplot(df_variables, aes(x=Type, y=Freq2, fill=Replicate_measured_count))+
  geom_bar(stat = "identity") +
  geom_text(aes(label=Freq2),size = 3, position = position_stack(vjust = 0.5)) +
  xlab(NULL) +
  ylab("Percentage") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

p7_1_2 <- ggplot(df_variables, aes(x=Type, y=Freq2, fill=Replicate_measured_count))+
  geom_bar(stat = "identity") +
  geom_text_repel(aes(label=Freq2),size = 3, position = position_stack(vjust = 0.5)) +
  xlab(NULL) +
  ylab("Percentage") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))

pdf(file.path(out_dir, paste0("5_5_1_", Sys.Date(), "_imputation_plots.pdf")), width = 10, height = 8)
print(p1)
print(p1_1)
print(p2)
print(p3)
print(p4)
print(p5)
print(p6)
print(p6_1)
print(p7)
print(p7_1)
print(p2_2)
print(p3_2)
print(p4_2)
print(p5_2)
print(p6_2)
print(p6_1_2)
print(p7_2)
print(p7_1_2)
dev.off()
rm(p1)
rm(p1_1)
rm(p2)
rm(p2_2)
rm(p3_2)
rm(p3)
rm(p4)
rm(p4_2)
rm(p5)
rm(p5_2)
rm(p6)
rm(p6_1)
rm(p6_1_2)
rm(p6_2)
rm(p7)
rm(p7_1)
rm(p7_1_2)
rm(p7_2)
rm(df_variables)
rm(pG_mbr_melt)
# 5.5.2 # Imputation bpca >=1 replicates and add as a column to df ###########
myfile <- list.files(path=out_dir, pattern="5_5_1.*4impute\\.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))

pG_mbr_melt$SystemicIDko[pG_mbr_melt$SystemicIDko==""] <- "tech"

pG_mbr_melt <- subset(pG_mbr_melt, SystemicIDko != "tech")

repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
experiments <- unique(repInt_decode$Systemic.ID)
experiments <- experiments[-grep("wt", experiments)]
experiments <- experiments[!is.na(experiments)]
rm(repInt_decode)

myconditions <- c(experiments, "wt")

intensity_matrix <- pG_mbr_melt[,c(3,5,9)]
intensity_matrix <- dcast(intensity_matrix, ProteinIDs ~ ReplicateID)
rownames(intensity_matrix) <- intensity_matrix$ProteinIDs
intensity_matrix <- intensity_matrix[,-1]
intensity_matrix <- as.matrix(intensity_matrix)

intensity_matrix2 <- get_imputation_bpca_bycond(norm_matrix=intensity_matrix, 
                                                conditions=myconditions, cores=1, repCount=1)


# rownames(intensity_matrix2) <- rownames(intensity_matrix)
intensity_matrix <- as.data.frame(intensity_matrix2)  

saveRDS(intensity_matrix,file.path(out_dir, paste0("5_5_2_", Sys.Date(), "_bpcaImputed_1rep_df.rds")))

intensity_matrix$ProteinIDs <- rownames(intensity_matrix)
intensity_matrix <- melt(intensity_matrix, id="ProteinIDs")

intensity_matrix$mergeID <- paste(intensity_matrix$ProteinIDs, intensity_matrix$variable, sep="=")
intensity_matrix <- as.data.frame(intensity_matrix[,3:4])
names(intensity_matrix)[1] <- "log2Imputed1"
pG_mbr_melt <- merge(pG_mbr_melt, intensity_matrix, by.x="mergeID", by.y="mergeID", all=FALSE)
rm(intensity_matrix)

pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs) %>%
  dplyr::mutate(ProteinIDs_measured_count=sum(!is.na(log2Normalized))) %>%
  as.data.frame()

pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs, SystemicIDko) %>%
  dplyr::mutate(Replicate_measured_count=sum(!is.na(log2Normalized))) %>%
  as.data.frame()

pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs) %>%
  dplyr::mutate(ProteinIDs_imputed_count=sum(!is.na(log2Imputed1))) %>%
  as.data.frame()

pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs, SystemicIDko) %>%
  dplyr::mutate(Replicate_imputed_count=sum(!is.na(log2Imputed1))) %>%
  as.data.frame()
saveRDS(pG_mbr_melt,file.path(out_dir, paste0("5_5_2_", Sys.Date(), "_pG_mbr_meltALL_imputed.rds")))


df_count <- as.data.frame(table(pG_mbr_melt[,c(12,14)]))
df_count <- as.data.frame(subset(df_count, Freq !=0))
df_count$Freq2 <- round(100*df_count$Freq/sum(df_count$Freq),1)
df_count$Type <- paste(df_count$Replicate_measured_count, df_count$Replicate_imputed_count, sep="_")

p1 <- ggplot(df_count, aes(x=Type, y=Freq)) +
  geom_bar(stat = "identity") +
  xlab("Measured_Imputed") +
  ylab("Count") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14)) +
  geom_text(aes(label=Freq, y = Freq + 30000), position = position_dodge(0.9), vjust = 0, size=6)+
  geom_text(aes(label=Freq2, y = Freq + 10000), position = position_dodge(0.9), vjust = 0, size=6)

ggsave(file.path(out_dir, paste0("5_5_2_", Sys.Date(),"_counts.pdf")), p1)
rm(p1)
rm(df_count)
rm(pG_mbr_melt)
rm(intensity_matrix2)
# 5.5.3 # Keep the imputations if "Replicate_measured_count >= 3 # 20190516 #######################
myfile <- list.files(path=out_dir, pattern = "pG_mbr_meltALL_imputed.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))

pG_mbr_melt$wt <- FALSE
pG_mbr_melt$wt[grep("wt", pG_mbr_melt$SystemicIDko)] <- TRUE

pG_mbr_melt <- pG_mbr_melt %>%
  group_by(wt, ProteinIDs) %>%
  dplyr::mutate(wt_count=sum(!is.na(log2Normalized))) %>%
  as.data.frame()

pG_mbr_melt$wt_count[pG_mbr_melt$wt == FALSE] <- FALSE

pG_mbr_melt$Keep <- FALSE
table(pG_mbr_melt$Keep) # FALSE = 943872
pG_mbr_melt$Keep[!is.na(pG_mbr_melt$log2Normalized)] <- TRUE
table(pG_mbr_melt$Keep) # TRUE = 618815 = 66% &&& FALSE = 325057

pG_mbr_melt$Keep[pG_mbr_melt$Replicate_measured_count >= 3 & pG_mbr_melt$wt != TRUE ] <- TRUE
table(pG_mbr_melt$Keep) # TRUE = 647412 = 68.6% &&& FALSE = 296460

pG_mbr_melt$Keep[pG_mbr_melt$wt_count >= 3 & pG_mbr_melt$wt == TRUE ] <- TRUE
table(pG_mbr_melt$Keep) # TRUE = 649725 = 68.8% &&& FALSE = 294147

pG_mbr_melt$log2Imputed1_Keep <- pG_mbr_melt$log2Imputed1
pG_mbr_melt$log2Imputed1_Keep[pG_mbr_melt$Keep == FALSE] <- NA
sum(is.na(pG_mbr_melt$log2Measured)) # 325049
sum(is.na(pG_mbr_melt$log2Normalized)) # 325057
sum(is.na(pG_mbr_melt$log2Imputed1)) # 146272
sum(is.na(pG_mbr_melt$log2Imputed1_Keep)) # 294147
saveRDS(pG_mbr_melt,file.path(out_dir, paste0("5_5_3_", Sys.Date(), "_pG_mbr_meltALL_imputed_Keep.rds")))

pG_mbr_melt <- pG_mbr_melt[,c(3,5,18)]
intensity_matrix <- dcast(pG_mbr_melt, ProteinIDs ~ ReplicateID)
rownames(intensity_matrix) <- intensity_matrix$ProteinIDs
intensity_matrix <- intensity_matrix[,-1]
saveRDS(intensity_matrix,file.path(out_dir, paste0("5_5_3_", Sys.Date(), "_bpcaImputed_3rep_df.rds")))
rm(intensity_matrix)
rm(pG_mbr_melt)
# double checked: all measured values are kept #
# dim(pG_mbr_melt[!is.na(pG_mbr_melt$log2Normalized) & is.na(pG_mbr_melt$log2Imputed1_Keep),])
# 5.5.3.1 # check if filtered for wt coun how many pG/ko replicate ##########################################
myfile <- list.files(path=out_dir, pattern = "bpcaImputed_3rep")
df <- readRDS(file.path(out_dir, myfile))

wt_col <- grep("wt", names(df))
jnk <- rowSums(!is.na(df[,wt_col]))
jnk2 <- as.data.frame(table(jnk))

p1 <- ggplot(jnk2, aes(x=as.factor(jnk), Freq)) +
  geom_bar(stat="identity") +
  geom_text(aes(label=Freq), position=position_dodge(width=0.9), vjust=-0.25, size=6)+
  xlab("WT number of measured") +
  ylab("Number of proteins")

df_wt8 <- df[jnk==8,]

repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
experiments <- unique(repInt_decode$Systemic.ID)
experiments <- experiments[-grep("wt", experiments)]
experiments <- experiments[!is.na(experiments)]
rm(repInt_decode)

my_df <- data.frame(Strain=experiments, Original_4=NA, Original_2=NA, Original_1=NA, Original_0=NA,
                    WT8_4=NA, WT8_2=NA, WT8_1=NA, WT8_0=NA)


for (i in 1:dim(my_df)[1]) {
  print(i)
  myexp <- my_df$Strain[i]
  df_jnk <- df[,grep(myexp, names(df))]
  df_wt8_jnk <- df_wt8[,grep(myexp, names(df_wt8))]
  jnk <- as.data.frame(table(rowSums(!is.na(df_jnk))))
  my_df$Original_4[i] <- jnk$Freq[jnk$Var1 == 4]
  my_df$Original_2[i] <- jnk$Freq[jnk$Var1 == 2]
  my_df$Original_1[i] <- jnk$Freq[jnk$Var1 == 1]
  my_df$Original_0[i] <- jnk$Freq[jnk$Var1 == 0]
  jnk <- as.data.frame(table(rowSums(!is.na(df_wt8_jnk))))
  my_df$WT8_4[i] <- jnk$Freq[jnk$Var1 == 4]
  my_df$WT8_2[i] <- jnk$Freq[jnk$Var1 == 2]
  my_df$WT8_1[i] <- jnk$Freq[jnk$Var1 == 1]
  my_df$WT8_0[i] <- jnk$Freq[jnk$Var1 == 0]
}

my_df$Difference_4 <- my_df$Original_4 - my_df$WT8_4
my_df$Difference_2 <- my_df$Original_2 - my_df$WT8_2
my_df$Difference_1 <- my_df$Original_1 - my_df$WT8_1
my_df$Difference_0 <- my_df$Original_0 - my_df$WT8_0


my_df_melt <- melt(my_df, id="Strain")
my_df_melt$RefDF <- gsub("(.*)\\_[0-9]", "\\1", my_df_melt$variable)
my_df_melt$Count <- gsub("(.*)\\_([0-9])", "\\2", my_df_melt$variable)

p2 <- ggplot(my_df_melt, aes(as.factor(Count), value)) +
  geom_boxplot()+
  facet_grid(RefDF ~ ., scales="free")+
  xlab("Count ko") +
  ylab("Number of proteins")

wt_col <- grep("wt", names(df))
jnk <- rowSums(!is.na(df[,wt_col]))
df_wt2 <- df[jnk==2,]

my_df2 <- data.frame(Strain=experiments,
                    WT2_4=NA, WT2_2=NA, WT2_1=NA, WT2_0=NA)


for (i in 1:dim(my_df2)[1]) {
  print(i)
  myexp <- my_df2$Strain[i]
  df_WT2_jnk <- df_wt2[,grep(myexp, names(df_wt2))]
  jnk <- as.data.frame(table(rowSums(!is.na(df_WT2_jnk))))
  my_df2$WT2_4[i] <- jnk$Freq[jnk$Var1 == 4]
  my_df2$WT2_2[i] <- jnk$Freq[jnk$Var1 == 2]
  my_df2$WT2_1[i] <- jnk$Freq[jnk$Var1 == 1]
  my_df2$WT2_0[i] <- jnk$Freq[jnk$Var1 == 0]
}



my_df2_melt <- melt(my_df2, id="Strain")
my_df2_melt$RefDF <- gsub("(.*)\\_[0-9]", "\\1", my_df2_melt$variable)
my_df2_melt$Count <- gsub("(.*)\\_([0-9])", "\\2", my_df2_melt$variable)

p3 <- ggplot(my_df2_melt, aes(as.factor(Count), value)) +
  geom_boxplot()+
  xlab("Count ko") +
  ylab("Number of proteins")+
  ggtitle("WT=2")

pdf(file.path(out_dir, paste0("5_5_3_1_", Sys.Date(), "_imputation_plots.pdf")), width = 10, height = 8)
print(p1)
print(p2)
print(p3)
dev.off()



# 5.5.4 # check for the counts again ##########################################################################
myfile <- list.files(path=out_dir, pattern = "pG_mbr_meltALL_imputed_Keep.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))

pG_mbr_melt <- subset(pG_mbr_melt, SystemicIDko != "wt1" & SystemicIDko != "wt2")

pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs) %>%
  dplyr::mutate(ProteinIDs_imputed_count_keep=sum(!is.na(log2Imputed1_Keep))) %>%
  as.data.frame()

pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs, SystemicIDko) %>%
  dplyr::mutate(Replicate_imputed_count_keep=sum(!is.na(log2Imputed1_Keep))) %>%
  as.data.frame()


df_variables <- as.data.frame(table(pG_mbr_melt[,c(6,7,12,20)]))
df_variables <- subset(df_variables, Freq !=0)
df_variables$Type <- paste(df_variables$IdentificationType, df_variables$Quantified, sep="_")
df_variables$Type <- gsub("By ", "", df_variables$Type)
df_variables$Type <- gsub("matching_FALSE", "matching", df_variables$Type)
df_variables$Type <- gsub("NotIdentified_FALSE", "NotIdentified", df_variables$Type)
df_variables$Type2 <- df_variables$Type

df_variables$Type<- factor(df_variables$Type, levels = c("MS/MS_TRUE", "MS/MS_FALSE", "matching", "NotIdentified"))

df_variables$Freq2 <- round(df_variables$Freq*100/sum(df_variables$Freq),1)


p1 <- ggplot(df_variables, aes(x=Replicate_measured_count, y=Replicate_imputed_count_keep)) + 
  geom_point(aes(color=Type2), size=10) +
  geom_text(aes(label=Freq2),size = 3) +
  facet_grid(.~Type)
  

pG_mbr_melt$Type <- paste(pG_mbr_melt$IdentificationType, pG_mbr_melt$Quantified, sep="_")
pG_mbr_melt$Type <- gsub("By ", "", pG_mbr_melt$Type)
pG_mbr_melt$Type <- gsub("matching_FALSE", "matching", pG_mbr_melt$Type)
pG_mbr_melt$Type <- gsub("NotIdentified_FALSE", "NotIdentified", pG_mbr_melt$Type)


p2 <- ggplot(pG_mbr_melt, aes(x=Replicate_measured_count, y=Replicate_imputed_count_keep)) + 
  geom_jitter(stat = "identity", aes(color = Type), alpha=0.6) 


p3 <- ggplot(df_variables, aes(x=Type, y=Freq2, fill=Replicate_measured_count, color=Replicate_imputed_count_keep))+
  geom_bar(stat = "identity", size=1) +
  #  geom_text(aes(label=Freq2),size = 3, position = position_stack(vjust = 0.5), color="black") +
  xlab(NULL) +
  ylab("Percentage") +
  theme(axis.text=element_text(size=12),
        axis.title=element_text(size=14))+
  scale_color_manual(values=c("#d9d9d9","#bdbdbd", "#969696", "#737373", "#252525"))

df_variables2 <- df_variables[,c(2,1,3,4,5,8)]
df_variables2 <- df_variables2[order(df_variables2$Replicate_measured_count, decreasing = TRUE),] 

library(gridExtra)
pdf(file.path(out_dir, paste0("5_5_4_1", Sys.Date(), "_imputation_plots.pdf")), width = 10, height = 8)
grid.table(df_variables2)
print(p3)
print(p1)
print(p2)
dev.off()

pdf(file.path(out_dir, paste0("5_5_4_2", Sys.Date(), "_imputation_plots.pdf")), width = 10, height = 8)
grid.table(df_variables2)
print(p3)
print(p1)
dev.off()

pdf(file.path(out_dir, paste0("5_5_4_3", Sys.Date(), "_imputation_plots.pdf")), width = 10, height = 8)
print(p2)
dev.off()
rm(p1)
rm(p2)
rm(p3)
rm(df_variables)
rm(df_variables2)
rm(pG_mbr_melt)
# 5.5.4.2 #  on the side _ counts number of replicates per comparison #######################################################################################################
myfile <- list.files(path=out_dir, pattern = "pG_mbr_meltALL_imputed_Keep.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))

pG_mbr_melt$wt_count[pG_mbr_melt$wt == FALSE] <- NA
# pG_mbr_melt$Replicate_measured_count[pG_mbr_melt$wt == TRUE] <- NA
pG_mbr_melt <-  pG_mbr_melt %>%
  group_by(ProteinIDs, SystemicIDko) %>%
  dplyr::mutate(Replicate_imputed_keep_count=sum(!is.na(log2Imputed1_Keep))) %>%
  as.data.frame()

pG_mbr_melt <- pG_mbr_melt %>%
  group_by(wt, ProteinIDs) %>%
  dplyr::mutate(wt_count_keep=sum(!is.na(log2Imputed1_Keep))) %>%
  as.data.frame()

pG_mbr_melt$wt_count_keep[pG_mbr_melt$wt == FALSE] <- NA

jnk <- as.data.frame(table(pG_mbr_melt[,c(12,16)]))
jnk <- jnk[jnk$Freq>0,]
jnk$Freq2 <- round(100*jnk$Freq/sum(jnk$Freq),1)
# jnk$Replicate_measured_count <- as.numeric(jnk$Replicate_measured_count)-1
# jnk$wt_count <- as.numeric(jnk$wt_count)-1
# 
# jnk2 <- subset(jnk, Replicate_measured_count < 2 | wt_count < 2)
# sum(jnk2$Freq2)  
# 
# sum(jnk$Freq2[jnk$Replicate_measured_count < 2 | jnk$wt_count < 2])
# 
# jnk$group <- jnk$Replicate_measured_count<2 | jnk$wt_count < 2

p1 <- ggplot(jnk, aes(wt_count, Replicate_measured_count)) +
  geom_point(aes(size=Freq)) +
  geom_text(aes(label=Freq),size = 4, nudge_y = 0.15) +
  geom_text(aes(label=Freq2),size = 4, nudge_y = -0.15) +
  ggtitle("Most data points are in 8wt and 29.5% less than 2 replicates")

jnk <- as.data.frame(table(pG_mbr_melt[,c(19,20)]))
jnk <- jnk[jnk$Freq>0,]
jnk$Freq2 <- round(100*jnk$Freq/sum(jnk$Freq),1)
#jnk$Replicate_imputed_keep_count <- as.numeric(jnk$Replicate_imputed_keep_count)-1
#jnk$wt_count_keep <- as.numeric(jnk$wt_count_keep)-1

# jnk2 <- subset(jnk, Replicate_imputed_keep_count < 2 | wt_count_keep < 2)
# sum(jnk2$Freq2)  
# 
# sum(jnk$Freq2[jnk$Replicate_imputed_keep_count < 2 | jnk$wt_count_keep < 2])
# 
# jnk$group <- jnk$Replicate_imputed_keep_count<2 | jnk$wt_count_keep < 2

p2 <- ggplot(jnk, aes(wt_count_keep, Replicate_imputed_keep_count)) +
  geom_point(aes(size=Freq)) +
  geom_text(aes(label=Freq),size = 4, nudge_y = 0.15) +
  geom_text(aes(label=Freq2),size = 4, nudge_y = -0.15) +
  ggtitle("Most data points are in 8wt and 20% less than 2 replicates")


df_imp <- pG_mbr_melt[,c(3,5,18)]
df_imp <- dcast(df_imp, ProteinIDs ~ ReplicateID)
rownames(df_imp) <- df_imp$ProteinIDs
df_imp <- df_imp[,-1]

repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
experiments <- unique(repInt_decode$Systemic.ID)
experiments <- experiments[-grep("wt", experiments)]
experiments <- experiments[!is.na(experiments)]
rm(repInt_decode)
myconditions <- c(experiments, "wt")

my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
rows2keep <- unique(c(grep("^wt", my_comparisons$V1), grep("^wt", my_comparisons$V2)))
my_comparisons <- my_comparisons[rows2keep,]
my_comparisons$ComparisonSize <- NA

# my_comparisons$ValueCount_ko_0 <- NA
# my_comparisons$ValueCount_ko_1 <- NA
# my_comparisons$ValueCount_ko_2 <- NA
# my_comparisons$ValueCount_ko_3 <- NA
# my_comparisons$ValueCount_ko_4 <- NA
# 
# my_comparisons$ValueCount_wt_0 <- NA
# my_comparisons$ValueCount_wt_1 <- NA
# my_comparisons$ValueCount_wt_2 <- NA
# my_comparisons$ValueCount_wt_3 <- NA
# my_comparisons$ValueCount_wt_4 <- NA
# my_comparisons$ValueCount_wt_5 <- NA
# my_comparisons$ValueCount_wt_6 <- NA
# my_comparisons$ValueCount_wt_7 <- NA
# my_comparisons$ValueCount_wt_8 <- NA

for (i in 1:dim(my_comparisons)[1]) {
  print(i)
  group1 <- my_comparisons$V1[i]
  group2 <- my_comparisons$V2[i]
  
  group1Cols <- grep(group1, names(df_imp))
  group2Cols <- grep(group2, names(df_imp))
  
  df_group <- df_imp[,c(group1Cols, group2Cols)]
  df_group <- df_group[rowSums(!is.na(df_group)) != 0,]
  my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
  
  group1Cols <- grep(group1, names(df_group))
  group2Cols <- grep(group2, names(df_group))
  
  df_group$ko_count <- rowSums(!is.na(df_group[,group1Cols]))
  df_group$wt_count <- rowSums(!is.na(df_group[,group2Cols]))
  jnk <- as.data.frame(table(df_group[,13:14]))
  if(i==1){
    jnk2 <- paste("Counts_", jnk$ko_count, "_", jnk$wt_count, sep="")
    my_comparisons <- cbind(my_comparisons, as.data.frame(matrix(NA, ncol=length(jnk2), nrow = dim(my_comparisons)[1])))
    names(my_comparisons)[4:dim(my_comparisons)[2]] <- jnk2
  }
  my_comparisons[i,4:dim(my_comparisons)[2]] <- jnk$Freq
  # my_comparisons$ValueCount_ko_0[i] <- sum(rowSums(!is.na(df_group[,group1Cols]))==0)
  # my_comparisons$ValueCount_ko_1[i] <- sum(rowSums(!is.na(df_group[,group1Cols]))==1)
  # my_comparisons$ValueCount_ko_2[i] <- sum(rowSums(!is.na(df_group[,group1Cols]))==2)
  # my_comparisons$ValueCount_ko_3[i] <- sum(rowSums(!is.na(df_group[,group1Cols]))==3)
  # my_comparisons$ValueCount_ko_4[i] <- sum(rowSums(!is.na(df_group[,group1Cols]))==4)
  # 
  # my_comparisons$ValueCount_wt_0[i] <- sum(rowSums(!is.na(df_group[,group2Cols]))==0)
  # my_comparisons$ValueCount_wt_1[i] <- sum(rowSums(!is.na(df_group[,group2Cols]))==1)
  # my_comparisons$ValueCount_wt_2[i] <- sum(rowSums(!is.na(df_group[,group2Cols]))==2)
  # my_comparisons$ValueCount_wt_3[i] <- sum(rowSums(!is.na(df_group[,group2Cols]))==3)
  # my_comparisons$ValueCount_wt_4[i] <- sum(rowSums(!is.na(df_group[,group2Cols]))==4)
  # my_comparisons$ValueCount_wt_5[i] <- sum(rowSums(!is.na(df_group[,group2Cols]))==5)
  # my_comparisons$ValueCount_wt_6[i] <- sum(rowSums(!is.na(df_group[,group2Cols]))==6)
  # my_comparisons$ValueCount_wt_7[i] <- sum(rowSums(!is.na(df_group[,group2Cols]))==7)
  # my_comparisons$ValueCount_wt_8[i] <- sum(rowSums(!is.na(df_group[,group2Cols]))==8)
  
}
my_comparisons_melt <- melt(my_comparisons, id=c("V1", "V2", "ComparisonSize"))
my_comparisons_melt$valuePercentage <- round(100 * my_comparisons_melt$value / my_comparisons_melt$ComparisonSize,1)
my_comparisons_melt$Count_ko <- gsub("Counts\\_([0-9]*)\\_[0-9]*", "\\1", my_comparisons_melt$variable)
my_comparisons_melt$Count_wt <- gsub("Counts\\_([0-9]*)\\_([0-9]*)", "\\2", my_comparisons_melt$variable)

my_comparisons_melt2 <- subset(my_comparisons_melt, Count_ko > 1)


p3 <- ggplot(my_comparisons_melt, aes(Count_ko, value))+
  geom_boxplot(aes(color=Count_wt)) +
  #  facet_grid(Count_wt ~ .,  scales = "free", drop=TRUE) +
  ylab("Number of proteins") +
  scale_y_continuous(breaks = c(0,50,100,1400)) +
  ggtitle("After imputation, 65% of pG values in 4 replicates")

my_comparisons_melt2 <- my_comparisons_melt2 %>%
  group_by(V1) %>%
  dplyr::mutate(ComparisonSize2=sum(value)) %>%
  as.data.frame()
my_comparisons_melt2$valuePercentage2 <- round(100 * my_comparisons_melt2$value / my_comparisons_melt2$ComparisonSize2,1)

p4 <- ggplot(my_comparisons_melt2, aes(Count_ko, value))+
  geom_boxplot(aes(color=Count_wt)) +
  #  facet_grid(Count_wt ~ .,  scales = "free", drop=TRUE) +
  ylab("Number of proteins") +
  scale_y_continuous(breaks = c(0,50,100,1400))

p5 <- ggplot(my_comparisons_melt2, aes(Count_ko, valuePercentage2))+
  geom_boxplot(aes(color=Count_wt)) +
  #  facet_grid(Count_wt ~ .,  scales = "free", drop=TRUE) +
  ylab("Percentage") +
  scale_y_continuous(breaks = c(0,2,5,80))


saveRDS(my_comparisons_melt2, file.path(out_dir, paste0("5_5_4_2_", Sys.Date(), "_myComparisons_counts.rds")))
pdf(file.path(out_dir, paste0("5_5_4_2_", Sys.Date(), "_countPlots_comparisonSize.pdf")))
print(p1)
print(p2)
print(p3)
print(p4)
print(p5)
dev.off()
rm(df_group)
rm(df_imp)
rm(jnk)
rm(jnk2)
rm(my_comparisons)
rm(my_comparisons_melt)
rm(my_comparisons_melt2)
rm(my_comparisons_melt_melt)
rm(p1)
rm(p2)
rm(p3)
rm(p4)
rm(p5)
rm(pG_mbr_melt)
################################################################################################
}
if(decideCutOffPvalue){
# 5.5.5 # diffreg criteria after imputation ########################
myfile <- list.files(path=out_dir, pattern = "pG_mbr_meltALL_imputed_Keep.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))

pG_mbr_melt$wt_count[pG_mbr_melt$wt == FALSE] <- NA
# pG_mbr_melt$Replicate_measured_count[pG_mbr_melt$wt == TRUE] <- NA

pG_mbr_melt2 <- pG_mbr_melt[,c(3,4,18)]

pG_mbr_melt2$SystemicIDko[grep("wt", pG_mbr_melt2$SystemicIDko)] <- "wt"

pG_mbr_melt2 <- pG_mbr_melt2 %>%
  group_by(ProteinIDs, SystemicIDko) %>%
  dplyr::mutate(Count_ = sum(!is.na(log2Imputed1_Keep))) %>%
  as.data.frame()

pG_mbr_melt2$Category <- pG_mbr_melt2$SystemicIDko
pG_mbr_melt2$Category[pG_mbr_melt2$Category != "wt"] <- "ko"

pG_mbr_melt3 <- unique(pG_mbr_melt2[,c(1,2,4)])

pG_mbr_melt3 <- dcast(pG_mbr_melt3, ProteinIDs ~ SystemicIDko)
pG_mbr_melt4 <- melt(pG_mbr_melt3, id=c("ProteinIDs", "wt"))
names(pG_mbr_melt4)[4] <- "ko"

jnk <- as.data.frame(table(pG_mbr_melt4[,c(2,4)]))
jnk <- jnk[jnk$Freq>0,]
jnk$Freq2 <- round(100*(jnk$Freq/sum(jnk$Freq)),1)
p1 <- ggplot(jnk, aes(wt, ko)) +
  geom_point(aes(size=Freq)) +
  geom_text(aes(label=Freq), vjust = 0, nudge_y = 0.1) +
  geom_text(aes(label=Freq2), vjust = 0, nudge_y = -0.1)

ggsave(file.path(out_dir, paste0("5_5_5_", Sys.Date(),"_counts.pdf")), p1)

df_imp <- pG_mbr_melt[,c(3,5,18)]
df_imp <- dcast(df_imp, ProteinIDs ~ ReplicateID)
rownames(df_imp) <- df_imp$ProteinIDs
df_imp <- df_imp[,-1]

repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
# 5.5.5.1 # 4 vs 4 wt1, wt2 ########################
myfile <- list.files(path=out_dir, pattern = "pG_mbr_meltALL_imputed_Keep.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))
df_imp <- pG_mbr_melt[,c(3,5,18)]
df_imp <- dcast(df_imp, ProteinIDs ~ ReplicateID)
rownames(df_imp) <- df_imp$ProteinIDs
df_imp <- df_imp[,-1]

repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))

experiments <- unique(repInt_decode$Systemic.ID)
#experiments <- experiments[-grep("wt", experiments)]
experiments <- experiments[!is.na(experiments)]
# rm(repInt_decode)
myconditions <- experiments

my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
rows2keep <- unique(c(grep("^wt", my_comparisons$V1), grep("^wt", my_comparisons$V2)))
my_comparisons <- my_comparisons[rows2keep,]
#my_comparisons <- rbind(my_comparisons, c("wt1", "wt2"))
rm(pG_mbr_melt)
my_comparisons$ComparisonSize <- NA

library(combinat)
jnk <- permn(c(1,1,2,2))
jnk2 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
jnk2 <- unique(jnk2)
rm(jnk)

myPvalueCutOFF <- seq(0,0.05,0.005)
myFCCutOFF <- seq(0,1,0.05)
my_P_FC <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
# my_P_FC <- as.data.frame(subset(my_P_FC, group1 != group2))
my_P_FC2 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))

my_P_FC$group <- "Original"
my_P_FC2$group <- "Shuffle_FDR"
my_P_FC <- as.data.frame(rbind(my_P_FC2, my_P_FC))
rm(my_P_FC2)
names(my_P_FC)[1] <- "myFCCutOFF"
names(my_P_FC)[2] <- "myPvalueCutOFF"

my_P_FC$col2add <- paste("myFCCutOFF", my_P_FC$myFCCutOFF ,"myPvalueCutOFF", my_P_FC$myPvalueCutOFF, my_P_FC$group, sep="_")

new_jnk <- as.data.frame(matrix(NA, nrow = dim(my_comparisons)[1], ncol = dim(my_P_FC)[1]))
names(new_jnk) <- my_P_FC$col2add

my_comparisons <- as.data.frame(cbind(my_comparisons, new_jnk))
rm(new_jnk)
rm(my_P_FC)
# i.e. SPBPB10D8.06c=86 180
for (i in 1:dim(my_comparisons)[1]) {
  print(i)
  group1 <- my_comparisons$V1[i]
  group2 <- my_comparisons$V2[i]
  
  group1Cols <- grep(group1, names(df_imp))
  group2Cols <- grep(group2, names(df_imp))
  
  df_group <- df_imp[,c(group1Cols, group2Cols)]
  df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
  my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
  
  for (j in myPvalueCutOFF) {
    for (k in myFCCutOFF) {
      # original 
      group1Cols <- grep(group1, names(df_group))
      group2Cols <- grep(group2, names(df_group))
      
      myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
      myPvalue <- myPvalue[,c(6,13)]
      myPvalue$mean.diff <- abs(myPvalue$mean.diff)
      
      myPvalue_dim_original <- dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1]
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Original", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- myPvalue_dim_original
      
      # shuffle 
      shuffled_values <- NULL
      for (groups2compare1 in 1:dim(jnk2)[1]) {
        for (groups2compare2 in 1:dim(jnk2)[1]) {
          mygrouping <- data.frame(mycolname=names(df_group), 
                                   mygroup=c(t(jnk2[groups2compare1,]), t(jnk2[groups2compare2,])))
          
          group1Cols <- grep("1", mygrouping$mygroup)
          group2Cols <- grep("2", mygrouping$mygroup)
          
          myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
          myPvalue <- myPvalue[,c(6,13)]
          myPvalue$mean.diff <- abs(myPvalue$mean.diff)
          shuffled_values <- c(shuffled_values, dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1])
          }
      }
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Shuffle_FDR", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- round(100*mean(shuffled_values)/(1+myPvalue_dim_original),0)
      }
  }
}

saveRDS(my_comparisons, file.path(out_dir, paste0("5_5_5_1_", Sys.Date(), "_myComparisons_permuted.rds")))
# 5.5.5.2 # 4ko vs 8wt = 2+4 ########################
myfile <- list.files(path=out_dir, pattern = "pG_mbr_meltALL_imputed_Keep.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))
df_imp <- pG_mbr_melt[,c(3,5,18)]
df_imp <- dcast(df_imp, ProteinIDs ~ ReplicateID)
rownames(df_imp) <- df_imp$ProteinIDs
df_imp <- df_imp[,-1]

repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
experiments <- unique(repInt_decode$Systemic.ID)
experiments <- experiments[-grep("wt", experiments)]
experiments <- experiments[!is.na(experiments)]
# rm(repInt_decode)
myconditions <- c(experiments,"wt")

my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
rows2keep <- unique(c(grep("^wt", my_comparisons$V1), grep("^wt", my_comparisons$V2)))
my_comparisons <- my_comparisons[rows2keep,]
#my_comparisons <- rbind(my_comparisons, c("wt1", "wt2"))
rm(pG_mbr_melt)
my_comparisons$ComparisonSize <- NA

library(combinat)
jnk <- permn(c(1,1,2,2))
jnk2 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
jnk2 <- unique(jnk2)
jnk <- permn(c(1,1,1,1,2,2,2,2))
jnk3 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
jnk3 <- unique(jnk3)
rm(jnk)

myPvalueCutOFF <- seq(0,0.05,0.005)
myFCCutOFF <- seq(0,1,0.05)
my_P_FC <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
# my_P_FC <- as.data.frame(subset(my_P_FC, group1 != group2))
my_P_FC2 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))

my_P_FC$group <- "Original"
my_P_FC2$group <- "Shuffle_FDR"
my_P_FC <- as.data.frame(rbind(my_P_FC2, my_P_FC))
rm(my_P_FC2)
names(my_P_FC)[1] <- "myFCCutOFF"
names(my_P_FC)[2] <- "myPvalueCutOFF"

my_P_FC$col2add <- paste("myFCCutOFF", my_P_FC$myFCCutOFF ,"myPvalueCutOFF", my_P_FC$myPvalueCutOFF, my_P_FC$group, sep="_")

new_jnk <- as.data.frame(matrix(NA, nrow = dim(my_comparisons)[1], ncol = dim(my_P_FC)[1]))
names(new_jnk) <- my_P_FC$col2add

my_comparisons <- as.data.frame(cbind(my_comparisons, new_jnk))
rm(new_jnk)
rm(my_P_FC)
my_comparisons <- list.files(path=out_dir, pattern="5_5_5_2_2019-05-25")
my_comparisons <- readRDS(file.path(out_dir, my_comparisons))
for (i in 76:dim(my_comparisons)[1]) {
  print(i)
  group1 <- my_comparisons$V1[i]
  group2 <- my_comparisons$V2[i]
  
  group1Cols <- grep(group1, names(df_imp))
  group2Cols <- grep(group2, names(df_imp))
  
  df_group <- df_imp[,c(group1Cols, group2Cols)]
  df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
  my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
  
  for (j in myPvalueCutOFF) {
    for (k in myFCCutOFF) {
      # original 
      group1Cols <- grep(group1, names(df_group))
      group2Cols <- grep(group2, names(df_group))
      
      myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
      myPvalue <- myPvalue[,c(6,13)]
      myPvalue$mean.diff <- abs(myPvalue$mean.diff)
      
      myPvalue_dim_original <- dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1]
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Original", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- myPvalue_dim_original
      
      # shuffle 
      shuffled_values <- NULL
      for (groups2compare1 in 1:dim(jnk2)[1]) {
        for (groups2compare2 in 1:dim(jnk3)[1]) {
          mygrouping <- data.frame(mycolname=names(df_group), 
                                   mygroup=c(t(jnk2[groups2compare1,]), t(jnk3[groups2compare2,])))
          
          group1Cols <- grep("1", mygrouping$mygroup)
          group2Cols <- grep("2", mygrouping$mygroup)
          
          myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
          myPvalue <- myPvalue[,c(6,13)]
          myPvalue$mean.diff <- abs(myPvalue$mean.diff)
          shuffled_values <- c(shuffled_values, dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1])
        }
      }
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Shuffle_FDR", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- round(100*mean(shuffled_values)/(1+myPvalue_dim_original),0)
    }
  }
  saveRDS(my_comparisons, file.path(out_dir, paste0("5_5_5_2_", Sys.Date(), "_myComparisons_permuted.rds")))
}
saveRDS(my_comparisons, file.path(out_dir, paste0("5_5_5_2_", Sys.Date(), "_myComparisons_permuted.rds")))


# dont # 5.5.5.3 # 4ko vs 4/8wt = 2+2 ########################
# myfile <- list.files(path=out_dir, pattern = "pG_mbr_meltALL_imputed_Keep.rds")
# pG_mbr_melt <- readRDS(file.path(out_dir, myfile))
# df_imp <- pG_mbr_melt[,c(3,5,18)]
# df_imp <- dcast(df_imp, ProteinIDs ~ ReplicateID)
# rownames(df_imp) <- df_imp$ProteinIDs
# df_imp <- df_imp[,-1]
# 
# repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
# experiments <- unique(repInt_decode$Systemic.ID)
# experiments <- experiments[-grep("wt", experiments)]
# experiments <- experiments[!is.na(experiments)]
# # rm(repInt_decode)
# myconditions <- c(experiments,"wt")
# 
# my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
# rows2keep <- unique(c(grep("^wt", my_comparisons$V1), grep("^wt", my_comparisons$V2)))
# my_comparisons <- my_comparisons[rows2keep,]
# #my_comparisons <- rbind(my_comparisons, c("wt1", "wt2"))
# rm(pG_mbr_melt)
# my_comparisons$ComparisonSize <- NA
# 
# library(combinat)
# jnk <- permn(c(1,1,2,2))
# jnk2 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
# jnk2 <- unique(jnk2)
# jnk <- permn(c(1,1,1,1,2,2,2,2))
# jnk3 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
# jnk3 <- unique(jnk3)
# rm(jnk)
# 
# myPvalueCutOFF <- seq(0,0.05,0.005)
# myFCCutOFF <- seq(0,1,0.05)
# my_P_FC <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
# # my_P_FC <- as.data.frame(subset(my_P_FC, group1 != group2))
# my_P_FC2 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
# 
# my_P_FC$group <- "Original"
# my_P_FC2$group <- "Shuffle_FDR"
# my_P_FC <- as.data.frame(rbind(my_P_FC2, my_P_FC))
# rm(my_P_FC2)
# names(my_P_FC)[1] <- "myFCCutOFF"
# names(my_P_FC)[2] <- "myPvalueCutOFF"
# 
# my_P_FC$col2add <- paste("myFCCutOFF", my_P_FC$myFCCutOFF ,"myPvalueCutOFF", my_P_FC$myPvalueCutOFF, my_P_FC$group, sep="_")
# 
# new_jnk <- as.data.frame(matrix(NA, nrow = dim(my_comparisons)[1], ncol = dim(my_P_FC)[1]))
# names(new_jnk) <- my_P_FC$col2add
# 
# my_comparisons <- as.data.frame(cbind(my_comparisons, new_jnk))
# rm(new_jnk)
# rm(my_P_FC)
# for (i in 1:dim(my_comparisons)[1]) {
#   print(i)
#   group1 <- my_comparisons$V1[i]
#   group2 <- my_comparisons$V2[i]
#   
#   group1Cols <- grep(group1, names(df_imp))
#   group2Cols <- grep(group2, names(df_imp))
#   
#   df_group <- df_imp[,c(group1Cols, group2Cols)]
#   df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
#   my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
#   
#   for (j in myPvalueCutOFF) {
#     for (k in myFCCutOFF) {
#       # original 
#       group1Cols <- grep(group1, names(df_group))
#       group2Cols <- grep(group2, names(df_group))
#       
#       myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
#       myPvalue <- myPvalue[,c(6,13)]
#       myPvalue$mean.diff <- abs(myPvalue$mean.diff)
#       
#       myPvalue_dim_original <- dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1]
#       mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Original", sep="_")
#       my_comparisons[i,grep(mycolname, names(my_comparisons))] <- myPvalue_dim_original
#       
#       # shuffle 
#       shuffled_values <- NULL
#       for (groups2compare1 in 1:dim(jnk2)[1]) {
#         for (groups2compare2 in 1:dim(jnk3)[1]) {
#           mygrouping1 <- data.frame(mycolname=names(df_group)[group2Cols], 
#                                    mygroup=t(jnk3[groups2compare2,]))
#           cols2keep_1 <- c(grep(group1, names(df_group)), 
#                            grep(paste0(mygrouping1$mycolname[mygrouping1$X1==1], collapse = "|"), names(df_group)))
#           df_group1 <- df_group[,cols2keep_1]
#           for (groups2compare3 in 1:dim(jnk2)[1]) {
#             
#             mygrouping <- data.frame(mycolname=names(df_group1), 
#                                    mygroup=c(t(jnk2[groups2compare1,]), t(jnk2[groups2compare3,])))
#           
#             group1Cols1 <- grep("1", mygrouping$mygroup)
#             group2Cols1 <- grep("2", mygrouping$mygroup)
#           
#           myPvalue <- row_t_equalvar(df_group1[, group1Cols1], df_group1[, group2Cols1], alternative = "two.sided", mu = 0, conf.level = 0.95)
#           myPvalue <- myPvalue[,c(6,13)]
#           myPvalue$mean.diff <- abs(myPvalue$mean.diff)
#           shuffled_values <- c(shuffled_values, dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1])
#         }
#       }
#       }
#       
#       mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Shuffle_FDR", sep="_")
#       my_comparisons[i,grep(mycolname, names(my_comparisons))] <- round(100*mean(shuffled_values)/(1+myPvalue_dim_original),0)
#     }
#   }
#   saveRDS(my_comparisons, file.path(out_dir, paste0("5_5_5_3_",i, Sys.Date(), "_myComparisons_permuted.rds")))
#   
# }
# 
# 
# 5.5.6 # decide FC and pvalue based on FDR ########################
myfiles <- list.files(path=out_dir, pattern="^5_5_5_[1-9].*rds")

my_comparisons <- readRDS(file.path(out_dir, myfiles[1]))

my_comparisons$identifier <- paste(my_comparisons$V1, my_comparisons$V2,
                                   my_comparisons$ComparisonSize, sep="-")
my_comparisons <- my_comparisons[,-c(grep("V1|V2|ComparisonSize", names(my_comparisons)))]

my_comparisons1 <- my_comparisons[,c(grep("identifier", names(my_comparisons)),
                                     grep("Original", names(my_comparisons)))]
my_comparisons2 <- my_comparisons[,c(grep("identifier", names(my_comparisons)),
                                     grep("Shuffle", names(my_comparisons)))]
# number of proteins changing #
my_comparisons1 <- melt(my_comparisons1, id.vars="identifier")
my_comparisons1$FoldChange <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_.*", "\\1", my_comparisons1$variable)
my_comparisons1$Pvalue <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_(.*)\\_.*", "\\2", my_comparisons1$variable)
my_comparisons1$pfc <- paste(my_comparisons1$Pvalue, my_comparisons1$FoldChange)

my_comparisons1$WT <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\1", my_comparisons1$identifier)
my_comparisons1$Strain <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\2", my_comparisons1$identifier)

my_comparisons1 <- my_comparisons1 %>%
  group_by(pfc) %>%
  dplyr::mutate(pfc_fdr = quantile(value, 0.5)[1]) %>%
  as.data.frame()

my_comparisons1_1 <- unique(my_comparisons1[,c(4,5,6,9)])
names(my_comparisons1_1)[4] <- "NumberChanging" 
ggplot(my_comparisons1_1, aes(FoldChange, NumberChanging))+
  geom_point(aes(color=Pvalue)) 
# percentage FDR #
my_comparisons2 <- melt(my_comparisons2, id.vars="identifier")
my_comparisons2$FoldChange <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_.*", "\\1", my_comparisons2$variable)
my_comparisons2$Pvalue <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_(.*)\\_.*\\_.*", "\\2", my_comparisons2$variable)
my_comparisons2$pfc <- paste(my_comparisons2$Pvalue, my_comparisons2$FoldChange)

my_comparisons2$WT <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\1", my_comparisons2$identifier)
my_comparisons2$Strain <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\2", my_comparisons2$identifier)

my_comparisons2 <- my_comparisons2 %>%
  group_by(pfc) %>%
  dplyr::mutate(pfc_fdr = quantile(value, 0.5)[1]) %>%
  as.data.frame()

my_comparisons3 <- unique(my_comparisons2[,c(4,5,6,9)])

ggplot(my_comparisons3, aes(FoldChange, pfc_fdr))+
  geom_point(aes(color=Pvalue)) +
  #facet_grid(FoldChange ~., scales = "free")+
  ylim(0,100)

my_comparisons_4_4 <- merge(my_comparisons1_1, my_comparisons3, by.x="pfc", by.y="pfc")
my_comparisons_4_4 <- my_comparisons_4_4[,c(1:4, 7)]

ggplot(my_comparisons_4_4, aes(FoldChange.x, pfc_fdr))+
  geom_point(aes(color=Pvalue.x)) +
  geom_point(aes(y=NumberChanging, color=Pvalue.x), shape=12)
  

# for the 4 vs 8 ##
my_comparisons <- readRDS(file.path(out_dir, myfiles[2]))

my_comparisons$identifier <- paste(my_comparisons$V1, my_comparisons$V2,
                                   my_comparisons$ComparisonSize, sep="-")
my_comparisons <- my_comparisons[,-c(grep("V1|V2|ComparisonSize", names(my_comparisons)))]

my_comparisons1 <- my_comparisons[,c(grep("identifier", names(my_comparisons)),
                                     grep("Original", names(my_comparisons)))]
my_comparisons2 <- my_comparisons[,c(grep("identifier", names(my_comparisons)),
                                     grep("Shuffle", names(my_comparisons)))]
# number of proteins changing #
my_comparisons1 <- melt(my_comparisons1, id.vars="identifier")
my_comparisons1$FoldChange <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_.*", "\\1", my_comparisons1$variable)
my_comparisons1$Pvalue <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_(.*)\\_.*", "\\2", my_comparisons1$variable)
my_comparisons1$pfc <- paste(my_comparisons1$Pvalue, my_comparisons1$FoldChange)

my_comparisons1$WT <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\1", my_comparisons1$identifier)
my_comparisons1$Strain <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\2", my_comparisons1$identifier)

my_comparisons1 <- my_comparisons1 %>%
  group_by(pfc) %>%
  dplyr::mutate(pfc_fdr = quantile(value, 0.5)[1]) %>%
  as.data.frame()

my_comparisons1_1 <- unique(my_comparisons1[,c(4,5,6,9)])
names(my_comparisons1_1)[4] <- "NumberChanging" 
ggplot(my_comparisons1_1, aes(FoldChange, NumberChanging))+
  geom_point(aes(color=Pvalue)) 
# percentage FDR ##
my_comparisons2 <- melt(my_comparisons2, id.vars="identifier")
my_comparisons2$FoldChange <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_.*", "\\1", my_comparisons2$variable)
my_comparisons2$Pvalue <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_(.*)\\_.*\\_.*", "\\2", my_comparisons2$variable)
my_comparisons2$pfc <- paste(my_comparisons2$Pvalue, my_comparisons2$FoldChange)

my_comparisons2$WT <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\1", my_comparisons2$identifier)
my_comparisons2$Strain <- gsub("(wt[0-9]*)\\-(.*)\\-[0-9]*", "\\2", my_comparisons2$identifier)

my_comparisons2 <- my_comparisons2 %>%
  group_by(pfc) %>%
  dplyr::mutate(pfc_fdr = quantile(value, 0.5)[1]) %>%
  as.data.frame()

my_comparisons3 <- unique(my_comparisons2[,c(4,5,6,9)])

ggplot(my_comparisons3, aes(FoldChange, pfc_fdr))+
  geom_point(aes(color=Pvalue)) +
  #facet_grid(FoldChange ~., scales = "free")+
  ylim(0,100)

my_comparisons_4_8 <- merge(my_comparisons1_1, my_comparisons3, by.x="pfc", by.y="pfc")
my_comparisons_4_8 <- my_comparisons_4_8[,c(1:4, 7)]

ggplot(my_comparisons_4_8, aes(FoldChange.x, pfc_fdr))+
  geom_point(aes(color=Pvalue.x)) +
  geom_point(aes(y=NumberChanging, color=Pvalue.x), shape=12)

names(my_comparisons_4_4)[2] <- "FC"
names(my_comparisons_4_4)[3] <- "p"
names(my_comparisons_4_4)[4] <- "Changing_4_4" 
names(my_comparisons_4_4)[5] <- "FDR_4_4" 
names(my_comparisons_4_8)[4] <- "Changing_4_8" 
names(my_comparisons_4_8)[5] <- "FDR_4_8" 

my_comparisons_4_8 <- my_comparisons_4_8[,c(1,4,5)]
my_comparisons <- merge(my_comparisons_4_4, my_comparisons_4_8,
                        by.x="pfc", by.y="pfc")
rm(my_comparisons1)
rm(my_comparisons1_1)
rm(my_comparisons2)
rm(my_comparisons3)
rm(my_comparisons_4_4)
rm(my_comparisons_4_8)

saveRDS(my_comparisons, file.path(out_dir, paste0("5_5_6_", Sys.Date(), "_FDR.rds")))
# 5.5.7 # decide FC and pvalue based on FDR - plots ########################
myfile <- list.files(path=out_dir, pattern="^5_5_6.*rds")
my_comparisons <- readRDS(file.path(out_dir, myfile))
my_comparisons$candidateCutOff <- FALSE

my_comparisons$candidateCutOff[grep(max(my_comparisons$Changing_4_8[my_comparisons$FDR_4_8<=10]),my_comparisons$Changing_4_8)] <- TRUE


my_comparisons$candidateCutOff[my_comparisons$FDR_4_8<=10]

p1 <- ggplot(my_comparisons, aes(FDR_4_4, FDR_4_8))+
  geom_point()

p2 <- ggplot(my_comparisons, aes(Changing_4_4, Changing_4_8))+
  geom_point()

p3 <- ggplot(my_comparisons, aes(FDR_4_8, Changing_4_8))+
  geom_point(aes(color=candidateCutOff, size=candidateCutOff))+
  guides(color=NULL)

p0 <- ggplot(my_comparisons, aes(FC, FDR_4_8))+
  geom_point(aes(color=p, size=candidateCutOff))

myfile <- list.files(path=out_dir, pattern="^5_5_5_2_.*rds")
my_comparisons_original <- readRDS(file.path(out_dir, myfile))


jnk <- my_comparisons[my_comparisons$candidateCutOff == TRUE,]
my_comparisons_original2 <- my_comparisons_original[,c(1:3,
                                                       grep(paste0("myFCCutOFF_", jnk$FC,
                                                                   "_myPvalueCutOFF_", jnk$p,"_"), 
                                                            names(my_comparisons_original)))]
names(my_comparisons_original2)[4] <- "FP"
names(my_comparisons_original2)[5] <- "Original"
p4 <- ggplot(my_comparisons_original2, aes(Original, 
                                           FP))+
  geom_point(aes(color=ComparisonSize), size=4)+
  xlab("Number of proteins changing") +
  ylab("False positive %") +
  guides(color=NULL) +
  geom_hline(yintercept = c(3,48.8), linetype="dashed") +
  geom_vline(xintercept = c(34,388.6), linetype="dashed")+
  geom_hline(yintercept = 10, color="darkred") +
  geom_vline(xintercept = 144.5, color="darkred")+
  geom_rug()


p5 <- ggplot(my_comparisons, aes(FC, p))+
  geom_tile(aes(fill=FDR_4_8)) +
  geom_tile(data=subset(my_comparisons, candidateCutOff == TRUE),aes(fill=FDR_4_8),color="black") +
  geom_text(aes(label=Changing_4_8))+
  scale_fill_gradient2(midpoint = 10)
  
pdf(file.path(out_dir, paste0("5_5_7_", Sys.Date(), "_FDR_pFC_0-03_0-2.pdf")), height = 8, width = 12)
print(p1)
print(p2)
print(p3)
print(p0)
print(p5)
print(p4)
dev.off()
rm(jnk)
rm(my_comparisons)
rm(my_comparisons_original)
rm(my_comparisons_original2)
rm(p0)
rm(p1)
rm(p2)
rm(p3)
rm(p4)
rm(p5)
# 20190718 # 4ko vs 8wt =2+4 but smaller intervals ####################################################
# 5.5.8 # 4ko vs 8wt = 2+4 ########################
myfile <- list.files(path=out_dir, pattern = "pG_mbr_meltALL_imputed_Keep.rds")
pG_mbr_melt <- readRDS(file.path(out_dir, myfile))
df_imp <- pG_mbr_melt[,c(3,5,18)]
df_imp <- dcast(df_imp, ProteinIDs ~ ReplicateID)
rownames(df_imp) <- df_imp$ProteinIDs
df_imp <- df_imp[,-1]

repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-24_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
experiments <- unique(repInt_decode$Systemic.ID)
experiments <- experiments[-grep("wt", experiments)]
experiments <- experiments[!is.na(experiments)]
# rm(repInt_decode)
myconditions <- c(experiments,"wt")

my_comparisons <- as.data.frame(t(combn(unique(myconditions), 2)))
rows2keep <- unique(c(grep("^wt", my_comparisons$V1), grep("^wt", my_comparisons$V2)))
my_comparisons <- my_comparisons[rows2keep,]
#my_comparisons <- rbind(my_comparisons, c("wt1", "wt2"))
rm(pG_mbr_melt)
my_comparisons$ComparisonSize <- NA

library(combinat)
jnk <- permn(c(1,1,2,2))
jnk2 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
jnk2 <- unique(jnk2)
jnk <- permn(c(1,1,1,1,2,2,2,2))
jnk3 <- data.frame(matrix(unlist(jnk), nrow=length(jnk), byrow=T),stringsAsFactors=FALSE)
jnk3 <- unique(jnk3)
rm(jnk)

myPvalueCutOFF <- seq(0,0.05,0.0001)
myFCCutOFF <- seq(0,1,0.001)
my_P_FC <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))
# my_P_FC <- as.data.frame(subset(my_P_FC, group1 != group2))
my_P_FC2 <- as.data.frame(expand.grid(myFCCutOFF, myPvalueCutOFF))

my_P_FC$group <- "Original"
my_P_FC2$group <- "Shuffle_FDR"
my_P_FC <- as.data.frame(rbind(my_P_FC2, my_P_FC))
rm(my_P_FC2)
names(my_P_FC)[1] <- "myFCCutOFF"
names(my_P_FC)[2] <- "myPvalueCutOFF"

my_P_FC$col2add <- paste("myFCCutOFF", my_P_FC$myFCCutOFF ,"myPvalueCutOFF", my_P_FC$myPvalueCutOFF, my_P_FC$group, sep="_")

new_jnk <- as.data.frame(matrix(NA, nrow = dim(my_comparisons)[1], ncol = dim(my_P_FC)[1]))
names(new_jnk) <- my_P_FC$col2add

my_comparisons <- as.data.frame(cbind(my_comparisons, new_jnk))
rm(new_jnk)
rm(my_P_FC)
for (i in 1:dim(my_comparisons)[1]) {
  print(i)
  group1 <- my_comparisons$V1[i]
  group2 <- my_comparisons$V2[i]
  
  group1Cols <- grep(group1, names(df_imp))
  group2Cols <- grep(group2, names(df_imp))
  
  df_group <- df_imp[,c(group1Cols, group2Cols)]
  df_group <- df_group[rowSums(!is.na(df_group)) == dim(df_group)[2],]
  my_comparisons$ComparisonSize[i] <- dim(df_group)[1]
  
  for (j in myPvalueCutOFF) {
    for (k in myFCCutOFF) {
      # original 
      group1Cols <- grep(group1, names(df_group))
      group2Cols <- grep(group2, names(df_group))
      
      myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
      myPvalue <- myPvalue[,c(6,13)]
      myPvalue$mean.diff <- abs(myPvalue$mean.diff)
      
      myPvalue_dim_original <- dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1]
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Original", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- myPvalue_dim_original
      
      # shuffle 
      shuffled_values <- NULL
      for (groups2compare1 in 1:dim(jnk2)[1]) {
        for (groups2compare2 in 1:dim(jnk3)[1]) {
          mygrouping <- data.frame(mycolname=names(df_group), 
                                   mygroup=c(t(jnk2[groups2compare1,]), t(jnk3[groups2compare2,])))
          
          group1Cols <- grep("1", mygrouping$mygroup)
          group2Cols <- grep("2", mygrouping$mygroup)
          
          myPvalue <- row_t_equalvar(df_group[, group1Cols], df_group[, group2Cols], alternative = "two.sided", mu = 0, conf.level = 0.95)
          myPvalue <- myPvalue[,c(6,13)]
          myPvalue$mean.diff <- abs(myPvalue$mean.diff)
          shuffled_values <- c(shuffled_values, dim(subset(myPvalue, pvalue<j & mean.diff>=k))[1])
        }
      }
      mycolname <- paste("myFCCutOFF", k ,"myPvalueCutOFF", j, "Shuffle_FDR", sep="_")
      my_comparisons[i,grep(mycolname, names(my_comparisons))] <- round(100*mean(shuffled_values)/(1+myPvalue_dim_original),0)
    }
  }
  saveRDS(my_comparisons, file.path(out_dir, paste0("5_5_8_", Sys.Date(), "_myComparisons_permuted.rds")))
}
saveRDS(my_comparisons, file.path(out_dir, paste0("5_5_8_", Sys.Date(), "_myComparisons_permuted.rds")))


}
# use FC=0.2, p=0.03 ###############################################
if(oldShuffleCheck==ignore){
# #####################
# my_comparisons <- melt(my_comparisons, id.vars=c("V1", "V2", "ComparisonSize"))
# names(my_comparisons) <- c("Group1", "Group2", "ComparisonSize", "Condition", "NumberRegulated")
# 
# my_comparisons_FPR <- melt(my_comparisons_FPR, id.vars=c("V1", "V2", "ComparisonSize"))
# my_comparisons$identifier <- paste(my_comparisons$Group1, my_comparisons$Group2)
# my_comparisons_FPR$identifier <- paste(my_comparisons_FPR$V1, my_comparisons_FPR$V2)
# my_comparisons_FPR <- my_comparisons_FPR[,5:6]
# 
# if(sum(my_comparisons$identifier == my_comparisons_FPR$identifier)==dim(my_comparisons)[1]){
# my_comparisons <- cbind(my_comparisons, my_comparisons_FPR)
# } else {print("look at 5.5.6 merge")}
# 
# my_comparisons <- my_comparisons[,c(1:5, 7)]
# names(my_comparisons)[6] <- "FalsePositiveRate"
# # my_comparisons$FalsePositiveRate <- round(my_comparisons$FalsePositiveRate,2)
# rm(my_comparisons_FPR)
# 
# my_comparisons$Belonging <- "Shuffled"
# my_comparisons$Belonging[grep("Original", my_comparisons$Condition)] <- "Original"
# my_comparisons$ComparisonType <- "WT-KO"
# my_comparisons$ComparisonType[my_comparisons$Group1=="wt1" & my_comparisons$Group2=="wt2"] <- "WT-WT"
# my_comparisons$FoldChange <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_.*", "\\1", my_comparisons$Condition)
# my_comparisons$Pvalue <- gsub("myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_(.*)\\_.*\\_.*", "\\2", my_comparisons$Condition)
# my_comparisons$pfc <- paste(my_comparisons$Pvalue, my_comparisons$FoldChange)
# 
# my_comparisons <- unique(my_comparisons)
# 
# my_comparisons <- my_comparisons %>%
#   group_by(Belonging, ComparisonType, Pvalue, FoldChange) %>%
#   dplyr::mutate(Mean_FPR=mean(FalsePositiveRate),
#                 Median_FPR=median(FalsePositiveRate),
#                 Q10_FPR=quantile(FalsePositiveRate, 0.1)[[1]],
#                 Q25_FPR=quantile(FalsePositiveRate, 0.25)[[1]],
#                 Q75_FPR=quantile(FalsePositiveRate, 0.75)[[1]],
#                 Q90_FPR=quantile(FalsePositiveRate, 0.9)[[1]],
#                 Max_FPR=max(FalsePositiveRate)) %>%
#   
#   as.data.frame()
# 
# my_comparisons$Category <- paste(my_comparisons$Belonging, my_comparisons$ComparisonType, sep="_")
# 
# saveRDS(my_comparisons, file.path(out_dir, paste0("5_5_6_0_", Sys.Date(), "_myComparisons_FPR.rds")))
# 
# ######################################################################################################################
# # 5.5.8 # decide FC and pvalue based on FDR  # plots #################################################################
# myfile <- list.files(path = out_dir, pattern = "5_5_6_")
# my_comparisons <- readRDS(file.path(out_dir, myfile))
# 
# my_comparisons_wt <- subset(my_comparisons, ComparisonType == "WT-WT")
# 
# p1 <- ggplot(my_comparisons_wt, aes(FoldChange, NumberRegulated))+
#   geom_boxplot(aes(color=Pvalue)) +
#   facet_grid(Belonging ~ Pvalue, scales="free") +
#   ggtitle("WT")
# 
# my_comparisons_wt$pfc <- paste(my_comparisons_wt$Pvalue, my_comparisons_wt$FoldChange)
# 
# ggplot(data=subset(my_comparisons_wt, Belonging == "Shuffled"), aes(FoldChange, NumberRegulated))+
#   geom_boxplot() +
#   geom_point(data=subset(my_comparisons_wt, Belonging != "Shuffled"), color="red") +
#   facet_grid(Pvalue ~ ., scales = "free", space="free") +
#   ggtitle("WT")
# 
# 
# 
# my_comparisons_ko <- subset(my_comparisons, ComparisonType == "WT-KO")
# my_comparisons_ko <- as.data.frame(my_comparisons_ko)
# 
# my_comparisons_ko$mergeID <- paste(my_comparisons_ko$Group1, my_comparisons_ko$Group2, gsub("(myFCCutOFF_.*_myPvalueCutOFF_.*)\\_.*\\_.*","\\1",my_comparisons_ko$Condition))
# 
# my_comparisons_ko1 <- as.data.frame(subset(my_comparisons_ko, Belonging == "Original"))
# my_comparisons_ko2 <- as.data.frame(subset(my_comparisons_ko, Belonging != "Original"))
# 
# my_comparisons_ko1 <- my_comparisons_ko1[,c(5,6,19)]
# my_comparisons_ko2 <- my_comparisons_ko2[,c(5,6,19)]
# names(my_comparisons_ko1) <- c("Regulated_Original", "FPR_Original", "mergeID")
# names(my_comparisons_ko2) <- c("Regulated_Shuffle", "FPR_Shuffle", "mergeID")
# 
# my_comparisons_ko3 <- merge(my_comparisons_ko1, my_comparisons_ko2, by.x="mergeID", by.y="mergeID", all=FALSE)
# rm(my_comparisons_ko1)
# rm(my_comparisons_ko2)
# my_comparisons_ko3 <- my_comparisons_ko3[,c(1,2,4)]
# my_comparisons_ko3$FPR <- round(100*(my_comparisons_ko3$Regulated_Shuffle / (1+my_comparisons_ko3$Regulated_Original)),1)
# 
# my_comparisons_ko3$FC <- gsub(".+\\ myFCCutOFF\\_(.*)\\_myPvalueCutOFF\\_.*","\\1",my_comparisons_ko3$mergeID)
# my_comparisons_ko3$Pvalue <- gsub(".+\\ myFCCutOFF_(.*)_myPvalueCutOFF_(.*)","\\2",my_comparisons_ko3$mergeID)
# 
# p2 <- ggplot(my_comparisons_ko3, aes(Regulated_Original, Regulated_Shuffle))+
#   geom_point(aes(color=FC)) 
# 
# p3 <- ggplot(my_comparisons_ko, aes(FoldChange, NumberRegulated))+
#   geom_point(aes(color=Pvalue)) +
#   facet_grid(Belonging ~.) +
#   ggtitle("WT-KO")
# 
# p4 <- ggplot(my_comparisons_ko3, aes(Regulated_Original, Regulated_Shuffle))+
#   geom_point(aes(color=FC)) +
#   facet_grid(Pvalue ~., scales = "free")
# 
# p5 <- ggplot(my_comparisons_ko3, aes(FC, FPR))+
#   geom_point(aes(color=Pvalue)) +
#   facet_grid(Pvalue ~., scales = "free") +
#   ggtitle("WT-KO")
# 
# p5 <- ggplot(my_comparisons_ko3, aes(FC, FPR))+
#   geom_hex() +
#   facet_grid(Pvalue ~., scales = "free") +
#   ggtitle("WT-KO") 
# 
# p6 <- ggplot(my_comparisons_ko3, aes(FC, FPR))+
#   geom_hex() +
#   facet_grid(Pvalue ~., scales = "free") +
#   ggtitle("WT-KO") +
#   ylim(0,100)
# ggsave(file.path(out_dir, paste0("5_5_8_6_", Sys.Date(), "_FP_FDR.png")), p6)
# 
# ggsave(file.path(out_dir, paste0("5_5_8_1_", Sys.Date(), "_FP_FDR.png")), p1)
# ggsave(file.path(out_dir, paste0("5_5_8_2_", Sys.Date(), "_FP_FDR.png")), p2)
# ggsave(file.path(out_dir, paste0("5_5_8_3_", Sys.Date(), "_FP_FDR.png")), p3)
# ggsave(file.path(out_dir, paste0("5_5_8_4_", Sys.Date(), "_FP_FDR.png")), p4)
# ggsave(file.path(out_dir, paste0("5_5_8_5_", Sys.Date(), "_FP_FDR.png")), p5)
# 
# 
# my_comparisons_ko3_FC3 <- subset(my_comparisons_ko3, FC == 0.3)
# my_comparisons_ko3_FC3_p05 <- subset(my_comparisons_ko3_FC3, Pvalue == 0.05)
# 
# 
# p3 <- ggplot(my_comparisons_ko3_FC3, aes(Regulated_Original, FPR))+
#   geom_hex()
# 
# p4 <- ggplot(my_comparisons_ko3_FC3, aes(Regulated_Original, FPR))+
#   geom_hex() +
#   ylim(0,100)
# 
# ggsave(file.path(out_dir, paste0("5_5_8_3_2_", Sys.Date(), "_FP_FDR.png")), p3)
# ggsave(file.path(out_dir, paste0("5_5_8_4_2_", Sys.Date(), "_FP_FDR.png")), p4)
# 
# ######## all the plots continue ### 20190509 ###########
# 
# 
# ggplot(my_comparisons_ko, aes(FoldChange, NumberRegulated))+
#   geom_boxplot(aes(color=Pvalue, fill=Group2)) +
#   facet_grid(Belonging ~.)
# 
# ggplot(my_comparisons, aes(Pvalue, FalsePositiveRate)) +
#   geom_boxplot() +
#   facet_grid(.~ Category)
# 
# cor(my_comparisons$FoldChange, my_comparisons$FalsePositiveRate)
# cor(my_comparisons$Pvalue, my_comparisons$FalsePositiveRate)
# 
# 
# 
# 
# 
# 
# my_comparisons_jnk <- subset(my_comparisons, Pvalue == 0.05)
# 
# ggplot(subset(my_comparisons_jnk, Belonging=="Original"), aes(FoldChange, FalsePositiveRate)) +
#   geom_point(aes(color=Belonging, size=Belonging)) +
#   facet_grid(.~ ComparisonType)
# 
# ggplot(my_comparisons_jnk, aes(FoldChange, FalsePositiveRate)) +
#   geom_point() +
#   geom_smooth(method = lm, se = FALSE) +
#   facet_grid(.~ ComparisonType)
# 
# 
# 
# 
# #########################################################################
  # library(plot3D)
  # library(rgl)
  # library(scatterplot3d)
  # 
  # scatter3D(as.numeric(my_comparisons$FC), 
  #           as.numeric(my_comparisons$p), 
  #           as.numeric(my_comparisons$FDR_4_4))
  # 
  # scatterplot3d(my_comparisons[,c(2,3,5)], pch = 16)
  # 
  # s3d <- scatterplot3d(my_comparisons[,c(2,3,5)], box=FALSE)
  # 
  # 
  # slice3D(x=as.numeric(my_comparisons$FC), 
  #          y= as.numeric(my_comparisons$p), 
  #           z=as.numeric(my_comparisons$FDR_4_4))
}

if(later){
#########################################################
# 5.5.2 # each k/o strain vs wild types and their own background population _after imputation ########
repInt_decode <- read.delim(file.path(out_dir, "2_5_2_2019-04-10_ReporterIntensityDecode_Extended_Simplified_Final.txt"))
experiments <- unique(repInt_decode$Systemic.ID)
experiments <- experiments[-grep("wt", experiments)]
experiments <- experiments[!is.na(experiments)]
rm(repInt_decode)

df_normalized <- readRDS(file.path(out_dir, "5_5_1_2019-04-12_bpcaImputed_2rep_df.rds"))
df_normalized[df_normalized == 0] <- NA
df_normalized_VP <- df_normalized
# rm(df_normalized)

proteinsIdentified <- dim(df_normalized_VP)[1]
numberOfStrains <- dim(df_normalized_VP)[2]
allCols <- 1:numberOfStrains
wtCols <- grep("wt", colnames(df_normalized_VP))
wttecCols <- grep("WT_Tech", colnames(df_normalized_VP))
wtbiomixCols <- grep("WT_Bio_mix", colnames(df_normalized_VP))
koCols <- setdiff(allCols, c(wtCols,wttecCols, wtbiomixCols))
koCols_ED666 <- grep("ED666", colnames(df_normalized_VP))
koCols_ED668 <- grep("ED668", colnames(df_normalized_VP))



pdf(file.path(out_dir, paste0("5_5_2_", Sys.Date(), "_volcanoPlot_eachKO_bpcaImputed2.pdf")))

for (j in 1:length(experiments)) {
  i <- experiments[j]
  print(j)
  ko_col <- grep(i, names(df_normalized_VP))
  wt_col <- grep("wt", names(df_normalized_VP))
  
  bg_wt <- unique(gsub("(ED[0-9]*)\\-.*", "\\1", names(df_normalized_VP)[ko_col]))
  ko_bg_cols <- setdiff(grep(bg_wt, names(df_normalized_VP)), ko_col)
  
  my_new_df <- data.frame(Mean_wt = apply(df_normalized_VP[,wt_col], 1, mean, na.rm=T),
                          Mean_ko = apply(df_normalized_VP[,ko_col], 1, mean, na.rm=T),
                          Mean_kobg = apply(df_normalized_VP[,ko_bg_cols], 1, mean, na.rm=T))
  
  my_new_df$FoldChange_KOwt <- my_new_df$Mean_ko - my_new_df$Mean_wt
  my_new_df$FoldChange_KObg <- my_new_df$Mean_ko - my_new_df$Mean_kobg
  
  # calculate the p values #
  my_new_df$pValue_KOwt <- NA
  my_new_df$pValue_KObg <- NA
  
  
  my.t.test.p.value <- function(x,y) {
    obj<-try(t.test(x,y), silent=TRUE)
    if (is(obj, "try-error")) return(NA) else return(obj$p.value)
  }
  
  for (k in 1:dim(my_new_df)[1]) {
    my_new_df$pValue_KOwt[k] <- my.t.test.p.value(df_normalized_VP[k,ko_col], df_normalized_VP[k,wt_col])
    my_new_df$pValue_KObg[k] <- my.t.test.p.value(df_normalized_VP[k,ko_col], df_normalized_VP[k,ko_bg_cols])
  }
  
  # volcano plot with corrected p values and fold changes #
  my_new_df$GeneNames <- rownames(my_new_df)
  my_gene_name <- grep(i, my_new_df$GeneNames)
  p1 <- ggplot(my_new_df, aes(x=FoldChange_KOwt, y=-log10(pValue_KOwt)))+
    geom_point()+
    geom_point(data = subset(my_new_df, 
                             pValue_KOwt <= 0.05 & FoldChange_KOwt >= 0.5 | pValue_KOwt <= 0.05 & FoldChange_KOwt <= -0.5), 
               color="red") +
    geom_point(data = subset(my_new_df, GeneNames == my_new_df$GeneNames[my_gene_name]), color="blue") +
    # geom_label_repel(data = subset(my_new_df, 
    #                                pValue_KOwt <= 0.05 & FoldChange_KOwt >= 0.5 | pValue_KOwt <= 0.05 & FoldChange_KOwt <= -0.5), 
    #                  aes(label=GeneNames)) +
    geom_vline(xintercept = 0.5, color="red", alpha=0.3) +
    geom_vline(xintercept = -0.5, color="red", alpha=0.3) +
    geom_hline(yintercept = -log10(0.05), color="red", alpha=0.3) +
    xlab(paste0("log2(",i,"-wt)"))+
    ylab("-log10(p-value)")
  p2 <- ggplot(my_new_df, aes(x=FoldChange_KObg, y=-log10(pValue_KObg)))+
    geom_point()+
    geom_point(data = subset(my_new_df, 
                             pValue_KObg <= 0.05 & FoldChange_KObg >= 0.5 | pValue_KObg <= 0.05 & FoldChange_KObg <= -0.5), 
               color="red") +
    geom_point(data = subset(my_new_df, GeneNames == my_new_df$GeneNames[my_gene_name]), color="blue") +
    # geom_label_repel(data = subset(my_new_df, 
    #                                pValue_KObg <= 0.05 & FoldChange_KObg >= 0.5 | pValue_KObg <= 0.05 & FoldChange_KObg <= -0.5), 
    #                  aes(label=GeneNames)) +
    geom_vline(xintercept = 0.5, color="red", alpha=0.3) +
    geom_vline(xintercept = -0.5, color="red", alpha=0.3) +
    geom_hline(yintercept = -log10(0.05), color="red", alpha=0.3) +
    xlab(paste0("log2(",i,"-",bg_wt,")"))+
    ylab(NULL)
  
  p1_2 <- ggarrange(p1,p2,ncol = 2, nrow=1)
  p1_2 <- annotate_figure(p1_2, top = text_grob(i, size = 14, face="bold"))
  print(p1_2)
  names(my_new_df) <- paste(names(my_new_df), "-", i, sep="")
  my_new_df <- my_new_df[,4:7]
  df_normalized <- as.data.frame(cbind(df_normalized, my_new_df))
}
dev.off()

saveRDS(df_normalized,file.path(out_dir, paste0("5_5_3_", Sys.Date(), "_DiffReg_bpcaImputed2_df.rds")))
rm(df_normalized)
rm(df_normalized_VP)
rm(my_new_df)
rm(p1)
rm(p2)
rm(p1_2)
# 6 # KO detection # screen, proteome - transcriptome replicates #######################################
df_screen <- readRDS("10_3_meltAllInfo_pFDR0665_FPbyCHANCE_filtered.rds")
df_replicate_protein <- readRDS(file.path(out_dir, "5_0_2019-04-11_Data_Colnames_With_WT.rds"))
df_replicate_RNA <- readRDS("3_h_CountPerMil_proteinCoding_384.rds")

decode_screen <- read.delim("7_3_ReporterIntensityDecode_merged_SupTable1.txt")
decode_screen <- decode_screen[,c(5,16)]
df_screen <- merge(df_screen, decode_screen, by.y="Position_MS_Plate", by.x="Strain", all=FALSE)
rm(decode_screen)
saveRDS(df_screen, file.path(out_dir, paste0("6_1_", Sys.Date(), "_df_screen.rds")))

df_replicate_RNA$Gene <- rownames(df_replicate_RNA)
df_replicate_RNA <- melt(df_replicate_RNA, id="Gene")
df_replicate_RNA$Strain <- gsub("p[0-9]\\_(.*)", "\\1", df_replicate_RNA$variable)
df_replicate_RNA$Replicate <- gsub("p([0-9])\\_(.*)", "\\1", df_replicate_RNA$variable)
df_RNA_decode <- read.delim("20181110_finalfinalDecision2pick.txt")
df_RNA_decode$NewPosition <- paste(df_RNA_decode$NewPosition_Row, df_RNA_decode$NewPosition_Column, sep="")
df_RNA_decode <- df_RNA_decode[,c(1,5)]
df_replicate_RNA <- merge(df_replicate_RNA, df_RNA_decode, by.x="Strain", by.y="NewPosition", all=FALSE)
df_replicate_RNA$Sample <- paste(df_replicate_RNA$Systemic.ID, df_replicate_RNA$Replicate, sep="_")
df_replicate_RNA <- df_replicate_RNA[,c(7,3,2,4)]
names(df_replicate_RNA) <- c("Strain", "RNA_Seq_Position", "TargetGene", "log2CPM")
# df_RNA_decode$Systemic.ID %in% df_replicate_RNA$TargetGene
# SPBPB10D8.06c gene is not measured in RNA seq but in ko list
# also not measured at all in the screen or proteome replicates
rm(df_RNA_decode)
saveRDS(df_replicate_RNA, file.path(out_dir, paste0("6_2_", Sys.Date(), "_df_RNA.rds")))

# change the proteinIDs for the replicate protein data
df_ID <- as.data.frame(cbind(rownames(df_replicate_protein), rownames(df_replicate_protein)))
df_ID <- splitColumnBySep(df_ID, "V2")

df_ID$geneID <- gsub("(SP.*\\..*)\\.1\\:pep.*","\\1",df_ID$V2)
df_ID$geneID_length <- nchar(df_ID$geneID)
df_ID <- df_ID[,c(1,3)]

df_ID2 <- df_ID %>%
  group_by(V1) %>%
  dplyr::summarise(text=paste(geneID,collapse=';')) %>%
  as.data.frame()
rm(df_ID)

df_replicate_protein$Proteins <- rownames(df_replicate_protein)

df_replicate_protein <- merge(df_replicate_protein, df_ID2, by.x="Proteins", by.y="V1", all=FALSE)
rm(df_ID2)
rownames(df_replicate_protein) <- df_replicate_protein$text
df_replicate_protein <- df_replicate_protein[,-1]
names(df_replicate_protein)[dim(df_replicate_protein)[2]] <- "TargetProteins"
col2remove <- c(grep("WT_Tech", names(df_replicate_protein)),grep("WT_Bio_mix", names(df_replicate_protein)))
df_replicate_protein <- df_replicate_protein[,-col2remove]
rm(col2remove)

df_replicate_protein <- melt(df_replicate_protein, id="TargetProteins")
names(df_replicate_protein) <- c("TargetProtein", "MS_Position", "NormalizedValue")
df_replicate_protein <- as.data.frame(df_replicate_protein)
df_replicate_protein$KO_gene <- gsub(".*rep[0-9][A-z][0-9]*\\_(.*)\\_[0-9]", "\\1", df_replicate_protein$MS_Position)
saveRDS(df_replicate_protein, file.path(out_dir, paste0("6_3_", Sys.Date(), "_df_replicate_protein.rds")))
rm(df_replicate_protein)
rm(df_replicate_RNA)
# 6.1 # KO detection # in the screen for all ko genes #######################################
df_screen <- readRDS(file.path(out_dir, "6_1_2019-04-15_df_screen.rds"))
koStrains <- unique(df_screen$Systemic.ID)
koStrains <- koStrains[!is.na(koStrains)]


df_screen$Position_ID <- paste(df_screen$Strain, df_screen$Systemic.ID, sep="-")
df_screen <- df_screen[,c(9,2,3)]
df_screen <- dcast(df_screen, Proteins ~ Position_ID)
rownames(df_screen) <- df_screen$Proteins

KOdetectionTable <- data.frame(Systemic.ID=koStrains, MeasuredAll_number=0, Measured_run=FALSE, 
                               Measured_strain = FALSE, 
                               Abundace_mean_all=0, Abundace_min_all=0, Abundace_max_all=0,
                               Abundace_mean_run=0, Abundace_min_run=0, Abundace_max_run=0, 
                               Abundance_ko=0, 
                               Percentile_all=NA, Percentile_run=NA, 
                               Percentile_wt=NA, Percentile_ko=NA)

wt_bio <- grep("WT_Bio", names(df_screen))
koCols <- setdiff(2:dim(df_screen)[2], wt_bio)

for (i in 1:dim(KOdetectionTable)[1]) {
  print(i)
  strain <- KOdetectionTable$Systemic.ID[i]
  rowStrain <- grep(strain, df_screen$Proteins)
  
  if (length(rowStrain) == 1) {
    
    all_vector <- as.vector(df_screen[rowStrain,2:dim(df_screen)[2]])
    all_vector<- all_vector[!is.na(all_vector)]
    
    wt_vector <- as.vector(df_screen[rowStrain,wt_bio])
    wt_vector<- wt_vector[!is.na(wt_vector)]
    
    ko_vector <- as.vector(df_screen[rowStrain,koCols])
    ko_vector<- ko_vector[!is.na(ko_vector)]
    
    KOdetectionTable$MeasuredAll_number[i] <- sum(!is.na(df_screen[rowStrain,]))
    
    MSrun <- gsub("(Sp[0-9]*[A-Z][0-9]*)\\-.*", "\\1", names(df_screen)[grep(strain, names(df_screen))])
    
    MSrun2 <- paste("Sp",gsub("Sp([0-9]*)[A-Z][0-9]*", "\\1", MSrun),
                   "[A-Z]", gsub("Sp[0-9]*[A-Z]([0-9]*)", "\\1", MSrun), sep="")
    MSrun3 <- paste("Sp",gsub("Sp([0-9]*)[A-Z][0-9]*", "\\1", MSrun),
                    "WT_Bio", gsub("Sp[0-9]*[A-Z]([0-9]*)", "\\1", MSrun), sep="")
    
    df_screen_subset <- df_screen[,c(grep(MSrun2, names(df_screen)),grep(MSrun3, names(df_screen)))]
    df_screen_subset <- df_screen_subset[rowSums(is.na(df_screen_subset)) != dim(df_screen_subset)[2],]
    
    if (length(grep(strain, rownames(df_screen_subset)))!=0) {
      KOdetectionTable$Measured_run[i] <- TRUE
    }
    measured_run_row <- grep(strain, rownames(df_screen_subset))
    if (length(measured_run_row)!=0) {
      run_vector <- as.vector(df_screen_subset[measured_run_row,])
      run_vector<- run_vector[!is.na(run_vector)]
      
      KOdetectionTable$Measured_run[i] <- TRUE
      KOdetectionTable$Abundace_mean_run[i] <- mean(t(df_screen_subset[measured_run_row,]), na.rm=TRUE)
      KOdetectionTable$Abundace_min_run[i] <- min(t(df_screen_subset[measured_run_row,]), na.rm=TRUE)
      KOdetectionTable$Abundace_max_run[i] <- max(t(df_screen_subset[measured_run_row,]), na.rm=TRUE)
      
      
      
      if (!is.na(df_screen_subset[measured_run_row, grep(MSrun, names(df_screen_subset))])) {
        ko_value_measured <- df_screen[rowStrain,grep(strain, names(df_screen))]
        KOdetectionTable$Measured_strain[i] <- TRUE
        KOdetectionTable$Abundance_ko[i] <- df_screen_subset[measured_run_row, grep(MSrun, names(df_screen_subset))]
        
        KOdetectionTable$Percentile_all[i] <- 100*ecdf_fun(all_vector, ko_value_measured)
        KOdetectionTable$Percentile_run[i] <- 100*ecdf_fun(run_vector, ko_value_measured)
        KOdetectionTable$Percentile_wt [i] <- 100*ecdf_fun(wt_vector, ko_value_measured)
        KOdetectionTable$Percentile_ko[i] <- 100*ecdf_fun(ko_vector, ko_value_measured)
        
      }
    }
    KOdetectionTable$Abundace_mean_all[i] <- mean(t(df_screen[rowStrain,2:dim(df_screen)[2]]), na.rm=TRUE)
    KOdetectionTable$Abundace_min_all[i] <- min(t(df_screen[rowStrain,2:dim(df_screen)[2]]), na.rm=TRUE)
    KOdetectionTable$Abundace_max_all[i] <- max(t(df_screen[rowStrain,2:dim(df_screen)[2]]), na.rm=TRUE)
  }
}
saveRDS(KOdetectionTable, 
        file.path(out_dir, paste0("6_4_", Sys.Date(), "_KOdetectionTable_normalized_percentile.rds")))


rm(df_screen)
rm(df_screen_subset)
rm(wt_bio)
rm(koStrains)
rm(strain)
rm(rowStrain)
rm(MSrun)
rm(measured_run_row)
rm(MSrun2)
rm(MSrun3)
# KO detection Table - Plots ###
KOdetectionTable <- KOdetectionTable[with(KOdetectionTable, order(-Abundace_mean_all)), ]
KOdetectionTable$Rank <- 1:dim(KOdetectionTable)[1]

jnk <- data.frame(Total=dim(KOdetectionTable)[1],
                  notMeasuredAtAll = sum(KOdetectionTable$MeasuredAll_number==0),
                  MeasuredAtAll = sum(KOdetectionTable$MeasuredAll_number>0),
                  Measured_run = table(KOdetectionTable$Measured_run)[2][[1]],
                  Measured_strain=table(KOdetectionTable$Measured_strain)[2][[1]])

jnk$NotMeasured_run <- jnk$MeasuredAtAll - jnk$Measured_run
jnk <- jnk[,-3]
jnk$NotMeasured_strain <- jnk$Measured_run - jnk$Measured_strain
jnk <- jnk[,c(2,5,6,4)]

jnk <- melt(jnk)
jnk$Type <- "KOlibrary_m90percent"

d <- ggplot(jnk,aes(x=Type, y=value, fill=factor(variable)))+
  geom_bar(stat="identity", position = "stack")+
  geom_text(aes(label=value),size = 5, fontface = "bold", position = position_stack(vjust = 0.5))+
  ggtitle("Distribution of ko-genes by identification status, after filtering")+
  theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
        axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))+
  guides(fill=guide_legend(title=NULL))+
  ylab("Number of proteins") +
  xlab(NULL)

p <- ggplot(data=subset(KOdetectionTable, Measured_run==TRUE), 
            aes(x=Rank, y=Abundace_min_all))+
  geom_point(color="black") +
  geom_point(aes(x=Rank,y=Abundace_min_run), color="blue")+
  geom_point(aes(x=Rank,y=Abundance_ko), color="red")+
  ggtitle("Black=minAll, Blue=minRun, Red=koStrain") +
  theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
        axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))

s <- ggplot(data=subset(KOdetectionTable, Measured_run==TRUE), 
            aes(x=Rank, y=Abundace_min_all))+
  geom_smooth(color="black") +
  geom_smooth(aes(x=Rank,y=Abundace_min_run), color="blue")+
  geom_smooth(aes(x=Rank,y=Abundance_ko), color="red")+
  ggtitle("Black=minAll, Blue=minRun, Red=koStrain")+
  theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
        axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))

his_a <- ggplot(data=subset(KOdetectionTable, Measured_run==TRUE & Measured_strain==TRUE), 
                aes(Percentile_all))+
  geom_histogram(color="black", bins = 100)

his_wt <- ggplot(data=subset(KOdetectionTable, Measured_run==TRUE & Measured_strain==TRUE), 
                 aes(Percentile_wt))+
  geom_histogram(color="black", bins = 100)

perc <- ggplot(data=subset(KOdetectionTable, Measured_run==TRUE & Measured_strain==TRUE), 
               aes(x=Rank, y=Percentile_all))+
  geom_point(aes(color=MeasuredAll_number)) +
  theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
        axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))

perc_2 <- ggplot(data=subset(KOdetectionTable, Measured_run==TRUE & Measured_strain==TRUE), 
                 aes(x=Percentile_wt, y=Percentile_all))+
  geom_point(aes(color=MeasuredAll_number)) +
  theme(plot.title = element_text(lineheight=.8, face="bold", size=16), 
        axis.text=element_text(size=12),
        axis.title=element_text(size=14,face="bold"))

pdf(file.path(out_dir, paste0("6_5_", Sys.Date(), "_KOdetectionTable_Decisions.pdf")))
print(d)
print(p)
print(s)
print(his_a)
print(his_wt)
print(perc)
print(perc_2)
jnk <- dev.off()
rm(d)
rm(his_a)
rm(his_wt)
rm(KOdetectionTable)
rm(p)
rm(perc)
rm(perc_2)
rm(s)
rm(all_vector)
rm(ko_vector)
rm(run_vector)
rm(wt_vector)
# 6.2 # KO detection # for the replicate strains in all the data #################################
df_screen <- readRDS(file.path(out_dir, "6_1_2019-04-15_df_screen.rds"))
df_replicate_RNA <- readRDS(file.path(out_dir, "6_2_2019-04-15_df_RNA.rds"))
df_replicate_protein <- readRDS(file.path(out_dir, "6_3_2019-04-15_df_replicate_protein.rds"))


koStrains <- read.delim("ReplicateStrains96.txt")
koStrains <- unique(koStrains$Systemic.ID)
koStrains <- koStrains[-c(grep("wt", koStrains))]


pdf(file.path(out_dir, paste0("6_6_", Sys.Date(), "_ReplicateStrains_KOdetection.pdf")))
for (i in 1:length(koStrains)) {
  print(i)
  strain <- koStrains[i]
  df_screen_subset <- df_screen[grep(strain, df_screen$Proteins),]
  df_replicate_protein_subset <- df_replicate_protein[grep(strain, df_replicate_protein$TargetProtein),]
  df_replicate_RNA_subset <- df_replicate_RNA[grep(strain, df_replicate_RNA$TargetGene),]
  
  p1 <- ggplot(data=df_replicate_RNA_subset[-grep(strain, df_replicate_RNA_subset$Strain),], aes(x=TargetGene, y=log2CPM))+
    geom_violin() +
    geom_boxplot() +
    geom_point(data=df_replicate_RNA_subset[grep(strain, df_replicate_RNA_subset$Strain),], 
               aes(x=TargetGene, y=log2CPM), color="red", size=4) +
    ggtitle("replicates-transcriptome")
  
  
  p2 <- ggplot(data=df_replicate_protein_subset[-grep(strain, df_replicate_protein_subset$KO_gene),], aes(x=TargetProtein, y=NormalizedValue))+
    geom_violin() +
    geom_boxplot() +
    geom_point(data=df_replicate_protein_subset[grep(strain, df_replicate_protein_subset$KO_gene),], 
               aes(x=TargetProtein, y=NormalizedValue), color="red", size=4)+
    ggtitle("replicates-proteome")
  
  p3 <- ggplot(data=df_screen_subset[-grep(strain, df_screen_subset$Systemic.ID),], aes(x=Proteins, y=NormalizedValue))+
    geom_violin() +
    geom_boxplot() +
    geom_point(data=df_screen_subset[grep(strain, df_screen_subset$Systemic.ID),], 
               aes(x=Proteins, y=NormalizedValue), color="red", size=4) +
    ggtitle("Initial screen")
  
  p1_3 <- ggarrange(p3, p1, p2, ncol=3)
  p1_3 <- annotate_figure(p1_3, top = text_grob(strain, size = 14))
  print(p1_3)
  rm(p1)
  rm(p2)
  rm(p3)
  rm(p1_3)
}
dev.off()
rm(df_screen)
rm(df_screen_subset)
rm(df_replicate_protein)
rm(df_replicate_protein_subset)
rm(df_replicate_RNA)
rm(df_replicate_RNA_subset)

##############################################################################################
# 7 # essential genes recap ############################################################################################
# 7.1 # viability - essentiality #######################################################################################
viability <- read.delim("U:/Merve/AllinAll_Mrv_IMB/Project/SpKOlibrary/Spombe_allInfo_pombase/phenotype/FYPOviability.tsv",
                        header=FALSE)
names(viability) <- c("Strain", "Viability")

koLibrary <- read.delim("7_3_ReporterIntensityDecode_merged_SupTable1.txt")
koLibrary <- subset(koLibrary, Analyzed_ReMeasured == "ToBeAnalyzed")
koLibrary <- koLibrary[,c(16,14)]
koLibrary <- koLibrary[!is.na(koLibrary$Systemic.ID),]
koLibrary <- koLibrary[koLibrary$Systemic.ID != "BLANK",]

koLibrary$mut <- "koLibrary"

viability <- merge(viability, koLibrary, by = 1, all=TRUE)

allStrainsNumber <- dim(viability)[1]
viableStrainsNumber <- sum(viability$Viability=="viable", na.rm=TRUE)
inviableStrainsNumber <- sum(viability$Viability=="inviable", na.rm=TRUE)
conditionStrainsNumber <- sum(viability$Viability=="condition-dependent", na.rm=TRUE)

n25 <- dim(subset(viability, Viability=="viable" & mut == "koLibrary"))[1]
n35 <- dim(subset(viability, Viability=="condition-dependent" & mut == "koLibrary"))[1]
n45 <- dim(subset(viability, Viability=="inviable" & mut == "koLibrary"))[1]
saveRDS(viability, file.path(out_dir,paste0("7_1_", Sys.Date(), "_viability_library.rds")))

# Venn Diagram for strains viability ###
library(VennDiagram)
library(eulerr)
Qvenn <-  draw.quad.venn(viableStrainsNumber, conditionStrainsNumber, inviableStrainsNumber, dim(koLibrary)[1],
                         0, 0, n25, 0, n35, n45, 0, 0, 0, 0, 0, lwd=rep(0,4), cex = rep(2, 15),
                         cat.cex= rep(1.5, 4), alpha = rep(0.3, 4), lty=rep(0,4),
                         category = c("Viable", "ConditionDependent", "Inviable", "koLibrary"),
                         fill=c("#74c476", "#fed98e", "#bd0026", "#ffff99"))
fit <- euler(c(Viable = 335, ConditionDependent=41, Inviable = 1236, koLibrary=3, 
               "koLibrary&Inviable" = 7, "koLibrary&ConditionDependent" = 63, 
               "koLibrary&Viable" = 3235))

eulerr_ <- plot(fit, fill = c("#74c476", "#fed98e", "#bd0026", "#ffff99"), 
                fills = 0.4,counts = TRUE, fill_opacity=0.2, quantities = TRUE)

pdf(file.path(out_dir, paste0("7_2_", Sys.Date(), "_viability_library_Venn.pdf")), width=14)
grid.draw(Qvenn)
print(eulerr_)
dev.off()

rm(eulerr_)
rm(fit)
rm(Qvenn)
rm(koLibrary)
rm(viability)
# 7.2 # essential genes GO #######################################################################################
jnk_gff <- readRDS("2_b_geneType_geneID_ALL.rds")
viability <- readRDS(file.path(out_dir, "7_1_2019-04-15_viability_library.rds"))
viability$mut[303] <- "koLibrary"
viability <- viability[-304,]
saveRDS(viability, file.path(out_dir, paste0("7_1_", Sys.Date(), "_viability_library.rds")))
viability <- merge(viability, jnk_gff, by.x="Strain", by.y="geneID", all=TRUE)
viability <- subset(viability, biotype=="protein_coding")

jnk <- viability[!is.na(viability$Viability),]
jnk <- jnk$Strain[jnk$Viability=="inviable"]


jnk2 <- viability[!is.na(viability$mut),]
jnk2 <- jnk2$Strain[jnk2$mut=="koLibrary"]

write.table(jnk, file.path(out_dir, paste0("7_2_1_", Sys.Date(), "_inviable_Genes.txt")), sep="\t", quote = F, row.names = F, col.names = F)
write.table(jnk2, file.path(out_dir, paste0("7_2_2_", Sys.Date(), "_koLibrary_Genes.txt")), sep="\t", quote = F, row.names = F, col.names = F)
rm(jnk)
rm(jnk2)
rm(jnk_gff)
rm(viability)
# 7.3 # based on "Lethality and centrality of protein networks" by H.Jeong ##########################################
# 7.3.1 # viability vs. number of interaction partners ##############################################################
# pick one of the following with/out 2 hybrid 
## not 2hybrid
Spombe_PPI <- read.delim("U:/Merve/AllinAll_Mrv_IMB/Project/SpKOlibrary/Spombe_allInfo_biogrid/20180510_Spombe_PPI_biogrid_NOTtwoHybrid.txt")
## supported 2 hybrid
Spombe_PPI <- read.delim("U:/Merve/AllinAll_Mrv_IMB/Project/SpKOlibrary/Spombe_allInfo_biogrid/20180510_Spombe_PPI_biogrid_notOnlyTwoHybrid.txt")
## with 2hybrid
Spombe_PPI <- read.delim("U:/Merve/AllinAll_Mrv_IMB/Project/SpKOlibrary/Spombe_allInfo_biogrid/20180510_Spombe_PPI_biogrid_all.txt")
# picked with 2 hybrid
Spombe_PPI <- Spombe_PPI[,1:2]
Spombe_PPI <- Spombe_PPI[grep("^SP.*", Spombe_PPI$INTERACTOR_A),]
Spombe_PPI <- Spombe_PPI[grep("^SP.*", Spombe_PPI$INTERACTOR_B),]

Spombe_PPI_r <- Spombe_PPI[,c(2,1)]
names(Spombe_PPI_r) <- names(Spombe_PPI)
Spombe_PPI <- rbind(Spombe_PPI, Spombe_PPI_r)
Spombe_PPI <- unique(Spombe_PPI)
rm(Spombe_PPI_r)
# pombase interactions
physInteract <- read.delim("U:/Merve/AllinAll_Mrv_IMB/Project/SpKOlibrary/Spombe_allInfo_pombase/Interactions/pombase-go-physical-interactions.tsv.gz", header = F)
physInteract <- physInteract[,1:2]
physInteract_r <- physInteract[,c(2,1)]
names(physInteract_r) <- names(physInteract)
physInteract <- unique(rbind(physInteract, physInteract_r))
rm(physInteract_r)
names(physInteract) <- names(Spombe_PPI)
# combine biogrid and pombase #
Spombe_PPI_reduced <- unique(rbind(Spombe_PPI, physInteract))
rm(Spombe_PPI)
rm(physInteract)
Spombe_PPI_ <- Spombe_PPI_reduced
write.table(Spombe_PPI_, "Spombe_PPI_biogrid_pombase.txt", quote = F, row.names = F, sep="\t")
Spombe_PPI_reduced$value <- 1
Spombe_PPI_reduced <- Spombe_PPI_reduced[,-2]

Spombe_PPI_reduced <- Spombe_PPI_reduced %>% 
  group_by(INTERACTOR_A) %>% 
  summarise_all (funs(sum))
# viability = pombase phenotype 
viability <- read.delim("U:/Merve/AllinAll_Mrv_IMB/Project/SpKOlibrary/Spombe_allInfo_pombase/phenotype/FYPOviability.tsv",
                        header=FALSE)
names(viability) <- c("Strain", "Viability")

viability_PPI <- merge(viability, Spombe_PPI_reduced, by.x="Strain", by.y = "INTERACTOR_A", all=F)

my_comparisons <- list( c("inviable", "viable"), c("inviable", "condition-dependent"), 
                        c("viable", "condition-dependent") )
viability_PPI$Viability <- factor(viability_PPI$Viability,
                                  levels = c('viable','condition-dependent', "inviable"),ordered = TRUE)
p1<-ggplot(viability_PPI, aes(x=Viability, y=value)) +
  geom_boxplot(aes(fill=Viability)) +
  ylab("Number Of Interaction Partners") + 
  xlab(NULL) +
  ggtitle("Proteins with higher number of interaction partners are more likely to be inviable") +
  theme(plot.title = element_text(lineheight=.8, face="bold", size=10), 
        axis.text=element_text(size=14),
        axis.title=element_text(size=14,face="bold"),
        strip.text = element_text(size = 14, face="bold"),
        panel.border = element_blank()) +
  geom_signif(comparisons = my_comparisons, y_position = c(345, 330, 315)) +
  guides(fill=FALSE)

pdf(file.path(out_dir, paste0("7_3_1_", Sys.Date(), "_essentiality_centrality.pdf")))
print(p1)
dev.off()

rm(p1)
rm(my_comparisons)

# viability  being studied ... 
viability_PPI_all <- merge(viability, Spombe_PPI_reduced, by.x="Strain", by.y = "INTERACTOR_A", all.x=T)
viability_jnk <- as.data.frame(c('viable','condition-dependent', "inviable"))
viability_jnk$TotalNA <- c(sum(is.na(viability_PPI_all[viability_PPI_all$Viability=="viable",]$value)),
                           sum(is.na(viability_PPI_all[viability_PPI_all$Viability=="condition-dependent",]$value)),
                           sum(is.na(viability_PPI_all[viability_PPI_all$Viability=="inviable",]$value)))
viability_jnk$NotNA <- c(sum(!is.na(viability_PPI_all[viability_PPI_all$Viability=="viable",]$value)),
                         sum(!is.na(viability_PPI_all[viability_PPI_all$Viability=="condition-dependent",]$value)),
                         sum(!is.na(viability_PPI_all[viability_PPI_all$Viability=="inviable",]$value)))
# keep in mind viability_jnk ###############################################################
# 7.3.2 # genes with most interactions are genes with most genes changing? #####################
Changingtable_Var_Sd <- read.delim("12_3_6_ChangingTable_Variation.txt")

viability_PPI_all_changingTable <- merge(viability_PPI, Changingtable_Var_Sd, 
                                         by.x = "Strain", by.y = "Systemic.ID", all=FALSE)

viability_PPI_all_changingTable <- viability_PPI_all_changingTable[,c(1:3, 25:36)]
viability_PPI_all_changingTable <- viability_PPI_all_changingTable[,-13]
viability_PPI_all_changingTable <- viability_PPI_all_changingTable[,-2]
rownames(viability_PPI_all_changingTable) <- viability_PPI_all_changingTable$Strain
viability_PPI_all_changingTable <- viability_PPI_all_changingTable[,-1]

# correlations
library(corrplot)
library(PerformanceAnalytics)
df_pcor <- viability_PPI_all_changingTable
df_pcor_log <- df_pcor
df_pcor_log$value <- log2(df_pcor_log$value)

df_pcor <- df_pcor[complete.cases(df_pcor),]
df_pcor_log <- df_pcor[complete.cases(df_pcor_log),]

DF_cor<- cor(df_pcor, use="pairwise.complete.obs", method="pearson")
DF_cor_log<- cor(df_pcor_log, use="pairwise.complete.obs", method="pearson")

pdf(file.path(out_dir, paste0("7_3_2_", Sys.Date(), "_Correlation_PPInumber_RegulatedGenesNumber_notCorrelating.pdf")))
corrplot(DF_cor, type = "upper", order = "hclust", 
         tl.col = "black", tl.srt = 45, title="cor")

chart.Correlation(df_pcor, histogram=TRUE, pch=19)

corrplot(DF_cor_log, type = "upper", order = "hclust", 
         tl.col = "black", tl.srt = 45, title="cor")
chart.Correlation(df_pcor_log, histogram=TRUE, pch=19)
dev.off()
rm(Changingtable_Var_Sd)
rm(DF_cor)
rm(DF_cor_log)
rm(df_pcor)
rm(df_pcor_log)
rm(Spombe_PPI_)
rm(Spombe_PPI_reduced)
rm(viability)
rm(viability_jnk)
rm(viability_PPI)
rm(viability_PPI_all)
rm(viability_PPI_all_changingTable)
# 7.3.3 # essential genes varying the most or the least in all the wt and ko measurements ###############
df_normalized <- readRDS(file.path(out_dir, "6_1_2019-04-15_df_screen.rds"))
df_normalized <- df_normalized[,1:3]
df_normalized <- dcast(df_normalized, Proteins ~ Strain)
rownames(df_normalized) <- df_normalized$Proteins
df_normalized <- df_normalized[,-1]
viability <- readRDS(file.path(out_dir, "7_1_2019-04-15_viability_library.rds"))
viability <- as.data.frame(viability[,1:2])

proteinsIdentified <- dim(df_normalized)[1]
numberOfStrains <- dim(df_normalized)[2]
col_WTbio <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
df_normalized <- df_normalized[,1:numberOfStrains]

allCols <- 1:numberOfStrains
wtCols <- grep("Sp[0-9]*WT\\_Bio[0-9]*", colnames(df_normalized))
koCols <- setdiff(allCols, wtCols)

df_normalized$Sd_ko <- apply(df_normalized[,koCols], 1, sd, na.rm=T)
df_normalized$Sd_wt <- apply(df_normalized[,col_WTbio], 1, sd, na.rm=T)
df_normalized$Var_ko <- apply(df_normalized[,koCols], 1, var, na.rm=T)
df_normalized$Var_wt <- apply(df_normalized[,col_WTbio], 1, var, na.rm=T)

df_jnk <- df_normalized[,(numberOfStrains+1):dim(df_normalized)[2]]
df_jnk$Strain <- rownames(df_jnk)
rownames(df_jnk) <- NULL
df_jnk <- splitColumnBySep(df_jnk, "Strain")

df_jnk <- merge(df_jnk, viability, by.x = "Strain", by.y = "Strain", all=F)
pdf(file.path(out_dir, paste0("7_3_3_", Sys.Date(), "_essentiality_vs_variation_Independent.pdf")))
my_comparisons <- list( c("inviable", "viable"), c("inviable", "condition-dependent"), 
                        c("viable", "condition-dependent") )
df_jnk$Viability <- factor(df_jnk$Viability,
                           levels = c('viable','condition-dependent', "inviable"),ordered = TRUE)
p<-ggplot(df_jnk, aes(x=Viability, y=Sd_ko)) +
  geom_boxplot(aes(fill=Viability)) +
  ylab("Standard Deviation in knock-outs") + 
  xlab(NULL) +
  theme(plot.title = element_text(lineheight=.8, face="bold", size=10), 
        axis.text=element_text(size=14),
        axis.title=element_text(size=14,face="bold"),
        strip.text = element_text(size = 14, face="bold"),
        panel.border = element_blank()) +
  geom_signif(comparisons = my_comparisons, y_position = c(0.8,0.77,0.77)) +
  guides(fill=FALSE)
print(p)

p<-ggplot(df_jnk, aes(x=Viability, y=Sd_wt)) +
  geom_boxplot(aes(fill=Viability)) +
  ylab("Standard Deviation in wt") + 
  xlab(NULL) +
  theme(plot.title = element_text(lineheight=.8, face="bold", size=10), 
        axis.text=element_text(size=14),
        axis.title=element_text(size=14,face="bold"),
        strip.text = element_text(size = 14, face="bold"),
        panel.border = element_blank()) +
  geom_signif(comparisons = my_comparisons, y_position = c(1.4,1.35,1.35)) +
  guides(fill=FALSE)
print(p)

# p<-ggplot(df_jnk, aes(x=Viability, y=Var_ko)) +
#   geom_boxplot(aes(fill=Viability)) +
#   ylab("Variation in knock-outs") + 
#   xlab(NULL) +
#   theme(plot.title = element_text(lineheight=.8, face="bold", size=10), 
#         axis.text=element_text(size=14),
#         axis.title=element_text(size=14,face="bold"),
#         strip.text = element_text(size = 14, face="bold"),
#         panel.border = element_blank()) +
#   geom_signif(comparisons = my_comparisons, y_position = c(0.62,0.6,0.6)) +
#   guides(fill=FALSE)
# print(p)
# 
# p<-ggplot(df_jnk, aes(x=Viability, y=Var_wt)) +
#   geom_boxplot(aes(fill=Viability)) +
#   ylab("Variation in wt's") + 
#   xlab(NULL) +
#   theme(plot.title = element_text(lineheight=.8, face="bold", size=10), 
#         axis.text=element_text(size=14),
#         axis.title=element_text(size=14,face="bold"),
#         strip.text = element_text(size = 14, face="bold"),
#         panel.border = element_blank()) +
#   geom_signif(comparisons = my_comparisons, y_position = c(0.04,0.03,0.035)) +
#   guides(fill=FALSE)
# print(p)
dev.off()
rm(my_comparisons)
rm(p)
rm(df_jnk)
rm(df_normalized)
rm(viability)
# 7.3.4 interactors of essential genes have more genes regulated upon ko ##############
# a # interactors of inviable genes are more likely to be inviable and vice versa ######
library(reshape2)
Spombe_PPI_ <- read.delim("Spombe_PPI_biogrid_pombase.txt")
viability <- readRDS(file.path(out_dir, "7_1_2019-04-15_viability_library.rds"))
viability <- as.data.frame(viability[,1:2])

Spombe_PPI_ <- merge(Spombe_PPI_, viability, by=1, all.x = T)
names(Spombe_PPI_)[3] <- "Viability_A"

Spombe_PPI_ <- merge(Spombe_PPI_, viability, by.x = "INTERACTOR_B", by.y="Strain", all.x = T)
names(Spombe_PPI_)[4] <- "Viability_B"

Spombe_PPI_2 <- Spombe_PPI_
Spombe_PPI_2 <- Spombe_PPI_2[!is.na(Spombe_PPI_2$Viability_A),]
Spombe_PPI_2 <- Spombe_PPI_2[!is.na(Spombe_PPI_2$Viability_B),]

jnk <- chisq.test(Spombe_PPI_2$Viability_A, Spombe_PPI_2$Viability_B, correct=FALSE)


p<-ggplot(Spombe_PPI_2, aes(x=Viability_A, fill=Viability_A)) +
  geom_bar() +
  facet_grid(Viability_B ~ .) +
  xlab(NULL) +
  ggtitle("Pearson's Chi-squared test p-value < 2.2e-16") +
  theme(plot.title = element_text(lineheight=.8, face="bold", size=20), 
        axis.text=element_text(size=14),
        axis.title=element_text(size=14,face="bold"),
        strip.text = element_text(size = 14, face="bold")) +
  scale_fill_discrete(guide = 'none')


Spombe_PPI_2_ <- Spombe_PPI_2[,-c(1,2)]
Spombe_PPI_2_$value <- 1
Spombe_PPI_2_d <- dcast(Spombe_PPI_2_, Viability_A ~ Viability_B, fun.aggregate = sum)
rownames(Spombe_PPI_2_d) <- Spombe_PPI_2_d$Viability_A
Spombe_PPI_2_d <- Spombe_PPI_2_d[,-1]
Spombe_PPI_2_d <- as.table(as.matrix(Spombe_PPI_2_d))

pdf(file.path(out_dir, paste0("7_3_4_a_", Sys.Date(), "_PPI_viable-viable_inviable-inviable.pdf")))
print(p)
library(corrplot)
corrplot(jnk$residuals, is.cor = FALSE, title="Chi-squared test residuals")
dev.off()
rm(p)
rm(jnk)
rm(Spombe_PPI_)
rm(Spombe_PPI_2_)
rm(Spombe_PPI_2_d)
rm(viability)
# b #  group the ko strains based on interacting with an essential gene or not ######
Spombe_PPI_2_inviable <- subset(Spombe_PPI_2, Viability_A == "inviable")
Spombe_PPI_2_inviable_viable <- subset(Spombe_PPI_2_inviable, Viability_B != "inviable")
inviable_viable <- as.data.frame(unique(Spombe_PPI_2_inviable_viable$INTERACTOR_B))
inviable_viable$type <- "inviable_viable" 
Spombe_PPI_2_viable <- subset(Spombe_PPI_2, Viability_A == "viable")
Spombe_PPI_2_viable_viable <- subset(Spombe_PPI_2_viable, Viability_B != "inviable")
viable_viable <- unique(Spombe_PPI_2_viable_viable$INTERACTOR_B)
viable_viable <- setdiff(viable_viable, inviable_viable)
viable_viable <- as.data.frame(viable_viable)
viable_viable$type <- "viable_viable" 

names(inviable_viable)[1] <- "Strain"
names(viable_viable)[1] <- "Strain"
Strains <- rbind(inviable_viable, viable_viable)
rm(inviable_viable)
rm(viable_viable)

Changingtable_Var_Sd <- read.delim("12_3_6_ChangingTable_Variation.txt")

Strains <- merge(Strains, Changingtable_Var_Sd, by.x = "Strain", by.y = "Systemic.ID", all=F)
Strains <- Strains[,c(2,24:32, 34:35)]
jnk <- names(Strains)
Strains <- melt(Strains, id="type")
Strains <- as.data.frame(Strains)

pdf(file.path(out_dir, paste0("7_3_4_b_", Sys.Date(), "_ChangesInViablePPIof_inviableORviable.pdf")))
for (i in 2:length(jnk)) {
  df <- subset(Strains, variable == jnk[i])
  p<-ggplot(df, aes(x=type, y=value)) +
    geom_boxplot(aes(fill=type)) +
    ylab(NULL) + 
    xlab(NULL) +
    ggtitle(jnk[i]) +
    theme(plot.title = element_text(lineheight=.8, face="bold", size=10), 
          axis.text=element_text(size=14),
          axis.title=element_text(size=14,face="bold"),
          strip.text = element_text(size = 14, face="bold"),
          panel.border = element_blank()) +
    geom_signif(comparisons = list(c("viable_viable", "inviable_viable"))) +
    guides(fill=FALSE)
  print(p)
}
dev.off()
rm(p)
rm(Spombe_PPI_2_inviable)
rm(Spombe_PPI_2_inviable_viable)
rm(Spombe_PPI_2_viable)
rm(Spombe_PPI_2_viable_viable)
rm(df)
rm(Strains)
# c #  group the ko strains based on percentage of their interaction partners #######
Spombe_PPI_3 <- as.data.frame(table(Spombe_PPI_2[,2:4]))
Spombe_PPI_3 <- Spombe_PPI_3[,c(1,3,4)]
Spombe_PPI_3 <- dcast(Spombe_PPI_3, INTERACTOR_A ~ Viability_B, value.var="Freq", fun.aggregate = sum)
Spombe_PPI_3 <- cbind(Spombe_PPI_3, percentage=Spombe_PPI_3[,2:4]/rowSums(Spombe_PPI_3[,2:4]))

Changingtable_Var_Sd <- read.delim("12_3_6_ChangingTable_Variation.txt")

Strains <- merge(Spombe_PPI_3, Changingtable_Var_Sd, by.x = "INTERACTOR_A", by.y = "Systemic.ID", all=F)

Strains <- Strains[,c(1:7,29:37, 39:40)]
jnk <- names(Strains)


p1<-ggplot(Strains, aes(x=100*percentage.inviable, y=minMax_up)) +
    geom_point() +
    ylab("Number OF Genes Targeted") + 
    xlab("Interaction% == Inviable") +
    ggtitle(paste("minMax_up ", round(cor(Strains$percentage.inviable, Strains$minMax_up),2))) 

p2<-ggplot(Strains, aes(x=100*percentage.inviable, y=minMax_down)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("Interaction% == Inviable") +
  ggtitle(paste("minMax_down ", round(cor(Strains$percentage.inviable, Strains$minMax_down),2))) 

p3<-ggplot(Strains, aes(x=100*percentage.inviable, y=minMax_changing)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("Interaction% == Inviable") +
  ggtitle(paste("minMax_changing ", round(cor(Strains$percentage.inviable, Strains$minMax_changing),2))) 

p4<-ggplot(Strains, aes(x=100*percentage.inviable, y=sd3_up)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("Interaction% == Inviable") +
  ggtitle(paste("sd3_up ", round(cor(Strains$percentage.inviable, Strains$sd3_up),2))) 

p5<-ggplot(Strains, aes(x=100*percentage.inviable, y=sd3_down)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("Interaction% == Inviable") +
  ggtitle(paste("sd3_down ", round(cor(Strains$percentage.inviable, Strains$sd3_down),2))) 

p6<-ggplot(Strains, aes(x=100*percentage.inviable, y=sd3_changing)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("Interaction% == Inviable") +
  ggtitle(paste("sd3_changing ", round(cor(Strains$percentage.inviable, Strains$sd3_changing),2))) 

p7<-ggplot(Strains, aes(x=100*percentage.inviable, y=wt99_up)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("Interaction% == Inviable") +
  ggtitle(paste("wt99_up ", round(cor(Strains$percentage.inviable, Strains$wt99_up),2))) 

p8<-ggplot(Strains, aes(x=100*percentage.inviable, y=wt99_down)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("Interaction% == Inviable") +
  ggtitle(paste("wt99_down ", round(cor(Strains$percentage.inviable, Strains$wt99_down),2))) 

p9<-ggplot(Strains, aes(x=100*percentage.inviable, y=wt99_changing)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("Interaction% == Inviable") +
  ggtitle(paste("wt99_changing ", round(cor(Strains$percentage.inviable, Strains$wt99_changing),2))) 

p1_9 <- ggarrange(p1,p2,p3,p4,p5,p6,p7,p8,p9, ncol=3, nrow=3)

pdf(file.path(out_dir, paste0("7_3_4_c_", Sys.Date(), "_ChangesvsInviablePPI.pdf")), height = 8, width = 8)
print(p1_9)
dev.off()
rm(Changingtable_Var_Sd)
rm(p1)
rm(p2)
rm(p3)
rm(p4)
rm(p5)
rm(p6)
rm(p7)
rm(p8)
rm(p9)
rm(p1_9)
rm(Spombe_PPI_2)
rm(Spombe_PPI_3)
rm(Strains)
# d #  group the ko strains based on number of their interaction partners #######
Spombe_PPI_ <- read.delim("Spombe_PPI_biogrid_pombase.txt")
viability <- readRDS(file.path(out_dir, "7_1_2019-04-15_viability_library.rds"))
viability <- as.data.frame(viability[,1:2])

Spombe_PPI_ <- merge(Spombe_PPI_, viability, by=1, all.x = T)
names(Spombe_PPI_)[3] <- "Viability_A"

Spombe_PPI_ <- merge(Spombe_PPI_, viability, by.x = "INTERACTOR_B", by.y="Strain", all.x = T)
names(Spombe_PPI_)[4] <- "Viability_B"

Spombe_PPI_2 <- Spombe_PPI_
Spombe_PPI_2 <- Spombe_PPI_2[!is.na(Spombe_PPI_2$Viability_A),]
Spombe_PPI_2 <- Spombe_PPI_2[!is.na(Spombe_PPI_2$Viability_B),]

Spombe_PPI_3 <- as.data.frame(table(Spombe_PPI_2[,2:4]))
Spombe_PPI_3 <- Spombe_PPI_3[,c(1,3,4)]
Spombe_PPI_3 <- dcast(Spombe_PPI_3, INTERACTOR_A ~ Viability_B, value.var="Freq", fun.aggregate = sum)

Changingtable_Var_Sd <- read.delim("12_3_6_ChangingTable_Variation.txt")

Strains <- merge(Spombe_PPI_3, Changingtable_Var_Sd, by.x = "INTERACTOR_A", by.y = "Systemic.ID", all=F)

Strains <- Strains[,c(1:7,29:37, 39:40)]

p1<-ggplot(Strains, aes(x=inviable, y=minMax_up)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("#Interaction == Inviable") +
  ggtitle(paste("minMax_up ", round(cor(Strains$inviable, Strains$minMax_up),2))) 

p2<-ggplot(Strains, aes(x=inviable, y=minMax_down)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("#Interaction == Inviable") +
  ggtitle(paste("minMax_down ", round(cor(Strains$inviable, Strains$minMax_down),2))) 

p3<-ggplot(Strains, aes(x=inviable, y=minMax_changing)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("#Interaction == Inviable") +
  ggtitle(paste("minMax_changing ", round(cor(Strains$inviable, Strains$minMax_changing),2))) 

p4<-ggplot(Strains, aes(x=inviable, y=sd3_up)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("#Interaction == Inviable") +
  ggtitle(paste("sd3_up ", round(cor(Strains$inviable, Strains$sd3_up),2))) 

p5<-ggplot(Strains, aes(x=inviable, y=sd3_down)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("#Interaction == Inviable") +
  ggtitle(paste("sd3_down ", round(cor(Strains$inviable, Strains$sd3_down),2))) 

p6<-ggplot(Strains, aes(x=inviable, y=sd3_changing)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("#Interaction == Inviable") +
  ggtitle(paste("sd3_changing ", round(cor(Strains$inviable, Strains$sd3_changing),2))) 

p7<-ggplot(Strains, aes(x=inviable, y=wt99_up)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("#Interaction == Inviable") +
  ggtitle(paste("wt99_up ", round(cor(Strains$inviable, Strains$wt99_up),2))) 

p8<-ggplot(Strains, aes(x=inviable, y=wt99_down)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("#Interaction == Inviable") +
  ggtitle(paste("wt99_down ", round(cor(Strains$inviable, Strains$wt99_down),2))) 

p9<-ggplot(Strains, aes(x=inviable, y=wt99_changing)) +
  geom_point() +
  ylab("Number OF Genes Targeted") + 
  xlab("#Interaction == Inviable") +
  ggtitle(paste("wt99_changing ", round(cor(Strains$inviable, Strains$wt99_changing),2))) 

p1_9 <- ggarrange(p1,p2,p3,p4,p5,p6,p7,p8,p9, ncol=3, nrow=3)

pdf(file.path(out_dir, paste0("7_3_4_d_", Sys.Date(), "_ChangesvsInviablePPInumber.pdf")), height = 8, width = 8)
print(p1_9)
dev.off()
rm(Changingtable_Var_Sd)
rm(p1)
rm(p2)
rm(p3)
rm(p4)
rm(p5)
rm(p6)
rm(p7)
rm(p8)
rm(p9)
rm(p1_9)
rm(Spombe_PPI_2)
rm(Spombe_PPI_3)
rm(Strains)
# e #  group the ko strains based on number of their interaction partners #######
Spombe_PPI_ <- read.delim("Spombe_PPI_biogrid_pombase.txt")
Spombe_PPI_ <- merge(Spombe_PPI_, viability, by=1, all.x = T)
names(Spombe_PPI_)[3] <- "Viability_A"

Spombe_PPI_ <- merge(Spombe_PPI_, viability, by.x = "INTERACTOR_B", by.y="Strain", all.x = T)
names(Spombe_PPI_)[4] <- "Viability_B"

Spombe_PPI_2 <- Spombe_PPI_
Spombe_PPI_2 <- Spombe_PPI_2[!is.na(Spombe_PPI_2$Viability_A),]
Spombe_PPI_2 <- Spombe_PPI_2[!is.na(Spombe_PPI_2$Viability_B),]

Spombe_PPI_3 <- as.data.frame(table(Spombe_PPI_2[,2:4]))
Spombe_PPI_3 <- Spombe_PPI_3[,c(1,3,4)]
Spombe_PPI_3 <- dcast(Spombe_PPI_3, INTERACTOR_A ~ Viability_B, value.var="Freq", fun.aggregate = sum)


df_screen <- readRDS(file.path(out_dir, "6_1_2019-04-15_df_screen.rds"))
viability <- readRDS(file.path(out_dir, "7_1_2019-04-15_viability_library.rds"))
viability <- as.data.frame(viability[,1:2])

df_screen <- merge(df_screen, viability, by.x="Proteins", by.y="Strain", all=FALSE)
df_screen <- df_screen[rowSums(is.na(df_screen))==0,]
df_screen <- as.data.frame(subset(df_screen, abs(FC)>=0.5 & pvalue_FDR<=0.05))

new_df <- data.frame(Strain=unique(df_screen$Systemic.ID),
                     NumberRegulating=NA, NumberRegulatingInviable=NA)
for (i in 1:dim(new_df)[1]) {
  print(i)
  df_screen_subset <- as.data.frame(subset(df_screen, Systemic.ID==new_df$Strain[i]))
  new_df$NumberRegulating[i] <- dim(df_screen_subset)[1]
  new_df$NumberRegulatingInviable[i] <- sum(df_screen_subset$Viability=="inviable")
}

new_df <- merge(new_df, Spombe_PPI_3, by.x="Strain", by.y="INTERACTOR_A", all.x=TRUE)
new_df$numberOfPPI <- rowSums(new_df[,4:6], na.rm=TRUE)

p1<-ggplot(new_df, aes(x=NumberRegulating, y=NumberRegulatingInviable)) +
  geom_point() +
  xlab("Number OF Genes Targeted") + 
  ylab("Number OF Essential Genes Targeted") +
  ggtitle(paste("cor: ", round(cor(new_df$NumberRegulating, new_df$NumberRegulatingInviable,
                                   use="pairwise.complete.obs", method="pearson"),2))) 

p2<-ggplot(new_df, aes(x=inviable, y=NumberRegulatingInviable)) +
  geom_point() +
  ylab("Number OF Essential Genes Targeted") + 
  xlab("Number OF Essential PPI") +
  ggtitle(paste("cor: ", round(cor(new_df$inviable, new_df$NumberRegulatingInviable,
                                   use="pairwise.complete.obs", method="pearson"),2))) 

# correlations
df_pcor <- new_df[,2:7]
df_pcor <- df_pcor[complete.cases(df_pcor),]
DF_cor<- cor(df_pcor, use="pairwise.complete.obs", method="pearson")

pdf(file.path(out_dir, paste0("7_3_4_e_", Sys.Date(), "_TargetingEssentialGene.pdf")), height = 8, width = 8)
print(p1)
print(p2)
corrplot(DF_cor, type = "upper", order = "hclust", 
         tl.col = "black", tl.srt = 45, title="cor")

chart.Correlation(df_pcor, histogram=TRUE, pch=19)
dev.off()

rm(p1)
rm(p2)
rm(Spombe_PPI_2)
rm(Spombe_PPI_3)
rm(DF_cor)
rm(df_pcor)
rm(df_screen)
rm(df_screen_subset)
rm(jnk)
rm(new_df)
rm(Spombe_PPI_)
rm(viability)


if(cytoscape){
# 8 #  protein correlations cytoscape safe ######################################################################################
# 8.1 # protein correlations based on z-score, significant to cytoscape with annotations for SAFE ######
pc_z <- readRDS("C:/Users/moeztuer/Desktop/_analysis/20181022_reAnalysis/20181022_WTbio_filtered/20190226_19_myNetworkInference/19_2_pc_z.rds")
pc_z$p_ko_FDR <- p.adjust(pc_z$p_ko, method = "fdr", n = length(pc_z$p_ko))
pc_z_significant <- subset(pc_z, p_ko_FDR <= 0.05 & abs(cor_ko)>=0.7)
pc_z_significant <- pc_z_significant[,c(7,4,8)]
pc_z_significant <- pc_z_significant[pc_z_significant$Protein1 != pc_z_significant$Protein2,]

write.table(pc_z_significant, 
            file.path(out_dir, paste0("8_1_1_", Sys.Date(), "_pc_z_significant.txt")),
            quote = F, row.names = F, col.names = F, sep="\t")

write.table(pc_z_significant[,c(1,3)], 
            paste0("8_1_2_", Sys.Date(), "_pc_z_significant.txt"),
            quote = F, row.names = F, col.names = F, sep="\t")

write.table(unique(c(pc_z_significant$Protein1, pc_z_significant$Protein2)), 
            paste0("8_1_1_", Sys.Date(), "_listNodes.txt"),
            quote = F, row.names = F, col.names = F, sep="\t")
# 8.2 # gaf to txt files ######################################################################
setwd("C:/Users/moeztuer/Desktop/cytoscapeTest")
pombe <- read.delim("pombase.gaf", skip=42, header=FALSE)
cerevisiae <- read.delim("go_bp_140819.txt")

pombe_P <- subset(pombe, V9=="P")
pombe_F <- subset(pombe, V9=="F")
pombe_C <- subset(pombe, V9=="C")

pombe2 <- pombe_P[,c(2,5)]
pombe2$value <- 1
pombe2 <- dcast(pombe2, V2 ~ V5)
rownames(pombe2) <- pombe2$V2
pombe2 <- pombe2[,-1]
pombe2[pombe2>0] <- 1
pombe2$ORF <- rownames(pombe2)
pombe2 <- pombe2[,c(dim(pombe2)[2], 1:(dim(pombe2)[2]-1))]

write.table(pombe2, "pombase_GO_5_BP.txt", quote = F, row.names = F, col.names = T, sep="\t")

pombe2 <- pombe_F[,c(2,5)]
pombe2$value <- 1
pombe2 <- dcast(pombe2, V2 ~ V5)
rownames(pombe2) <- pombe2$V2
pombe2 <- pombe2[,-1]
pombe2[pombe2>0] <- 1
pombe2$ORF <- rownames(pombe2)
pombe2 <- pombe2[,c(dim(pombe2)[2], 1:(dim(pombe2)[2]-1))]

write.table(pombe2, "pombase_GO_5_MF.txt", quote = F, row.names = F, col.names = T, sep="\t")


pombe2 <- pombe_C[,c(2,5)]
pombe2$value <- 1
pombe2 <- dcast(pombe2, V2 ~ V5)
rownames(pombe2) <- pombe2$V2
pombe2 <- pombe2[,-1]
pombe2[pombe2>0] <- 1
pombe2$ORF <- rownames(pombe2)
pombe2 <- pombe2[,c(dim(pombe2)[2], 1:(dim(pombe2)[2]-1))]
write.table(pombe2, "pombase_GO_5_CC.txt", quote = F, row.names = F, col.names = T, sep="\t")

jnk <- read.delim("20190418_GO0015074.txt-neighborhood_scores_annotation-highest.txt", skip=3)
jnk2 <- melt(jnk, "name")
jnk3 <- jnk2 %>%
  group_by(variable) %>%
  dplyr::mutate(termValue=sum(value)) %>%
  as.data.frame()

jnk3 <- subset(jnk3, termValue > 0)
jnk3 <- subset(jnk3, value > 0)

jnk4 <- unique(jnk3[,c(2,4)])

# jnk4 <- as.data.frame(table(jnk3$variable))
# jnk4 <- jnk4[jnk4$Freq!=0,]
# jnk3 <- jnk3[jnk3$variable %in% jnk4$Var1,]







# 8.3 # check strain protein correlation significant ones ################################
pc_z <- readRDS("C:/Users/moeztuer/Desktop/_analysis/20181022_reAnalysis/20181022_WTbio_filtered/20190226_19_myNetworkInference/19_2_all_protein_pairs_final.rds")
pc_both <- subset(pc_z, Protein1_ko_available == TRUE & Protein2_ko_available == TRUE & Protein1_measured == TRUE & Protein2_measured == TRUE)
}
if(mnem){
  # failed to install because of R tools 
  library(devtools)
  # install_github("cbg-ethz/mnem")
  library(mnem)
  
  
  
  
}
if(aracne){
  library(minet)
  library(reshape2)
  pc_z <- readRDS("C:/Users/moeztuer/Desktop/_analysis/20181022_reAnalysis/20181022_WTbio_filtered/20190226_19_myNetworkInference/19_2_pc_z.rds")
  pc_z <- pc_z[,4:8]
  pc_z$p_ko_FDR <- p.adjust(pc_z$p_ko, method = "fdr", n = length(pc_z$p_ko))
  pc_z$cor_ko[pc_z$p_ko_FDR > 0.05] <- 0
  pc <- pc_z[,c(4,5,1)]
  pc <- dcast(pc, Protein1 ~ Protein2)
  rownames(pc) <- pc$Protein1
  pc <- pc[,-1]
  pcm <- as.matrix(pc)
  pcm_mim_spearman <- build.mim(pcm, estimator = "spearman", disc = "none", nbins = sqrt(NROW(pcm)))
  saveRDS(pcm_mim_spearman, file.path(out_dir, "_test_pcm_mim_spearman.rds"))
  pcm_mim_spearman_net <- aracne(pcm_mim_spearman)
  saveRDS(pcm_mim_spearman_net, file.path(out_dir, "_test_pcm_mim_spearman_net.rds"))

  pcm_net <- aracne(pcm)
  saveRDS(pcm_net, file.path(out_dir, "_test_pcm_net.rds"))
  
  pcm_net_melt <- as.data.frame(pcm_net)
  pcm_net_melt$Protein1 <- rownames(pcm_net_melt)
  pcm_net_melt <- melt(pcm_net_melt)
  names(pcm_net_melt) <- c("Protein1", "Protein2", "Link")
  pcm_net_melt <- subset(pcm_net_melt, Protein1 != Protein2)
  pcm_net_melt <- subset(pcm_net_melt, Link != 0)
  pcm_net_melt$Node <- pcm_net_melt$Protein1
  write.table(pcm_net_melt, 
              file.path(out_dir, paste0("_test_", Sys.Date(), "_significant_links.txt")),
              quote = F, row.names = F, col.names = F, sep="\t")
  
  library(viper)

  regul <- aracne2regulon(adjfile, dset, verbose = FALSE)
  
  
  
  
}
###################
# 7 # Assess TP/FP/TN/FN  of the screen with the replicates # NEW ##########################
df_screen <- readRDS("10_3_meltAllInfo_pFDR0665_FPbyCHANCE_filtered.rds")
df_replicate_Imputed <- readRDS(file.path(out_dir, "5_5_3_2019-04-12_DiffReg_bpcaImputed2_df.rds"))
# df_replicate_RNA <- readRDS("3_h_CountPerMil_proteinCoding_384.rds")


###################################################################
# Left here ##################
}

